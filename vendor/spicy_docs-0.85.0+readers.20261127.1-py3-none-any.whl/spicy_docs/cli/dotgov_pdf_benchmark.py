"""External-cache benchmark over the Library of Congress Labs ``dot-gov`` ``pdf_data`` package.

Pins ``dotgov_pdf_metadata.csv`` (529,455 bytes, Latin-1 encoded, 17 CDX + Apache Tika + BagIt columns)
and ``manifest.json`` by SHA-256 while keeping all binary PDFs in an external local cache outside Git.

Dataset provenance and scope (``https://data.labs.loc.gov/dot-gov/``, ``pdf_data/README.txt``):
- **Rights statement:** Derived from the Library of Congress Web Archive. LoC describes a notification
  and permission process for web-archive acquisition and researcher access across archived ``.gov`` sites
  rather than a blanket public-domain certification of every embedded work.
- **Oracle scope:** ``metadata.csv`` supplies ``pages`` from Apache Tika (987 positive integers and 13
  ``"-"`` rows where Tika recorded no page count; zero ``"0"`` rows), ``original`` capture URL, ``digest``
  (CDX Base32 SHA-1), ``file_size`` (CDX HTTP header ``Content-Length`` when present, which can exceed the
  captured WARC payload on truncated crawls), and BagIt ``sha256`` / ``sha512``. It supplies **no**
  empty-page or OCR-routing ground-truth labels: page-count agreement is scored against the 987 numeric
  Tika rows, the 13 ``"-"`` rows are characterized separately, reader text-yield / ``NativeOrOcr`` signals
  are reported as corpus distributions, and OCR-routing accuracy is scored only when a separately reviewed
  page-label manifest (``--ocr-sample-labels``) is supplied.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import csv
import hashlib
import http.client
import io
import json
import os
import posixpath
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urljoin, urlsplit

DOTGOV_PDF_PACKAGE_URL = "https://data.labs.loc.gov/dot-gov/pdf_data/"
DOTGOV_ALLOWED_HOST = "data.labs.loc.gov"
DOTGOV_ALLOWED_PATH_PREFIX = "/dot-gov/pdf_data/"

#: SHA-256 and byte length of LoC's published ``pdf_data/metadata.csv`` (updated 2024-06-11).
DOTGOV_PDF_METADATA_SHA256 = "4d01a08335380c61e9d460108bbb8a6ae61fc635b407f15506e2004851c89fed"
DOTGOV_PDF_METADATA_BYTES = 529_455

#: SHA-256 and byte length of LoC's published ``pdf_data/manifest.json``.
DOTGOV_PDF_MANIFEST_SHA256 = "473a9334d8e66bfd9f70756920224c6c4cee104f0343abe94b816d0caf884de6"
DOTGOV_PDF_MANIFEST_BYTES = 201_887

DOTGOV_RIGHTS_SUMMARY = (
    "Derived from the Library of Congress Web Archive under LoC's notification-and-permission process "
    "for web-archive acquisition and researcher access across archived .gov sites (not a blanket "
    "public-domain claim; see https://data.labs.loc.gov/dot-gov/ and pdf_data/README.txt Section V)."
)

DOTGOV_METADATA_COLUMNS: tuple[str, ...] = (
    "urlkey",
    "timestamp",
    "original",
    "mimetype",
    "statuscode",
    "digest",
    "pdf_version",
    "creator_tool",
    "producer",
    "date_created",
    "pages",
    "page_width",
    "page_height",
    "surface_area",
    "file_size",
    "sha256",
    "sha512",
)

DOTGOV_MANIFEST_COLUMNS: tuple[str, ...] = ("filename", "item_id", "md5", "size", "object_key")

DEFAULT_MAX_INPUT_BYTES = 64 * 1024**2
BENCHMARK_MAX_INPUT_BYTES = 128 * 1024**2
MAX_DOWNLOAD_CONCURRENCY = 4
USER_AGENT = "spicy-docs-dotgov-pdf-benchmark/1.0"

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_SHA512_RE = re.compile(r"^[0-9a-f]{128}$")
_MD5_RE = re.compile(r"^[0-9a-f]{32}$")
_CDX_DIGEST_RE = re.compile(r"^[A-Z2-7]{32}$")
_DECIMAL_RE = re.compile(r"^[0-9]+$")
_CHALLENGE_MARKERS = (
    b"<!doctype html",
    b"<html",
    b"just a moment",
    b"cf-browser-verification",
    b"challenge-platform",
    b"turnstile",
    b"g-recaptcha",
    b"hcaptcha",
)


class DotGovBenchmarkError(ValueError):
    """Manifest, containment, cache-integrity, or benchmark-configuration refusal."""


class DotGovDownloadBlockedError(RuntimeError):
    """Immediate stop on HTTP 401/403/429, Retry-After, Cloudflare mitigation, or unexpected HTML/challenge."""


@dataclass(frozen=True, slots=True)
class DotGovPdfEntry:
    """One validated row from ``dotgov_pdf_metadata.csv`` optionally enriched with ``manifest.json`` object facts."""

    row_number: int
    urlkey: str
    timestamp: str
    original: str
    original_host: str | None
    mimetype: str
    statuscode: str
    digest: str
    pdf_version: str | None
    creator_tool: str | None
    producer: str | None
    date_created: str | None
    tika_pages: int | None
    page_width: str | None
    page_height: str | None
    surface_area: str | None
    declared_file_size: int
    sha256: str
    sha512: str
    object_byte_size: int | None = None
    object_md5: str | None = None
    object_url: str | None = None

    def resolved_url(self, package_url: str = DOTGOV_PDF_PACKAGE_URL) -> str:
        if self.object_url is not None:
            return self.object_url
        base = package_url if package_url.endswith("/") else f"{package_url}/"
        return _check_allowed_url(f"{base}data/{self.digest}.pdf")


@dataclass(frozen=True, slots=True)
class DotGovPackageFile:
    """One validated PDF entry in ``pdf_data/manifest.json``."""

    filename: str
    item_id: str
    md5: str
    size: int
    object_key: str
    url: str


@dataclass(frozen=True, slots=True)
class OcrSampleLabel:
    """One separately reviewed page-level OCR-routing expectation."""

    sha256: str
    page: int
    expected_route_ocr: bool
    category: str
    note: str


def _optional_dash(value: str) -> str | None:
    return None if value == "-" else value


def _check_sha256(value: str, label: str = "sha256") -> str:
    normalized = value.strip().lower() if isinstance(value, str) else ""
    if _SHA256_RE.fullmatch(normalized) is None:
        raise DotGovBenchmarkError(f"invalid {label}: expected 64 lowercase hex characters")
    return normalized


def _check_allowed_url(url: str) -> str:
    parts = urlsplit(url)
    raw_lower = parts.path.lower()
    decoded = unquote(parts.path)
    normalized = posixpath.normpath(decoded) if decoded else ""
    if decoded.endswith("/") and not normalized.endswith("/"):
        normalized += "/"
    if (
        parts.scheme != "https"
        or parts.netloc != DOTGOV_ALLOWED_HOST
        or parts.query
        or parts.fragment
        or "%2f" in raw_lower
        or "%5c" in raw_lower
        or "\\" in decoded
        or "\x00" in decoded
        or unquote(decoded) != decoded
        or normalized != parts.path
        or not normalized.startswith(DOTGOV_ALLOWED_PATH_PREFIX)
        or any(seg in {".", ".."} for seg in decoded.split("/"))
    ):
        raise DotGovBenchmarkError(f"URL outside allowed LoC dot-gov pdf_data origin: {url!r}")
    return url


def contained_cache_path(cache_dir: Path, *parts: str) -> Path:
    """Resolve ``cache_dir / parts`` while refusing symlinks and path traversal."""
    if not parts or any(not part or part in {".", ".."} or "/" in part or "\\" in part for part in parts):
        raise DotGovBenchmarkError(f"invalid relative cache path parts: {parts!r}")
    root = cache_dir.resolve()
    current = cache_dir
    if current.exists() and current.is_symlink():
        raise DotGovBenchmarkError(f"cache root must not be a symlink: {cache_dir}")
    for part in parts:
        current = current / part
        if current.is_symlink():
            raise DotGovBenchmarkError(f"refusing symlink inside external PDF cache: {current}")
    resolved = current.resolve()
    if not resolved.is_relative_to(root):
        raise DotGovBenchmarkError(f"cache path escapes root {root}: {resolved}")
    return resolved


def pdf_cache_path(cache_dir: Path, sha256: str) -> Path:
    """Canonical content-addressed cache location ``<cache_dir>/pdfs/<sha256>.pdf``."""
    checked = _check_sha256(sha256)
    return contained_cache_path(cache_dir, "pdfs", f"{checked}.pdf")


@contextlib.contextmanager
def _exclusive_temp_file(parent: Path, prefix: str):
    """Create and yield an open exclusive temporary file ``(handle, tmp_path)`` inside ``parent`` honoring umask."""
    if parent.is_symlink():
        raise DotGovBenchmarkError(f"refusing symlink directory for atomic write: {parent}")
    parent.mkdir(parents=True, exist_ok=True)
    if parent.is_symlink():
        raise DotGovBenchmarkError(f"refusing symlink directory for atomic write: {parent}")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    for _ in range(16):
        candidate = parent / f"{prefix}{secrets.token_hex(8)}"
        try:
            fd = os.open(candidate, flags, 0o666)
        except FileExistsError:
            continue
        with os.fdopen(fd, "wb") as handle:
            yield handle, candidate
        return
    raise DotGovBenchmarkError(f"could not allocate exclusive temporary file in {parent}")


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Write ``data`` via an exclusively created sibling temporary file and replace ``path`` atomically."""
    if path.is_symlink():
        raise DotGovBenchmarkError(f"refusing to overwrite symlink: {path}")
    tmp: Path | None = None
    try:
        with _exclusive_temp_file(path.parent, f".{path.name}.tmp.") as (handle, tmp_path):
            tmp = tmp_path
            handle.write(data)
        os.replace(tmp, path)
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink(missing_ok=True)


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    atomic_write_bytes(path, (json.dumps(payload, indent=2, sort_keys=False) + "\n").encode("utf-8"))


def read_dotgov_package_manifest(
    manifest_path: Path,
    *,
    expected_sha256: str | None = DOTGOV_PDF_MANIFEST_SHA256,
) -> tuple[str, dict[str, DotGovPackageFile]]:
    """Read and validate ``pdf_data/manifest.json`` against its pinned SHA-256."""
    raw = manifest_path.read_bytes()
    actual_sha256 = hashlib.sha256(raw).hexdigest()
    if expected_sha256 is not None:
        pinned = _check_sha256(expected_sha256, "expected_manifest_sha256")
        if actual_sha256 != pinned:
            raise DotGovBenchmarkError(f"manifest.json sha256 mismatch: expected {pinned}, got {actual_sha256}")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise DotGovBenchmarkError(f"manifest.json is not valid UTF-8 JSON: {error}") from error
    if not isinstance(payload, dict):
        raise DotGovBenchmarkError("manifest.json root must be a JSON object")
    cols = payload.get("cols")
    rows = payload.get("rows")
    if not isinstance(cols, list) or tuple(cols) != DOTGOV_MANIFEST_COLUMNS:
        raise DotGovBenchmarkError(f"manifest.json cols mismatch: expected {list(DOTGOV_MANIFEST_COLUMNS)}")
    if not isinstance(rows, list) or not rows:
        raise DotGovBenchmarkError("manifest.json rows must be a nonempty list")
    files_by_digest: dict[str, DotGovPackageFile] = {}
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, list) or len(row) != len(DOTGOV_MANIFEST_COLUMNS):
            raise DotGovBenchmarkError(f"manifest.json row {index} does not match column count")
        filename, item_id, md5, size, object_key = row
        if not all(isinstance(v, str) and v for v in (filename, item_id, md5, object_key)):
            raise DotGovBenchmarkError(f"manifest.json row {index} has invalid string fields")
        if type(size) is not int or size < 0:
            raise DotGovBenchmarkError(f"manifest.json row {index} size must be a nonnegative integer")
        md5_norm = md5.lower()
        if _MD5_RE.fullmatch(md5_norm) is None:
            raise DotGovBenchmarkError(f"manifest.json row {index} has invalid md5")
        url = _check_allowed_url(f"https://{object_key}")
        if not filename.endswith(".pdf"):
            continue
        if _CDX_DIGEST_RE.fullmatch(item_id) is None or filename != f"{item_id}.pdf":
            raise DotGovBenchmarkError(f"manifest.json row {index} PDF filename/item_id mismatch: {filename!r}")
        if not object_key.endswith(f"/data/{filename}"):
            raise DotGovBenchmarkError(f"manifest.json row {index} unexpected object_key: {object_key!r}")
        if item_id in files_by_digest:
            raise DotGovBenchmarkError(f"manifest.json repeats digest {item_id}")
        files_by_digest[item_id] = DotGovPackageFile(
            filename=filename,
            item_id=item_id,
            md5=md5_norm,
            size=size,
            object_key=object_key,
            url=url,
        )
    if not files_by_digest:
        raise DotGovBenchmarkError("manifest.json contained zero PDF entries")
    return actual_sha256, files_by_digest


def read_dotgov_metadata_csv(
    metadata_path: Path,
    *,
    expected_sha256: str | None = DOTGOV_PDF_METADATA_SHA256,
    manifest_files: Mapping[str, DotGovPackageFile] | None = None,
) -> tuple[str, tuple[DotGovPdfEntry, ...]]:
    """Read ``dotgov_pdf_metadata.csv`` (Latin-1 encoded) and verify its SHA-256 pin and schema."""
    raw = metadata_path.read_bytes()
    if b"\x00" in raw:
        raise DotGovBenchmarkError("metadata.csv contains NUL bytes")
    actual_sha256 = hashlib.sha256(raw).hexdigest()
    if expected_sha256 is not None:
        pinned = _check_sha256(expected_sha256, "expected_metadata_sha256")
        if actual_sha256 != pinned:
            raise DotGovBenchmarkError(f"metadata.csv sha256 mismatch: expected {pinned}, got {actual_sha256}")
    text = raw.decode("latin-1")
    reader = csv.DictReader(io.StringIO(text, newline=""), restkey="__extra__", restval="__missing__")
    if reader.fieldnames is None or tuple(reader.fieldnames) != DOTGOV_METADATA_COLUMNS:
        raise DotGovBenchmarkError(
            f"metadata.csv columns {reader.fieldnames!r} do not match expected {list(DOTGOV_METADATA_COLUMNS)}"
        )
    entries: list[DotGovPdfEntry] = []
    seen_sha256: set[str] = set()
    seen_digest: set[str] = set()
    for row_number, row in enumerate(reader, start=1):
        if "__extra__" in row or any(value == "__missing__" or value is None for value in row.values()):
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} has wrong field count")
        digest = row["digest"].strip()
        if _CDX_DIGEST_RE.fullmatch(digest) is None:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} invalid CDX digest: {digest!r}")
        sha256 = _check_sha256(row["sha256"], f"row {row_number} sha256")
        sha512 = row["sha512"].strip().lower()
        if _SHA512_RE.fullmatch(sha512) is None:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} invalid sha512")
        if sha256 in seen_sha256:
            raise DotGovBenchmarkError(f"metadata.csv repeats sha256 {sha256} at row {row_number}")
        if digest in seen_digest:
            raise DotGovBenchmarkError(f"metadata.csv repeats digest {digest} at row {row_number}")
        seen_sha256.add(sha256)
        seen_digest.add(digest)

        pages_raw = row["pages"].strip()
        if pages_raw == "-":
            tika_pages: int | None = None
        elif _DECIMAL_RE.fullmatch(pages_raw):
            tika_pages = int(pages_raw)
        else:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} invalid pages value: {pages_raw!r}")

        size_raw = row["file_size"].strip()
        if _DECIMAL_RE.fullmatch(size_raw) is None:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} invalid file_size: {size_raw!r}")
        declared_file_size = int(size_raw)

        original = row["original"].strip()
        if not original:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} missing original URL")
        parsed_original = urlsplit(original if "://" in original else f"http://{original}")
        original_host = parsed_original.hostname.lower() if parsed_original.hostname else None

        pkg_file = manifest_files.get(digest) if manifest_files is not None else None
        if manifest_files is not None and pkg_file is None:
            raise DotGovBenchmarkError(f"metadata.csv row {row_number} digest {digest} missing from manifest.json")

        entries.append(
            DotGovPdfEntry(
                row_number=row_number,
                urlkey=row["urlkey"].strip(),
                timestamp=row["timestamp"].strip(),
                original=original,
                original_host=original_host,
                mimetype=row["mimetype"].strip(),
                statuscode=row["statuscode"].strip(),
                digest=digest,
                pdf_version=_optional_dash(row["pdf_version"].strip()),
                creator_tool=_optional_dash(row["creator_tool"].strip()),
                producer=_optional_dash(row["producer"].strip()),
                date_created=_optional_dash(row["date_created"].strip()),
                tika_pages=tika_pages,
                page_width=_optional_dash(row["page_width"].strip()),
                page_height=_optional_dash(row["page_height"].strip()),
                surface_area=_optional_dash(row["surface_area"].strip()),
                declared_file_size=declared_file_size,
                sha256=sha256,
                sha512=sha512,
                object_byte_size=pkg_file.size if pkg_file is not None else None,
                object_md5=pkg_file.md5 if pkg_file is not None else None,
                object_url=pkg_file.url if pkg_file is not None else None,
            )
        )
    if not entries:
        raise DotGovBenchmarkError("metadata.csv contained zero rows")
    if manifest_files is not None and set(manifest_files) != seen_digest:
        extra = sorted(set(manifest_files) - seen_digest)
        raise DotGovBenchmarkError(f"manifest.json has PDF digests absent from metadata.csv: {extra[:5]}")
    return actual_sha256, tuple(entries)


def read_ocr_sample_labels(labels_path: Path) -> tuple[str, tuple[OcrSampleLabel, ...]]:
    """Read a separately reviewed page-level OCR-routing label manifest."""
    raw = labels_path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise DotGovBenchmarkError(f"OCR sample labels file is not valid UTF-8 JSON: {error}") from error
    if not isinstance(payload, dict) or not isinstance(payload.get("samples"), list) or not payload["samples"]:
        raise DotGovBenchmarkError("OCR sample labels JSON must be an object with a nonempty 'samples' list")
    labels: list[OcrSampleLabel] = []
    seen: set[tuple[str, int]] = set()
    for index, item in enumerate(payload["samples"], start=1):
        if not isinstance(item, dict):
            raise DotGovBenchmarkError(f"OCR sample label {index} must be an object")
        sha256 = _check_sha256(str(item.get("sha256", "")), f"OCR sample {index} sha256")
        page = item.get("page")
        expected = item.get("expected_route_ocr")
        category = item.get("category")
        note = item.get("note")
        if type(page) is not int or page < 1:
            raise DotGovBenchmarkError(f"OCR sample {index} page must be a positive integer")
        if not isinstance(expected, bool):
            raise DotGovBenchmarkError(f"OCR sample {index} expected_route_ocr must be a boolean")
        if not isinstance(category, str) or not category.strip() or not isinstance(note, str) or not note.strip():
            raise DotGovBenchmarkError(f"OCR sample {index} requires nonempty category and note strings")
        key = (sha256, page)
        if key in seen:
            raise DotGovBenchmarkError(f"OCR sample labels repeat ({sha256}, page={page})")
        seen.add(key)
        labels.append(
            OcrSampleLabel(
                sha256=sha256,
                page=page,
                expected_route_ocr=expected,
                category=category.strip(),
                note=note.strip(),
            )
        )
    return digest, tuple(labels)


class _StrictOriginRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Enforce ``data.labs.loc.gov/dot-gov/pdf_data/`` and screening checks before following any redirect."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if headers.get("cf-mitigated") or headers.get("Retry-After"):
            raise DotGovDownloadBlockedError(f"redirect carried screening/backoff header ({code}) for {req.full_url}")
        resolved = urljoin(req.full_url, newurl)
        try:
            _check_allowed_url(resolved)
        except DotGovBenchmarkError as error:
            raise DotGovDownloadBlockedError(f"refusing redirect outside allowed origin: {resolved}") from error
        return super().redirect_request(req, fp, code, msg, headers, resolved)


def _looks_like_challenge_or_html(head: bytes, content_type: str | None) -> bool:
    ctype = (content_type or "").partition(";")[0].strip().lower()
    if ctype in {"text/html", "application/xhtml+xml"}:
        return True
    lowered = head.lower()
    return any(marker in lowered for marker in _CHALLENGE_MARKERS)


def _default_url_fetcher(
    url: str, *, timeout_seconds: float, max_bytes: int
) -> tuple[int, Mapping[str, str], IteratorBytes]:
    opener = urllib.request.build_opener(_StrictOriginRedirectHandler())
    request = urllib.request.Request(_check_allowed_url(url), headers={"User-Agent": USER_AGENT}, method="GET")
    try:
        response = opener.open(request, timeout=timeout_seconds)
    except urllib.error.HTTPError as error:
        headers = {k.lower(): v for k, v in error.headers.items()} if error.headers else {}
        content_type = headers.get("content-type")
        if (
            error.code in {401, 403, 429}
            or "cf-mitigated" in headers
            or "retry-after" in headers
            or _looks_like_challenge_or_html(b"", content_type)
        ):
            error.close()
            raise DotGovDownloadBlockedError(
                f"HTTP {error.code} from {url} (headers: cf-mitigated={headers.get('cf-mitigated')!r}, "
                f"retry-after={headers.get('retry-after')!r})"
            ) from error
        try:
            err_head = error.read(2048)
        except http.client.IncompleteRead as partial_err:
            err_head = bytes(partial_err.partial or b"")[:2048]
        except (OSError, http.client.HTTPException):
            err_head = b""
        finally:
            error.close()
        if _looks_like_challenge_or_html(err_head, content_type):
            raise DotGovDownloadBlockedError(
                f"HTTP {error.code} from {url} (headers: cf-mitigated={headers.get('cf-mitigated')!r}, "
                f"retry-after={headers.get('retry-after')!r})"
            ) from error
        raise

    headers = {k.lower(): v for k, v in response.headers.items()}
    status = int(getattr(response, "status", 200))
    if status in {401, 403, 429} or "cf-mitigated" in headers or "retry-after" in headers:
        response.close()
        raise DotGovDownloadBlockedError(
            f"screened or rate-limited HTTP {status} from {url} "
            f"(cf-mitigated={headers.get('cf-mitigated')!r}, retry-after={headers.get('retry-after')!r})"
        )
    if status != 200 or "content-range" in headers:
        response.close()
        raise DotGovBenchmarkError(f"unexpected HTTP {status} or partial Content-Range from {url}")
    final_url = response.geturl()
    if final_url:
        try:
            _check_allowed_url(final_url)
        except DotGovBenchmarkError as error:
            response.close()
            raise DotGovDownloadBlockedError(f"final URL left allowed origin: {final_url}") from error

    def _chunks():
        total = 0
        try:
            while True:
                chunk = response.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise DotGovBenchmarkError(f"download exceeded max_bytes ({max_bytes}) for {url}")
                yield chunk
        finally:
            response.close()

    return status, headers, _chunks()


IteratorBytes = Any


def _verify_cached_file(path: Path, entry: DotGovPdfEntry) -> tuple[bool, int]:
    """Check whether ``path`` exists and matches ``entry.sha256`` (plus ``manifest.json`` size/md5 when present)."""
    if not path.is_file():
        return False, 0
    sha256 = hashlib.sha256()
    md5 = hashlib.md5() if entry.object_md5 is not None else None
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            size += len(chunk)
            sha256.update(chunk)
            if md5 is not None:
                md5.update(chunk)
    if sha256.hexdigest() != entry.sha256:
        return False, size
    if entry.object_byte_size is not None and size != entry.object_byte_size:
        return False, size
    if md5 is not None and md5.hexdigest() != entry.object_md5:
        return False, size
    return True, size


def download_dotgov_pdfs(
    *,
    cache_dir: Path,
    metadata_path: Path,
    manifest_path: Path | None = None,
    expected_metadata_sha256: str | None = DOTGOV_PDF_METADATA_SHA256,
    expected_manifest_sha256: str | None = DOTGOV_PDF_MANIFEST_SHA256,
    package_url: str = DOTGOV_PDF_PACKAGE_URL,
    concurrency: int = MAX_DOWNLOAD_CONCURRENCY,
    timeout_seconds: float = 120.0,
    max_file_bytes: int = BENCHMARK_MAX_INPUT_BYTES,
    fetcher: Callable[..., tuple[int, Mapping[str, str], IteratorBytes]] | None = None,
) -> dict[str, Any]:
    """Download and SHA-256-verify the ``dot-gov`` ``pdf_data`` corpus into ``cache_dir/pdfs/``.

    Enforces ``1 <= concurrency <= 4``, resumes by verifying existing ``<sha256>.pdf`` files on disk,
    and aborts immediately if ``data.labs.loc.gov`` returns ``401``/``403``/``429``, ``Retry-After``,
    ``cf-mitigated``, an off-origin redirect, or an unexpected HTML/challenge body.
    """
    if type(concurrency) is not int or not 1 <= concurrency <= MAX_DOWNLOAD_CONCURRENCY:
        raise DotGovBenchmarkError(f"concurrency must be an integer in 1..{MAX_DOWNLOAD_CONCURRENCY}")
    if timeout_seconds <= 0 or type(max_file_bytes) is not int or max_file_bytes < 1:
        raise DotGovBenchmarkError("timeout_seconds and max_file_bytes must be positive")

    cache_dir.mkdir(parents=True, exist_ok=True)
    pdfs_dir = contained_cache_path(cache_dir, "pdfs")
    pdfs_dir.mkdir(parents=True, exist_ok=True)

    manifest_sha256: str | None = None
    manifest_files: dict[str, DotGovPackageFile] | None = None
    if manifest_path is not None:
        manifest_sha256, manifest_files = read_dotgov_package_manifest(
            manifest_path, expected_sha256=expected_manifest_sha256
        )
    metadata_sha256, entries = read_dotgov_metadata_csv(
        metadata_path,
        expected_sha256=expected_metadata_sha256,
        manifest_files=manifest_files,
    )

    active_fetcher = _default_url_fetcher if fetcher is None else fetcher
    started_at = datetime.now(UTC).isoformat()
    t0 = time.monotonic()

    reused_count = 0
    reused_bytes = 0
    pending: list[DotGovPdfEntry] = []
    quarantined_corrupt = 0

    for entry in entries:
        target = pdf_cache_path(cache_dir, entry.sha256)
        if target.exists():
            ok, existing_size = _verify_cached_file(target, entry)
            if ok:
                reused_count += 1
                reused_bytes += existing_size
                continue
            target.unlink()
            quarantined_corrupt += 1
        pending.append(entry)

    abort_event = threading.Event()
    abort_lock = threading.Lock()
    abort_reasons: list[str] = []
    downloaded_count = 0
    downloaded_bytes = 0
    failures: list[dict[str, Any]] = []

    def _download_one(entry: DotGovPdfEntry) -> tuple[str, int, str | None]:
        if abort_event.is_set():
            return ("skipped_after_abort", 0, None)
        url = entry.resolved_url(package_url)
        target = pdf_cache_path(cache_dir, entry.sha256)
        tmp: Path | None = None
        chunks: Any = None
        sha256 = hashlib.sha256()
        md5 = hashlib.md5()
        size = 0
        head = bytearray()
        try:
            status, raw_headers, chunks = active_fetcher(url, timeout_seconds=timeout_seconds, max_bytes=max_file_bytes)
            headers = {k.lower(): v for k, v in raw_headers.items()}
            if status in {401, 403, 429} or "cf-mitigated" in headers or "retry-after" in headers:
                raise DotGovDownloadBlockedError(
                    f"screened or rate-limited HTTP {status} from {url} "
                    f"(cf-mitigated={headers.get('cf-mitigated')!r}, retry-after={headers.get('retry-after')!r})"
                )
            if status != 200 or "content-range" in headers:
                content_type = headers.get("content-type")
                if status != 200 and _looks_like_challenge_or_html(b"", content_type):
                    raise DotGovDownloadBlockedError(f"unexpected HTTP {status} HTML/challenge body on {url}")
                try:
                    for chunk in chunks:
                        head.extend(chunk[: 1024 - len(head)])
                        if len(head) >= 1024:
                            break
                except http.client.IncompleteRead as partial_err:
                    head.extend(bytes(partial_err.partial or b"")[: 1024 - len(head)])
                    if _looks_like_challenge_or_html(bytes(head), content_type):
                        raise DotGovDownloadBlockedError(
                            f"unexpected HTTP {status} HTML/challenge body on {url}"
                        ) from partial_err
                    raise
                if _looks_like_challenge_or_html(bytes(head), content_type):
                    raise DotGovDownloadBlockedError(f"unexpected HTTP {status} HTML/challenge body on {url}")
                raise DotGovBenchmarkError(f"unexpected HTTP {status} or partial Content-Range from {url}")

            with _exclusive_temp_file(target.parent, f".{entry.sha256}.pdf.part.") as (out, tmp_path):
                tmp = tmp_path
                for chunk in chunks:
                    if abort_event.is_set():
                        return ("skipped_after_abort", 0, None)
                    if len(head) < 1024:
                        head.extend(chunk[: 1024 - len(head)])
                    size += len(chunk)
                    sha256.update(chunk)
                    md5.update(chunk)
                    out.write(chunk)

            got_sha256 = sha256.hexdigest()
            # Check pinned SHA-256 BEFORE HTML heuristics: one legitimate row in LoC's
            # published corpus (6HTC5FVAQW3DVHYRD7PVJGBBQS7GRZTL) is an archived XHTML
            # page whose exact bytes match metadata.csv's pinned sha256.
            if got_sha256 != entry.sha256:
                if _looks_like_challenge_or_html(bytes(head), headers.get("content-type")):
                    raise DotGovDownloadBlockedError(
                        f"unexpected HTML/challenge body on {url} (expected sha256 {entry.sha256}, got {got_sha256})"
                    )
                return ("failed", 0, f"sha256 mismatch for {entry.digest}: expected {entry.sha256}, got {got_sha256}")
            if entry.object_byte_size is not None and size != entry.object_byte_size:
                return (
                    "failed",
                    0,
                    f"manifest size mismatch for {entry.digest}: expected {entry.object_byte_size}, got {size}",
                )
            if entry.object_md5 is not None and md5.hexdigest() != entry.object_md5:
                return (
                    "failed",
                    0,
                    f"manifest md5 mismatch for {entry.digest}: expected {entry.object_md5}, got {md5.hexdigest()}",
                )
            os.replace(tmp, target)
            return ("downloaded", size, None)
        except DotGovDownloadBlockedError as blocked:
            abort_event.set()
            with abort_lock:
                abort_reasons.append(str(blocked))
            return ("blocked", 0, str(blocked))
        except (OSError, http.client.HTTPException, urllib.error.URLError, DotGovBenchmarkError, ValueError) as error:
            return ("failed", 0, f"{type(error).__name__}: {error}")
        finally:
            close_chunks = getattr(chunks, "close", None)
            if callable(close_chunks):
                close_chunks()
            if tmp is not None and tmp.exists():
                tmp.unlink(missing_ok=True)

    if pending:
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
            future_map = {pool.submit(_download_one, entry): entry for entry in pending}
            for future in concurrent.futures.as_completed(future_map):
                if future.cancelled():
                    continue
                entry = future_map[future]
                outcome, nbytes, message = future.result()
                if outcome == "downloaded":
                    downloaded_count += 1
                    downloaded_bytes += nbytes
                elif outcome in {"failed", "blocked"}:
                    failures.append(
                        {
                            "digest": entry.digest,
                            "sha256": entry.sha256,
                            "outcome": outcome,
                            "error": message,
                        }
                    )
                if abort_event.is_set():
                    for pending_future in future_map:
                        pending_future.cancel()

    verified_total = reused_count + downloaded_count
    complete = verified_total == len(entries) and not abort_reasons and not failures
    receipt = {
        "schema_version": "spicy-docs.dotgov-pdf-download.v1",
        "complete": complete,
        "aborted": bool(abort_reasons),
        "abort_reasons": abort_reasons,
        "started_at": started_at,
        "completed_at": datetime.now(UTC).isoformat(),
        "elapsed_seconds": round(time.monotonic() - t0, 3),
        "package_url": package_url,
        "concurrency": concurrency,
        "metadata_sha256": metadata_sha256,
        "manifest_sha256": manifest_sha256,
        "expected_entries": len(entries),
        "verified_entries": verified_total,
        "reused_verified_entries": reused_count,
        "reused_verified_bytes": reused_bytes,
        "downloaded_entries": downloaded_count,
        "downloaded_bytes": downloaded_bytes,
        "quarantined_corrupt_entries": quarantined_corrupt,
        "failure_count": len(failures),
        "failures": failures,
    }
    receipt_path = contained_cache_path(cache_dir, "download-receipt.json")
    atomic_write_json(receipt_path, receipt)
    return receipt


def _evaluate_single_pdf(
    entry: DotGovPdfEntry,
    body: bytes,
    *,
    max_input_bytes: int,
    min_chars: int,
    sample_pages_for_entry: Mapping[int, OcrSampleLabel],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Run ``assess_pdf_bytes``, ``DefaultReader`` (PyMuPDF), ``NativeOrOcr``, and ``PypdfReader`` on one body."""
    from spicy_docs.extraction.api import NativeOrOcr, control_characters
    from spicy_docs.extraction.model import ExtractionError, Observation
    from spicy_docs.extraction.pages import DefaultReader
    from spicy_docs.extraction.pypdf import PdfEncryptedError, PdfPageError, PdfReadError, PypdfReader
    from spicy_docs.extraction.quality import text_corruption_measures
    from spicy_docs.reading.pdf_bytes import assess_pdf_bytes

    byte_facts = assess_pdf_bytes(body)
    exceeds_default_64mib = len(body) > DEFAULT_MAX_INPUT_BYTES

    # Dummy backend never called because we invoke NativeOrOcr._route directly without rendering images.
    class _RouteProbeBackend:
        def recognize(self, image):  # pragma: no cover - routing probe never renders
            raise AssertionError("routing probe must not invoke OCR backend")

    router_default = NativeOrOcr(_RouteProbeBackend(), min_chars=min_chars, require_images=True)
    router_unconditional = NativeOrOcr(_RouteProbeBackend(), min_chars=min_chars, require_images=False)

    pymupdf_status = "ok"
    pymupdf_error: str | None = None
    pymupdf_page_count: int | None = None

    strict_native_error_pages = 0
    strict_native_first_error: str | None = None
    plain_text_recovered_pages = 0
    plain_text_unrecovered_pages = 0

    readable_native_pages = 0
    empty_native_pages = 0
    short_native_pages = 0
    image_bearing_pages = 0
    ocr_routed_default_pages = 0
    ocr_reason_garbled_pages = 0
    ocr_reason_short_with_image_pages = 0
    ocr_routed_unconditional_only_pages = 0
    unmapped_glyph_pages = 0
    unmapped_check_skipped_pages = 0
    font_glyph_mapped_pages = 0
    font_glyph_unresolved_pages = 0

    total_unicode_chars = 0
    total_nonspace_chars = 0
    total_alnum_chars = 0
    total_replacement_chars = 0
    total_control_chars = 0
    total_private_use_chars = 0
    total_latin_words = 0
    total_latin_singles = 0
    max_single_letter_run = 0

    sample_evaluations: list[dict[str, Any]] = []
    recorded_sample_pages: set[int] = set()

    if len(body) > max_input_bytes:
        pymupdf_status = "exceeds_max_input_bytes"
        pymupdf_error = f"source size {len(body)} exceeds max_input_bytes {max_input_bytes}"
    else:
        strict_reader = DefaultReader(native_zero_area="refuse")
        try:
            with strict_reader.open(body, "application/pdf") as document:
                pymupdf_page_count = document.page_count
                if pymupdf_page_count == 0:
                    pymupdf_status = "zero_pages"
                fallback_doc_cm = None
                fallback_doc = None
                try:
                    for page_num in range(1, pymupdf_page_count + 1):
                        page = document.page(page_num)
                        has_image = page.image_count() > 0
                        if has_image:
                            image_bearing_pages += 1
                        recognition = None
                        try:
                            recognition = page.native()
                        except ExtractionError as native_err:
                            strict_native_error_pages += 1
                            if strict_native_first_error is None:
                                strict_native_first_error = f"page {page_num}: {native_err}"
                            if fallback_doc is None:
                                fallback_reader = DefaultReader(native_zero_area="plain_text")
                                fallback_doc_cm = fallback_reader.open(body, "application/pdf")
                                fallback_doc = fallback_doc_cm.__enter__()
                            try:
                                recognition = fallback_doc.page(page_num).native()
                                plain_text_recovered_pages += 1
                            except ExtractionError:
                                plain_text_unrecovered_pages += 1

                        if recognition is None:
                            if page_num in sample_pages_for_entry:
                                label = sample_pages_for_entry[page_num]
                                recorded_sample_pages.add(page_num)
                                sample_evaluations.append(
                                    {
                                        "sha256": entry.sha256,
                                        "digest": entry.digest,
                                        "page": page_num,
                                        "category": label.category,
                                        "expected_route_ocr": label.expected_route_ocr,
                                        "actual_route_ocr": None,
                                        "actual_route_ocr_unconditional": None,
                                        "route_reason": "native_extraction_refused",
                                        "nonspace_chars": None,
                                        "image_bearing": has_image,
                                        "evaluated": False,
                                        "matched": False,
                                        "matched_unconditional": False,
                                        "note": label.note,
                                    }
                                )
                            continue

                        readable_native_pages += 1
                        text = recognition.text
                        nonspace = len("".join(text.split()))
                        total_nonspace_chars += nonspace
                        if nonspace == 0:
                            empty_native_pages += 1
                        elif nonspace < min_chars:
                            short_native_pages += 1

                        obs = Observation(
                            "native",
                            text,
                            recognition.configuration,
                            None,
                            recognition.blocks,
                            issues=recognition.issues,
                        )
                        route_default, why_default = router_default._route(page, obs)
                        route_uncond, _why_uncond = router_unconditional._route(page, obs)
                        garbled = control_characters(obs) is not None
                        if route_default:
                            ocr_routed_default_pages += 1
                            if garbled:
                                ocr_reason_garbled_pages += 1
                            else:
                                ocr_reason_short_with_image_pages += 1
                        elif route_uncond:
                            ocr_routed_unconditional_only_pages += 1

                        issue_codes = {issue.code for issue in recognition.issues}
                        if "unmapped-glyph-code" in issue_codes:
                            unmapped_glyph_pages += 1
                        if "unmapped-glyph-check-skipped" in issue_codes:
                            unmapped_check_skipped_pages += 1
                        if "font-glyph-mapped" in issue_codes:
                            font_glyph_mapped_pages += 1
                        if "font-glyph-unresolved" in issue_codes:
                            font_glyph_unresolved_pages += 1

                        measures = text_corruption_measures(text)
                        total_unicode_chars += measures["unicode_characters"]
                        total_alnum_chars += measures["alphanumeric_characters"]
                        total_replacement_chars += measures["replacement_characters"]
                        total_control_chars += measures["nonwhitespace_control_characters"]
                        total_private_use_chars += measures["private_use_characters"]
                        total_latin_words += measures["latin_word_tokens"]
                        total_latin_singles += measures["latin_single_letter_tokens"]
                        max_single_letter_run = max(max_single_letter_run, measures["longest_latin_single_letter_run"])

                        if page_num in sample_pages_for_entry:
                            label = sample_pages_for_entry[page_num]
                            recorded_sample_pages.add(page_num)
                            sample_evaluations.append(
                                {
                                    "sha256": entry.sha256,
                                    "digest": entry.digest,
                                    "page": page_num,
                                    "category": label.category,
                                    "expected_route_ocr": label.expected_route_ocr,
                                    "actual_route_ocr": route_default,
                                    "actual_route_ocr_unconditional": route_uncond,
                                    "route_reason": why_default,
                                    "nonspace_chars": nonspace,
                                    "image_bearing": has_image,
                                    "evaluated": True,
                                    "matched": route_default == label.expected_route_ocr,
                                    "matched_unconditional": route_uncond == label.expected_route_ocr,
                                    "note": label.note,
                                }
                            )
                finally:
                    if fallback_doc_cm is not None:
                        fallback_doc_cm.__exit__(None, None, None)
        except ExtractionError as enc_err:
            if "encrypted PDF" in str(enc_err):
                pymupdf_status = "encrypted"
            else:
                pymupdf_status = "open_error"
            pymupdf_error = str(enc_err)
        except (RuntimeError, ValueError, TypeError) as open_err:
            pymupdf_status = "open_error"
            pymupdf_error = f"{type(open_err).__name__}: {open_err}"

    for page_num, label in sorted(sample_pages_for_entry.items()):
        if page_num in recorded_sample_pages:
            continue
        reason = (
            f"page_out_of_range (page {page_num} > page_count {pymupdf_page_count})"
            if pymupdf_status == "ok" and pymupdf_page_count is not None
            else f"document_not_opened ({pymupdf_status})"
        )
        sample_evaluations.append(
            {
                "sha256": entry.sha256,
                "digest": entry.digest,
                "page": page_num,
                "category": label.category,
                "expected_route_ocr": label.expected_route_ocr,
                "actual_route_ocr": None,
                "actual_route_ocr_unconditional": None,
                "route_reason": reason,
                "nonspace_chars": None,
                "image_bearing": None,
                "evaluated": False,
                "matched": False,
                "matched_unconditional": False,
                "note": label.note,
            }
        )

    pypdf_status = "ok"
    pypdf_error: str | None = None
    pypdf_page_count: int | None = None
    pypdf_page_errors = 0
    pypdf_empty_password_status: str | None = None
    pypdf_empty_password_page_count: int | None = None

    pypdf_reader = PypdfReader(max_input_bytes=max_input_bytes)
    try:
        with pypdf_reader.open(body) as pypdf_doc:
            pypdf_page_count = pypdf_doc.page_count
            if pypdf_page_count == 0:
                pypdf_status = "zero_pages"
            # Probe page-level pypdf reads when Tika is unknown or counts disagree across engines.
            if (
                entry.tika_pages is None
                or pymupdf_page_count != entry.tika_pages
                or pypdf_page_count != pymupdf_page_count
            ):
                for page_num in range(1, min(pypdf_page_count, 200) + 1):
                    try:
                        pypdf_doc.read_page(page_num)
                    except PdfPageError:
                        pypdf_page_errors += 1
    except PdfEncryptedError as err:
        pypdf_status = "encrypted"
        pypdf_error = str(err)
        # PypdfReader(password=None) refuses owner-locked PDFs by contract; separately probe
        # password="" so owner-permissions locks stay distinct from user-password locks.
        try:
            with pypdf_reader.open(body, password="") as unlocked_doc:
                pypdf_empty_password_status = "ok"
                pypdf_empty_password_page_count = unlocked_doc.page_count
        except PdfEncryptedError:
            pypdf_empty_password_status = "encrypted"
        except PdfReadError:
            pypdf_empty_password_status = "open_error"
    except PdfReadError as err:
        pypdf_status = "open_error"
        pypdf_error = str(err)
    except ValueError as err:
        pypdf_status = "exceeds_max_input_bytes" if "max_input_bytes" in str(err) else "open_error"
        pypdf_error = str(err)

    if entry.tika_pages is not None:
        if pymupdf_status != "ok" or pymupdf_page_count is None:
            tika_comparison = f"tika_numeric_pymupdf_{pymupdf_status}"
        elif pymupdf_page_count == entry.tika_pages:
            tika_comparison = "exact_match"
        else:
            tika_comparison = "page_count_mismatch"
    else:
        if pymupdf_status == "ok":
            tika_comparison = "tika_unknown_pymupdf_opened"
        else:
            tika_comparison = f"tika_unknown_pymupdf_{pymupdf_status}"

    doc_record = {
        "row_number": entry.row_number,
        "digest": entry.digest,
        "sha256": entry.sha256,
        "original": entry.original,
        "original_host": entry.original_host,
        "declared_file_size": entry.declared_file_size,
        "actual_byte_size": len(body),
        "declared_vs_actual_size_diff": entry.declared_file_size - len(body),
        "exceeds_default_64mib_cap": exceeds_default_64mib,
        "tika_pages": entry.tika_pages,
        "tika_pdf_version": entry.pdf_version,
        "tika_producer": entry.producer,
        "byte_facts": {
            "header_pdf_version": byte_facts.pdf_version,
            "eof_in_tail": byte_facts.eof_in_tail,
            "terminal_xref_offset": byte_facts.terminal_xref_offset,
            "declared_linearized_bytes": byte_facts.declared_linearized_bytes,
            "trailing_zero_bytes": byte_facts.trailing_zero_bytes,
            "issues": list(byte_facts.issues),
        },
        "pymupdf": {
            "status": pymupdf_status,
            "page_count": pymupdf_page_count,
            "error": pymupdf_error,
            "readable_native_pages": readable_native_pages,
            "strict_native_error_pages": strict_native_error_pages,
            "strict_native_first_error": strict_native_first_error,
            "plain_text_recovered_pages": plain_text_recovered_pages,
            "plain_text_unrecovered_pages": plain_text_unrecovered_pages,
            "empty_native_pages": empty_native_pages,
            "short_native_pages": short_native_pages,
            "image_bearing_pages": image_bearing_pages,
            "ocr_routed_default_pages": ocr_routed_default_pages,
            "ocr_reason_garbled_pages": ocr_reason_garbled_pages,
            "ocr_reason_short_with_image_pages": ocr_reason_short_with_image_pages,
            "ocr_routed_unconditional_only_pages": ocr_routed_unconditional_only_pages,
            "unmapped_glyph_pages": unmapped_glyph_pages,
            "unmapped_check_skipped_pages": unmapped_check_skipped_pages,
            "font_glyph_mapped_pages": font_glyph_mapped_pages,
            "font_glyph_unresolved_pages": font_glyph_unresolved_pages,
            "text_yield": {
                "unicode_characters": total_unicode_chars,
                "nonspace_characters": total_nonspace_chars,
                "alphanumeric_characters": total_alnum_chars,
                "replacement_characters": total_replacement_chars,
                "nonwhitespace_control_characters": total_control_chars,
                "private_use_characters": total_private_use_chars,
                "latin_word_tokens": total_latin_words,
                "latin_single_letter_tokens": total_latin_singles,
                "latin_single_letter_fraction": (
                    round(total_latin_singles / total_latin_words, 6) if total_latin_words else None
                ),
                "longest_latin_single_letter_run": max_single_letter_run,
            },
        },
        "pypdf": {
            "status": pypdf_status,
            "page_count": pypdf_page_count,
            "error": pypdf_error,
            "sampled_page_errors": pypdf_page_errors,
            "empty_password_status": pypdf_empty_password_status,
            "empty_password_page_count": pypdf_empty_password_page_count,
        },
        "tika_comparison": tika_comparison,
        "pymupdf_equals_pypdf": (
            pymupdf_page_count == pypdf_page_count
            if pymupdf_page_count is not None and pypdf_page_count is not None
            else None
        ),
    }
    return doc_record, sample_evaluations


def evaluate_dotgov_pdfs(
    *,
    cache_dir: Path,
    metadata_path: Path,
    manifest_path: Path | None = None,
    expected_metadata_sha256: str | None = DOTGOV_PDF_METADATA_SHA256,
    expected_manifest_sha256: str | None = DOTGOV_PDF_MANIFEST_SHA256,
    ocr_sample_labels_path: Path | None = None,
    max_input_bytes: int = BENCHMARK_MAX_INPUT_BYTES,
    min_chars: int = 50,
    allow_partial: bool = False,
) -> dict[str, Any]:
    """Run the offline page-count, refusal, text-yield, and OCR-routing benchmark over ``cache_dir/pdfs/``."""
    from importlib.metadata import version

    if type(max_input_bytes) is not int or max_input_bytes < 1:
        raise DotGovBenchmarkError("max_input_bytes must be a positive integer")
    if type(min_chars) is not int or min_chars < 0:
        raise DotGovBenchmarkError("min_chars must be a nonnegative integer")

    manifest_sha256: str | None = None
    manifest_files: dict[str, DotGovPackageFile] | None = None
    if manifest_path is not None:
        manifest_sha256, manifest_files = read_dotgov_package_manifest(
            manifest_path, expected_sha256=expected_manifest_sha256
        )
    metadata_sha256, entries = read_dotgov_metadata_csv(
        metadata_path,
        expected_sha256=expected_metadata_sha256,
        manifest_files=manifest_files,
    )

    ocr_labels_sha256: str | None = None
    labels_by_sha: dict[str, dict[int, OcrSampleLabel]] = {}
    total_labels = 0
    if ocr_sample_labels_path is not None:
        ocr_labels_sha256, labels = read_ocr_sample_labels(ocr_sample_labels_path)
        total_labels = len(labels)
        known_shas = {entry.sha256 for entry in entries}
        for label in labels:
            if label.sha256 not in known_shas:
                raise DotGovBenchmarkError(f"OCR sample label sha256 {label.sha256} is absent from metadata.csv")
            labels_by_sha.setdefault(label.sha256, {})[label.page] = label

    started_at = datetime.now(UTC).isoformat()
    t0 = time.monotonic()

    missing_or_corrupt: list[dict[str, Any]] = []
    documents: list[dict[str, Any]] = []
    ocr_sample_results: list[dict[str, Any]] = []

    def _record_missing_cache_labels(entry: DotGovPdfEntry, reason: str) -> None:
        for page_num, label in sorted(labels_by_sha.get(entry.sha256, {}).items()):
            ocr_sample_results.append(
                {
                    "sha256": entry.sha256,
                    "digest": entry.digest,
                    "page": page_num,
                    "category": label.category,
                    "expected_route_ocr": label.expected_route_ocr,
                    "actual_route_ocr": None,
                    "actual_route_ocr_unconditional": None,
                    "route_reason": f"cache_{reason}",
                    "nonspace_chars": None,
                    "image_bearing": None,
                    "evaluated": False,
                    "matched": False,
                    "matched_unconditional": False,
                    "note": label.note,
                }
            )

    for entry in entries:
        path = pdf_cache_path(cache_dir, entry.sha256)
        if not path.is_file():
            missing_or_corrupt.append({"digest": entry.digest, "sha256": entry.sha256, "reason": "missing_from_cache"})
            _record_missing_cache_labels(entry, "missing_from_cache")
            continue
        body = path.read_bytes()
        if hashlib.sha256(body).hexdigest() != entry.sha256:
            missing_or_corrupt.append({"digest": entry.digest, "sha256": entry.sha256, "reason": "sha256_mismatch"})
            _record_missing_cache_labels(entry, "sha256_mismatch")
            continue
        if entry.object_byte_size is not None and len(body) != entry.object_byte_size:
            missing_or_corrupt.append(
                {"digest": entry.digest, "sha256": entry.sha256, "reason": "manifest_size_mismatch"}
            )
            _record_missing_cache_labels(entry, "manifest_size_mismatch")
            continue
        if entry.object_md5 is not None and hashlib.md5(body).hexdigest() != entry.object_md5:
            missing_or_corrupt.append(
                {"digest": entry.digest, "sha256": entry.sha256, "reason": "manifest_md5_mismatch"}
            )
            _record_missing_cache_labels(entry, "manifest_md5_mismatch")
            continue

        doc_record, sample_evals = _evaluate_single_pdf(
            entry,
            body,
            max_input_bytes=max_input_bytes,
            min_chars=min_chars,
            sample_pages_for_entry=labels_by_sha.get(entry.sha256, {}),
        )
        documents.append(doc_record)
        ocr_sample_results.extend(sample_evals)
        del body

    if missing_or_corrupt and not allow_partial:
        first = missing_or_corrupt[0]
        raise DotGovBenchmarkError(
            f"cache incomplete or corrupt ({len(missing_or_corrupt)} of {len(entries)} entries; "
            f"first: {first['digest']} {first['reason']})"
        )

    complete = len(documents) == len(entries) and not missing_or_corrupt
    tika_numeric_docs = [d for d in documents if d["tika_pages"] is not None]
    tika_unknown_docs = [d for d in documents if d["tika_pages"] is None]
    tika_zero_docs = [d for d in tika_numeric_docs if d["tika_pages"] == 0]

    comparison_counts = Counter(d["tika_comparison"] for d in documents)
    pymupdf_status_counts = Counter(d["pymupdf"]["status"] for d in documents)
    pypdf_status_counts = Counter(d["pypdf"]["status"] for d in documents)
    byte_issue_counts = Counter(issue for d in documents for issue in d["byte_facts"]["issues"])
    host_counts = Counter(d["original_host"] or "<missing>" for d in documents)

    both_opened = [d for d in documents if d["pymupdf"]["status"] == "ok" and d["pypdf"]["status"] == "ok"]
    engine_page_agreements = sum(1 for d in both_opened if d["pymupdf_equals_pypdf"])
    engine_disagreements = [d for d in both_opened if not d["pymupdf_equals_pypdf"]]

    discrepancies = [d for d in documents if d["tika_pages"] is not None and d["tika_comparison"] != "exact_match"]

    total_pymupdf_pages = sum(d["pymupdf"]["page_count"] or 0 for d in documents)
    total_readable_pages = sum(d["pymupdf"]["readable_native_pages"] for d in documents)
    total_strict_error_pages = sum(d["pymupdf"]["strict_native_error_pages"] for d in documents)
    total_plain_recovered_pages = sum(d["pymupdf"]["plain_text_recovered_pages"] for d in documents)
    total_empty_pages = sum(d["pymupdf"]["empty_native_pages"] for d in documents)
    total_short_pages = sum(d["pymupdf"]["short_native_pages"] for d in documents)
    total_image_pages = sum(d["pymupdf"]["image_bearing_pages"] for d in documents)
    total_ocr_default_pages = sum(d["pymupdf"]["ocr_routed_default_pages"] for d in documents)
    total_ocr_garbled_pages = sum(d["pymupdf"]["ocr_reason_garbled_pages"] for d in documents)
    total_ocr_short_image_pages = sum(d["pymupdf"]["ocr_reason_short_with_image_pages"] for d in documents)
    total_ocr_uncond_only_pages = sum(d["pymupdf"]["ocr_routed_unconditional_only_pages"] for d in documents)
    total_unmapped_glyph_pages = sum(d["pymupdf"]["unmapped_glyph_pages"] for d in documents)

    docs_fully_empty_native = sum(
        1
        for d in documents
        if (d["pymupdf"]["page_count"] or 0) > 0 and d["pymupdf"]["empty_native_pages"] == d["pymupdf"]["page_count"]
    )
    docs_any_ocr_default = sum(1 for d in documents if d["pymupdf"]["ocr_routed_default_pages"] > 0)
    docs_exceeding_default_64mib = [
        {
            "digest": d["digest"],
            "sha256": d["sha256"],
            "actual_byte_size": d["actual_byte_size"],
            "tika_pages": d["tika_pages"],
            "pymupdf_page_count": d["pymupdf"]["page_count"],
            "pypdf_page_count": d["pypdf"]["page_count"],
        }
        for d in documents
        if d["exceeds_default_64mib_cap"]
    ]
    declared_size_mismatches = [
        {
            "digest": d["digest"],
            "sha256": d["sha256"],
            "declared_file_size": d["declared_file_size"],
            "actual_byte_size": d["actual_byte_size"],
            "tika_pages": d["tika_pages"],
            "pymupdf_status": d["pymupdf"]["status"],
            "pymupdf_page_count": d["pymupdf"]["page_count"],
        }
        for d in documents
        if d["declared_file_size"] != d["actual_byte_size"]
    ]

    ocr_sample_summary: dict[str, Any] | None = None
    if ocr_sample_labels_path is not None:
        evaluated_samples = sum(1 for item in ocr_sample_results if item.get("evaluated", False))
        unevaluated_samples = total_labels - evaluated_samples
        matched_labels = sum(1 for item in ocr_sample_results if item["matched"])
        matched_uncond = sum(1 for item in ocr_sample_results if item.get("matched_unconditional"))
        ocr_sample_summary = {
            "labels_sha256": ocr_labels_sha256,
            "declared_samples": total_labels,
            "evaluated_samples": evaluated_samples,
            "unevaluated_samples": unevaluated_samples,
            "matched_samples": matched_labels,
            "disagreed_samples": total_labels - matched_labels,
            "matched_unconditional_samples": matched_uncond,
            "disagreed_unconditional_samples": total_labels - matched_uncond,
            "results": ocr_sample_results,
        }

    return {
        "schema_version": "spicy-docs.dotgov-pdf-benchmark.v1",
        "complete": complete,
        "started_at": started_at,
        "completed_at": datetime.now(UTC).isoformat(),
        "elapsed_seconds": round(time.monotonic() - t0, 3),
        "dataset": {
            "package_url": DOTGOV_PDF_PACKAGE_URL,
            "metadata_sha256": metadata_sha256,
            "manifest_sha256": manifest_sha256,
            "rights_statement": DOTGOV_RIGHTS_SUMMARY,
            "ground_truth_note": (
                "metadata.csv provides Apache Tika 'pages' for 987 rows and '-' for 13 rows (zero '0' rows). "
                "It provides NO ground-truth empty-page or OCR-routing labels; text-yield and NativeOrOcr "
                "figures over the 1,000 files are unlabeled reader distributions unless paired with "
                "separately reviewed --ocr-sample-labels."
            ),
        },
        "environment": {
            "python": sys.version.split()[0],
            "pymupdf": version("pymupdf"),
            "pypdf": version("pypdf"),
            "default_max_input_bytes": DEFAULT_MAX_INPUT_BYTES,
            "benchmark_max_input_bytes": max_input_bytes,
            "native_or_ocr_min_chars": min_chars,
        },
        "summary": {
            "expected_entries": len(entries),
            "evaluated_entries": len(documents),
            "missing_or_corrupt_entries": len(missing_or_corrupt),
            "tika_numeric_entries": len(tika_numeric_docs),
            "tika_unknown_dash_entries": len(tika_unknown_docs),
            "tika_zero_page_entries": len(tika_zero_docs),
            "tika_exact_page_matches": comparison_counts.get("exact_match", 0),
            "tika_numeric_discrepancies": len(discrepancies),
            "tika_comparison_breakdown": dict(sorted(comparison_counts.items())),
            "pymupdf_status_breakdown": dict(sorted(pymupdf_status_counts.items())),
            "pypdf_status_breakdown": dict(sorted(pypdf_status_counts.items())),
            "both_engines_opened": len(both_opened),
            "pymupdf_pypdf_page_count_agreements": engine_page_agreements,
            "pymupdf_pypdf_page_count_disagreements": len(engine_disagreements),
            "exceeds_default_64mib_count": len(docs_exceeding_default_64mib),
            "declared_vs_actual_size_mismatch_count": len(declared_size_mismatches),
            "byte_issue_counts": dict(sorted(byte_issue_counts.items())),
            "distinct_original_hosts": len(host_counts),
            "top_original_hosts": host_counts.most_common(15),
            "page_totals": {
                "pymupdf_pages": total_pymupdf_pages,
                "readable_native_pages": total_readable_pages,
                "strict_native_geometry_error_pages": total_strict_error_pages,
                "plain_text_fallback_recovered_pages": total_plain_recovered_pages,
                "empty_native_pages": total_empty_pages,
                "short_native_pages_under_min_chars": total_short_pages,
                "image_bearing_pages": total_image_pages,
                "ocr_routed_default_pages": total_ocr_default_pages,
                "ocr_reason_garbled_pages": total_ocr_garbled_pages,
                "ocr_reason_short_with_image_pages": total_ocr_short_image_pages,
                "ocr_routed_unconditional_only_pages": total_ocr_uncond_only_pages,
                "unmapped_glyph_pages": total_unmapped_glyph_pages,
                "documents_all_pages_empty_native": docs_fully_empty_native,
                "documents_with_any_default_ocr_page": docs_any_ocr_default,
            },
        },
        "ocr_sample_evaluation": ocr_sample_summary,
        "exceeds_default_64mib_entries": docs_exceeding_default_64mib,
        "declared_vs_actual_size_mismatches": declared_size_mismatches,
        "tika_numeric_discrepancies": discrepancies,
        "tika_unknown_dash_entries": tika_unknown_docs,
        "pymupdf_pypdf_disagreements": engine_disagreements,
        "missing_or_corrupt": missing_or_corrupt,
        "documents": documents,
    }


def render_markdown_report(report: Mapping[str, Any]) -> str:
    """Render a deterministic Markdown summary of an ``evaluate_dotgov_pdfs`` report."""
    summary = report["summary"]
    dataset = report["dataset"]
    env = report["environment"]
    pages = summary["page_totals"]

    lines = [
        "# Library of Congress Labs `dot-gov` 1,000-PDF External-Cache Benchmark",
        "",
        f"- **Complete run:** `{report['complete']}` (`{summary['evaluated_entries']}/{summary['expected_entries']}` files verified by SHA-256)",
        f"- **Pinned `metadata.csv` SHA-256:** `{dataset['metadata_sha256']}`",
        f"- **Pinned `manifest.json` SHA-256:** `{dataset['manifest_sha256']}`",
        f"- **Backends:** Python `{env['python']}`, PyMuPDF `{env['pymupdf']}`, pypdf `{env['pypdf']}` (`elapsed_seconds={report['elapsed_seconds']}`)",
        f"- **Rights & access note:** {dataset['rights_statement']}",
        f"- **Oracle boundary:** {dataset['ground_truth_note']}",
        "",
        "## 1. Page-Count Oracle Comparison (Apache Tika `pages` vs `spicy-docs`)",
        "",
        "| Population / Outcome | Count |",
        "| --- | ---: |",
        f"| Total manifest entries | {summary['expected_entries']} |",
        f"| Tika numeric `pages` rows (`> 0`) | {summary['tika_numeric_entries']} |",
        f"| Tika `pages == '0'` rows | {summary['tika_zero_page_entries']} |",
        f"| Tika unknown `pages == '-'` rows | {summary['tika_unknown_dash_entries']} |",
        f"| Exact page-count agreement (`DefaultReader` == Tika `pages`) | {summary['tika_exact_page_matches']} |",
        f"| Discrepancies on numeric Tika rows | {summary['tika_numeric_discrepancies']} |",
        f"| Both `DefaultReader` and `PypdfReader` opened | {summary['both_engines_opened']} |",
        f"| `DefaultReader` == `PypdfReader` page-count agreement | {summary['pymupdf_pypdf_page_count_agreements']} |",
        f"| Exceeds default `64 MiB` `max_input_bytes` cap | {summary['exceeds_default_64mib_count']} |",
        f"| CDX `file_size` != actual BagIt object bytes | {summary['declared_vs_actual_size_mismatch_count']} |",
        "",
        "## 2. Unlabeled Reader Text-Yield & `NativeOrOcr` Routing Distribution",
        "",
        "| Page / Document Observation | Count |",
        "| --- | ---: |",
        f"| Total `DefaultReader` pages across opened PDFs | {pages['pymupdf_pages']} |",
        f"| Readable native pages | {pages['readable_native_pages']} |",
        f"| Strict geometry refusal pages (`native_zero_area='refuse'`) | {pages['strict_native_geometry_error_pages']} |",
        f"| Recovered by `native_zero_area='plain_text'` | {pages['plain_text_fallback_recovered_pages']} |",
        f"| Empty native pages (`0` non-space chars) | {pages['empty_native_pages']} |",
        f"| Short native pages (`1..{env['native_or_ocr_min_chars'] - 1}` non-space chars) | {pages['short_native_pages_under_min_chars']} |",
        f"| Pages drawing raster images (`image_count() > 0`) | {pages['image_bearing_pages']} |",
        f"| `NativeOrOcr` default routed pages (`garbled` or `< {env['native_or_ocr_min_chars']}` chars + image) | {pages['ocr_routed_default_pages']} |",
        f"| — Routed for control/replacement garble | {pages['ocr_reason_garbled_pages']} |",
        f"| — Routed for `< {env['native_or_ocr_min_chars']}` non-space chars with image | {pages['ocr_reason_short_with_image_pages']} |",
        f"| Short/blank pages without images (`require_images=False` only) | {pages['ocr_routed_unconditional_only_pages']} |",
        f"| Pages with `unmapped-glyph-code` (`NativeWithRegions(unmapped_glyphs=True)`) | {pages['unmapped_glyph_pages']} |",
        f"| Documents with all pages empty native text | {pages['documents_all_pages_empty_native']} |",
        f"| Documents with >= 1 default `NativeOrOcr` page | {pages['documents_with_any_default_ocr_page']} |",
        "",
        "## 3. Numeric Tika Discrepancies",
        "",
    ]

    discrepancies = report["tika_numeric_discrepancies"]
    if not discrepancies:
        lines.append("None.")
    else:
        lines.extend(
            [
                "| Digest | SHA-256 (prefix) | Actual Bytes | Declared `file_size` | Tika `pages` | PyMuPDF | pypdf | Byte Issues / Error |",
                "| --- | --- | ---: | ---: | ---: | --- | --- | --- |",
            ]
        )
        for d in discrepancies:
            pm = d["pymupdf"]["page_count"] if d["pymupdf"]["status"] == "ok" else d["pymupdf"]["status"]
            pp = d["pypdf"]["page_count"] if d["pypdf"]["status"] == "ok" else d["pypdf"]["status"]
            issues = ", ".join(d["byte_facts"]["issues"])
            err = d["pymupdf"]["error"] or d["pypdf"]["error"] or ""
            detail = f"{issues}; {err}".strip("; ")
            lines.append(
                f"| `{d['digest']}` | `{d['sha256'][:12]}` | {d['actual_byte_size']} | {d['declared_file_size']} | "
                f"{d['tika_pages']} | `{pm}` | `{pp}` | {detail} |"
            )

    lines.extend(
        [
            "",
            "## 4. Tika Unknown (`pages == '-'`) Entries",
            "",
            "| Digest | SHA-256 (prefix) | Actual Bytes | Declared `file_size` | PyMuPDF | pypdf | Byte Issues / Error |",
            "| --- | --- | ---: | ---: | --- | --- | --- |",
        ]
    )
    for d in report["tika_unknown_dash_entries"]:
        pm = f"ok ({d['pymupdf']['page_count']}p)" if d["pymupdf"]["status"] == "ok" else d["pymupdf"]["status"]
        pp = f"ok ({d['pypdf']['page_count']}p)" if d["pypdf"]["status"] == "ok" else d["pypdf"]["status"]
        issues = ", ".join(d["byte_facts"]["issues"])
        err = d["pymupdf"]["error"] or d["pypdf"]["error"] or ""
        detail = f"{issues}; {err}".strip("; ")
        lines.append(
            f"| `{d['digest']}` | `{d['sha256'][:12]}` | {d['actual_byte_size']} | {d['declared_file_size']} | "
            f"`{pm}` | `{pp}` | {detail} |"
        )

    ocr_eval = report.get("ocr_sample_evaluation")
    if ocr_eval is not None:
        unevaluated = ocr_eval.get("unevaluated_samples")
        if unevaluated is None:
            unevaluated = ocr_eval["declared_samples"] - ocr_eval["evaluated_samples"]
        lines.extend(
            [
                "",
                "## 5. Reviewed OCR-Routing Sample Check",
                "",
                f"- **Labels SHA-256:** `{ocr_eval['labels_sha256']}`",
                f"- **Evaluated / declared samples:** `{ocr_eval['evaluated_samples']}/{ocr_eval['declared_samples']}` (`unevaluated={unevaluated}`)",
                f"- **Default `NativeOrOcr(require_images=True)` matched:** `{ocr_eval['matched_samples']}/{ocr_eval['declared_samples']}` (`disagreed={ocr_eval['disagreed_samples']}`)",
                f"- **Unconditional `NativeOrOcr(require_images=False)` matched:** `{ocr_eval['matched_unconditional_samples']}/{ocr_eval['declared_samples']}` (`disagreed={ocr_eval['disagreed_unconditional_samples']}`)",
                "",
                "| Digest | Page | Category | Expected OCR | `require_images=True` | `require_images=False` | Reason / Note |",
                "| --- | ---: | --- | --- | --- | --- | --- |",
            ]
        )
        for item in ocr_eval["results"]:
            lines.append(
                f"| `{item['digest']}` | {item['page']} | `{item['category']}` | `{item['expected_route_ocr']}` | "
                f"`{item['actual_route_ocr']}` | `{item.get('actual_route_ocr_unconditional')}` | "
                f"{item['route_reason']} — {item['note']} |"
            )

    return "\n".join(lines) + "\n"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Download or benchmark the external LoC Labs dot-gov 1,000-PDF corpus against spicy-docs readers."
    )
    sub = p.add_subparsers(dest="command", required=True)

    dl = sub.add_parser("download", help="Download and SHA-256-verify dot-gov PDFs into an external cache directory")
    dl.add_argument("--cache-dir", type=Path, required=True, help="External directory for cached PDFs and receipts")
    dl.add_argument("--metadata-csv", type=Path, required=True, help="Path to dotgov_pdf_metadata.csv")
    dl.add_argument("--manifest-json", type=Path, help="Optional path to pdf_data/manifest.json")
    dl.add_argument(
        "--metadata-sha256",
        default=DOTGOV_PDF_METADATA_SHA256,
        help="Expected SHA-256 of metadata.csv (defaults to LoC's published digest)",
    )
    dl.add_argument(
        "--manifest-sha256",
        default=DOTGOV_PDF_MANIFEST_SHA256,
        help="Expected SHA-256 of manifest.json when --manifest-json is supplied",
    )
    dl.add_argument("--concurrency", type=int, default=MAX_DOWNLOAD_CONCURRENCY, help="Worker count (1..4)")
    dl.add_argument("--timeout-seconds", type=float, default=120.0)

    ev = sub.add_parser("evaluate", help="Offline benchmark over SHA-256-verified cached PDFs (no network calls)")
    ev.add_argument("--cache-dir", type=Path, required=True, help="External directory holding pdfs/<sha256>.pdf")
    ev.add_argument("--metadata-csv", type=Path, required=True, help="Path to dotgov_pdf_metadata.csv")
    ev.add_argument("--manifest-json", type=Path, help="Optional path to pdf_data/manifest.json")
    ev.add_argument(
        "--metadata-sha256",
        default=DOTGOV_PDF_METADATA_SHA256,
        help="Expected SHA-256 of metadata.csv (defaults to LoC's published digest)",
    )
    ev.add_argument(
        "--manifest-sha256",
        default=DOTGOV_PDF_MANIFEST_SHA256,
        help="Expected SHA-256 of manifest.json when --manifest-json is supplied",
    )
    ev.add_argument("--ocr-sample-labels", type=Path, help="Optional JSON of reviewed page-level OCR routing labels")
    ev.add_argument(
        "--fail-on-ocr-disagreement",
        action="store_true",
        help="Exit 1 when default NativeOrOcr disagrees with --ocr-sample-labels",
    )
    ev.add_argument("--max-input-bytes", type=int, default=BENCHMARK_MAX_INPUT_BYTES)
    ev.add_argument("--min-chars", type=int, default=50)
    ev.add_argument("--allow-partial", action="store_true", help="Report partial caches (still exits non-zero)")
    ev.add_argument("--report-json", type=Path, required=True, help="Output JSON report path")
    ev.add_argument("--report-md", type=Path, help="Optional output Markdown summary path")
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "download":
        receipt = download_dotgov_pdfs(
            cache_dir=args.cache_dir,
            metadata_path=args.metadata_csv,
            manifest_path=args.manifest_json,
            expected_metadata_sha256=args.metadata_sha256 or None,
            expected_manifest_sha256=args.manifest_sha256 or None,
            concurrency=args.concurrency,
            timeout_seconds=args.timeout_seconds,
        )
        print(
            json.dumps(
                {k: v for k, v in receipt.items() if k != "failures" or len(v) <= 10},
                indent=2,
            )
        )
        return 0 if receipt["complete"] else 2

    if args.fail_on_ocr_disagreement and args.ocr_sample_labels is None:
        raise DotGovBenchmarkError("--fail-on-ocr-disagreement requires --ocr-sample-labels")

    report = evaluate_dotgov_pdfs(
        cache_dir=args.cache_dir,
        metadata_path=args.metadata_csv,
        manifest_path=args.manifest_json,
        expected_metadata_sha256=args.metadata_sha256 or None,
        expected_manifest_sha256=args.manifest_sha256 or None,
        ocr_sample_labels_path=args.ocr_sample_labels,
        max_input_bytes=args.max_input_bytes,
        min_chars=args.min_chars,
        allow_partial=args.allow_partial,
    )
    atomic_write_json(args.report_json, report)
    if args.report_md is not None:
        atomic_write_bytes(args.report_md, render_markdown_report(report).encode("utf-8"))
    print(json.dumps(report["summary"], indent=2))
    if not report["complete"]:
        return 2
    ocr_eval = report.get("ocr_sample_evaluation")
    if args.fail_on_ocr_disagreement and (
        ocr_eval is None
        or ocr_eval["disagreed_samples"] > 0
        or ocr_eval.get("unevaluated_samples", ocr_eval["declared_samples"] - ocr_eval["evaluated_samples"]) > 0
    ):
        return 1
    return 0


__all__ = [
    "BENCHMARK_MAX_INPUT_BYTES",
    "DEFAULT_MAX_INPUT_BYTES",
    "DOTGOV_MANIFEST_COLUMNS",
    "DOTGOV_METADATA_COLUMNS",
    "DOTGOV_PDF_MANIFEST_BYTES",
    "DOTGOV_PDF_MANIFEST_SHA256",
    "DOTGOV_PDF_METADATA_BYTES",
    "DOTGOV_PDF_METADATA_SHA256",
    "DOTGOV_PDF_PACKAGE_URL",
    "DOTGOV_RIGHTS_SUMMARY",
    "MAX_DOWNLOAD_CONCURRENCY",
    "DotGovBenchmarkError",
    "DotGovDownloadBlockedError",
    "DotGovPackageFile",
    "DotGovPdfEntry",
    "OcrSampleLabel",
    "build_parser",
    "contained_cache_path",
    "download_dotgov_pdfs",
    "evaluate_dotgov_pdfs",
    "main",
    "pdf_cache_path",
    "read_dotgov_metadata_csv",
    "read_dotgov_package_manifest",
    "read_ocr_sample_labels",
    "render_markdown_report",
]


if __name__ == "__main__":
    raise SystemExit(main())
