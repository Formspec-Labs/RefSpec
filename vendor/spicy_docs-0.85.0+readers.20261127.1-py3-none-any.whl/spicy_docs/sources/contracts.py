"""Stdlib-only shared contracts for reader metadata, cursors, locators, and visual review audits."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, runtime_checkable

ACQUISITION_MODES = ("bulk", "paged_api", "versioned_document", "extraction", "stream")
ACQUISITION_OUTCOMES = ("retained", "unchanged", "empty", "incomplete", "unavailable", "deleted", "failed")
VALID_LOCATOR_KINDS = ("raw_bytes", "decoded_text", "xml_xpath", "pdf_page", "archive_member", "api_record")
VALID_CURSOR_KINDS = ("none", "cursor", "offset", "page-number", "url", "watermark", "etag")


def canonical_sha256(data: bytes) -> str:
    """Return a canonical ``sha256:<hex>`` digest for exact bytes."""
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _check_non_negative_int(value: int | None, field_name: str) -> None:
    if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
        raise ValueError(f"{field_name} must be a non-negative integer or None")


def _check_positive_int(value: int | None, field_name: str) -> None:
    if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 1):
        raise ValueError(f"{field_name} must be a positive integer or None")


@dataclass(frozen=True, slots=True)
class LocatorSpan:
    """Explicitly typed locator separating raw bytes, decoded text, XML XPaths, and PDF coordinates."""

    locator_kind: Literal["raw_bytes", "decoded_text", "xml_xpath", "pdf_page", "archive_member", "api_record"]
    uri: str | None = None
    byte_offset: int | None = None
    byte_length: int | None = None
    char_offset: int | None = None
    char_length: int | None = None
    source_xpath: str | None = None
    page_number: int | None = None
    bbox: tuple[float, float, float, float] | None = None
    member_name: str | None = None
    encoding: str | None = None

    def __post_init__(self) -> None:
        if self.locator_kind not in VALID_LOCATOR_KINDS:
            raise ValueError(f"locator_kind must be one of {VALID_LOCATOR_KINDS}")
        _check_non_negative_int(self.byte_offset, "byte_offset")
        _check_non_negative_int(self.byte_length, "byte_length")
        _check_non_negative_int(self.char_offset, "char_offset")
        _check_non_negative_int(self.char_length, "char_length")
        _check_positive_int(self.page_number, "page_number")
        if self.bbox is not None and (
            len(self.bbox) != 4
            or any(
                isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(float(v)) for v in self.bbox
            )
        ):
            raise ValueError("bbox must be a 4-tuple of finite numbers")
        if self.locator_kind == "raw_bytes":
            if self.char_offset is not None or self.char_length is not None:
                raise ValueError("raw_bytes locator must not carry decoded char_offset/char_length")
        elif self.locator_kind == "decoded_text":
            if self.byte_offset is not None or self.byte_length is not None:
                raise ValueError("decoded_text locator must not carry raw byte_offset/byte_length")
        elif self.locator_kind == "xml_xpath":
            if not isinstance(self.source_xpath, str) or not self.source_xpath:
                raise ValueError("xml_xpath locator requires a nonempty source_xpath")
            if self.byte_offset is not None or self.byte_length is not None:
                raise ValueError("xml_xpath locator identifies an element position, not raw byte offsets")
        elif self.locator_kind == "pdf_page":
            if self.page_number is None:
                raise ValueError("pdf_page locator requires page_number >= 1")
            if self.byte_offset is not None or self.byte_length is not None:
                raise ValueError("pdf_page locator uses page/bbox coordinates, not raw byte offsets")
        elif self.locator_kind == "archive_member" and (not isinstance(self.member_name, str) or not self.member_name):
            raise ValueError("archive_member locator requires member_name")

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"locator_kind": self.locator_kind}
        for key in (
            "uri",
            "byte_offset",
            "byte_length",
            "char_offset",
            "char_length",
            "source_xpath",
            "page_number",
            "member_name",
            "encoding",
        ):
            value = getattr(self, key)
            if value is not None:
                out[key] = value
        if self.bbox is not None:
            out["bbox"] = list(self.bbox)
        return out


@dataclass(frozen=True, slots=True)
class SourceVersionIdentity:
    """Publisher and content version identity retained across refreshes and recovery."""

    source_id: str
    version_id: str | None = None
    content_sha256: str | None = None
    etag: str | None = None
    last_modified: str | None = None
    published_at: str | None = None
    rendition: str | None = None
    parser_version: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.source_id, str) or not self.source_id.strip():
            raise ValueError("source_id must be a nonempty string")

    def matches(self, other: SourceVersionIdentity) -> bool:
        """True when both identities share source_id and at least one non-None validator matches with no disagreement."""
        if self.source_id != other.source_id:
            return False
        compared = 0
        for field_name in ("content_sha256", "etag", "version_id", "last_modified"):
            a = getattr(self, field_name)
            b = getattr(other, field_name)
            if a is not None and b is not None:
                compared += 1
                if a != b:
                    return False
        return compared > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "version_id": self.version_id,
            "content_sha256": self.content_sha256,
            "etag": self.etag,
            "last_modified": self.last_modified,
            "published_at": self.published_at,
            "rendition": self.rendition,
            "parser_version": self.parser_version,
        }


@dataclass(frozen=True, slots=True)
class ReaderCursor:
    """Explicit continuation and conditional watermark state for resumable readers."""

    cursor_kind: Literal["none", "cursor", "offset", "page-number", "url", "watermark", "etag"] = "none"
    token: str | None = None
    offset: int | None = None
    page_number: int | None = None
    next_url: str | None = None
    watermark: str | None = None
    etag: str | None = None
    last_modified: str | None = None
    exhausted: bool = False

    def __post_init__(self) -> None:
        if self.cursor_kind not in VALID_CURSOR_KINDS:
            raise ValueError(f"cursor_kind must be one of {VALID_CURSOR_KINDS}")
        _check_non_negative_int(self.offset, "offset")
        _check_positive_int(self.page_number, "page_number")

    def to_dict(self) -> dict[str, Any]:
        return {
            "cursor_kind": self.cursor_kind,
            "token": self.token,
            "offset": self.offset,
            "page_number": self.page_number,
            "next_url": self.next_url,
            "watermark": self.watermark,
            "etag": self.etag,
            "last_modified": self.last_modified,
            "exhausted": self.exhausted,
        }


@dataclass(frozen=True, slots=True)
class BoundedLimits:
    """Declared execution and resource bounds enforced during acquisition or inspection."""

    max_bytes: int | None = None
    max_requests: int | None = None
    max_pages: int | None = None
    max_records: int | None = None
    max_members: int | None = None
    max_depth: int | None = None
    timeout_seconds: float | None = None
    truncated: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "max_bytes": self.max_bytes,
            "max_requests": self.max_requests,
            "max_pages": self.max_pages,
            "max_records": self.max_records,
            "max_members": self.max_members,
            "max_depth": self.max_depth,
            "timeout_seconds": self.timeout_seconds,
            "truncated": self.truncated,
        }


@dataclass(frozen=True, slots=True)
class ReaderFinding:
    """One structured diagnostic or audit finding produced while reading or checking source bytes."""

    code: str
    severity: Literal["info", "warning", "error"]
    message: str
    locator: LocatorSpan | Mapping[str, Any] | None = None
    count: int = 1

    def __post_init__(self) -> None:
        if not isinstance(self.code, str) or not self.code:
            raise ValueError("finding code must be nonempty")
        if self.severity not in ("info", "warning", "error"):
            raise ValueError("finding severity must be info, warning, or error")
        _check_positive_int(self.count, "count")

    def to_dict(self) -> dict[str, Any]:
        loc = (
            self.locator.to_dict()
            if isinstance(self.locator, LocatorSpan)
            else (dict(self.locator) if self.locator else None)
        )
        return {
            "code": self.code,
            "severity": self.severity,
            "message": self.message,
            "locator": loc,
            "count": self.count,
        }


@dataclass(frozen=True, slots=True)
class VisualReviewAudit:
    """Bounded audit record binding extracted PDF/XML/HTML observation back to immutable source identity."""

    source_sha256: str
    locator: LocatorSpan | Mapping[str, Any]
    rendition: str
    extraction_method: str
    findings: tuple[ReaderFinding, ...] = ()
    limits: BoundedLimits = field(default_factory=BoundedLimits)
    pages_reviewed: tuple[int, ...] = ()
    text_sha256: str | None = None
    reviewed_at: str | None = None
    truncated: bool = False

    def to_dict(self) -> dict[str, Any]:
        loc = self.locator.to_dict() if isinstance(self.locator, LocatorSpan) else dict(self.locator)
        return {
            "source_sha256": self.source_sha256,
            "locator": loc,
            "rendition": self.rendition,
            "extraction_method": self.extraction_method,
            "findings": [item.to_dict() for item in self.findings],
            "limits": self.limits.to_dict(),
            "pages_reviewed": list(self.pages_reviewed),
            "text_sha256": self.text_sha256,
            "reviewed_at": self.reviewed_at,
            "truncated": self.truncated,
        }


@dataclass(frozen=True, slots=True)
class ReaderMetadata:
    """Shared acquisition metadata emitted by maintained source readers."""

    source_id: str
    reader_class: str
    acquisition_mode: Literal["bulk", "paged_api", "versioned_document", "extraction", "stream"]
    parser_version: str
    request_scope: Mapping[str, Any]
    version_identity: SourceVersionIdentity
    cursor: ReaderCursor | None = None
    outcome: Literal["retained", "unchanged", "empty", "incomplete", "unavailable", "deleted", "failed"] = "retained"
    limits: BoundedLimits | None = None
    findings: tuple[ReaderFinding, ...] = ()
    observed_at: str | None = None
    locator: LocatorSpan | Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.acquisition_mode not in ACQUISITION_MODES:
            raise ValueError(f"acquisition_mode must be one of {ACQUISITION_MODES}")
        if self.outcome not in ACQUISITION_OUTCOMES:
            raise ValueError(f"outcome must be one of {ACQUISITION_OUTCOMES}")

    def to_dict(self) -> dict[str, Any]:
        loc = (
            self.locator.to_dict()
            if isinstance(self.locator, LocatorSpan)
            else (dict(self.locator) if self.locator else None)
        )
        return {
            "source_id": self.source_id,
            "reader_class": self.reader_class,
            "acquisition_mode": self.acquisition_mode,
            "parser_version": self.parser_version,
            "request_scope": dict(self.request_scope),
            "version_identity": self.version_identity.to_dict(),
            "cursor": self.cursor.to_dict() if self.cursor is not None else None,
            "outcome": self.outcome,
            "limits": self.limits.to_dict() if self.limits is not None else None,
            "findings": [item.to_dict() for item in self.findings],
            "observed_at": self.observed_at,
            "locator": loc,
        }


@runtime_checkable
class AcquisitionReader(Protocol):
    """Protocol for any source reader exposing structured acquisition metadata."""

    def reader_metadata(self) -> ReaderMetadata: ...


__all__ = [
    "ACQUISITION_MODES",
    "ACQUISITION_OUTCOMES",
    "VALID_CURSOR_KINDS",
    "VALID_LOCATOR_KINDS",
    "AcquisitionReader",
    "BoundedLimits",
    "LocatorSpan",
    "ReaderCursor",
    "ReaderFinding",
    "ReaderMetadata",
    "SourceVersionIdentity",
    "VisualReviewAudit",
    "canonical_sha256",
]
