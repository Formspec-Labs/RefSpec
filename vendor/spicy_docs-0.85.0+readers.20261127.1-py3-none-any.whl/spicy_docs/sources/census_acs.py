"""Literal ACS five-year county and congressional district cells, metadata and bounded credentialed capture.

The header decoder and variable partitioning adapt datamade/census at
3da5a1068164c27f6e83815f5d28ec300e184fdf (BSD-3-Clause; see census_acs.LICENSE).
Numeric conversion and positional merging are deliberately omitted: source
strings, annotations, nulls and geography-key membership remain authoritative.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING
from urllib.parse import quote, urlencode

from spicy_docs.reading.json_input import load_integer_json
from spicy_docs.transport.captured import CapturedBodyResponse, attached_capture
from spicy_docs.transport.credentials import CredentialRefusedError
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_payload, check_request_count, utc_now

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    import httpx

API = "https://api.census.gov/data"
# Nationwide 48-variable county responses are ~1.2 MB; cap each JSON response at 5 MiB.
MAX_BYTES = 5 * 1024 * 1024
MAX_VARIABLES = 192
# Census permits 50 requested fields; every split repeats NAME and GEO_ID.
VARIABLES_PER_REQUEST = 48
PILOT_VARIABLES = tuple(f"{group}_001{suffix}" for group in ("B01003", "B19013") for suffix in ("E", "M", "EA", "MA"))
SUPPORTED_GEOGRAPHIES = frozenset({"county", "congressional district"})
_GEOGRAPHY_RECORD_KEY = {"county": "county", "congressional district": "congressional_district"}
_VARIABLE = re.compile(r"[BC][0-9]{5}[A-I]?_[0-9]{3}(?:E|M|EA|MA)")
_STATE_CODE = re.compile(r"[0-9]{2}")
_COUNTY_CODE = re.compile(r"[0-9]{3}")
# Live Census ACS5 CD responses (2009-2024) emit 2-digit districts ("00" at-large, "01".."53",
# "98" DC/PR non-voting) and "ZZ" for "Congressional Districts not defined".
_CD_CODE = re.compile(r"(?:[0-9]{2}|ZZ)")
# GEO_ID summary level 500 embeds the 2-digit Congress session suffix (e.g. 5001800US for 118th,
# 5001900US for 119th) followed by 2-digit state FIPS and 2-character district code.
_CD_GEO_ID = re.compile(r"(500[0-9]{2}00US)([0-9]{2})([0-9]{2}|ZZ)")


class AcsError(ValueError):
    """The selected ACS response cannot be read without losing source meaning."""


@dataclass(frozen=True, slots=True)
class AcsSelection:
    vintage: int
    state: str
    variables: tuple[str, ...] = PILOT_VARIABLES
    geography: str = "county"

    def __post_init__(self) -> None:
        if type(self.vintage) is not int or not 2009 <= self.vintage <= 9999:
            # The upper bound is not pre-checked beyond a well-formed year: ACS
            # vintages are publisher-defined, and a nonexistent year refuses at
            # request time as unavailable.
            raise AcsError("ACS5 vintage must be an explicit year from 2009 onward")
        if not isinstance(self.state, str) or (self.state != "*" and _STATE_CODE.fullmatch(self.state) is None):
            raise AcsError("state must be '*' or its literal two-digit identifier")
        if not isinstance(self.geography, str) or self.geography not in SUPPORTED_GEOGRAPHIES:
            raise AcsError("geography must be 'county' or 'congressional district'")
        if (
            not isinstance(self.variables, tuple)
            or not 1 <= len(self.variables) <= MAX_VARIABLES
            or len(set(self.variables)) != len(self.variables)
            or any(not isinstance(v, str) or _VARIABLE.fullmatch(v) is None for v in self.variables)
        ):
            raise AcsError("variables must be a bounded unique tuple of ACS estimate/error/annotation names")
        if len(self.groups) > 12:
            raise AcsError("one ACS operation supports at most twelve metadata groups")

    @property
    def endpoint(self) -> str:
        return f"{API}/{self.vintage}/acs/acs5"

    @property
    def groups(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(v.split("_")[0] for v in self.variables))

    @property
    def chunks(self) -> tuple[tuple[str, ...], ...]:
        return tuple(
            self.variables[i : i + VARIABLES_PER_REQUEST] for i in range(0, len(self.variables), VARIABLES_PER_REQUEST)
        )

    def metadata_url(self, group: str) -> str:
        if group not in self.groups:
            raise AcsError("metadata group is outside the selected variables")
        return f"{self.endpoint}/groups/{group}.json"

    def data_url(self, variables: tuple[str, ...]) -> str:
        if variables not in self.chunks:
            raise AcsError("data variables differ from the selected request partition")
        return (
            self.endpoint
            + "?"
            + urlencode(
                {
                    "get": ",".join(("NAME", "GEO_ID", *variables)),
                    "for": f"{self.geography}:*",
                    "in": f"state:{self.state}",
                },
                safe=",:*",
                quote_via=quote,
            )
        )

    @property
    def urls(self) -> tuple[str, ...]:
        return tuple(self.metadata_url(g) for g in self.groups) + tuple(self.data_url(v) for v in self.chunks)


def descriptor(capture: CapturedBodyResponse) -> dict:
    """Credential-free capture identity retained beside the exact source bytes."""
    return {
        "request_url": capture.requested_url,
        "response_sha256": capture.sha256,
        "observed_at": capture.observed_at,
        "byte_size": capture.byte_size,
    }


def _capture_json(capture: CapturedBodyResponse, url: str) -> object:
    if (
        capture.requested_url != url
        or capture.resolved_url != url
        or capture.status_code != 200
        or capture.method != "GET"
        or capture.request_body is not None
        or capture.content_encoding != "identity"
        or (capture.content_type or "").split(";", 1)[0].strip().lower() != "application/json"
    ):
        raise AcsError("capture differs from the selected ACS URL, status or JSON representation")
    try:
        instant = datetime.fromisoformat(capture.observed_at)
    except (TypeError, ValueError) as error:
        raise AcsError("capture requires an observed timestamp") from error
    if instant.utcoffset() is None:
        raise AcsError("capture timestamp needs a timezone")
    raw = check_payload(capture.body, MAX_BYTES, label="ACS response", error_type=AcsError, allow_empty=False)
    return load_integer_json(raw, source="ACS response", error_type=AcsError)


def _max_table_rows(selection: AcsSelection) -> int:
    # Header + up to 5,000 nationwide counties (3,222 live in 2024), or 1,000 for single-state / CDs (~440 nationwide).
    return 5001 if selection.geography == "county" and selection.state == "*" else 1001


def _validate_geography_row(
    selection: AcsSelection, row: dict[str, str | None], *, cd_prefix: str | None
) -> tuple[str, str, str | None]:
    state = row["state"]
    if not isinstance(state, str) or (
        _STATE_CODE.fullmatch(state) is None if selection.state == "*" else state != selection.state
    ):
        raise AcsError("ACS geography state differs from the selected state")
    code = row[selection.geography]
    name = row["NAME"]
    geo_id = row["GEO_ID"]
    if not isinstance(name, str) or not name or not isinstance(geo_id, str):
        raise AcsError("ACS geography name or GEO_ID is missing")
    if selection.geography == "county":
        if not isinstance(code, str) or _COUNTY_CODE.fullmatch(code) is None or geo_id != f"0500000US{state}{code}":
            raise AcsError("ACS county identity differs from the selected state or county GEO_ID")
        return state, code, cd_prefix
    if not isinstance(code, str) or _CD_CODE.fullmatch(code) is None:
        raise AcsError("ACS congressional district code differs from supported two-character format")
    match = _CD_GEO_ID.fullmatch(geo_id)
    if match is None or match[2] != state or match[3] != code:
        raise AcsError("ACS congressional district GEO_ID differs from 500<session>00US<state><district>")
    if cd_prefix is not None and match[1] != cd_prefix:
        raise AcsError("ACS congressional district response mixes Congress session GEO_ID prefixes")
    return state, code, match[1]


def acs_records(selection: AcsSelection, captures: Sequence[CapturedBodyResponse]) -> tuple[dict, ...]:
    """Join exact request partitions by geography; retain every source cell and locator.

    No count is stated by this API. An empty array without a header refuses;
    header-only results mean requested-empty, never absence. Changed membership,
    repeated geography, a short row or mismatched metadata refuses the whole set.
    """
    if len(captures) != len(selection.urls):
        raise AcsError("capture inventory differs from the selected requests")
    parsed = [_capture_json(c, url) for c, url in zip(captures, selection.urls, strict=True)]
    variables, metadata_sources = {}, {}
    for index, group in enumerate(selection.groups):
        value = parsed[index]
        if not isinstance(value, dict) or not isinstance(value.get("variables"), dict):
            raise AcsError("ACS variable metadata must contain variables")
        for variable in (v for v in selection.variables if v.split("_")[0] == group):
            field = value["variables"].get(variable)
            if (
                not isinstance(field, dict)
                or field.get("group") != group
                or not isinstance(field.get("label"), str)
                or not field["label"]
                or field.get("predicateType") not in {"int", "long", "float", "string"}
            ):
                raise AcsError("selected variable metadata is missing or differs")
            variables[variable] = field
            metadata_sources[variable] = {k: v for k, v in descriptor(captures[index]).items() if k != "byte_size"} | {
                "json_pointer": f"/variables/{variable}"
            }
    record_key = _GEOGRAPHY_RECORD_KEY[selection.geography]
    max_rows = _max_table_rows(selection)
    merged: dict[tuple[str, str], dict] = {}
    cd_prefix: str | None = None
    for part, requested in enumerate(selection.chunks, start=len(selection.groups)):
        table, capture = parsed[part], captures[part]
        if not isinstance(table, list) or not table or not isinstance(table[0], list):
            raise AcsError("ACS data must be a header-plus-row array")
        header = table[0]
        expected = {"NAME", "GEO_ID", "state", selection.geography, *requested}
        if any(not isinstance(v, str) for v in header) or len(set(header)) != len(header) or set(header) != expected:
            raise AcsError("ACS header omits, repeats or adds selected fields")
        if len(table) > max_rows:
            raise AcsError("selected scope exceeds the bounded geography inventory")
        rows: dict[tuple[str, str], dict] = {}
        for row_index, cells in enumerate(table[1:], start=1):
            if (
                not isinstance(cells, list)
                or len(cells) != len(header)
                or any(c is not None and not isinstance(c, str) for c in cells)
            ):
                raise AcsError("ACS row shape or literal cell type differs")
            row = dict(zip(header, cells, strict=True))
            state, code, cd_prefix = _validate_geography_row(selection, row, cd_prefix=cd_prefix)
            key = (state, code)
            if key in rows:
                raise AcsError("ACS response repeats geography")
            values = {v: row[v] for v in requested}
            sources = {
                v: {k: item for k, item in descriptor(capture).items() if k != "byte_size"}
                | {"row_index": row_index, "column_index": header.index(v)}
                for v in requested
            }
            rows[key] = {
                "dataset": "acs/acs5",
                "vintage": selection.vintage,
                "geography": selection.geography,
                "state": state,
                record_key: code,
                "name": row["NAME"],
                "geo_id": row["GEO_ID"],
                "values": values,
                "value_sources": sources,
                "variables": variables,
                "metadata_sources": metadata_sources,
            }
        if part == len(selection.groups):
            merged = rows
        else:
            if rows.keys() != merged.keys():
                raise AcsError("ACS split requests have mismatched geography membership")
            for key, row in rows.items():
                if any(row[f] != merged[key][f] for f in ("name", "geo_id")):
                    raise AcsError("ACS split requests disagree on geography identity")
                merged[key]["values"].update(row["values"])
                merged[key]["value_sources"].update(row["value_sources"])
    return tuple(merged.values())


def county_records(selection: AcsSelection, captures: Sequence[CapturedBodyResponse]) -> tuple[dict, ...]:
    """Join exact county request partitions by geography; retain every source cell and locator."""
    if selection.geography != "county":
        raise AcsError("county_records requires geography='county'; use acs_records")
    return acs_records(selection, captures)


def _key_transport(api_key: str, transport):
    """Attach Census's required query key only at HTTP dispatch, outside capture URLs."""
    import httpx

    if not isinstance(api_key, str) or re.fullmatch(r"[A-Za-z0-9]{8,128}", api_key) is None:
        raise CredentialRefusedError("Census acquisition requires an explicit API key")
    underlying = transport if transport is not None else httpx.HTTPTransport()

    class KeyTransport(httpx.BaseTransport):
        def handle_request(self, request):
            if (
                request.url.scheme != "https"
                or request.url.host != "api.census.gov"
                or request.url.port not in (None, 443)
                or request.url.userinfo
                or "key" in request.url.params
            ):
                raise CredentialRefusedError("Census credential target differs from the official API")
            keyed = httpx.Request(
                request.method,
                request.url.copy_add_param("key", api_key),
                headers=request.headers,
                stream=request.stream,
                extensions=request.extensions,
            )
            response = underlying.handle_request(keyed)
            # The transport never follows redirects. Restore the public locator
            # before the shared capture client observes response.url or errors.
            response.request = request
            return response

        def close(self):
            underlying.close()

    return KeyTransport()


class AcsAcquirer(SourceAcquirer):
    """One bounded, explicitly selected county query plus its variable metadata."""

    def __init__(
        self,
        *,
        api_key: str,
        max_requests: int = 16,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        check_request_count(max_requests)
        if max_requests > 64:
            raise AcsError("ACS operation request budget cannot exceed 64 attempts")
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=30,
            min_request_interval_seconds=0.2,
            user_agent="spicy-docs-census-acs/1",
            label="Census ACS",
            error_type=AcsError,
            context_key="census_acs_acquisition",
            transport=_key_transport(api_key, transport),
            clock=clock,
            credential=api_key,
        )

    def acquire(
        self, selection: AcsSelection, *, retain: Callable[[CapturedBodyResponse], None]
    ) -> tuple[CapturedBodyResponse, ...]:
        """Retain each validated raw capture immediately; failure never yields a partial county set."""
        captures = []
        for index, url in enumerate(selection.urls):
            try:
                _, capture = self.capture_validated(
                    url,
                    media_types=("application/json",),
                    parse=lambda c, limit: _capture_json(c, c.requested_url),
                    max_bytes=MAX_BYTES,
                    unavailable=lambda c: AcsError("selected ACS resource unavailable"),
                    context={
                        "operation": f"{selection.geography}-query",
                        "vintage": selection.vintage,
                        "state": selection.state,
                    },
                    reset_budget=index == 0,
                )
            except AcsError as error:
                # Non-success statuses can fail before SourceAcquirer's body
                # check. Never expose their credential echo as retained evidence.
                failed = attached_capture(error)
                refused = getattr(error, "refused_response", None)
                bodies = (failed.body if failed else None, getattr(refused, "response_bytes", None))
                if self._credential is not None and any(
                    body is not None and self._credential.encode() in body for body in bodies
                ):
                    error.__dict__.pop("capture", None)
                    error.__dict__.pop("refused_response", None)
                    raise CredentialRefusedError(
                        "Census response echoed the API credential; capture was not retained"
                    ) from None
                raise
            retain(capture)
            captures.append(capture)
        acs_records(selection, captures)
        return tuple(captures)
