"""House filing index facts and bounded, explicitly selected original captures.

Index parsing is an attributed port of austin-starks/congressional-disclosures
at 2965e8796bd4cb9423a83b964a1f9dbd076a0ad6 (MIT; see NOTICE). Unlike the
upstream PTR selector, this reader retains every filing category and literal cell.
PDF transaction interpretation is separate from deterministic index discovery.
"""

# House index parser
#
# The deterministic index reader in src/spicy_docs/sources/house_disclosures.py adapts
# parseHouseIndexTsv and parseHouseIndexZip from austin-starks/congressional-disclosures
# at 2965e8796bd4cb9423a83b964a1f9dbd076a0ad6.
#
# MIT License
#
# Copyright (c) 2026 Austin Starks
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import hashlib
import re
import zlib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from io import BytesIO
from zipfile import BadZipFile, ZipFile

from spicy_docs.reading.pdf_bytes import check_pdf_bytes, terminal_xref_offset
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_final_url,
    check_request_count,
    check_timing,
    limit_byte_bound,
)

ORIGIN = "https://disclosures-clerk.house.gov"
PARSER_VERSION = "house-disclosures-index-v1"
MAX_BYTES = 32 * 1024**2
MIN_INDEX_YEAR = 2008
DEFAULT_MAX_INDEX_YEAR = 2026
DEFAULT_INDEX_YEARS = tuple(range(MIN_INDEX_YEAR, DEFAULT_MAX_INDEX_YEAR + 1))
DEFAULT_MAX_REQUESTS = 64
PTR_FILING_TYPE = "P"
OUT_OF_SCOPE_ANNUAL_FILING_TYPES = frozenset({"A", "B"})
_COLUMNS = ("prefix", "last", "first", "suffix", "filingtype", "statedst", "year", "filingdate", "docid")


class HouseDisclosureError(ValueError):
    """A selected House input cannot establish the requested source facts."""


def _year(year: object) -> int:
    if type(year) is not int or not 2008 <= year <= 2100:
        raise HouseDisclosureError("House index year must be an integer from 2008 to 2100")
    return year


def index_url(year: int) -> str:
    return f"{ORIGIN}/public_disc/financial-pdfs/{_year(year)}FD.zip"


def report_url(year: int, doc_id: str, *, ptr: bool) -> str:
    """Construct the publisher's route; an index row does not prove the PDF is held."""
    if not isinstance(doc_id, str) or re.fullmatch(r"[0-9]+", doc_id) is None:
        raise HouseDisclosureError("House DocID must contain only ASCII digits")
    directory = "ptr-pdfs" if ptr else "financial-pdfs"
    return f"{ORIGIN}/public_disc/{directory}/{_year(year)}/{doc_id}.pdf"


@dataclass(frozen=True)
class HouseIndexRow:
    index_year: int
    source_line: int
    doc_id: str
    filing_type: str
    filing_date_raw: str
    prefix: str
    first: str
    last: str
    suffix: str
    state_district: str
    year_raw: str
    raw_cells: tuple[tuple[str, str], ...]

    @property
    def url(self) -> str:
        return report_url(self.index_year, self.doc_id, ptr=self.filing_type == "P")


@dataclass(frozen=True)
class HouseIndexCapture:
    """One captured House annual disclosure index ZIP and its parsed rows."""

    year: int
    rows: tuple[HouseIndexRow, ...]
    capture: CapturedBodyResponse


@dataclass(frozen=True)
class HousePtrCapture:
    """One captured native House PTR PDF and its content hash."""

    year: int
    doc_id: str
    sha256: str
    capture: CapturedBodyResponse


def index_years(
    years: Iterable[int] | None = None,
    *,
    start_year: int = MIN_INDEX_YEAR,
    end_year: int = DEFAULT_MAX_INDEX_YEAR,
) -> tuple[int, ...]:
    """Resolve and validate a non-empty, duplicate-free House index year sequence."""
    if years is not None:
        selected = tuple(_year(year) for year in years)
        if not selected:
            raise HouseDisclosureError("House index years must not be empty")
        if len(set(selected)) != len(selected):
            raise HouseDisclosureError("House index years must not repeat")
        return selected
    first = _year(start_year)
    last = _year(end_year)
    if first > last:
        raise HouseDisclosureError("House index start_year must not exceed end_year")
    return tuple(range(first, last + 1))


def parse_index_zips(archives: Mapping[int, bytes] | Iterable[tuple[int, bytes]]) -> tuple[HouseIndexRow, ...]:
    """Parse multiple annual House index ZIPs deterministically, preserving year and physical line order."""
    if isinstance(archives, Mapping):
        entries = list(archives.items())
    else:
        entries = [item for item in archives]
    if not entries:
        raise HouseDisclosureError("House index archive batch must not be empty")
    seen_years: set[int] = set()
    combined: list[HouseIndexRow] = []
    for entry in entries:
        if not isinstance(entry, tuple) or len(entry) != 2:
            raise HouseDisclosureError("House index batch entries must be (year, zip_bytes) pairs")
        year, body = entry
        checked_year = _year(year)
        if checked_year in seen_years:
            raise HouseDisclosureError(f"House index batch repeats year {checked_year}")
        if not isinstance(body, bytes):
            raise HouseDisclosureError("House index ZIP must be bytes")
        seen_years.add(checked_year)
        combined.extend(parse_index_zip(body, year=checked_year))
    return tuple(combined)


def is_native_ptr_candidate(row: HouseIndexRow) -> bool:
    """Return True only for Periodic Transaction Reports ('P'); annual A/B and other forms stay out of scope."""
    if not isinstance(row, HouseIndexRow):
        raise HouseDisclosureError("House index row must be a HouseIndexRow")
    return row.filing_type == PTR_FILING_TYPE


def select_ptr_rows(rows: Iterable[HouseIndexRow]) -> tuple[HouseIndexRow, ...]:
    """Retain only 'P' PTR rows, keeping Forms A, B, and other non-PTR categories explicitly out of scope."""
    return tuple(row for row in rows if is_native_ptr_candidate(row))


def parse_index_tsv(body: bytes, *, year: int) -> tuple[HouseIndexRow, ...]:
    """Read all categories, retaining original cells and physical TSV line locators.

    A header-only index is an observed empty input. Missing columns, inconsistent
    row widths/years refuse. Repeated DocIDs remain distinct line observations;
    a downstream report selection must resolve any ambiguous index identity.
    """
    _year(year)
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House index exceeds the byte bound or is not bytes")
    try:
        lines = body.decode("utf-8-sig").splitlines()
    except UnicodeDecodeError as error:
        raise HouseDisclosureError("House index is not UTF-8") from error
    header = lines[0].split("\t") if lines else []
    keys = [name.strip().lower() for name in header]
    if len(keys) != len(set(keys)) or not set(_COLUMNS).issubset(keys):
        raise HouseDisclosureError("House index has duplicate or missing required columns")
    result = []
    for number, line in enumerate(lines[1:], 2):
        if not line.strip():
            continue
        values = line.split("\t")
        if len(values) != len(header):
            raise HouseDisclosureError(f"House index line {number} has an inconsistent column count")
        row = dict(zip(keys, values, strict=True))
        cell = {key: value.strip() for key, value in row.items()}
        doc_id = cell["docid"]
        report_url(year, doc_id, ptr=cell["filingtype"].upper() == "P")
        if cell["year"] != str(year) or not cell["filingtype"]:
            raise HouseDisclosureError(f"House index line {number} has a wrong year or blank category")
        result.append(
            HouseIndexRow(
                year,
                number,
                doc_id,
                cell["filingtype"].upper(),
                row["filingdate"],
                row["prefix"],
                row["first"],
                row["last"],
                row["suffix"],
                row["statedst"],
                row["year"],
                tuple(zip(header, values, strict=True)),
            )
        )
    return tuple(result)


def parse_index_zip(body: bytes, *, year: int) -> tuple[HouseIndexRow, ...]:
    """Read the exact named text member, leaving the original ZIP authoritative."""
    _year(year)
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House ZIP exceeds the byte bound or is not bytes")
    member = f"{year}FD.txt"
    try:
        with ZipFile(BytesIO(body)) as archive:
            matches = [info for info in archive.infolist() if info.filename == member]
            if len(matches) != 1 or matches[0].file_size > MAX_BYTES or matches[0].flag_bits & 1:
                raise HouseDisclosureError("House ZIP lacks one bounded unencrypted year index")
            with archive.open(matches[0]) as member_stream:
                member_body = member_stream.read(MAX_BYTES + 1)
            if len(member_body) > MAX_BYTES:
                raise HouseDisclosureError("House index exceeds the byte bound or is not bytes")
            return parse_index_tsv(member_body, year=year)
    except (BadZipFile, zlib.error, EOFError, RuntimeError, OSError) as error:
        raise HouseDisclosureError("House index ZIP cannot be read") from error


def validate_pdf(body: bytes) -> str:
    if not isinstance(body, bytes) or len(body) > MAX_BYTES:
        raise HouseDisclosureError("House PDF exceeds the byte bound or is not bytes")
    check_pdf_bytes(body, error_type=HouseDisclosureError, label="House disclosure PDF")
    if terminal_xref_offset(body) is None:
        raise HouseDisclosureError("House disclosure PDF lacks a terminal cross-reference")
    return "sha256:" + hashlib.sha256(body).hexdigest()


class HouseDisclosureAcquirer(SourceAcquirer):
    """Direct public file capture only; no search acknowledgement or access bypass."""

    def __init__(
        self,
        *,
        max_requests: int = DEFAULT_MAX_REQUESTS,
        max_bytes: int = MAX_BYTES,
        timeout_seconds: float = 45,
        min_request_interval_seconds: float = 0.5,
        transport=None,
    ):
        check_request_count(max_requests)
        limit = limit_byte_bound(max_bytes, name="max_bytes", cap=MAX_BYTES, error_type=HouseDisclosureError)
        check_timing(timeout_seconds, min_request_interval_seconds)
        self.max_requests = max_requests
        self.max_bytes = limit
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=timeout_seconds,
            min_request_interval_seconds=min_request_interval_seconds,
            user_agent="spicy-docs-house-disclosures/1.0",
            label="House disclosures",
            error_type=HouseDisclosureError,
            context_key="house_disclosure_acquisition",
            keyless=True,
            transport=transport,
        )

    def _acquire(self, url, parse, media_types, *, reset_budget: bool = True):
        def checked(capture, _limit):
            if capture.status_code != 200:
                raise HouseDisclosureError(f"House source answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                url,
                error_type=HouseDisclosureError,
                message="House final URL differs from the selected file",
            )
            return parse(capture.body)

        return self.capture_validated(
            url,
            media_types=media_types,
            parse=checked,
            max_bytes=self.max_bytes,
            unavailable=lambda capture: HouseDisclosureError(f"House source unavailable (HTTP {capture.status_code})"),
            context={"url": url},
            reset_budget=reset_budget,
            max_attempts=1,
        )

    def acquire_index(self, *, year: int, reset_budget: bool = True):
        return self._acquire(
            index_url(year),
            lambda body: parse_index_zip(body, year=year),
            ("application/zip", "application/x-zip-compressed", "application/octet-stream"),
            reset_budget=reset_budget,
        )

    def acquire_indexes(
        self,
        years: Iterable[int] | None = None,
        *,
        start_year: int = MIN_INDEX_YEAR,
        end_year: int = DEFAULT_MAX_INDEX_YEAR,
    ) -> tuple[HouseIndexCapture, ...]:
        """Acquire a validated multi-year sequence of House disclosure index ZIPs under one request budget."""
        selected = index_years(years, start_year=start_year, end_year=end_year)
        self._http.reset_budget()
        results: list[HouseIndexCapture] = []
        for yr in selected:
            rows, capture = self.acquire_index(year=yr, reset_budget=False)
            results.append(HouseIndexCapture(year=yr, rows=rows, capture=capture))
        return tuple(results)

    def acquire_ptr(self, *, year: int, doc_id: str, reset_budget: bool = True):
        return self._acquire(
            report_url(year, doc_id, ptr=True),
            validate_pdf,
            ("application/pdf", "application/octet-stream"),
            reset_budget=reset_budget,
        )

    def acquire_ptrs(self, selections: Iterable[HouseIndexRow | tuple[int, str]]) -> tuple[HousePtrCapture, ...]:
        """Acquire native 'P' PTR PDFs in batch; explicitly refuses non-'P' (including Forms A/B) selections."""
        pairs: list[tuple[int, str]] = []
        for item in selections:
            if isinstance(item, HouseIndexRow):
                if not is_native_ptr_candidate(item):
                    raise HouseDisclosureError(
                        f"House filing type {item.filing_type!r} is outside native PTR scope; only 'P' is supported"
                    )
                year, doc_id = item.index_year, item.doc_id
            elif isinstance(item, tuple) and len(item) == 2:
                year, doc_id = item
            else:
                raise HouseDisclosureError("House PTR selection must be a HouseIndexRow or (year, doc_id) tuple")
            report_url(year, doc_id, ptr=True)
            pairs.append((year, doc_id))
        self._http.reset_budget()
        results: list[HousePtrCapture] = []
        for year, doc_id in pairs:
            sha256, capture = self.acquire_ptr(year=year, doc_id=doc_id, reset_budget=False)
            results.append(HousePtrCapture(year=year, doc_id=doc_id, sha256=sha256, capture=capture))
        return tuple(results)
