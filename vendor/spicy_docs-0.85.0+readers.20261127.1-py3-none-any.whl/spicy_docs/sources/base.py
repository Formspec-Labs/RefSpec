"""Base interface and shared metadata contracts for acquisition readers.

Subclass `Reader` to add a connector that pulls records from an external
system (S3 bucket, REST API, scraped HTML, etc.). Source-native publication
uses `SourceNativeProfile` and the shared release publisher.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator

from spicy_docs.sources.contracts import (
    ACQUISITION_MODES,
    ACQUISITION_OUTCOMES,
    VALID_CURSOR_KINDS,
    VALID_LOCATOR_KINDS,
    AcquisitionReader,
    BoundedLimits,
    LocatorSpan,
    ReaderCursor,
    ReaderFinding,
    ReaderMetadata,
    SourceVersionIdentity,
    VisualReviewAudit,
    canonical_sha256,
)


class Reader(ABC):
    """A connector that reads records from an external system.

    Subclasses configure connection details via ``__init__`` and yield
    records (dicts) from ``iter_records``. Pagination, batching, retries,
    and dedup semantics are the subclass's responsibility.

    Subclasses that pull from a keyed source (S3 keys, URLs, file paths)
    should populate ``last_keys`` during ``iter_records`` with the keys
    *successfully* consumed, so the caller can append them to a manifest.
    Keys that were attempted but failed go on ``failed_keys`` instead — the
    caller must NOT manifest these, so the next run retries them. Both default
    to empty lists for sources without addressable keys.
    """

    def __init__(self) -> None:
        self.last_keys: list[str] = []
        self.failed_keys: list[str] = []

    @abstractmethod
    def iter_records(self) -> Iterator[dict]: ...

    def cursor_state(self) -> ReaderCursor | None:
        """Return the current explicit continuation/watermark cursor, when tracked."""
        return getattr(self, "_cursor_state", None)

    def version_identity(self) -> SourceVersionIdentity | None:
        """Return explicit publisher/content version identity, when known."""
        return getattr(self, "_version_identity", None)

    def reader_metadata(self) -> ReaderMetadata:
        """Return shared reader metadata, cursor, version identity, and findings."""
        source_id = str(getattr(self, "source_id", type(self).__name__))
        parser_version = str(getattr(self, "parser_version", "1"))
        mode = getattr(self, "acquisition_mode", "stream")
        scope = dict(getattr(self, "request_scope", {}))
        version = self.version_identity() or SourceVersionIdentity(
            source_id=source_id,
            parser_version=parser_version,
        )
        failed = list(getattr(self, "failed_keys", ()))
        extra_findings: list[ReaderFinding] = list(getattr(self, "reader_findings", ()))
        if failed:
            extra_findings.append(
                ReaderFinding(
                    code="READER-FAILED-KEYS",
                    severity="warning",
                    message=f"{len(failed)} source key(s) failed during read",
                    count=len(failed),
                )
            )
        return ReaderMetadata(
            source_id=source_id,
            reader_class=f"{type(self).__module__}.{type(self).__qualname__}",
            acquisition_mode=mode,
            parser_version=parser_version,
            request_scope=scope,
            version_identity=version,
            cursor=self.cursor_state(),
            outcome=getattr(self, "acquisition_outcome", "retained"),
            limits=getattr(self, "bounded_limits", None),
            findings=tuple(extra_findings),
            observed_at=getattr(self, "observed_at", None),
            locator=getattr(self, "source_locator", None),
        )


__all__ = [
    "ACQUISITION_MODES",
    "ACQUISITION_OUTCOMES",
    "VALID_CURSOR_KINDS",
    "VALID_LOCATOR_KINDS",
    "AcquisitionReader",
    "BoundedLimits",
    "LocatorSpan",
    "Reader",
    "ReaderCursor",
    "ReaderFinding",
    "ReaderMetadata",
    "SourceVersionIdentity",
    "VisualReviewAudit",
    "canonical_sha256",
]
