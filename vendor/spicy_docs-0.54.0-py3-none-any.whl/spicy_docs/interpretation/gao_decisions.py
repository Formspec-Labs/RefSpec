"""GAO's outcome for a legal decision, read from the sentence its own listing states, through a closed table.

GAO's Month in Review and Annual Index state a decision's outcome as a sentence ("We deny the protest."), which
``sources.gao.month_in_review`` keeps word for word as ``status``. This module reads that sentence into one of six
outcomes through an exact-sentence table (``gao_decision_outcomes.json``), never a pattern: a sentence the table does
not hold is no outcome and is counted, so a wording GAO writes later is seen rather than guessed. The table's
provenance and the forms it leaves unmapped are in the file itself.

``request`` means the sentence decides only a request -- reconsideration, costs, reimbursement, dismissal. A
sentence that decides the protest and a request reads the protest's outcome ("We deny the protest and the request
for costs." is ``denied``; "We grant the request for reconsideration and sustain the protest." is ``sustained``),
since the protest is what the decision is counted by. GAO's docket pages state one coarser outcome per docket number ("Sustained", "Denied"), not
per decision page; this reading is the listing's, not the docket's.

Interpretation lives here, not in a host (``docs/decisions.md``, 2026-09-19): a host applies
:func:`decision_outcome` to every row it holds, so a new table version needs no re-read of the listing.
"""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from importlib.resources import files
from types import MappingProxyType

#: Moves whenever ``gao_decision_outcomes.json`` changes; ``tests/test_gao_decisions.py`` pins the file's digest.
GAO_OUTCOME_RULE_VERSION = "002"
GAO_OUTCOME_RULE = f"gao-decision-outcome/{GAO_OUTCOME_RULE_VERSION}"
GAO_DECISION_OUTCOMES: tuple[str, ...] = (
    "sustained",
    "sustained_in_part",
    "denied",
    "dismissed",
    "denied_in_part_dismissed_in_part",
    "request",
)
OUTCOME_TABLE = "gao_decision_outcomes.json"


def _load() -> tuple[Mapping[str, str], frozenset[str]]:
    table = json.loads(files(__package__).joinpath(OUTCOME_TABLE).read_text(encoding="utf-8"))
    if table["rule"] != GAO_OUTCOME_RULE or tuple(table["outcomes"]) != GAO_DECISION_OUTCOMES:
        raise ValueError(f"{OUTCOME_TABLE} states another rule or outcome vocabulary than {GAO_OUTCOME_RULE}")
    by_sentence: dict[str, str] = {}
    for outcome, sentences in table["outcomes"].items():
        for sentence in sentences:
            if sentence in by_sentence:
                raise ValueError(f"{OUTCOME_TABLE} lists {sentence!r} twice")
            by_sentence[sentence] = outcome
    unmapped = frozenset(table["unmapped"])
    if unmapped & by_sentence.keys() or len(unmapped) != len(table["unmapped"]):
        raise ValueError(f"{OUTCOME_TABLE} lists an unmapped sentence twice or also maps it")
    return MappingProxyType(by_sentence), unmapped


#: Every sentence the table reads, to its outcome; and the seen sentences it deliberately reads as none.
OUTCOME_BY_SENTENCE, UNMAPPED_SENTENCES = _load()


@dataclass(frozen=True, slots=True)
class DecisionOutcome:
    """``outcome`` and ``rule`` are None together: no sentence, or one the table does not read."""

    outcome: str | None
    rule: str | None
    status: str | None


def decision_outcome(status: str | None) -> DecisionOutcome:
    """The outcome GAO's sentence states, by the closed table; None where there is no sentence or the table lacks it."""
    outcome = None if status is None else OUTCOME_BY_SENTENCE.get(status)
    return DecisionOutcome(outcome, None if outcome is None else GAO_OUTCOME_RULE, status)


def unmapped_sentences(statuses: Iterable[str | None]) -> Counter[str]:
    """How many times each stated sentence read as no outcome, for a host's run journal: a count the table should
    shrink, not a silent NULL. A sentence the table lists as unmapped is counted too; a missing sentence is not."""
    return Counter(status for status in statuses if status is not None and status not in OUTCOME_BY_SENTENCE)


__all__ = [
    "GAO_DECISION_OUTCOMES",
    "GAO_OUTCOME_RULE",
    "GAO_OUTCOME_RULE_VERSION",
    "OUTCOME_BY_SENTENCE",
    "UNMAPPED_SENTENCES",
    "DecisionOutcome",
    "decision_outcome",
    "unmapped_sentences",
]
