"""Legislative stage and signing date from a bill's retained actions.

The progress ladder keeps its existing keys. Failed passage and veto are
separate outcomes, not positions on that ladder. The latest classified action
wins, except that enactment is terminal, a veto remains until enactment is
recorded, once a chamber has passed the bill no introduction or committee
step moves it back (a vitiated passage is undone), once both chambers have
agreed to one text nothing below `cleared` moves it back, and before passage
only a referral of the bill lowers `calendared`. Full source text, matched
rule, and action location stay inspectable.

A mention is not an event: an action reads a step only where it is that step,
so a publisher code that names the event is read before the text (see
``RUNG_CODES`` and ``SPECIAL_RULE_CODES``), and text that only cites or
describes one -- "originally introduced by", "text as reported", a special
rule's report, a star print -- classifies nothing.

The unitedstates/congress action tests supplied independent veto, failed-vote,
and resolution cases; see docs/sources/bill-stage.md for source pins and the
bounded BILLSTATUS comparison. Only narrowly qualified publisher codes override
prose: the executive E30000 code occurs on both signatures and vetoes.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace
from types import MappingProxyType
from typing import NamedTuple

DEFAULT_STAGE = "introduced"
LAW_STAGE = "law"
CLEARED = "cleared"

HOUSE, SENATE = "House", "Senate"
ORIGIN_CHAMBERS_BY_NAME: frozenset[str] = frozenset({HOUSE, SENATE})
#: The chamber a measure originates in, read from its type. BILLSTATUS ``originChamber`` agrees on every one of the
#: 173,278 bills of the 108th-119th Congresses in the live bill-family generation (``fd1bb730...``, 2026-10-03).
ORIGIN_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {
        **dict.fromkeys(("hr", "hres", "hjres", "hconres"), HOUSE),
        **dict.fromkeys(("s", "sres", "sjres", "sconres"), SENATE),
    }
)
#: The chamber whose system entered an action, by the publisher's ``sourceSystem/name``. The Senate states only its
#: name (no code); the Library of Congress system names no chamber.
SOURCE_SYSTEM_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {"Senate": SENATE, "House floor actions": HOUSE, "House committee actions": HOUSE}
)
#: A matcher whose text names no chamber, so the system that entered the action says where it happened: every one of
#: the 1,936 House "Held at the desk." actions names neither chamber, and 101 of the Senate's name both.
SOURCE_SYSTEM = "source system"


@dataclass(frozen=True, slots=True)
class Stage:
    """One rung, with the display strings that travel with the vocabulary."""

    key: str
    label: str
    short: str


STAGES: tuple[Stage, ...] = (
    Stage("introduced", "Introduced", "Intro"),
    Stage("committee", "In committee", "Cmte"),
    # Owner decision, round 5 (2026-10-03): a placement on the bill's own chamber's calendar is a rung of its own, and so
    # is passage by both chambers, which `passed_chamber` and `other_chamber` used to stand for.
    Stage("calendared", "On calendar", "Cal"),
    Stage("passed_chamber", "Passed chamber", "Pass"),
    Stage("other_chamber", "Other chamber", "Other"),
    Stage("passed_both", "Passed both chambers", "Both"),
    Stage("conference", "Conference", "Conf"),
    # Owner decision, round 6 (2026-10-03): both chambers have agreed to one text -- the second passed it as it
    # arrived, a chamber agreed to the other's amendment with none of its own, or both agreed to a conference report --
    # which the Library of Congress once stated as "Cleared for White House." (109th-111th Congresses only).
    Stage("cleared", "Cleared Congress", "Clrd"),
    Stage("presented", "Presented to President", "Pres"),
    Stage("law", "Became law", "Law"),
)
STAGE_KEYS: tuple[str, ...] = tuple(stage.key for stage in STAGES)
# These have no numerical progress value: a failed vote may later pass, and a
# veto may be overridden. Callers can display their labels beside the ladder.
OUTCOME_STAGES: tuple[Stage, ...] = (
    Stage("failed", "Passage failed", "Failed"),
    Stage("vetoed", "Vetoed", "Veto"),
)
_OUTCOME_KEYS = frozenset(stage.key for stage in OUTCOME_STAGES)


@dataclass(frozen=True, slots=True)
class StageRule:
    """Lowercase substrings, or a pattern ``_MATCHER_PATTERNS`` keys by the matcher; the first rule with any hit wins.

    ``chambers`` scopes a rule to the chamber an action happens in: each matcher's chamber (``HOUSE``, ``SENATE``, or
    ``SOURCE_SYSTEM`` where the text names none), and a matcher fires only where that chamber is known and is not the
    bill's origin -- or, with ``own_chamber``, only where it is known and is the bill's origin. A matcher skipped for
    its chamber passes the text on to the next matcher and rule.
    """

    stage: str
    matchers: tuple[str, ...]
    chambers: Mapping[str, str] | None = None
    own_chamber: bool = False


# Order is load-bearing and each comment says why, as the original did.
STAGE_RULES: tuple[StageRule, ...] = (
    # An enactment statement is checked at the start of the action below;
    # mentioning another public law or ordering a public print is not enactment.
    StageRule(
        "law",
        (
            "became public law",
            "became private law",
            "became law without",
            "signed by president",
            "approved by president",
        ),
    ),
    StageRule(
        "presented",
        ("presented to president", "sent to the president", "transmitted to president"),
    ),
    # Both chambers have agreed to one text (owner decision, round 6): the Library of Congress's own "Cleared for White
    # House." (109th-111th), or a chamber agreeing to the other's amendment with no amendment of its own -- "Senate
    # agreed to the House amendment", the House's "motion that the House agree to the Senate amendment ... Agreed to",
    # "considered to have agreed", a recession. ``_AGREES_TO_THE_OTHER_AMENDMENT`` lists what leaves the text open. Both
    # chambers agreeing to a conference report clears it too, a bill's state ``infer_stage`` reads (codes 21000/23000).
    StageRule("cleared", ("cleared for white house", "agreed to the other chamber's amendment")),
    # The other chamber passing the measure as it arrived: the Senate says "without amendment"; the House names the
    # text in its suspension motion ("pass the bill", not "pass the bill, as amended"). The House's "On passage Passed"
    # names no amendment either way -- 57 of the 343 Senate measures the House passed so were followed by an exchange of
    # amendments, 108th-119th (bill family e264e62b, 2026-10-03) -- so it clears nothing; nor does a first passage.
    StageRule(
        "cleared",
        ("passed senate without amendment", "passed without amendment", "suspend the rules and pass"),
        chambers=MappingProxyType(
            {
                "passed senate without amendment": SENATE,
                "passed without amendment": SOURCE_SYSTEM,
                "suspend the rules and pass": HOUSE,
            }
        ),
    ),
    # The Library of Congress files every exchange of amendments under "Resolving differences" (codes 19500/20500),
    # agreements and further amendments alike, so the category is no conference (BillTrax read it as one; 29 bills of
    # the 108th-119th read `conference` from it alone, round 6). A conference is one requested, held or reported.
    StageRule(
        "conference",
        (
            "conference report",
            "conference committee",
            "requests a conference",
            "request a conference",
            "requested a conference",
            "sent to conference",
            "appointed conferees",
            "returned to house from senate with amendment",
            "returned to senate from house with amendment",
            "house insisted on its amendment",
            "senate insisted on its amendment",
        ),
    ),
    StageRule(
        "passed_chamber",
        (
            "engrossed",
            "enrolled",
            "passed house",
            "passed senate",
            "passed/agreed to",
            "on passage passed",
            "on passage agreed",
            "agreed to in house",
            "agreed to in senate",
            "passed by recorded vote",
            "passed by voice vote",
        ),
    ),
    # A measure is received only by the chamber it did not originate in, so receipt is the other chamber whatever the
    # bill.
    StageRule("other_chamber", ("received in the senate", "received in the house")),
    # Calendars, the desk, motions to proceed and cloture exist in the chamber of origin too; there they classify
    # nothing and the earlier rung stands (a reported bill reads `committee`). 659 of the 119th's 1,453
    # `other_chamber` bills read it from their own chamber before this scope (round 4, 2026-10-03). The bare
    # "calendar" keeps its place ahead of the House calendars it already caught, so published matcher spellings
    # do not move; the named ones only add a chamber where no source system names one.
    StageRule(
        "other_chamber",
        (
            "placed on calendar",
            "placed on the union calendar",
            "placed on senate legislative calendar",
            "calendar",
            "placed on the house calendar",
            "discharge calendar",
            "held at the desk",
            "motion to proceed",
            "cloture",
        ),
        chambers=MappingProxyType(
            {
                "placed on calendar": SOURCE_SYSTEM,
                "placed on the union calendar": HOUSE,
                "placed on senate legislative calendar": SENATE,
                "calendar": SOURCE_SYSTEM,
                "placed on the house calendar": HOUSE,
                "discharge calendar": HOUSE,
                "held at the desk": SOURCE_SYSTEM,
                "motion to proceed": SENATE,
                "cloture": SENATE,
            }
        ),
    ),
    # The same three named calendars in the bill's own chamber: a reported bill awaiting the floor, or one placed there
    # unreported (Senate Rule XIV, a discharge). Owner decision, round 5; the bare "calendar", "placed on calendar" and
    # the Discharge Calendar stay out, since in the own chamber they also name a return or a discharge motion.
    StageRule(
        "calendared",
        ("placed on the union calendar", "placed on senate legislative calendar", "placed on the house calendar"),
        chambers=MappingProxyType(
            {
                "placed on the union calendar": HOUSE,
                "placed on senate legislative calendar": SENATE,
                "placed on the house calendar": HOUSE,
            }
        ),
        own_chamber=True,
    ),
    # Before "introduced": "reported" can appear alongside "introduced" and is
    # the more advanced stage. Neither reads a citation of the text "as reported" or "as introduced", nor an action
    # that does not begin with the introduction (see ``_MATCHER_PATTERNS``), nor a coded action whose code is not the
    # rung's own (``RUNG_CODES``).
    StageRule("committee", ("reported", "ordered to be reported", "markup", "referred")),
    StageRule("introduced", ("introduced",)),
)


@dataclass(frozen=True, slots=True)
class StageFinding:
    """``rule`` and ``matcher`` are ``None`` when no rule fired and the default stood."""

    stage: str
    rule: str | None
    matcher: str | None
    source_text: str | None
    action_index: int | None
    action_date: str | None


def stage_index(stage: str) -> int:
    """Position in **display** order; -1 for a stage outside the vocabulary.

    This is where the rung is drawn, not how far the bill has got -- do not
    compare two stages with it.
    """
    return STAGE_KEYS.index(stage) if stage in STAGE_KEYS else -1


def stage_progress(stage: str) -> float:
    """Fraction of the **display** ladder drawn, 0.0 at ``introduced`` and 1.0 at ``law``.

    A declared change from the original, whose ``stageProgress`` returned
    ``-1 / 6`` for an unknown stage: a stage outside the vocabulary raises
    ``ValueError`` here.
    """
    index = stage_index(stage)
    if index < 0:
        raise ValueError(f"unknown stage {stage!r}")
    return index / (len(STAGES) - 1)


def _field(record: object, *names: str) -> object:
    """Read the first of ``names`` a mapping holds or an object carries."""
    if isinstance(record, Mapping):
        for name in names:
            if name in record:
                return record[name]
        return None
    for name in names:
        value = getattr(record, name, None)
        if value is not None:
            return value
    return None


def _action_text(action: object) -> str | None:
    """A ``BillAction``'s ``text``, or a published ``bill_actions`` row's ``action_text``."""
    if action is None or isinstance(action, str):
        return action
    value = _field(action, "text", "action_text")
    return value if isinstance(value, str) else None


def _action_date(action: object) -> str | None:
    if action is None or isinstance(action, str):
        return None
    value = _field(action, "action_date", "actionDate")
    return value if isinstance(value, str) else None


_VETO_PREFIXES = ("vetoed by president", "pocket vetoed by president")
# Match the vote being decided, not a procedural motion or a quoted bill.
_PASSAGE_VOTE = re.compile(
    r"^(?:on passage\b|on motion to suspend the rules and (?:pass|agree to)\b|"
    r"on (?:agreeing to|adoption of) (?:the )?(?:resolution|concurrent resolution)\b)",
    re.IGNORECASE,
)
_VOTE_FAILED = re.compile(r"\b(?:failed|rejected|not agreed to)\b", re.IGNORECASE)
_VOTE_PASSED = re.compile(r"\b(?:passed|agreed to)\b", re.IGNORECASE)
# A motion's result is the motion's, not the measure's: "Motion to proceed to consideration of measure agreed to in
# Senate", "Motion to table the motion to reconsider the vote by which S.J. Res. 49 failed of passage ... agreed to".
# 516 actions of the 108th-119th read passage this way (bill family ``fd1bb730...``, 2026-10-03), 46 bills' stage.
_PROCEDURAL_MOTION = re.compile(r"^(?:\w+ )?motion\b|^point of order\b")
# "Disagreed to in Senate by Yea-Nay Vote. 47 - 48." is the measure failing, which the Library of Congress codes 18000
# beside it; the substring "agreed to in senate" read it as passage (8 bills of the 108th-119th). A conference report
# "disagreed to in House" is the report's, not the measure's, and stays with the conference rule.
_DISAGREED = re.compile(r"(?:^|\bwas )disagreed to in (?:the )?(?:house|senate)\b")


#: A chamber's amendment as the other names it: "the Senate amendments", "House amendment", "amendment of the House".
_HOUSE_AMENDMENT = r"(?:the )?(?:house amendments?|amendments? of the house)\b"
_SENATE_AMENDMENT = r"(?:the )?(?:senate amendments?|amendments? of the senate)\b"
#: A chamber agreeing to the other's amendment, with the result stated: the Senate "agreed to"/"concurred in" the
#: House's amendment (or agreed to a motion to, or receded from its own amendment); the House "agreed to" the Senate's,
#: is "considered to have agreed" by a special rule, or its motion to agree, concur or recede and concur was "Agreed
#: to". Not where the same action adds an amendment ("with an amendment", "with House amendment No. 2"), takes only
#: part of the other's (a section, a portion of a divided question, the title alone, one of several numbered
#: amendments, the ones "striking" or "adding" something), disagrees or fails: then the text is still open (110-hr-2642
#: and 110-hr-2764 agreed to "House amendment No. 1" with No. 2 still in dispute). A motion made, a cloture vote on one,
#: a special rule's description and the House agreeing to its own amendments "en gros" name an agreement without being
#: this one.
_AGREES_TO_THE_OTHER_AMENDMENT = re.compile(
    r"^(?!.*(?:\bwith (?:\S+ ){0,3}?amendments?\b|\breplaces it with\b|\bdisagree|\bfailed\b|\bportion\b"
    r"|\bdivided question\b|\b(?:agree|concur) (?:to|in) (?:all but )?section\b|\bamendments? no\. ?\d|\bnumbered \d"
    r"|\b(?:striking|adding|inserting)\b))"
    r"(?!(?!.* and ).*\bamendments? (?:of the (?:house|senate) )?to (?:the )?title\b)"
    r".*?(?:\bsenate (?:agreed|concurred)\b(?:,? [^.;]*?)? (?:to|in) "
    + _HOUSE_AMENDMENT
    + r"|\bsenate agreed to (?:the )?motion to (?:agree to|concur in) "
    + _HOUSE_AMENDMENT
    + r"|^motion (?:by senator [^;]*? )?to concur in "
    + _HOUSE_AMENDMENT
    + r"[^;]*?\bagreed to\b"
    + r"|\bsenate receded from its amendment\b"
    + r"|\bhouse (?:agreed|concurred) (?:to|in) "
    + _SENATE_AMENDMENT
    + r"|\bconsidered to have agreed to "
    + _SENATE_AMENDMENT
    + r"|\bon motion (?:that )?(?:the house )?(?:to )?(?:to )?(?:suspend the rules and )?"
    r"(?:recede (?:from [^;]*? )?and )?(?:agree|concur) (?:to|in) (?:"
    + _SENATE_AMENDMENT
    + r"|the senate\b)[^;]*?\bagreed to\b)",
    re.DOTALL,
)
#: A second passage "without amendment", not "and an amended preamble" or "and an amendment to the title".
_WITHOUT_AMENDMENT = r"(?:(?!\bwith\b)[^.;])*?\bwithout amendment\b(?! and (?:an amended preamble|an amendment))"

# The bare "calendar" matcher reads a placement on some calendar, not a span of calendar days, a calendar year or a
# nomination's calendar number, all of which action text states (House special rules: "through the calendar day of
# ..."; a Senate sequential referral "for 30 calendar days"). Since the chamber scope, such text no longer moves a
# measured stage on its own (119-s-1602's referral also says "placed on the calendar", in its own chamber); the
# pattern keeps the matcher's meaning honest for whatever text comes next. Round 6: "reported" is not a citation of
# the text "as reported" ("Considered under suspension of the rules. (... text of measure as reported in House: ...)",
# 664 actions), "introduced" is an action that begins with the introduction, not "a bill originally introduced by" or
# "text of measure as introduced" (565 actions), and a conference request is the one agreed to, not the motion made.
_MATCHER_PATTERNS: Mapping[str, re.Pattern[str]] = MappingProxyType(
    {
        "calendar": re.compile(r"calendar(?! (?:days?|years?|numbers?)\b)"),
        "agreed to in house": re.compile(r"(?<!dis)agreed to in house"),
        "agreed to in senate": re.compile(r"(?<!dis)agreed to in senate"),
        "reported": re.compile(r"(?<!\bas )reported"),
        "introduced": re.compile(r"^introduced\b"),
        "request a conference": re.compile(r"\brequest a conference\b[^;]*?\bagreed to\b"),
        "cleared for white house": re.compile(r"^cleared for white house\b"),
        "agreed to the other chamber's amendment": _AGREES_TO_THE_OTHER_AMENDMENT,
        "passed senate without amendment": re.compile(
            r"\b(?:passed senate|agreed to in (?:the )?senate)\b" + _WITHOUT_AMENDMENT
        ),
        "passed without amendment": re.compile(r"\b(?:passed|agreed to)\b" + _WITHOUT_AMENDMENT),
        "suspend the rules and pass": re.compile(
            r"^(?:passed/agreed to in house: )?on motion to suspend the rules and (?:pass|agree to) the "
            r"(?:bill|joint resolution|concurrent resolution|resolution)\b(?!,? as amended)[^;]*?\bagreed to\b"
        ),
    }
)
#: Text that is another measure's step or a description of one: a special rule ("Rule H. Res. 1333 passed House.",
#: "Rules Committee Resolution H. Res. 1333 Reported to House.", the House's description "The rule provides ..." /
#: "The resolution waives ..."), a reprint ("Star Print ordered on the reported bill."), a procedural question. Where
#: the action carries a code, ``SPECIAL_RULE_CODES`` says so first; this reads the same text without one.
_NOT_THIS_MEASURES_STEP = (
    "rule ",
    "rules committee resolution",
    "the rule ",
    "the resolution ",
    "star print",
    "on motion to recommit",
    "on motion to commit",
)
#: A citation in parentheses -- "(consideration: CR H5188-5193; text of measure as reported in House: CR H5188)", "(text
#: as House agreed to Senate amendment: CR H8852)" -- names the text it cites; it is no step of its own.
_CITATION = re.compile(r"\([^()]*\)")


def _found(matcher: str, lowered: str) -> bool:
    pattern = _MATCHER_PATTERNS.get(matcher)
    return matcher in lowered if pattern is None else pattern.search(lowered) is not None


def _scope_holds(rule: StageRule, matcher: str, origin_chamber: str | None, source_chamber: str | None) -> bool:
    """Whether a chamber-scoped matcher's action happened in the chamber its rule asks for -- the one the bill did not
    originate in, or with ``own_chamber`` the one it did -- as far as known; both sides must be known."""
    assert rule.chambers is not None
    chamber = rule.chambers[matcher]
    where = source_chamber if chamber == SOURCE_SYSTEM else chamber
    if where is None or origin_chamber is None:
        return False
    return (where == origin_chamber) if rule.own_chamber else (where != origin_chamber)


def infer_stage_from_text(
    text: str | None,
    *,
    origin_chamber: str | None = None,
    source_chamber: str | None = None,
    rules: Iterable[StageRule] = STAGE_RULES,
) -> StageFinding:
    """Classify an action or version description, retaining explicit non-progress outcomes.

    ``origin_chamber`` is the bill's (``HOUSE``/``SENATE``) and ``source_chamber`` the chamber whose system entered the
    action; a chamber-scoped matcher (see ``StageRule.chambers``) fires only where both sides are known and differ, so
    text read with neither -- a version description, a committee print's phrase -- reads no calendar or floor step as
    the other chamber. ``rules`` is the rule table, read in order; ``infer_stage`` re-reads an action without the
    `cleared` rules where a bill's passages do not both stand.
    """
    if not text:
        return StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    lowered = text.lower().strip()
    for prefix in _VETO_PREFIXES:
        if lowered.startswith(prefix):
            return StageFinding("vetoed", "vetoed", prefix, text, None, None)
    passage_vote = _PASSAGE_VOTE.search(lowered)
    failed = (
        lowered.startswith("failed of passage")
        or (passage_vote and _VOTE_FAILED.search(lowered))
        or _DISAGREED.search(lowered)
    )
    if failed:
        stage = "vetoed" if "veto" in lowered or "objections of the president" in lowered else "failed"
        return StageFinding(stage, "failed_passage", "failed passage vote", text, None, None)
    # These actions describe a rule or a procedural question, not passage of
    # this bill. Upstream distinguishes vote-aux actions for the same reason.
    if lowered.startswith(_NOT_THIS_MEASURES_STEP):
        return StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    procedural = _PROCEDURAL_MOTION.match(lowered) is not None
    uncited = _CITATION.sub("", lowered)
    for rule in rules:
        if rule.stage == "passed_chamber":
            if passage_vote and _VOTE_PASSED.search(lowered):
                return StageFinding("passed_chamber", "passed_chamber", "successful passage vote", text, None, None)
            if procedural:
                continue
        for matcher in rule.matchers:
            if not _found(matcher, uncited if rule.stage == CLEARED else lowered):
                continue
            if rule.stage == "law" and not lowered.startswith(matcher):
                continue
            if rule.chambers is not None and not _scope_holds(rule, matcher, origin_chamber, source_chamber):
                continue
            return StageFinding(rule.stage, rule.stage, matcher, text, None, None)
    return StageFinding(DEFAULT_STAGE, None, None, text, None, None)


# The passage and presentation rows of ``bill_actions.BILLSTATUS_ACTION_CODES``
# (passed/agreed to in House or Senate; presented to President).
_QUALIFIED_ACTION_CODES = {
    "8000": "passed_chamber",
    "17000": "passed_chamber",
    "28000": "presented",
    "E20000": "presented",
}
#: The publisher's codes for a referral of the measure to a committee: the guide's (``bill_actions``
#: ``BILLSTATUS_ACTION_CODES["referred"]``) and the House's joint (H11100-A) and sequential (H11200) referrals.
_REFERRAL_CODES = frozenset({"H11100", "H11100-A", "H11200", "2000", "11000"})
#: The publisher's codes for the two rungs below the calendar, read before the text (round 6): an action that carries
#: a code reads `introduced` or `committee` only where its code is that rung's, so a floor statement (H8D000: "ASSUMING
#: FIRST SPONSORSHIP ... a bill originally introduced by", "The Clerk reported the resolution"), a consideration citing
#: the text "as reported" (H30000) or a discharge (H12300) is no introduction or report whatever it quotes. A referral
#: is the one step read from its text whatever the code: the House records a referral made on the floor -- a motion to
#: refer agreed to, a veto message the Chair refers -- under its narrative code H8D000, not H11100. An uncoded action
#: -- the Senate's own entries, the House committees', bare strings -- is read from its text. The guide's codes are
#: ``bill_actions``'s ``introduced``, ``referred`` and ``reported`` rows; that module imports this one, so a test binds
#: the two. Intro-H, Intro-S, H11100-A, H11200, H12100 (an original measure reported) and 1010 ("Reported in House")
#: are the wire's: in bill family e264e62b (2026-10-03) every coded action read `introduced` or `committee` by its text
#: carries one of these codes, refers the measure on the floor, or misreads a mention.
RUNG_CODES: Mapping[str, frozenset[str]] = MappingProxyType(
    {
        DEFAULT_STAGE: frozenset({"1000", "10000", "Intro-H", "Intro-S"}),
        "committee": _REFERRAL_CODES | {"5000", "14000", "H12100", "H12200", "1010"},
    }
)
#: The House's codes for a special rule's own steps: the Rules Committee reporting it (H1L210, ``bill_actions``
#: ``rule_for_consideration``), the House adopting it (H1L220) and the description of what it provides (H12700, which
#: occurs only on the rule's own list). None is a step of the measure whose list carries it, whatever the text names
#: ("Reported to House", "the conference report", "a motion to proceed"): 1,947 actions of the 108th-119th read a
#: stage from one, 42 bills their stage (bill family e264e62b, 2026-10-03).
SPECIAL_RULE_CODES = frozenset({"H1L210", "H1L220", "H12700"})


def _action_code(action: object) -> str | None:
    code = _field(action, "action_code", "actionCode")
    return code if isinstance(code, str) and code else None


def infer_stage_from_action(
    action: object, *, bill_type: str | None = None, rules: Iterable[StageRule] = STAGE_RULES
) -> StageFinding:
    """Read qualified BILLSTATUS codes, then the action's complete text.

    The GPO guide warns that action codes were reused. E30000 is deliberately
    absent here: real veto and signature records both carry it. Failed/veto
    text wins over a contradictory passage code, and so does a reading that the
    passage cleared the measure. A code that names another event classifies
    the action before its text can (``SPECIAL_RULE_CODES``, ``RUNG_CODES``);
    other unknown codes fall back to text and do not manufacture a known event.
    ``bill_type`` (``hr``, ``sres``...) names the chamber of origin and the
    action's ``source_system_name`` the chamber it happened in; without them no
    calendar or floor step reads as the other chamber.
    """
    code = _action_code(action)
    text = _action_text(action)
    if _is_became_law(action):
        return StageFinding(
            LAW_STAGE, "became_law_code", str(code or _field(action, "action_type", "type")), text, None, None
        )
    if code in SPECIAL_RULE_CODES:
        return StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    system = _field(action, "source_system_name")
    finding = infer_stage_from_text(
        text,
        origin_chamber=ORIGIN_CHAMBERS.get(bill_type) if isinstance(bill_type, str) else None,
        source_chamber=SOURCE_SYSTEM_CHAMBERS.get(system) if isinstance(system, str) else None,
        rules=rules,
    )
    if finding.stage in _OUTCOME_KEYS or finding.stage == CLEARED:
        return finding
    admitted = RUNG_CODES.get(finding.stage)
    if code is not None and admitted is not None and code not in admitted and not _sends_to_committee(text):
        finding = StageFinding(DEFAULT_STAGE, None, None, text, None, None)
    stage = _QUALIFIED_ACTION_CODES.get(code) if code is not None else None
    return finding if stage is None else replace(finding, stage=stage, rule="action_code", matcher=code)


#: Once a bill has passed a chamber, an introduction or committee step -- the other chamber's referral or report, a
#: star print -- no longer moves the stage back.
_BEFORE_PASSAGE = frozenset({DEFAULT_STAGE, "committee", "calendared"})
_PASSED_RUNGS = frozenset(STAGE_KEYS[STAGE_KEYS.index("passed_chamber") :])
#: Once both chambers have agreed to one text, no rung below `cleared` moves it back: an enrollment message, a floor
#: record of the vote that cleared it, the other chamber's papers held at the desk.
_BELOW_CLEARED = frozenset(STAGE_KEYS[: STAGE_KEYS.index(CLEARED)])
_RULES_BELOW_CLEARED = tuple(rule for rule in STAGE_RULES if rule.stage != CLEARED)
#: The Library of Congress's own statement that a chamber passed the measure (``bill_actions.BILLSTATUS_ACTION_CODES``
#: ``passed_house``/``passed_senate``), with that chamber.
_PASSAGE_CODE_CHAMBERS: Mapping[str, str] = MappingProxyType({"8000": HOUSE, "17000": SENATE})
#: The Library of Congress's "Conference report agreed to in House" (21000) and "... in Senate" (23000), and on a list
#: without codes the same words at the start of the text.
_CONFERENCE_AGREEMENT_CODES: Mapping[str, str] = MappingProxyType({"21000": HOUSE, "23000": SENATE})
_CONFERENCE_AGREED = re.compile(r"^conference report agreed to in (house|senate)\b", re.IGNORECASE)
#: A text passage reading that names its chamber, for a list whose actions name no system (bare strings).
_TEXT_PASSAGE_CHAMBERS: Mapping[str, str] = MappingProxyType(
    {
        "passed house": HOUSE,
        "agreed to in house": HOUSE,
        "passed senate": SENATE,
        "agreed to in senate": SENATE,
        "passed senate without amendment": SENATE,
        "suspend the rules and pass": HOUSE,
    }
)
#: The `cleared` readings that are a chamber's passage, as the hold and `passed_both` count passages on an uncoded list.
_CLEARING_PASSAGES = frozenset(next(rule for rule in STAGE_RULES if rule.stage == CLEARED and rule.chambers).matchers)
#: The rungs a bill passed by both chambers outranks; a later rung (conference, presented, law) or an outcome stands.
_BELOW_PASSED_BOTH = frozenset({"passed_chamber", "other_chamber"})
#: The Senate's statement that an earlier passage no longer stands: "Senate vitiated previous passage." on 30 bills of
#: the 108th-119th (2026-10-03), after which the bill is passed again, returned to the calendar, postponed or
#: re-referred. No other wording of it, and no House one for a measure's passage, occurs there.
_VITIATED_PASSAGE = re.compile(r"\bvitiated previous passage\b", re.IGNORECASE)
#: Before passage, a committee step lowers `calendared` only where it sends the bill to a committee: a referral by code
#: (``_REFERRAL_CODES``), or text that refers it to a committee and not to a subcommittee. A report, an order to report,
#: a subcommittee referral or a floor step after a placement leaves the bill on the calendar.
_SENDS_TO_COMMITTEE = re.compile(r"\breferred\b(?![^.;]*\bsubcommittee\b)")


def _action_chamber(action: object) -> str | None:
    system = _field(action, "source_system_name")
    return SOURCE_SYSTEM_CHAMBERS.get(system) if isinstance(system, str) else None


class _Reading(NamedTuple):
    """One classified action of a bill: its place, the finding, the chamber it happened in, its code, the action."""

    key: tuple[str, int]
    finding: StageFinding
    chamber: str | None
    code: str | None
    action: object


def infer_stage(actions: Iterable[object], *, newest_first: bool = False, bill_type: str | None = None) -> StageFinding:
    """Return the stage of the latest action any rule classifies, held once the bill has passed a chamber.

    ``actions`` holds ``BillAction`` records, mappings shaped like published
    action rows, or bare action-text strings, and text is read whole; a
    mapping carries the action's ``source_system_name`` as the published row
    does. ``bill_type`` is the measure's own type, read for the chamber of
    origin (``ORIGIN_CHAMBERS``). "Latest"
    is the later ``actionDate``, then the later place in the list; an undated
    action never outranks a dated one. A BILLSTATUS list runs newest first, so
    its caller passes ``newest_first=True`` and a day's first classified action
    is that day's latest. The list's order, not ``actionTime``, orders one
    day's actions: the publisher's order already follows the stated times and
    places the untimed Library of Congress actions among them, where the time
    alone would put a timed House vote after the untimed Senate receipt that
    followed it. Measured on the live ``bill_actions`` generation
    (``c28ed5b1…``, 930,779 actions, 2026-09-28): no adjacent pair runs
    forward in date, and none of 106,013 same-day timed pairs runs forward in
    time (receipt ``unitedstates-reuse-20260928/release-0.51.0/stage-replay/``).
    An action no rule classifies leaves the stage alone, enactment is terminal,
    and a veto remains until enactment is recorded.

    Before passage, only a referral of the bill lowers `calendared`: a report,
    an order to report, a subcommittee referral or a floor step after the
    placement leaves it there (H.R. 744, 119th: the day's report is listed
    above its own placement), while a referral sends it back (S. 1602, 119th,
    referred sequentially after its placement). One day's actions are not
    ranked by rung: the list's order stands. On S. 1781 (108th) the publisher
    lists the referral by unanimous consent after the same day's General Orders
    placement, and the referral is the later step; a rule that ranked the
    placement last would misread it.

    The stage never moves back once the bill has passed a chamber: a later
    ``introduced`` or ``committee`` reading (the other chamber's referral or
    report, a star print, an introduction phrase on the passing action) no
    longer outranks the passage or a later rung. Where the list carries
    publisher codes (any BILLSTATUS action does), only the Library of
    Congress's passage code (8000/17000) holds the stage, and text alone moves
    it as before; where it carries none, a passage read from text holds it. A
    "vitiated previous passage" voids that chamber's earlier passage, so a
    bill whose passage was vitiated and then re-referred reads ``committee``.

    ``passed_both`` is the bill's state, never one action's: where both
    chambers' passages stand (by code on a coded list, by text otherwise) and
    the latest reading is ``passed_chamber`` or ``other_chamber``, the stage is
    ``passed_both``, read from the passage that completed it. `cleared` needs
    the same two passages and an action that completes agreement on one text
    (the `cleared` rules, or both chambers' agreement to a conference report,
    read from the later); from then no lower rung moves it back. Where the
    passages do not both stand, such an action reads what the rules below
    `cleared` read.
    """
    readings: list[_Reading] = []
    vitiations: list[tuple[tuple[str, int], str | None]] = []
    coded = False
    for position, action in enumerate(actions):
        date = _action_date(action)
        key = (date or "", -position if newest_first else position)
        code = _action_code(action)
        coded |= code is not None
        text = _action_text(action)
        if text and _VITIATED_PASSAGE.search(text):
            vitiations.append((key, _action_chamber(action)))
        finding = infer_stage_from_action(action, bill_type=bill_type)
        if finding.rule is None:
            continue
        chamber = (
            _PASSAGE_CODE_CHAMBERS.get(code or "")
            or _CONFERENCE_AGREEMENT_CODES.get(code or "")
            or _action_chamber(action)
            or _TEXT_PASSAGE_CHAMBERS.get(finding.matcher or "")
        )
        readings.append(_Reading(key, replace(finding, action_index=position, action_date=date), chamber, code, action))

    def stands(reading: _Reading) -> bool:
        return reading.finding.stage not in ("passed_chamber", CLEARED) or not any(
            reading.key < vitiated and where in (None, reading.chamber) for vitiated, where in vitiations
        )

    def passage(reading: _Reading) -> bool:
        # On a coded list the Library of Congress's code, as for the hold; on an uncoded one a passage read from text.
        if coded:
            return reading.code in _PASSAGE_CODE_CHAMBERS and reading.finding.stage in ("passed_chamber", CLEARED)
        return reading.finding.stage == "passed_chamber" or reading.finding.matcher in _CLEARING_PASSAGES

    standing = sorted((reading for reading in readings if stands(reading)), key=lambda reading: reading.key)
    # Each chamber's first standing passage.
    first_passage: dict[str, _Reading] = {}
    for reading in standing:
        if reading.chamber is not None and passage(reading):
            first_passage.setdefault(reading.chamber, reading)
    both_passed = len(first_passage) == len(ORIGIN_CHAMBERS_BY_NAME)
    if both_passed:
        standing = sorted([*standing, *_conference_agreed_by_both(standing, coded)], key=lambda reading: reading.key)
    else:
        standing = [_below_cleared(reading, bill_type) for reading in standing]
        standing = [reading for reading in standing if reading.finding.rule is not None]
    holds = (
        any(passage(reading) for reading in standing)
        if coded
        else any(reading.finding.stage in _PASSED_RUNGS for reading in standing)
    )
    cleared = any(reading.finding.stage == CLEARED for reading in standing)
    candidates = [
        reading
        for reading in standing
        if not (holds and reading.finding.stage in _BEFORE_PASSAGE)
        and not (cleared and reading.finding.stage in _BELOW_CLEARED)
    ]
    chosen = (
        _latest(reading for reading in standing if reading.finding.stage == LAW_STAGE)
        or _latest(reading for reading in standing if reading.finding.stage == "vetoed")
        or _latest(candidates)
    )
    if chosen is None:
        return StageFinding(DEFAULT_STAGE, None, None, None, None, None)
    if chosen.finding.stage == "committee":
        chosen = _calendared_unless_referred(chosen, standing)
    if chosen.finding.stage in _BELOW_PASSED_BOTH and both_passed:
        # Both chambers have passed it: the stage is that state, read from the passage that completed it.
        completing = max(first_passage.values(), key=lambda reading: reading.key)
        return replace(completing.finding, stage="passed_both", rule="passed_both")
    return chosen.finding


def _latest(readings: Iterable[_Reading]) -> _Reading | None:
    return max(readings, default=None, key=lambda reading: reading.key)


def _calendared_unless_referred(chosen: _Reading, standing: list[_Reading]) -> _Reading:
    """A committee step after a calendar placement, with only such steps between, leaves the placement standing unless
    it refers the bill to a committee (a ``_REFERRAL_CODES`` code, or ``_SENDS_TO_COMMITTEE`` in its text)."""
    for reading in reversed([reading for reading in standing if reading.key <= chosen.key]):
        if reading.finding.stage == "committee" and not _refers(reading):
            continue
        return reading if reading.finding.stage == "calendared" else chosen
    return chosen


def _sends_to_committee(text: str | None) -> bool:
    return bool(text) and _SENDS_TO_COMMITTEE.search(_CITATION.sub("", text.lower())) is not None


def _refers(reading: _Reading) -> bool:
    return reading.code in _REFERRAL_CODES or _sends_to_committee(reading.finding.source_text)


def _conference_agreed_by_both(standing: list[_Reading], coded: bool) -> list[_Reading]:
    """Both chambers' agreement to the conference report, as a `cleared` reading of the later agreement; on a coded
    list the Library of Congress's 21000/23000, on an uncoded one the same words at the start of the text."""
    agreed: dict[str, _Reading] = {}
    for reading in standing:
        if coded:
            chamber = _CONFERENCE_AGREEMENT_CODES.get(reading.code or "")
        else:
            match = _CONFERENCE_AGREED.match(reading.finding.source_text or "")
            chamber = match and {"house": HOUSE, "senate": SENATE}[match.group(1).lower()]
        if chamber:
            agreed.setdefault(chamber, reading)
    if len(agreed) < len(ORIGIN_CHAMBERS_BY_NAME):
        return []
    completing = max(agreed.values(), key=lambda reading: reading.key)
    matcher = completing.code or completing.finding.matcher
    return [completing._replace(finding=replace(completing.finding, stage=CLEARED, rule=CLEARED, matcher=matcher))]


def _below_cleared(reading: _Reading, bill_type: str | None) -> _Reading:
    """A `cleared` reading of a bill whose passages do not both stand, re-read by the rules below `cleared`."""
    if reading.finding.stage != CLEARED:
        return reading
    finding = infer_stage_from_action(reading.action, bill_type=bill_type, rules=_RULES_BELOW_CLEARED)
    return reading._replace(
        finding=replace(finding, action_index=reading.finding.action_index, action_date=reading.finding.action_date)
    )


# The publisher's own identifiers for "became public law": ``36000`` is the
# Library of Congress code (``type`` "BecameLaw") and ``E40000`` the executive
# code carrying the same event; both appear on the same bill with the same
# date. ``type`` is checked too so a future code spelling still resolves. A
# private law carries E40000 too, beside the Library of Congress's 41000
# ("Became Private Law", type "BecameLaw").
BECAME_PUBLIC_LAW_ACTION_CODES = frozenset({"36000", "E40000"})
BECAME_PUBLIC_LAW_ACTION_TYPE = "BecameLaw"
PUBLIC_LAW_TYPE_TERM = "public"
PRIVATE_LAW_TYPE_TERM = "private"

SIGNED_DATE_RULES: tuple[str, ...] = (
    "public_law_and_became_law_action",
    "public_law_without_became_law_action",
    "no_public_law",
    # Round 6: a private law's coded became-law action dates its signing too (16 private laws of the 108th-119th).
    "private_law_and_became_law_action",
)


@dataclass(frozen=True, slots=True)
class SignedDateFinding:
    """``signed_date`` is ``None`` unless the coded action supplied one."""

    signed_date: str | None
    public_law_number: str | None
    rule: str
    action_index: int | None
    action_code: str | None


def _law_entry(laws: object) -> tuple[str, str] | None:
    """The kind (``public`` or ``private``) and number of the bill's laws entry, a public one first."""
    if not isinstance(laws, Iterable) or isinstance(laws, str | Mapping):
        return None
    found: dict[str, str] = {}
    for entry in laws:
        law_type, number = _field(entry, "type"), _field(entry, "number")
        if not isinstance(law_type, str) or not isinstance(number, str):
            continue
        for term in (PUBLIC_LAW_TYPE_TERM, PRIVATE_LAW_TYPE_TERM):
            if term in law_type.lower():
                found.setdefault(term, number)
    kind = next((term for term in (PUBLIC_LAW_TYPE_TERM, PRIVATE_LAW_TYPE_TERM) if term in found), None)
    return None if kind is None else (kind, found[kind])


def _is_became_law(action: object) -> bool:
    code = _field(action, "action_code", "actionCode")
    if isinstance(code, str) and code in BECAME_PUBLIC_LAW_ACTION_CODES:
        return True
    action_type = _field(action, "action_type", "type")
    return isinstance(action_type, str) and action_type == BECAME_PUBLIC_LAW_ACTION_TYPE


def signed_date(status: object) -> SignedDateFinding:
    """Derive the signing date from the ``laws`` entry and the coded became-law action.

    ``status`` is a ``BillStatus`` -- which reads ``<laws>`` and each action's
    code -- or a mapping shaped like a published bill row carrying ``actions``
    and ``laws``. A public law entry without a coded action keeps the law
    number and reports ``public_law_without_became_law_action`` rather than
    falling back to a keyword scan of prose: measured zero on the 118th
    Congress's ``hr``/``s`` bulk zips, but an absent action is not a promise no
    future one will lack the code. A private law is dated the same way
    (``private_law_and_became_law_action``) but has no public law number; one
    without a coded action reads ``no_public_law``. BillTrax read only
    public-law numbers, and the port kept that gate without a reason.
    """
    entry = _law_entry(_field(status, "laws"))
    if entry is None:
        return SignedDateFinding(None, None, "no_public_law", None, None)
    kind, number = entry
    public_number = number if kind == PUBLIC_LAW_TYPE_TERM else None
    actions = _field(status, "actions")
    if isinstance(actions, Iterable) and not isinstance(actions, str | Mapping):
        for position, action in enumerate(actions):
            if not _is_became_law(action):
                continue
            date = _field(action, "action_date", "actionDate")
            code = _field(action, "action_code", "actionCode")
            return SignedDateFinding(
                date if isinstance(date, str) else None,
                public_number,
                f"{kind}_law_and_became_law_action",
                position,
                code if isinstance(code, str) else None,
            )
    if public_number is None:
        return SignedDateFinding(None, None, "no_public_law", None, None)
    return SignedDateFinding(None, public_number, "public_law_without_became_law_action", None, None)


#: Every name ``stage_rule`` can hold, for a bill or one action: each rung's own text rule, the veto and failed-vote
#: readings, the Library of Congress's passage and presentation codes, the became-law codes, and the two bill states.
#: The contract text names exactly these (a test binds the two; the schema is a leaf and cannot import this module).
STAGE_RULE_NAMES: tuple[str, ...] = (
    *dict.fromkeys(rule.stage for rule in STAGE_RULES),
    "vetoed",
    "failed_passage",
    "action_code",
    "became_law_code",
    "passed_both",
)


__all__ = [
    "BECAME_PUBLIC_LAW_ACTION_CODES",
    "BECAME_PUBLIC_LAW_ACTION_TYPE",
    "CLEARED",
    "DEFAULT_STAGE",
    "HOUSE",
    "LAW_STAGE",
    "ORIGIN_CHAMBERS",
    "OUTCOME_STAGES",
    "RUNG_CODES",
    "SENATE",
    "SIGNED_DATE_RULES",
    "SOURCE_SYSTEM",
    "SOURCE_SYSTEM_CHAMBERS",
    "SPECIAL_RULE_CODES",
    "STAGES",
    "STAGE_KEYS",
    "STAGE_RULES",
    "STAGE_RULE_NAMES",
    "SignedDateFinding",
    "Stage",
    "StageFinding",
    "StageRule",
    "infer_stage",
    "infer_stage_from_action",
    "infer_stage_from_text",
    "signed_date",
    "stage_index",
    "stage_progress",
]
