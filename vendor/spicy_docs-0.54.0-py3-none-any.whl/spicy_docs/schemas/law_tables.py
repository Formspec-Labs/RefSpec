"""The ``laws`` table (Congress.gov law list rows joined to their PLAW USLM citation), ``law_code_sections`` (OLRC
per-Congress classification lines) and ``table3_records`` (OLRC Table III records), closing gap A8.

``laws`` keys ``(congress, law_type, number)`` with ``law_type`` sealed to ``public``/``private`` so the list route, the
bulk folder and the USLM file share one key; ``law_code_sections`` keys on position because the same line can appear
twice on one page.  ``congress_bills.statutes_at_large_cite`` stays NULL on purpose: the citation lives in the PLAW USLM
the laws rollup acquires once per law, so the host joins ``laws`` on ``bill_id`` at merge time.

Both OLRC tables append ``usc_section_key``, the bare section folded by ``tables.usc_section_key``, so a key folded the
same way (``31-5318a``) meets a row printed ``5318A``, and ``usc_place``, where on that section the row lands; both come
from :func:`usc_section_place`, which a host also runs over a held row's stored ``usc_section`` and ``action``.  The
citation side is not folded yet: ``document_citations``' ``usc_section`` rule 001 keeps the printed case, so a consumer
folds it through the same helper until B4's grammar, which lower-cases and adopts the helper, lands.  The two are last
on purpose: spicy-regs' ``merge_contract_table`` re-reads the contract, and its ``merge_table`` selects a column a prior
Parquet file lacks as ``CAST(NULL AS VARCHAR)`` (``test_merge_null_fills_columns_the_prior_table_lacks``), so rows
published before a column carry NULL until their scope is captured again or re-derived.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from typing import Any
from urllib.parse import urlsplit

from spicy_docs.schemas.tables import (
    Reference,
    Row,
    TableContractError,
    flag,
    natural_key,
    table_contract,
    text,
    usc_section_key,
)

#: The Statutes at Large citation as the PLAW USLM ``citableAs`` spells it,
#: the rule the legislative data map's ``plaw→statute`` edge proved.
STAT_CITE = re.compile(r"(?P<volume>[0-9]+) Stat\. (?P<page>[0-9]+)")
#: A printed page's identifier in the PLAW USLM (``/us/stat/140/745``).
_STAT_PAGE = re.compile(r"/us/stat/(?P<volume>[0-9]+)/(?P<page>[0-9A-Za-z-]+)")
_LAW_NUMBER = re.compile(r"(?P<congress>[1-9][0-9]{0,2})-(?P<number>[1-9][0-9]*)")
#: The PLAW bulkdata file grammar (``PLAW-119publ1.xml``), measured over every
#: file in the 119th's folders; the package id is the stem.
_PACKAGE_KINDS = {"public": "publ", "private": "pvtl"}
#: ``v3`` (2026-10-03) also reads the page markers into ``statutes_at_large_last_page``; a row read under ``v2`` lacks it.
USLM_READER_VERSION = "laws-uslm-v3"
USLM_OUTCOMES = ("captured", "captured_partial", "captured_refused", "request_failed", "unavailable", "not_requested")
LAW_TEXT_OUTCOMES = ("not_requested", "parsed", "refused")

#: Where on a Code section a classification lands, in the words of OLRC's legend (``nt`` note, ``prec`` preceding).
USC_PLACES = ("section", "note", "preceding", "note_preceding")
_NOTE_WORDS = frozenset({"nt", "nt.", "nts", "nts."})
_PRECEDING_WORDS = frozenset({"prec", "prec."})
_PLACE_WORDS = _NOTE_WORDS | _PRECEDING_WORDS

#: Both OLRC tables' appended join key and place, described once.
_USC_SECTION_KEY = (
    "The one U.S. Code section the row names, as a join key: the section number without Table III's printed note "
    "words (`nt`, `nts`, `prec.`; usc_place states them), lower-cased, with every dash spelling an ASCII hyphen, as "
    "RefSpec's section oracle keys it. Both OLRC tables key it the same way, so they meet on usc_title, "
    "usc_section_key and usc_place; without usc_place a note line meets the section's own line. Fold another source "
    "the same way (schemas.tables.usc_section_key): document_citations' usc_section rule 001 keeps the printed case "
    "and dashes. NULL where usc_section is NULL or names no single section (a list, a range or a chapter, which Table "
    "III prints for some older acts), and on rows published before the column existed."
)
_USC_PLACE = (
    "Where on that section the row lands: `section` (the section itself), `note` (a note under it; OLRC's `nt` or "
    "`nts`), `preceding` (the place just before it, such as a chapter or subchapter heading a law adds there; `prec`) "
    "or `note_preceding` (a note at that place). Read from the section as Table III prints it (`1101 nt`, `prec. "
    "1071`, `nt. prec. 791`) and from the head of law_code_sections.action (`nt new`, `prec`, `nt prec new`), by "
    "schemas.law_tables.usc_section_place. NULL where usc_section_key is NULL, and on rows published before the column "
    "existed."
)

LAWS = table_contract(
    "laws",
    references=(Reference(("bill_id",), "congress_bills", ("bill_id",)),),
    grain="One row per enacted law the Congress.gov law list route states, with its PLAW USLM citation where captured.",
    identity=("congress", "law_type", "number"),
    version_column="update_date",
    columns={
        "law_id": "Natural key: congress, law_type and number joined with hyphens.",
        "congress": "The numbered Congress that enacted the law.",
        "law_type": (
            "`public` or `private`: the publisher's Public Law or Private Law folded onto the spelling the "
            "PLAW USLM publicPrivate field uses, so the list route, the bulk folder and the USLM file share one key."
        ),
        "number": "The law's number within its Congress and type, without the Congress prefix.",
        "law_number": "The publisher's own spelling of the number, Congress prefix included.",
        "publisher_law_type": "The publisher's laws[].type exactly as spelled (Public Law or Private Law).",
        "package_id": "The GovInfo PLAW package id by the measured bulk-file rule: `PLAW-` plus congress, publ or pvtl, and number.",
        "bill_id": "Natural key of the measure this law enacted, as congress_bills keys it.",
        "bill_type": "The enacted measure's type, lowercased as the bill tables spell it.",
        "bill_number": "The enacted measure's number.",
        "title": "The measure's title as the list route states it.",
        "origin_chamber": "The chamber the measure originated in, as the publisher states it.",
        "origin_chamber_code": "The publisher's one-letter origin chamber code.",
        "latest_action_date": (
            "Date of the publisher's latestAction entry. Usually the became-law action, but the publisher lists a "
            "later action when there is one (119-public-68: a committee report filed after signing), so for the "
            "enactment date read approved_date where the PLAW was captured, else congress_bills.signed_date through "
            "bill_id (a private law's too)."
        ),
        "latest_action_text": "Text of that latestAction entry.",
        "update_date": "The publisher's updateDate on the list row; the merge prefers the larger value.",
        "update_date_including_text": "The publisher's updateDateIncludingText on the list row.",
        "url": "The publisher's own URL for the enacted measure.",
        "statutes_at_large_cite": (
            "The native Statutes at Large citation, when stated. NULL with captured_partial means the acquired "
            "identity-matched USLM does not state this citation; see uslm_reason and uslm_citable_as_json."
        ),
        "statutes_at_large_volume": "The volume part of that citation.",
        "statutes_at_large_page": "The page part of that citation.",
        "approved_date": "The USLM meta's approvedDate, where the PLAW was captured.",
        "uslm_title": "The USLM meta's dc:title, where the PLAW was captured.",
        "uslm_processed_date": "The USLM meta's processedDate, where the PLAW was captured.",
        "uslm_sha256": "Digest of the captured PLAW USLM bytes, so the citation is traceable to one file.",
        "uslm_observed_at": (
            "When the read whose outcome this row states got its response: the validated file's capture, the refused "
            "body's, or the 404's; a later failed read the row does not record leaves it unchanged. NULL when no read "
            "was attempted (not_requested) or the attempt got no response."
        ),
        "uslm_outcome": (
            "captured or captured_partial retain validated native metadata; captured_refused retains a refused "
            "capture without unvalidated metadata; request_failed records an attempted read without an accepted "
            "body; unavailable records supported source absence; not_requested means no attempt."
        ),
        "uslm_citable_as_json": "Every literal native USLM meta citableAs value, source order retained.",
        "uslm_reason": "Bounded outcome reason token; NULL on complete capture or when no read was attempted.",
        "uslm_reader_version": "Native mapping rule used for this attempted read; old or absent rules require rereading.",
        "law_text_outcome": "not_requested, parsed or refused: section reading is separate from validated USLM metadata.",
        "law_text_reader_version": "Section-reader rule for this attempt; NULL when no section read was attempted.",
        "law_section_count": "Native section occurrences emitted by a successful read, including quoted nested sections; NULL unless parsed.",
        "law_text_reason": "Bounded reason token for a refused section read; NULL on success or no attempt.",
        "law_body_remainder": (
            "Main-body text outside every native section subtree, including hierarchy headings and enacting "
            "formula; block-spaced like section body. Empty string means parsed with no remainder; NULL means not "
            "parsed. Print furniture (page numbers, running heads and, from law_text_reader_version "
            "law-sections-uslm-v2, the margin notes: the approval date, the bill number, the short-title note) is "
            "excluded with an issue in law_text_issues_json."
        ),
        "law_text_issues_json": "Document-level reading scope and observations about the main-body remainder; section-specific issues are on law_sections. NULL unless parsed.",
        "law_text_url": "Actual resolved XML acquisition URL for an attempted law-text read, distinct from the bill API url. Supplied from capture evidence, never inferred; NULL when unattempted or the caller retained no URL. A refused read does not validate the target's law identity.",
        "statutes_at_large_last_page": (
            "The last Statutes at Large page the law is printed on: the last page marker the PLAW USLM states in the "
            'cited volume (`<page identifier="/us/stat/140/746">`), so a page from statutes_at_large_page to this '
            "one, in statutes_at_large_volume, is inside the law. On the 102 public laws of the 119th's PLAW file "
            "(2026-09-14) the first marker is the cited page on every law and the next law starts on the following "
            "page on 97 of 98 consecutive pairs (one page between on the other). NULL where no USLM was captured, "
            "it states no citation or no marker in its volume, and on a row read under uslm_reader_version "
            "laws-uslm-v2 or earlier."
        ),
    },
)

LAW_SECTIONS = table_contract(
    "law_sections",
    grain="One native USLM section occurrence within a public or private law, including explicitly flagged quoted sections.",
    identity=("law_id", "seq"),
    version_column="observed_at",
    # laws uses (congress, law_type, number) as its declared identity. law_id
    # is the derived join key, like the one on law_code_sections below.
    columns={
        "law_id": "Validated congress-kind-number law key; joins laws.law_id and through laws.bill_id to the enacted measure.",
        "seq": "Zero-based native section occurrence in document order; missing or repeated labels never merge rows.",
        "publisher_id": "The section element's literal id attribute, including repeats; NULL if missing.",
        "publisher_identifier": "The section element's literal identifier attribute, not inferred from its number.",
        "section_number": "Text of the section's direct num element; repeated direct num elements are newline-joined and flagged.",
        "section_number_value": "The single direct num element's value attribute, where stated; NULL for missing or repeated num elements.",
        "heading": "Mixed inline text of the direct heading; repeated direct headings are newline-joined and flagged.",
        "parent_seq": "Occurrence of the nearest containing native section; NULL for sections without a section ancestor.",
        "hierarchy_json": "Source-order structural ancestors with element, namespace-qualified path, native IDs, number and heading.",
        "native_path": "Absolute XPath 1.0 using local-name and namespace-uri predicates into the exact source XML.",
        "body": (
            "Section-owned source text: block boundaries become newlines; inline adjacency survives, amending "
            "actions included. Excludes own number/heading, print furniture and nested sections, which have "
            "separate rows. Print furniture is the page's apparatus beside the enacted words: page numbers, "
            "running heads and, from law_text_reader_version law-sections-uslm-v2, the USLM sidenote margin notes "
            "(`42 USC 405 note.`, a topical catchword such as `Contracts.`), each flagged in issues_json as "
            "print_furniture_excluded:<element>; under law-sections-uslm-v1 the margin notes were kept as body "
            "lines. This is not consolidated or applied law text."
        ),
        "is_quoted": "true when a native quotedContent ancestor encloses this section; a quoted section is not a separate enacted section.",
        "issues_json": "Observed missing/repeated labels or IDs, unknown elements, excluded nested text and print furniture; these observations do not interpret legal effect.",
        "source_sha256": "SHA-256 of the exact identity-validated law XML shared with the parent law metadata capture.",
        "reader_version": "Source-owned USLM section-reading rule; no enrolled BILLS parser or diff equivalence is used.",
        "observed_at": "When the caller captured the law XML, not when this section reader ran.",
    },
)

LAW_CODE_SECTIONS = table_contract(
    "law_code_sections",
    grain="One row per line of one OLRC per-Congress classification table: a Code place one public law section touched.",
    identity=("congress", "session", "seq"),
    version_column="observed_at",
    columns={
        "congress": "The Congress the table page states in its caption.",
        "session": "The session (1 or 2) the table page states in its caption.",
        "seq": "Zero-based position of this line in the page; part of the identity because one line can repeat.",
        "law_id": "Natural key of the law, as laws keys it.",
        "law_number": "The public law number as the table prints it, Congress prefix included.",
        "law_type": "Always `public`: the page is the publisher's table for public laws.",
        "number": "The law's number within its Congress.",
        "usc_title": "The U.S. Code title as printed; a trailing A means the title's appendix, per the page's legend.",
        "usc_section": "The U.S. Code section as printed.",
        "action": (
            "Column 3 verbatim; NULL where the page left it blank. The page's own legend (Explanation of Table, "
            "column 3, as the retained tbl119pl_2nd.htm prints it): `nt` means note; `nt [tbl]` means note "
            "[table]; `prec` means preceding; `fr` means a transfer from another section; `to` means a transfer to "
            "another section; `new` means a new section or new note; `gen amd` means the section or note is "
            "generally amended; `omitted` means the section is omitted; `repealed` means the section or note is "
            "repealed; `nt ed chg` and `ed chg` refer to the Editorial Classification Change Table; no entry or "
            "`nt` by itself means the section or note is amended. Tokens combine (`nt new`: a new note). A transfer "
            "prints as `tr fr <title>/<section>` (from that section) or `tr to <title>/<section>` (to it), the "
            "legend's `fr` and `to`. The leading `nt` or `prec` is the row's place, which usc_place states."
        ),
        "act_section": "The law's own section that did it, as printed; a quoted item after it names a new section.",
        "statutes_at_large_volume": "The volume the page's column header names.",
        "statutes_at_large_page": "The page as printed: one page, or a span such as two pages joined by a comma or a dash.",
        "link_volume": "The volume in the row's statviewer link, where the row carries one.",
        "link_page": "The page in the row's statviewer link, where the row carries one.",
        "table_order": "Which of the publisher's two orders the page is: `public-law` or `code`; both hold the same lines.",
        "stated_laws": "The law range the page's caption states it covers, verbatim.",
        "prepared_date": "The date the page states it was prepared.",
        "observed_at": "When the page was captured; the merge prefers the larger value.",
        "usc_section_key": _USC_SECTION_KEY,
        "usc_place": _USC_PLACE,
    },
)

TABLE3_RECORDS = table_contract(
    "table3_records",
    grain="One row per classification record of one act in OLRC's Table III, read from its page or the bulk file.",
    identity=("act_key", "seq"),
    version_column="observed_at",
    columns={
        "act_key": "The act key: a public law number, or a pre-1957 session-law chapter.",
        "stated_key": "The act number as Table III states it: `119-4` in the bulk file, `119–4` (en dash) on a page.",
        "seq": "Zero-based position of this record in its act, in the source's own order.",
        "congress": "The Congress Table III states for the act: `119` in the bulk file, `119th Cong.` on a page.",
        "act_date": "The act's date as Table III states it: `2025-03-15` in the bulk file, `Mar. 15, 2025` on a page.",
        "statutes_at_large_volume": (
            "The volume Table III states for the act, or in the bulk file for the fragment holding this record: "
            "`139` there, `139 Stat.` on a page."
        ),
        "release_point": "The release point Table III states it is current through: the bulk member's name, or a page's banner.",
        "act_section": "The native act section; NULL when a meaningful source row leaves its label blank.",
        "record_volume": (
            "The volume of this record's Statutes at Large page: its statviewer link's on a page, its fragment's in the "
            "bulk file; NULL where neither is stated."
        ),
        "record_page": "The Statutes at Large page for this record.",
        "usc_title": "The Code title the section went to; NULL where it went nowhere.",
        "usc_section": (
            "The Code section the section went to, as Table III prints it: a note or preceding place is part of the "
            "value (`1101 nt`, `prec. 1071`, `nt. prec. 791`), where law_code_sections prints the bare section and "
            "puts `nt` or `prec` in action; usc_section_key and usc_place split it. NULL where it went nowhere."
        ),
        "status": (
            "Table III's status for the record, as printed and not expanded: `Rep.` (repealed) or `Elim.` "
            "(eliminated) on the 119th Congress's records; older acts also print `Rev. T.` (revised title) or a "
            "Revised Statutes or Internal Revenue Code reference (`R.S. Sec 572`). NULL where it prints none. The "
            "per-Congress tables spell a repeal `repealed` in law_code_sections.action."
        ),
        "observed_at": "When the page or bulk file was captured; the merge prefers the larger value.",
        "usc_section_key": _USC_SECTION_KEY,
        "usc_place": _USC_PLACE,
    },
)


def _law_type(publisher_type: object) -> str:
    if not isinstance(publisher_type, str):
        raise TableContractError("laws: a laws[] entry needs a string type")
    lowered = publisher_type.lower()
    if "private" in lowered:
        return "private"
    if "public" in lowered:
        return "public"
    raise TableContractError(f"laws: unknown law type {publisher_type!r}")


def law_id(congress: object, law_type: str, number: object) -> str:
    return natural_key(congress, law_type, number)


def _split_law_number(law_number: object, congress: object) -> str:
    match = _LAW_NUMBER.fullmatch(str(law_number))
    if match is None:
        raise TableContractError(f"laws: law number {law_number!r} is not congress-number")
    if match["congress"] != str(congress):
        raise TableContractError(f"laws: law number {law_number!r} names another Congress than {congress}")
    return match["number"]


def _stat_cite(citable_as: tuple[str, ...]) -> tuple[str | None, str | None, str | None]:
    """Read a stated Statutes citation without inventing one for a valid private law."""
    for citation in citable_as:
        match = STAT_CITE.fullmatch(citation.strip())
        if match is not None:
            return match[0], match["volume"], match["page"]
    return None, None, None


def _last_page(identifiers: tuple[str, ...], volume: str | None) -> str | None:
    """The page of the last ``/us/stat/{volume}/{page}`` marker in the cited volume, or ``None``."""
    pages = [m["page"] for i in identifiers if (m := _STAT_PAGE.fullmatch(i)) is not None and m["volume"] == volume]
    return pages[-1] if volume is not None and pages else None


def shape_law(
    record: Mapping[str, Any],
    law: Mapping[str, Any],
    *,
    uslm: object | None = None,
    uslm_sha256: str | None = None,
    uslm_observed_at: str | None = None,
    uslm_outcome: str = "not_requested",
    uslm_reason: str | None = None,
    law_text_outcome: str = "not_requested",
    law_text_reader_version: str | None = None,
    law_section_count: int | None = None,
    law_text_reason: str | None = None,
    law_body_remainder: str | None = None,
    law_text_issues: tuple[str, ...] | None = None,
    law_text_url: str | None = None,
) -> Row:
    """One ``laws`` row from one law list record and one of its ``laws[]`` entries.

    ``uslm`` is given exactly when the read validated (``captured`` or ``captured_partial``); its own congress, kind
    and number must agree with the row or the join is refused, so a citation can never land on the wrong law. The
    outcome then follows from the file: ``captured`` when its meta states a Statutes at Large citation, otherwise
    ``captured_partial`` with reason ``statutes_citation_not_stated`` (a private law's own ``citableAs`` is kept in
    ``uslm_citable_as_json``). Without ``uslm``, ``uslm_outcome`` and ``uslm_reason`` say what the attempt found.
    """
    if law_text_outcome not in LAW_TEXT_OUTCOMES:
        raise TableContractError(f"laws: law_text_outcome must be one of {LAW_TEXT_OUTCOMES}")
    if law_text_url is not None:
        if law_text_outcome == "not_requested":
            raise TableContractError("laws: an unattempted section read has no acquired URL")
        if not isinstance(law_text_url, str) or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in law_text_url):
            raise TableContractError(
                "laws: law_text_url must be an absolute HTTP(S) URL without credentials or whitespace"
            )
        try:
            parsed_url = urlsplit(law_text_url)
            if (
                parsed_url.scheme not in {"http", "https"}
                or not parsed_url.hostname
                or parsed_url.username is not None
                or parsed_url.password is not None
            ):
                raise ValueError("not an absolute credential-free HTTP URL")
            _ = parsed_url.port  # Reject malformed ports without changing the stated URL.
        except ValueError as exc:
            raise TableContractError(
                "laws: law_text_url must be an absolute HTTP(S) URL without credentials or whitespace"
            ) from exc
    if law_text_outcome == "parsed":
        if (
            not isinstance(law_body_remainder, str)
            or not isinstance(law_text_issues, tuple)
            or any(not isinstance(issue, str) for issue in law_text_issues)
        ):
            raise TableContractError("laws: parsed sections require the main-body remainder and reading issues")
    elif law_body_remainder is not None or law_text_issues is not None:
        raise TableContractError("laws: only parsed sections carry remainder text and reading issues")
    if law_text_outcome == "not_requested":
        if any(value is not None for value in (law_text_reader_version, law_section_count, law_text_reason)):
            raise TableContractError("laws: an unattempted section read has no version, count or refusal")
    else:
        if not isinstance(law_text_reader_version, str) or not law_text_reader_version:
            raise TableContractError("laws: an attempted section read requires its reader version")
        if law_text_outcome == "parsed":
            if type(law_section_count) is not int or law_section_count < 1 or law_text_reason is not None:
                raise TableContractError("laws: parsed sections require a positive count and no refusal")
        elif (
            law_section_count is not None
            or not isinstance(law_text_reason, str)
            or re.fullmatch(r"[a-z_]{1,128}", law_text_reason) is None
        ):
            raise TableContractError("laws: refused section reads require a bounded reason and no count")
    if uslm_reason is not None and re.fullmatch(r"[a-z_]{1,128}", uslm_reason) is None:
        raise TableContractError("laws: uslm_reason must be a bounded reason token")
    if uslm_outcome not in USLM_OUTCOMES:
        raise TableContractError(f"laws: uslm_outcome must be one of {USLM_OUTCOMES}")
    if (uslm is not None) != (uslm_outcome in ("captured", "captured_partial")):
        raise TableContractError("laws: uslm is given exactly when uslm_outcome is captured or captured_partial")
    congress = record.get("congress")
    law_type = _law_type(law.get("type"))
    number = _split_law_number(law.get("number"), congress)
    latest = record.get("latestAction")
    latest = latest if isinstance(latest, Mapping) else {}
    bill_type = record.get("type")
    cite = volume = page = last_page = None
    if uslm is not None:
        stated = (str(uslm.congress), uslm.public_private, str(uslm.doc_number))
        if stated != (str(congress), law_type, number):
            raise TableContractError(f"laws: USLM meta states {stated}, not {(str(congress), law_type, number)}")
        cite, volume, page = _stat_cite(uslm.citable_as)
        last_page = _last_page(uslm.page_identifiers, volume)
        uslm_outcome = "captured" if cite is not None else "captured_partial"
        uslm_reason = None if cite is not None else "statutes_citation_not_stated"
    return {
        "law_id": law_id(congress, law_type, number),
        "congress": text(congress),
        "law_type": law_type,
        "number": number,
        "law_number": text(law.get("number")),
        "publisher_law_type": text(law.get("type")),
        "package_id": f"PLAW-{congress}{_PACKAGE_KINDS[law_type]}{number}",
        "bill_id": natural_key(congress, bill_type, record.get("number")),
        "bill_type": None if bill_type is None else str(bill_type).lower(),
        "bill_number": text(record.get("number")),
        "title": text(record.get("title")),
        "origin_chamber": text(record.get("originChamber")),
        "origin_chamber_code": text(record.get("originChamberCode")),
        "latest_action_date": text(latest.get("actionDate")),
        "latest_action_text": text(latest.get("text")),
        "update_date": text(record.get("updateDate")),
        "update_date_including_text": text(record.get("updateDateIncludingText")),
        "url": text(record.get("url")),
        "statutes_at_large_cite": cite,
        "statutes_at_large_volume": volume,
        "statutes_at_large_page": page,
        "approved_date": None if uslm is None else text(uslm.approved_date),
        "uslm_title": None if uslm is None else text(uslm.title),
        "uslm_processed_date": None if uslm is None else text(uslm.processed_date),
        "uslm_sha256": text(uslm_sha256),
        "uslm_observed_at": text(uslm_observed_at),
        "uslm_outcome": uslm_outcome,
        "uslm_citable_as_json": None if uslm is None else json.dumps(list(uslm.citable_as), ensure_ascii=False),
        "uslm_reason": uslm_reason,
        "uslm_reader_version": None if uslm_outcome == "not_requested" else USLM_READER_VERSION,
        "law_text_outcome": law_text_outcome,
        "law_text_reader_version": law_text_reader_version,
        "law_section_count": text(law_section_count),
        "law_text_reason": law_text_reason,
        "law_body_remainder": law_body_remainder,
        "law_text_issues_json": None if law_text_issues is None else json.dumps(law_text_issues, ensure_ascii=False),
        "law_text_url": law_text_url,
        "statutes_at_large_last_page": last_page,
    }


def shape_law_section(section: object, *, document: object, observed_at: str) -> Row:
    """Shape one occurrence from its validated document; native labels do not become row identity."""
    if not 0 <= section.seq < len(document.sections) or document.sections[section.seq] != section:
        raise TableContractError("law_sections: section does not belong to this validated document")
    meta = document.metadata
    return {
        "law_id": law_id(meta.congress, meta.public_private, meta.doc_number),
        "seq": text(section.seq),
        "publisher_id": text(section.publisher_id),
        "publisher_identifier": text(section.publisher_identifier),
        "section_number": text(section.section_number),
        "section_number_value": text(section.section_number_value),
        "heading": text(section.heading),
        "parent_seq": text(section.parent_seq),
        "hierarchy_json": json.dumps(section.hierarchy, ensure_ascii=False),
        "native_path": section.native_path,
        "body": section.body,
        "is_quoted": flag(section.is_quoted),
        "issues_json": json.dumps(section.issues, ensure_ascii=False),
        "source_sha256": document.source_sha256,
        "reader_version": document.reader_version,
        "observed_at": observed_at,
    }


def usc_section_place(usc_section: object, action: object = None) -> tuple[str | None, str | None]:
    """``(usc_section_key, usc_place)`` for a row of either OLRC classification table, from its printed columns.

    Table III prints the place inside the section (``668dd nt``, ``11 nts``, ``prec. 1071``, ``nt. prec. 791``, and
    for older acts ``prec.7101``, ``3901 nt prec.``); the per-Congress tables print the bare section and lead column 3
    with it (``nt new``, ``prec``, ``nt prec new``, ``nts prec ed chg``; a transfer's ``tr fr 14/548`` is not read).
    The key is the one word left once the place words are read off, folded by ``tables.usc_section_key``. A value
    naming no single section -- a list, range or chapter (``13, 13a``, ``137 to 137-2``, ``ch. 12A``: 12,094 of the
    317,590 records of Table III's bulk file at 119-73) -- gives ``(None, None)``, as a NULL section does. A host
    re-derives a held row's two columns from its stored ``usc_section`` and ``action`` with this, without a re-read.
    """
    if usc_section is None:
        return None, None
    words = re.sub(r"\bprec\.(?=\S)", "prec. ", str(usc_section)).split()
    rest = [word for word in words if word.lower() not in _PLACE_WORDS]
    if len(rest) != 1 or "," in rest[0]:
        return None, None
    note = any(word.lower() in _NOTE_WORDS for word in words)
    preceding = any(word.lower() in _PRECEDING_WORDS for word in words)
    lead = str(action or "").split()
    if lead[:1] in (["nt"], ["nts"]):
        note, lead = True, lead[1:]
    preceding = preceding or lead[:1] == ["prec"]
    place = ("note_preceding" if preceding else "note") if note else ("preceding" if preceding else "section")
    return usc_section_key(rest[0]), place


def shape_law_code_section(record: object, *, table: object, observed_at: str) -> Row:
    """One ``law_code_sections`` row from one ``ClassificationRecord`` on its ``ClassificationTable``."""
    number = _split_law_number(record.law_number, table.congress)
    key, place = usc_section_place(record.usc_section, record.description)
    return {
        "congress": text(table.congress),
        "session": text(table.session),
        "seq": text(record.seq),
        "law_id": law_id(table.congress, "public", number),
        "law_number": text(record.law_number),
        "law_type": "public",
        "number": number,
        "usc_title": text(record.usc_title),
        "usc_section": text(record.usc_section),
        "action": text(record.description),
        "act_section": text(record.act_section),
        "statutes_at_large_volume": text(table.statutes_at_large_volume),
        "statutes_at_large_page": text(record.statutes_at_large_page),
        "link_volume": text(record.link_volume),
        "link_page": text(record.link_page),
        "table_order": text(table.order),
        "stated_laws": text(table.stated_laws),
        "prepared_date": text(table.prepared_date),
        "observed_at": text(observed_at),
        "usc_section_key": key,
        "usc_place": place,
    }


def shape_table3_record(record: object, *, page: object, seq: int, observed_at: str) -> Row:
    """One ``table3_records`` row from one ``Table3Record`` on its ``Table3Page``.

    A bulk ``<act>`` fragment can stand in for the page: the row then carries the file's own spellings.
    """
    key, place = usc_section_place(record.usc_section)
    return {
        "act_key": text(page.key),
        "stated_key": text(page.stated_key),
        "seq": text(seq),
        "congress": text(page.congress),
        "act_date": text(page.act_date),
        "statutes_at_large_volume": text(page.statutes_at_large_volume),
        "release_point": text(page.release_point),
        "act_section": text(record.act_section),
        "record_volume": text(record.statutes_at_large_volume),
        "record_page": text(record.statutes_at_large_page),
        "usc_title": text(record.usc_title),
        "usc_section": text(record.usc_section),
        "status": text(record.status),
        "observed_at": text(observed_at),
        "usc_section_key": key,
        "usc_place": place,
    }


__all__ = [
    "LAWS",
    "LAW_CODE_SECTIONS",
    "LAW_SECTIONS",
    "LAW_TEXT_OUTCOMES",
    "STAT_CITE",
    "TABLE3_RECORDS",
    "USC_PLACES",
    "USLM_OUTCOMES",
    "law_id",
    "shape_law",
    "shape_law_code_section",
    "shape_law_section",
    "shape_table3_record",
    "usc_section_place",
]
