"""Frozen scorecards-v1 source tables. All values are literal text or NULL.

Publisher observations stay separate from downstream member and legislative resolution.
See docs/sources/scorecards.md for source scope and snapshot admission rules.
"""

from types import MappingProxyType

from spicy_docs.schemas.tables import VALUE_KEY, Reference, table_contract

SCHEMA_VERSION = "scorecards-v1"

_DESCRIPTIONS = {
    "abbreviation": "Source-stated abbreviation, preserved as text; NULL when unstated.",
    "action_text": "Action as reported by the publisher, without substituting an official legislative record.",
    "adjustment_text": "Source-stated adjustment, preserved as text; NULL when unstated.",
    "aliases_json": "JSON array of publisher name aliases as stated by the source.",
    "amendment_citation_text": "Source-stated amendment citation, preserved as text; NULL when unstated.",
    "bill_citation_text": "Source-stated bill citation, preserved as text; NULL when unstated.",
    "capture_id": "Opaque caller-issued identity of the source observation supporting this row.",
    "capture_ids_json": "JSON array of opaque capture identifiers selected for this accepted snapshot.",
    "capture_roles_json": "Capture attribution by field group: exactly one primary source per group, plus corroborations.",
    "chamber_scope_text": "Source-stated chamber scope, preserved as text; NULL when unstated.",
    "chamber_text": "Source-stated chamber, preserved as text; NULL when unstated.",
    "cohort_text": "Source-stated cohort, preserved as text; NULL when unstated.",
    "combination_rule_text": "Source-stated combination rule, preserved as text; NULL when unstated.",
    "completeness_rule": "Publisher-specific proof that every required edition source and record was captured.",
    "completeness_status": "Complete for an accepted snapshot; failed attempts produce no source table rows.",
    "component_metric_id": "Stable source-layer component metric id; no downstream identity resolution.",
    "congress_text": "Source-stated congress, preserved as text; NULL when unstated.",
    "contribution_number": "Optional exact decimal text for a source-stated contribution.",
    "contribution_rule_text": "Source-stated contribution rule, preserved as text; NULL when unstated.",
    "contribution_text": "Source-stated contribution, preserved as text; NULL when unstated.",
    "counts_toward_metric": "Source-stated participation as true or false, or NULL when unstated.",
    "disclosure_status": "Source-stated disclosure status, preserved as text; NULL when unstated.",
    "district": "Source-stated district, preserved as text; NULL when unstated.",
    "edition_label_text": "Source-stated edition label, preserved as text; NULL when unstated.",
    "effective_at_text": "Source-stated effective at, preserved as text; NULL when unstated.",
    "eligibility_text": "Source-stated eligibility, preserved as text; NULL when unstated.",
    "evidence_policy": "Caller-selected public evidence policy: full, hash_only or metadata_only.",
    "homepage_url": "Source-stated homepage url, preserved as text; NULL when unstated.",
    "identifiers_json": "Ordered source-supplied member identifiers, each with scheme and value.",
    "identity_rule_version": "Versioned rule assigning stable source member, item and edition keys.",
    "is_primary": "Publisher primary-measure designation as true or false, or NULL when unstated.",
    "item_date_text": "Source-stated item date, preserved as text; NULL when unstated.",
    "item_id": "Stable source-layer item id; no downstream identity resolution.",
    "item_kind_text": "Source-stated item kind, preserved as text; NULL when unstated.",
    "member_name": "Source-stated member name, preserved as text; NULL when unstated.",
    "methodology_digest": "Optional permitted digest of the source methodology; NULL when retention policy forbids it.",
    "methodology_id": "Stable source-layer methodology id; no downstream identity resolution.",
    "methodology_text": "Source-stated methodology, preserved as text; NULL when unstated.",
    "methodology_url": "Source-stated methodology url, preserved as text; NULL when unstated.",
    "metric_id": "Stable source-layer metric id; no downstream identity resolution.",
    "name": "Source-stated name, preserved as text; NULL when unstated.",
    "notes_text": "Source-stated notes, preserved as text; NULL when unstated.",
    "observed_at": "UTC instant at which the supporting source response was observed.",
    "parent_metric_id": "Stable source-layer parent metric id; no downstream identity resolution.",
    "parsed_counts_json": "JSON object of parsed table counts within this edition.",
    "parser_version": "Version of the publisher-specific reader used for this snapshot.",
    "participation_id": "Stable source-layer participation id; no downstream identity resolution.",
    "party": "Source-stated party, preserved as text; NULL when unstated.",
    "period_text": "Source-stated period, preserved as text; NULL when unstated.",
    "periods_json": "Ordered explicit or relative source periods with occurrence_id, period_text, kind and source_path.",
    "position_basis": "Whether a publisher position is explicit, inferred by its presentation, or absent.",
    "position_source_path": "Exact source locator supporting the publisher position.",
    "published_at_text": "Source-stated published at, preserved as text; NULL when unstated.",
    "publisher_edition_key": "Source-stated publisher edition key, preserved as text; NULL when unstated.",
    "publisher_id": "Stable source-layer publisher id; no downstream identity resolution.",
    "publisher_item_id": "Stable source-layer publisher item id; no downstream identity resolution.",
    "publisher_member_id": "Stable source-layer publisher member id; no downstream identity resolution.",
    "publisher_member_key": "Versioned reader key for this source member context; not a resolved official identifier.",
    "publisher_name_text": "Source-stated publisher name, preserved as text; NULL when unstated.",
    "publisher_position_text": "Source-stated publisher position, preserved as text; NULL when unstated.",
    "rank_population_text": "Source-stated rank population, preserved as text; NULL when unstated.",
    "rank_text": "Source-stated rank, preserved as text; NULL when unstated.",
    "reason_text": "Source-stated reason, preserved as text; NULL when unstated.",
    "references_json": "Ordered source citation occurrences with occurrence_id, citation_text, kind and source_path.",
    "rendition_selection_rule": "Versioned field-level selection of authoritative sources where alternate renditions differ.",
    "result_id": "Stable source-layer result id; no downstream identity resolution.",
    "result_text": "Publisher result glyph or text, preserving display decoding without inferring an official action.",
    "roll_number_text": "Source-stated roll number, preserved as text; NULL when unstated.",
    "scale_text": "Source-stated scale, preserved as text; NULL when unstated.",
    "scorecard_id": "Stable source-layer scorecard id; no downstream identity resolution.",
    "scorecard_index_url": "Source-stated scorecard index url, preserved as text; NULL when unstated.",
    "series_id": "Stable source-layer series id; no downstream identity resolution.",
    "session_text": "Source-stated session, preserved as text; NULL when unstated.",
    "snapshot_id": "Opaque identity of the complete accepted edition capture and parse.",
    "source_declared_counts_json": "JSON object of counts explicitly stated by the publisher, not expected official roster sizes.",
    "source_path": "Source locator within the captured response, such as cell, JSON path or PDF page.",
    "source_url": "Original publisher URL supporting this observation.",
    "state": "Source-stated state, preserved as text; NULL when unstated.",
    "timespan_text": "Source-stated timespan, preserved as text; NULL when unstated.",
    "title": "Source-stated title, preserved as text; NULL when unstated.",
    "updated_at_text": "Source-stated updated at, preserved as text; NULL when unstated.",
    "value_number": "Optional exact decimal text read from an unambiguous numerical value; never a grade conversion.",
    "value_status_text": "Source-stated value status, preserved as text; NULL when unstated.",
    "value_text": "The publisher-reported rating, including units, suffixes and exclusions; reader-documented text normalization retains the original in source evidence.",
    "value_unit_text": "Source-stated value unit, preserved as text; NULL when unstated.",
    "weight_number": "Optional exact decimal text for a source-stated weight; no inferred normalization.",
    "weight_text": "Source-stated weight, preserved as text; NULL when unstated.",
    "year_text": "Source-stated year, preserved as text; NULL when unstated.",
}

SCORECARD_PUBLISHERS = table_contract(
    "scorecard_publishers",
    grain="One stable publisher identity; historical names remain on edition observations.",
    identity=("publisher_id",),
    key_spelling=VALUE_KEY,
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "publisher_id",
            "name",
            "abbreviation",
            "aliases_json",
            "homepage_url",
            "scorecard_index_url",
            "observed_at",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(),
)

SCORECARDS = table_contract(
    "scorecards",
    grain="One publisher-defined edition, with a series_id for continuity; a live series is not itself an edition.",
    identity=("scorecard_id",),
    key_spelling=VALUE_KEY,
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "publisher_id",
            "series_id",
            "publisher_edition_key",
            "publisher_name_text",
            "title",
            "edition_label_text",
            "chamber_scope_text",
            "year_text",
            "congress_text",
            "session_text",
            "timespan_text",
            "periods_json",
            "source_url",
            "methodology_url",
            "published_at_text",
            "updated_at_text",
            "observed_at",
            "snapshot_id",
            "capture_id",
            "source_path",
        )
    },
    references=(
        Reference(("publisher_id",), "scorecard_publishers", ("publisher_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
    ),
)

SCORECARD_SNAPSHOTS = table_contract(
    "scorecard_snapshots",
    grain="One complete accepted edition capture and parse; unsuccessful attempts remain in the run journal.",
    identity=("snapshot_id",),
    key_spelling=VALUE_KEY,
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "snapshot_id",
            "scorecard_id",
            "observed_at",
            "capture_ids_json",
            "parser_version",
            "methodology_digest",
            "completeness_status",
            "completeness_rule",
            "source_declared_counts_json",
            "parsed_counts_json",
            "evidence_policy",
            "capture_roles_json",
            "rendition_selection_rule",
            "identity_rule_version",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),),
)

SCORECARD_METHODOLOGIES = table_contract(
    "scorecard_methodologies",
    grain="One source-stated rule set in an edition, scoped to chamber and cohort as stated.",
    identity=("scorecard_id", "methodology_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "methodology_id",
            "chamber_text",
            "cohort_text",
            "effective_at_text",
            "methodology_text",
            "methodology_url",
            "disclosure_status",
            "capture_id",
            "source_path",
            "snapshot_id",
            "source_url",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
    ),
)

SCORECARD_METRICS = table_contract(
    "scorecard_metrics",
    grain="One publisher measurement for an explicit chamber, cohort and period in an edition.",
    identity=("scorecard_id", "metric_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "metric_id",
            "methodology_id",
            "name",
            "value_unit_text",
            "chamber_text",
            "cohort_text",
            "period_text",
            "periods_json",
            "is_primary",
            "scale_text",
            "rank_population_text",
            "snapshot_id",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
        Reference(("scorecard_id", "methodology_id"), "scorecard_methodologies", ("scorecard_id", "methodology_id")),
    ),
)

SCORECARD_ITEMS = table_contract(
    "scorecard_items",
    grain="One publisher-identified action or scoring item; multiple actions on one bill remain separate.",
    identity=("scorecard_id", "item_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "item_id",
            "publisher_item_id",
            "item_kind_text",
            "title",
            "item_date_text",
            "congress_text",
            "chamber_text",
            "session_text",
            "roll_number_text",
            "bill_citation_text",
            "amendment_citation_text",
            "references_json",
            "source_url",
            "source_path",
            "publisher_position_text",
            "position_basis",
            "position_source_path",
            "snapshot_id",
            "capture_id",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
    ),
)

SCORECARD_METRIC_ITEMS = table_contract(
    "scorecard_metric_items",
    grain="One item's participation in a metric under a particular source rule.",
    identity=("scorecard_id", "metric_id", "item_id", "participation_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "metric_id",
            "item_id",
            "participation_id",
            "methodology_id",
            "publisher_position_text",
            "position_basis",
            "weight_text",
            "weight_number",
            "contribution_rule_text",
            "counts_toward_metric",
            "snapshot_id",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
        Reference(("scorecard_id", "metric_id"), "scorecard_metrics", ("scorecard_id", "metric_id")),
        Reference(("scorecard_id", "item_id"), "scorecard_items", ("scorecard_id", "item_id")),
        Reference(("scorecard_id", "methodology_id"), "scorecard_methodologies", ("scorecard_id", "methodology_id")),
    ),
)

SCORECARD_METRIC_COMPONENTS = table_contract(
    "scorecard_metric_components",
    grain="One source-stated relationship between a component metric and its parent metric.",
    identity=("scorecard_id", "parent_metric_id", "component_metric_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "parent_metric_id",
            "component_metric_id",
            "weight_text",
            "weight_number",
            "combination_rule_text",
            "snapshot_id",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
        Reference(("scorecard_id", "parent_metric_id"), "scorecard_metrics", ("scorecard_id", "metric_id")),
        Reference(("scorecard_id", "component_metric_id"), "scorecard_metrics", ("scorecard_id", "metric_id")),
    ),
)

SCORECARD_MEMBERS = table_contract(
    "scorecard_members",
    grain="One source member occurrence/context in the edition, including ungraded or excluded members.",
    identity=("scorecard_id", "publisher_member_key"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "publisher_member_key",
            "publisher_member_id",
            "identifiers_json",
            "member_name",
            "chamber_text",
            "state",
            "district",
            "party",
            "period_text",
            "eligibility_text",
            "notes_text",
            "snapshot_id",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
    ),
)

SCORECARD_MEMBER_RATINGS = table_contract(
    "scorecard_member_ratings",
    grain="One source-reported metric value for a member; different grades, ranks and scores remain distinct measurements.",
    identity=("scorecard_id", "metric_id", "publisher_member_key"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "metric_id",
            "publisher_member_key",
            "value_text",
            "value_number",
            "value_status_text",
            "rank_text",
            "notes_text",
            "source_url",
            "source_path",
            "snapshot_id",
            "capture_id",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
        Reference(("scorecard_id", "metric_id"), "scorecard_metrics", ("scorecard_id", "metric_id")),
        Reference(
            ("scorecard_id", "publisher_member_key"), "scorecard_members", ("scorecard_id", "publisher_member_key")
        ),
    ),
)

SCORECARD_MEMBER_ITEM_RESULTS = table_contract(
    "scorecard_member_item_results",
    grain="One publisher-reported member result for an item, with optional source-stated metric participation. Metric-free grids require no fabricated measurement.",
    identity=("scorecard_id", "item_id", "publisher_member_key", "result_id"),
    version_column=None,
    columns={
        field: _DESCRIPTIONS[field]
        for field in (
            "scorecard_id",
            "result_id",
            "metric_id",
            "item_id",
            "participation_id",
            "publisher_member_key",
            "action_text",
            "result_text",
            "contribution_text",
            "contribution_number",
            "eligibility_text",
            "counts_toward_metric",
            "adjustment_text",
            "reason_text",
            "snapshot_id",
            "capture_id",
            "source_url",
            "source_path",
        )
    },
    references=(
        Reference(("scorecard_id",), "scorecards", ("scorecard_id",)),
        Reference(("snapshot_id",), "scorecard_snapshots", ("snapshot_id",)),
        Reference(
            ("scorecard_id", "publisher_member_key"), "scorecard_members", ("scorecard_id", "publisher_member_key")
        ),
        Reference(("scorecard_id", "item_id"), "scorecard_items", ("scorecard_id", "item_id")),
        Reference(
            ("scorecard_id", "metric_id", "item_id", "participation_id"),
            "scorecard_metric_items",
            ("scorecard_id", "metric_id", "item_id", "participation_id"),
        ),
    ),
)

SCORECARD_TABLES = MappingProxyType(
    {
        table.name: table
        for table in (
            SCORECARD_PUBLISHERS,
            SCORECARDS,
            SCORECARD_SNAPSHOTS,
            SCORECARD_METHODOLOGIES,
            SCORECARD_METRICS,
            SCORECARD_ITEMS,
            SCORECARD_METRIC_ITEMS,
            SCORECARD_METRIC_COMPONENTS,
            SCORECARD_MEMBERS,
            SCORECARD_MEMBER_RATINGS,
            SCORECARD_MEMBER_ITEM_RESULTS,
        )
    }
)

# TableContract.Reference names a relationship; nullability is checked at bundle admission.
SCORECARD_OPTIONAL_REFERENCES = frozenset(
    (
        ("scorecard_metrics", ("scorecard_id", "methodology_id"), "scorecard_methodologies"),
        ("scorecard_metric_items", ("scorecard_id", "methodology_id"), "scorecard_methodologies"),
        (
            "scorecard_member_item_results",
            ("scorecard_id", "metric_id", "item_id", "participation_id"),
            "scorecard_metric_items",
        ),
    )
)
