"""The FEC committee master as a table: one row per committee per two-year cycle, and its row projection."""

from __future__ import annotations

import re
from collections.abc import Mapping

from spicy_docs.schemas.tables import AT_JOINED_KEY, table_contract

#: Each published column after ``committee_id`` and ``cycle``, and the header field it copies. Together with
#: ``CMTE_ID`` these are every ``sources.fec.committee_master.COMMITTEE_MASTER_FIELDS`` entry once; a test holds the two
#: lists to that, because this stdlib-only leaf does not import ``sources``.
_FROM_FIELD: dict[str, str] = {
    "name": "CMTE_NM",
    "treasurer_name": "TRES_NM",
    "street_1": "CMTE_ST1",
    "street_2": "CMTE_ST2",
    "city": "CMTE_CITY",
    "state": "CMTE_ST",
    "zip": "CMTE_ZIP",
    "designation": "CMTE_DSGN",
    "committee_type": "CMTE_TP",
    "party": "CMTE_PTY_AFFILIATION",
    "filing_frequency": "CMTE_FILING_FREQ",
    "organization_type": "ORG_TP",
    "connected_organization_name": "CONNECTED_ORG_NM",
    "candidate_id": "CAND_ID",
}


#: What is left of a filed placeholder once everything but letters and digits is dropped and the case folded: ``NONE``,
#: ``"NONE"``, ``None.``; ``N/A``, ``NA``, ``N A``; ``N/A-NONE``; ``BLANK``, ``(BLANK)``; ``0``; and punctuation alone
#: (``-``, ``.``, ``$``, ``/``). Every spelling measured on the published fec_committee_history (2026-10-03: 59,050 of
#: its 148,235 stated connected organizations, 55,824 of them ``NONE``); none of them is a name.
_PLACEHOLDER_LETTERS = frozenset({"", "NONE", "NA", "NANONE", "BLANK", "0"})


def is_placeholder_name(value: object) -> bool:
    """Whether a name a committee filed is its placeholder for "none" (``NONE``, ``N/A``, ``-``, ``BLANK``, ...).

    FEC's own files keep these verbatim, and so does this table; a consumer reads one as no organization or committee
    named. A blank field is not a placeholder: it is already NULL. One rule for every FEC name field that takes them,
    so the connected organization and Form 1's affiliated committee read placeholders alike.
    """
    if not isinstance(value, str) or not value:
        return False
    return re.sub(r"[^0-9A-Za-z]", "", value).upper() in _PLACEHOLDER_LETTERS


def project_committee_master_row(row: Mapping) -> dict[str, str | None]:
    """Project one :func:`iter_committee_master_rows` row onto the published columns; a blank field is NULL.

    A blank ``CMTE_ID`` refuses: it would publish an empty identity.
    """
    fields = row["fields"]
    if not fields["CMTE_ID"]:
        raise ValueError("FEC committee master row has a blank CMTE_ID")
    projected: dict[str, str | None] = {"committee_id": fields["CMTE_ID"], "cycle": str(row["cycle"])}
    projected.update({column: fields[field] or None for column, field in _FROM_FIELD.items()})
    return projected


FEC_COMMITTEE_HISTORY = table_contract(
    "fec_committee_history",
    grain="One row per FEC committee per two-year cycle, as that cycle's bulk committee master states it.",
    identity=("committee_id", "cycle"),
    # No component can hold "@": committee_id is C plus eight digits and cycle a four-digit year (none of 298,395 live
    # rows has one; 2026-09-27).
    key_spelling=AT_JOINED_KEY,
    version_column=None,
    columns={
        "committee_id": "The FEC committee id (`CMTE_ID`).",
        "cycle": "The two-year cycle the file covers, as its closing even year.",
        "name": "The committee's name as that cycle's file states it (`CMTE_NM`); NULL when blank.",
        "treasurer_name": "The treasurer's name as filed (`TRES_NM`); NULL when blank.",
        "street_1": "The first street line of the committee's address (`CMTE_ST1`); NULL when blank.",
        "street_2": "The second street line (`CMTE_ST2`); NULL when blank.",
        "city": "The address city (`CMTE_CITY`); NULL when blank.",
        "state": "The address state (`CMTE_ST`); NULL when blank.",
        "zip": "The address ZIP code as filed (`CMTE_ZIP`); NULL when blank.",
        "designation": "The FEC's committee designation code (`CMTE_DSGN`), literal; NULL when blank.",
        "committee_type": "The FEC's committee type code (`CMTE_TP`), literal; NULL when blank.",
        "party": "The party affiliation code (`CMTE_PTY_AFFILIATION`); NULL when blank.",
        "filing_frequency": "The filing frequency code (`CMTE_FILING_FREQ`), literal; NULL when blank.",
        "organization_type": "The interest-group category code (`ORG_TP`); NULL when blank.",
        "connected_organization_name": (
            "The connected organization's name (`CONNECTED_ORG_NM`) as the committee filed it; NULL when blank. "
            "Committees often file a placeholder instead (`NONE`, `N/A`, `-`, and until 2016 `BLANK`), kept verbatim "
            "as FEC's own committee master carries it: read one as no connected organization "
            "(schemas.fec_committee_history.is_placeholder_name says which values are)."
        ),
        "candidate_id": "The candidate the committee is linked to that cycle (`CAND_ID`); NULL when none.",
    },
)

__all__ = ["FEC_COMMITTEE_HISTORY", "is_placeholder_name", "project_committee_master_row"]
