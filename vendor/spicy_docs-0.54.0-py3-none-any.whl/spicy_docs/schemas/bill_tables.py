"""BILLSTATUS bill, action, committee, publisher-summary and cosponsor projections.

``congress_bills``'s first ten columns keep the exact order and spelling of spicy-regs's live
``build_congress_bills.COLUMNS`` because other repositories pin that prefix by digest through ``catalog.json``, so new
columns are appended.  Every function reads its input by attribute, keeping this a leaf whose vocabularies -- a referral
signal, a version-kind label -- arrive as caller-named arguments.  ``bill_publisher_summaries`` is named apart from the
model-backed ``bill_summaries`` on purpose: BillTrax used one name for both.
"""

from __future__ import annotations

from spicy_docs.schemas.tables import (
    VALUE_KEY,
    Reference,
    Row,
    TableContractError,
    bill_id,
    flag,
    joined,
    json_column,
    read_json_column,
    table_contract,
    text,
)

#: The publisher's title types for a short title that names only part of a measure, exactly as spelled: the XML's
#: three spellings, observed in every type's 119th BILLSTATUS zip and the hr and s zips of the 108th, 113th and 118th
#: (GovInfo bulk, 2026-10-03), then the BILLSTATUS user guide's table 6 (retained in
#: ``tests/fixtures/billstatus_codes``), which current XML does not use. A short title of one of these covers a
#: division or title of an omnibus (119-hr-1's "FEHB Protection Act of 2025"), not the measure.
PORTION_SHORT_TITLE_TYPES = frozenset(
    {
        "Short Title(s) as Introduced for portions of this bill",
        "Short Title(s) as Reported to House for portions of this bill",
        "Short Title(s) as Reported to Senate for portions of this bill",
        "Short Title(s) as Passed House for portions of this bill",
        "Short Title(s) as Passed Senate for portions of this bill",
        "Short Titles as Introduced for portions of this bill",
        "Short Titles as Reported to House for portions of this bill",
        "Short Titles as Reported to Senate for portions of this bill",
        "Short Titles as Passed House for portions of this bill",
        "Short Titles as Passed Senate for portions of this bill",
        "Short Titles as Enacted for portions of this bill",
        "Short Titles on Conference report for portions of this bill",
        "Short Titles for portions of this bill from ENR (Enrolled) bill text",
        "Short Titles for portions of this bill from PCS (Placed on Senate Calendar) bill text",
        "Short Title(s) for portions of this bill from RFS (Referred to Senate) bill text",
        "Short Title(s) from Engrossed Amendment House for portions of this bill",
        "Short Title(s) from Engrossed Amendment Senate for portions of this bill",
        "Other Short Titles for portions of a bill",
        "Short Title as Introduced for portions of this bill",
        "Short Title as Reported to House for portions of this bill",
        "Short Title as Reported to Senate for portions of this bill",
        "Short Title as Passed House for portions of this bill",
        "Short Title as Passed Senate for portions of this bill",
        "Short Title as Enacted for portions of this bill",
        "Short Title on Conference report for portions of this bill",
        "Short Titles on Other Versions for portions of this bill",
    }
)

#: The rule name ``bill_committees.referral_signal`` is produced by.  The six
#: system codes it reads live in ``interpretation.money_bills.COMMITTEE_CODES``
#: and the lookup happens there; this table records which rule was applied.
COMMITTEE_REFERRAL_RULE = "committee_system_code"

CONGRESS_BILLS = table_contract(
    "congress_bills",
    references=(Reference(("sponsor_bioguide_id",), "members", ("bioguide_id",)),),
    grain="One row per bill or resolution, as one BILLSTATUS document states it.",
    identity=("bill_id",),
    version_column="update_date",
    key_spelling=VALUE_KEY,
    columns={
        # --- frozen prefix: spicy-regs build_congress_bills.COLUMNS 1-10 ---
        "bill_id": "Natural key: congress, bill type and number joined with hyphens (119-hr-6028).",
        "congress": "The numbered Congress this measure belongs to.",
        "bill_type": "Lowercase publisher bill or resolution type (hr, s, hjres, sres...).",
        "bill_number": "The measure's number within its Congress and type.",
        "title": "The measure's official title as BILLSTATUS states it.",
        "origin_chamber": "The chamber the measure originated in, as the publisher states it.",
        "latest_action_date": "Date of the publisher's own latestAction entry.",
        "latest_action_text": "Text of the publisher's own latestAction entry.",
        "update_date": "The publisher's updateDate for this record; the merge prefers the larger value.",
        "url": "The publisher's own legislation URL for this measure.",
        # --- appended ---
        "schema_version": "The BILLSTATUS schema version the document declared (3.0.0 today).",
        "update_date_including_text": "The publisher's updateDateIncludingText, which moves when a text version posts.",
        "introduced_date": "The date the measure was introduced, as the publisher states it.",
        "policy_area": "The publisher's single policy-area term for this measure.",
        "subjects_json": "Every legislative subject term the publisher lists, as a JSON array in publisher order.",
        "subject_count": "How many legislative subject terms the publisher listed.",
        "sponsor_bioguide_id": "Bioguide id of the first sponsor the publisher lists.",
        "sponsor_full_name": "Full name string of the first sponsor, exactly as the publisher spells it.",
        "cosponsor_count": (
            "Number of items in the publisher's separate cosponsors list, including withdrawn entries; "
            "NULL when that list was not examined."
        ),
        "latest_action_code": (
            "Action code of the actions[] entry the publisher's latestAction names; "
            "latestAction itself states no code, so the two are linked on date and text."
        ),
        "latest_action_time": "The publisher's actionTime on the latestAction entry.",
        "latest_action_source_system_code": "Source-system code of that same actions[] entry.",
        "latest_action_source_system_name": "Source-system name of that same actions[] entry.",
        "action_count": "How many action entries this document carries; the bill_actions row count for this bill.",
        "committee_count": (
            "How many committees and subcommittees this document names, at any nesting depth.  This is "
            "the bill_committees row count except where the publisher states a committee with no "
            "systemCode, which cannot be keyed and is refused."
        ),
        "version_count": (
            "How many text versions this BILLSTATUS document offers.  Not the bill_versions row count: "
            "a PDF twin and an upload are rows the publisher's own list does not name."
        ),
        "public_law_number": (
            "Public law number from the publisher's laws entry, when the measure became a public law; NULL on a "
            "private law (law_type says which; its number is laws.law_number)."
        ),
        "law_type": "The publisher's law type for the first laws entry (Public Law or Private Law).",
        "statutes_at_large_cite": (
            "NULL here on purpose: the citation is published on laws.statutes_at_large_cite, read from the PLAW USLM "
            "meta, and the host fills this column by joining laws on bill_id at merge time. The family build sees one "
            "BILLSTATUS document and its printings; the PLAW is a different package the laws rollup acquires once per "
            "law, so filling it here would fetch every PLAW twice or read another table's output, which the one-pass "
            "rule forbids."
        ),
        "stage": (
            "The whole bill's interpreted legislative stage: the latest step its actions show under the current rule, "
            "not a final outcome. On the ladder: `introduced`, `committee`, `calendared`, `passed_chamber`, "
            "`other_chamber`, `passed_both`, `conference`, `cleared`, `presented` or `law` (the terminal rung; the "
            "literal is `law`, never `enacted`); or an outcome with no rung, `failed` or `vetoed`. `introduced` is "
            "also the default when no rule fires (see stage_rule); NULL where the bill's actions were not examined, "
            "which is "
            'not a statement about enactment. A number the House reserves for its leadership (title "Reserved for the '
            'Speaker.") has no actions: it reads `introduced` with stage_rule NULL, or NULL where GovInfo holds no '
            'document. A mention is not an event: taking over the sponsorship of a bill "originally introduced by" '
            'another, a floor action citing the text "as introduced" or "as reported", a special rule\'s report or '
            "description, and a star print classify nothing, and where the publisher's action code names a step, the "
            "code is read before the text. `calendared` is a placement on the Union, House or Senate Legislative "
            "Calendar in the bill's own chamber (a reported bill awaiting the floor, or one placed there unreported "
            "under Senate Rule XIV or a discharge); a later report, order to report, subcommittee referral or floor "
            "step leaves it `calendared`, and only a referral of the bill to a committee lowers it. `passed_chamber` "
            "and `other_chamber` both mean the bill's own chamber has passed it; `other_chamber` adds that the other "
            "chamber has received it or taken a calendar, desk or floor step on it. A calendar placement, the desk, a "
            "motion to proceed or cloture reads `other_chamber` only where the chamber that took it (as the text names "
            "it, else the system that entered it) is not the one the bill's type originates in; in its own chamber the "
            "desk, a motion to proceed or cloture moves nothing. `passed_both` means both chambers have passed it (the "
            "Library of Congress's 8000 and 17000 where the actions carry codes, else the text) but not, as far as the "
            "wording shows, in one text: the second passage carried an amendment the other chamber has not "
            'agreed to, or names none either way (the House\'s "On passage Passed"). It is read from the passage '
            "that completed it. `conference` is a conference requested, held or reported; the Library of Congress's "
            '"Resolving differences" exchange of amendments is not one. `cleared` means both chambers have agreed to '
            'one text: the second chamber passed it as it arrived (the Senate "without amendment", or the House on a '
            "motion to suspend the rules that names no amendment), a chamber agreed to the other's amendment with no "
            "amendment of its own, or both agreed to a conference report; the Library of Congress's \"Cleared for "
            "White "
            'House." (109th-111th Congresses) reads it too. A bill or joint resolution is then ready for the '
            "President; a concurrent resolution is complete. `failed` is the latest vote on passage failing in either "
            "chamber, a failed two-thirds vote to suspend the rules included: the measure can still pass, and it reads "
            "over an earlier passage by the other chamber until a later step. `vetoed` stands until a recorded "
            "enactment; a failed override keeps it. The stage never moves back once a chamber has passed the bill: the "
            "other chamber's referral or report, a star print or an introduction phrase does not lower it, and only a "
            "passage the Senate states it vitiated is undone; where the actions carry publisher codes, the Library of "
            "Congress's passage code (8000 House, 17000 Senate) is what holds it. Once `cleared`, no lower rung moves "
            "it back. A motion's or a point of order's result (\"motion to proceed ... agreed to in Senate\") is not "
            'the measure\'s passage, and "disagreed to in Senate" reads `failed`.'
        ),
        "stage_rule": (
            "Which rule fired: a stage's own name where that rule read the action's text (`introduced`, `committee`, "
            "`calendared`, `passed_chamber`, `other_chamber`, `conference`, `cleared`, `presented`, `law`), `cleared` "
            "also for both chambers' agreement to a conference report, read from the second; `vetoed` for the "
            "President's veto; `failed_passage` for a failed vote on passage, a failed veto override included (which "
            "leaves the stage `vetoed`); `action_code` where the Library of Congress's passage or presentation code "
            "decided it; `became_law_code` for the publisher's became-law code; `passed_both` for the passage that "
            "left both chambers' passages standing. NULL when no rule fired and the default stood."
        ),
        "stage_matcher": "The matched text pattern, publisher code or vote-result reading used by the named rule.",
        "stage_action_index": (
            "Position in the publisher's action list of the action the stage was read from; the list runs newest "
            "first, so 0 is the bill's latest action."
        ),
        "stage_action_date": "Date of the action the stage was read from.",
        "stage_source_text": "The full action text the stage rule matched against, never shortened.",
        "signed_date": (
            "The date of the publisher's coded became-law action (36000, E40000 or the BecameLaw type) for a public or "
            "a private law; NULL where the bill states no law, or states one with no coded action."
        ),
        "signed_date_rule": (
            "Which signed-date rule produced that answer: `public_law_and_became_law_action`, "
            "`private_law_and_became_law_action`, `public_law_without_became_law_action` (a public law with no coded "
            "action, so no date) or `no_public_law` (no law entry, or a private law with no coded action)."
        ),
        "signed_date_action_index": "Position of the became-law action the signing date was read from.",
        "signed_date_action_code": "The publisher's action code on that became-law action.",
        "money_bill_kind": (
            "Interpreted money-bill kind, or NULL when no rule claimed the measure. A title heuristic with "
            "unmeasured recall: an appropriations act whose title lacks the pattern, or an appropriations division "
            "inside another bill, is NULL (money_bill_rule names the rule that fired). A simple or concurrent "
            "resolution (H. Res., S. Res., H. Con. Res., S. Con. Res.) is never a money bill, though a House special "
            "rule names the one it brings up, and `omnibus` is an appropriations omnibus only, not a statute named "
            '"Omnibus" (the Omnibus Crime Control and Safe Streets Act).'
        ),
        "money_bill_rule": "Which money-bill rule fired, or NULL alongside a NULL kind.",
        "money_bill_reason_codes": (
            "The rule's reason codes, unit-separator joined; BillTrax computed and then discarded these."
        ),
        "fiscal_year": (
            "Fiscal year the display title states, spelled FY plus the year: `fiscal year 2027`, the long title's "
            "`for the fiscal year ending September 30, 2027`, or an appropriations act's closing year "
            "(`... Appropriations Act, 2027`, `Continuing Appropriations and Extensions Act, 2027`). Never read from "
            "short_title, which a reused vehicle takes from the act it replaced. NULL where the title states none."
        ),
        "appropriations_subcommittee": (
            "Which of the twelve appropriations subcommittees the title names, under the statutory names: the "
            "House's National Security, Department of State, and Related Programs reads `State, Foreign "
            "Operations`. Read only where the regular-appropriations rule (or a manual override) classified the bill."
        ),
        "referral_signals": (
            "The referral signals the money-bill classifier was given, sorted and unit-separator joined; "
            "this is the classifier's input, recorded so a classification can be re-derived."
        ),
        "short_title": (
            "The publisher's short title for the whole measure: the first titles[] entry whose titleType names a "
            "short title, which is the newest stage's because the publisher lists titles newest stage first, "
            "skipping the types that name only portions of the bill (an omnibus's divisions); NULL where the measure "
            "states no short title for the whole of it, which is ordinary."
        ),
        "related_bills_json": (
            "Every relatedBills entry the publisher states, as a JSON array, with each one's relationship "
            "details nested; this replaces BillTrax's hand-set related_bill_id with the publisher's own fact."
        ),
        "related_bill_count": "How many related bills the publisher states.",
        "cbo_cost_estimates_outcome": (
            "BILLSTATUS estimate-block observation: NULL means unread; populated means estimate items were "
            "read; requested-empty:absent means no element; requested-empty:present-and-empty means an empty "
            "element; requested-empty:unexpected-shape:<shape> names an unsupported XML shape. These are "
            "observations of this document, never evidence that no CBO estimate exists. Populated items "
            "can still have unkeyable URLs, which the family records as refusals."
        ),
        "url_source": (
            "Who stated url, and so which kind of URL it is: billstatus (the BILLSTATUS legislationUrl, "
            "the congress.gov page), congress_api (the Congress.gov detail record's legislationUrl, the same "
            "page), congress_api_list (the Congress.gov list route's url, the API resource), or inherited "
            "(this observation stated none and a host merge kept an earlier observation's value; its lineage "
            "is that earlier source, not a fresh read). NULL when url is NULL or the row predates this label."
        ),
        "cosponsors_outcome": "Source list state: absent, empty or populated; NULL means not read.",
    },
)

BILL_ACTIONS = table_contract(
    "bill_actions",
    references=(Reference(("bill_id",), "congress_bills", ("bill_id",)),),
    grain=(
        "One row per entry of the bill's own action list (actions in its BILLSTATUS document), in publisher order; "
        "actions recorded under the bill's amendments (amendments/amendment/actions) are not rows, so a roll call on "
        "an amendment can have no action here."
    ),
    identity=("bill_id", "action_index"),
    version_column="action_date",
    columns={
        "bill_id": "The bill this action belongs to.",
        "action_index": (
            "Zero-based position in the publisher's own action list, which runs newest first: 0 is the bill's latest "
            "action. Part of the identity."
        ),
        "action_date": "The publisher's actionDate for this action.",
        "action_time": "The publisher's actionTime, where the source system states one.",
        "action_text": "The action text exactly as written, whitespace included; NULL when the publisher stated none.",
        "action_code": "The publisher's action code, which is what the became-law rule keys on.",
        "action_type": "The publisher's action type (IntroReferral, Floor, BecameLaw...).",
        "source_system_code": "Code of the system that reported the action.",
        "source_system_name": "Name of the system that reported the action.",
        "recorded_vote_count": "How many recordedVote entries this action carries.",
        "is_latest_action": ("True on the one actions[] entry the publisher's separate latestAction element names."),
        "stage": (
            "The stage this one action's qualified code and text classify as, in the same vocabulary as "
            "congress_bills.stage (`introduced`, `committee`, `calendared`, `passed_chamber`, `other_chamber`, "
            "`conference`, `cleared`, `presented`, `law`, or the outcomes `failed` and `vetoed`; never `passed_both`, "
            "which is a bill's state, not one action's); `introduced` with stage_rule NULL when no rule classifies the "
            "action, as for the desk or a floor step in the bill's own chamber. An action reads `cleared` where its own "
            "words complete agreement on one text; a chamber's agreement to a conference report reads `conference` "
            "here, and the bill reads `cleared` from the second. One action's classification, not the bill's state."
        ),
        "stage_rule": (
            "Which stage rule fired on this action (the names congress_bills.stage_rule lists, but never passed_both), "
            "or NULL when none did."
        ),
        "stage_matcher": "The matched text pattern, publisher code or vote-result reading used by the named rule.",
    },
)

BILL_COMMITTEES = table_contract(
    "bill_committees",
    references=(
        Reference(("bill_id",), "congress_bills", ("bill_id",)),
        Reference(("system_code",), "committees", ("system_code",)),
    ),
    grain="One row per committee or subcommittee a bill reached, as its BILLSTATUS document names it.",
    identity=("bill_id", "system_code"),
    version_column="snapshot_update_date",
    columns={
        "bill_id": "The bill this referral belongs to.",
        "system_code": "The publisher's own committee identifier (hsap00); what a referral rule keys on.",
        "name": "The committee's name as prose, which no rule reads.",
        "chamber": "The chamber, which the publisher states for a committee and omits for a subcommittee.",
        "committee_type": "The publisher's committee type (Standing, Select...); absent on a subcommittee.",
        "parent_system_code": "The parent committee's system code when this row is a subcommittee.",
        "is_subcommittee": "True when this row came from another committee's subcommittees list.",
        "snapshot_update_date": "The parent document's updateDate, so a committee list is versioned with its bill.",
        "referral_signal": (
            "The money-bill referral signal this system code raises, from the six full-committee codes; "
            "NULL outside them, supplied by the caller that owns the vocabulary."
        ),
        "referral_rule": "The rule applied to produce referral_signal; a system-code lookup, never a name match.",
    },
)

BILL_COMMITTEE_ACTIVITIES = table_contract(
    "bill_committee_activities",
    references=(
        Reference(("bill_id",), "congress_bills", ("bill_id",)),
        Reference(("bill_id", "system_code"), "bill_committees", ("bill_id", "system_code")),
    ),
    grain=(
        "One row per activity a BILLSTATUS document lists under one of the bill's committees or subcommittees: what "
        "the committee did and when. A clean key for a committee's work but not a complete one: 119-s-545's lists "
        "Markup By and no Reported By while its actions record the report, so a report can appear in bill_actions "
        "only."
    ),
    identity=("bill_id", "system_code", "activity_name", "activity_date", "occurrence"),
    version_column="snapshot_update_date",
    columns={
        "bill_id": "The bill whose committee this activity belongs to.",
        "system_code": "The publisher's identifier of the committee or subcommittee that did it (ssju00).",
        "activity_name": (
            "The publisher's activity name exactly as written, in either capitalisation it uses (Reported By and "
            "Reported by, Referred To and Referred to): Referred To, Markup By, Reported By, Discharged From, "
            "Hearings By (full committee), Hearings By (subcommittee), Reported Original Measure, Bills of Interest - "
            "Exchange of Letters, Unknown."
        ),
        "activity_date": (
            "The publisher's timestamp for it, as written (2026-05-11T20:30:49Z), in UTC: an evening step can fall on "
            "the next day here while bill_actions.action_date keeps the day the publisher states for the action "
            "(119-hr-1703's discharge: 2026-10-01T03:17:50Z here, 2026-09-30 there). Empty where the item states none, "
            "as every Bills of Interest - Exchange of Letters item does."
        ),
        "occurrence": (
            "1 for an activity's first listing under this committee, 2 for an exact repeat (same name and "
            "timestamp), and so on: the publisher lists some referrals twice (119-s-545)."
        ),
        "parent_system_code": "The parent committee's system code when the activity is a subcommittee's.",
        "snapshot_update_date": "The parent document's updateDate, so a committee's activities are versioned with its bill.",
    },
)

BILL_PUBLISHER_SUMMARIES = table_contract(
    "bill_publisher_summaries",
    references=(Reference(("bill_id",), "congress_bills", ("bill_id",)),),
    grain="One row per CRS summary the publisher states on a bill, at the version and action it describes.",
    identity=("bill_id", "summary_version_code", "action_date"),
    version_column="update_date",
    columns={
        "bill_id": "The bill this summary describes.",
        "summary_version_code": "The publisher's two-digit summary version code (00 introduced, 53 passed House...).",
        "action_date": "The date of the action this summary describes.",
        "action_desc": "The publisher's description of that action.",
        "update_date": "When the publisher last updated this summary; the merge prefers the larger value.",
        "summary_html": "The summary exactly as the publisher escaped it, from either placement, untruncated.",
        "summary_chars": "Character length of summary_html, so a truncation upstream is visible without reading it.",
    },
)


def _committee_rows(committees: object) -> int:
    """Count committees and their subcommittees at any nesting depth, as ``committee_count`` states."""
    total = 0
    for committee in committees or ():
        total += 1 + _committee_rows(committee.subcommittees)
    return total


def latest_action_index(status: object) -> int | None:
    """Where in ``actions`` the publisher's ``latestAction`` entry sits, if anywhere.

    ``<latestAction>`` is a separate element stating only date, time and text, so the link is made on those fields and
    the coded fields are then read from the matching action rather than published NULL.  The last match wins: a repeated
    date and text is the same event stated twice, and the later entry is where a newest-last list ends.
    """
    latest = status.latest_action
    if latest is None:
        return None
    found: int | None = None
    for index, action in enumerate(status.actions):
        if action.action_date == latest.action_date and action.text == latest.text:
            found = index
    return found


def _short_title(titles: object) -> str | None:
    """The first ``titles[]`` short title for the whole measure, skipping ``PORTION_SHORT_TITLE_TYPES``.

    The publisher versions a short title by chamber and text version and lists titles newest stage first (the
    display title, then reported or passed, introduced last), so the first is the newest stage's. ``None`` when the
    measure states no short title for the whole of it: ordinary for an official title, and the reading for the 12
    bills of the 119th whose only short titles name portions (2026-10-03).
    """
    for entry in titles or ():
        title_type = entry.title_type
        if (
            isinstance(title_type, str)
            and "short title" in title_type.lower()
            and title_type not in PORTION_SHORT_TITLE_TYPES
        ):
            return entry.title
    return None


def _related_bill(entry: object) -> dict[str, object]:
    """One ``relatedBills`` entry, with its relationship details nested rather than re-quoted.

    ``RelatedBill.relationship_details_json`` is already canonical JSON, so it
    is read back before being embedded: a JSON document inside a JSON string is
    a second escaping every consumer would have to undo.
    """
    return {
        "congress": entry.congress,
        "bill_type": entry.bill_type,
        "number": entry.number,
        "title": entry.title,
        "latest_action_date": entry.latest_action_date,
        "latest_action_text": entry.latest_action_text,
        "relationship_details": read_json_column(entry.relationship_details_json),
    }


def shape_bill(
    status: object,
    *,
    referrals: frozenset[str],
    stage: object,
    signing: object,
    money: object,
) -> Row:
    """One ``congress_bills`` row from one BILLSTATUS document and the stage, signing and money findings.

    Each interpreted column is published beside the provenance columns of the finding that produced it, and
    ``referrals`` -- what the money-bill classifier was given -- is published so the classification can be re-derived
    from the row.
    """
    identity = status.identity
    latest = status.latest_action
    # The coded fields live on the action, not on <latestAction>; see
    # latest_action_index for why the two have to be linked rather than read
    # from one element.
    index = latest_action_index(status)
    coded = status.actions[index] if index is not None else None
    related = status.related_bills
    laws = status.laws or ()
    return {
        "bill_id": bill_id(identity),
        "congress": text(identity.congress),
        "bill_type": text(identity.bill_type),
        "bill_number": text(identity.number),
        "title": text(status.title),
        "origin_chamber": text(status.origin_chamber),
        "latest_action_date": text(None if latest is None else latest.action_date),
        "latest_action_text": text(None if latest is None else latest.text),
        "update_date": text(status.update_date),
        "url": text(status.legislation_url),
        "schema_version": text(status.schema_version),
        "update_date_including_text": text(status.update_date_including_text),
        "introduced_date": text(status.introduced_date),
        "policy_area": text(status.policy_area),
        "subjects_json": json_column(list(status.subjects)),
        "subject_count": text(len(status.subjects)),
        "sponsor_bioguide_id": text(status.sponsors[0].bioguide_id if status.sponsors else None),
        "sponsor_full_name": text(status.sponsors[0].full_name if status.sponsors else None),
        "cosponsor_count": text(None if status.cosponsors is None else len(status.cosponsors)),
        "latest_action_code": text(None if coded is None else coded.action_code),
        "latest_action_time": text(None if latest is None else latest.action_time),
        "latest_action_source_system_code": text(None if coded is None else coded.source_system_code),
        "latest_action_source_system_name": text(None if coded is None else coded.source_system_name),
        "action_count": text(len(status.actions)),
        "committee_count": text(_committee_rows(status.committees)),
        "version_count": text(len(status.text_versions)),
        "public_law_number": text(signing.public_law_number),
        "law_type": text(laws[0].type if laws else None),
        # Published on the laws table and joined at merge time; see this column's description.
        "statutes_at_large_cite": None,
        "stage": text(stage.stage),
        "stage_rule": text(stage.rule),
        "stage_matcher": text(stage.matcher),
        "stage_action_index": text(stage.action_index),
        "stage_action_date": text(stage.action_date),
        "stage_source_text": text(stage.source_text),
        "signed_date": text(signing.signed_date),
        "signed_date_rule": text(signing.rule),
        "signed_date_action_index": text(signing.action_index),
        "signed_date_action_code": text(signing.action_code),
        "money_bill_kind": text(money.kind),
        "money_bill_rule": text(money.rule),
        "money_bill_reason_codes": joined(money.reason_codes) or None,
        "fiscal_year": text(money.fiscal_year),
        "appropriations_subcommittee": text(money.subcommittee),
        "referral_signals": joined(sorted(referrals)) or None,
        "short_title": text(_short_title(status.titles)),
        "related_bills_json": json_column([_related_bill(entry) for entry in related]),
        "related_bill_count": text(len(related)),
        "cbo_cost_estimates_outcome": text(getattr(status, "cbo_cost_estimates_outcome", None)),
        "url_source": "billstatus" if text(status.legislation_url) else None,
        "cosponsors_outcome": text(getattr(status, "cosponsors_outcome", None)),
    }


def shape_bill_action(
    identity: object,
    action: object,
    *,
    action_index: int,
    is_latest: bool,
    stage: object,
) -> Row:
    """One ``bill_actions`` row, with the stage this one action's own text classifies as."""
    return {
        "bill_id": bill_id(identity),
        "action_index": text(action_index),
        "action_date": text(action.action_date),
        "action_time": text(action.action_time),
        "action_text": text(action.text),
        "action_code": text(action.action_code),
        "action_type": text(action.action_type),
        "source_system_code": text(action.source_system_code),
        "source_system_name": text(action.source_system_name),
        "recorded_vote_count": text(len(action.recorded_votes)),
        "is_latest_action": flag(is_latest),
        "stage": text(stage.stage),
        "stage_rule": text(stage.rule),
        "stage_matcher": text(stage.matcher),
    }


def shape_bill_committee(
    identity: object,
    committee: object,
    *,
    parent_system_code: str | None,
    update_date: str | None,
    referral_signal: str | None = None,
) -> Row:
    """One ``bill_committees`` row for a committee or one of its subcommittees.

    ``referral_signal`` is passed in rather than looked up: the six full-committee
    system codes are ``interpretation.money_bills.COMMITTEE_CODES``, and this
    module does not import that package.  ``referral_rule`` still records which
    rule produced the answer, including when that answer is NULL.
    """
    return {
        "bill_id": bill_id(identity),
        "system_code": text(committee.system_code),
        "name": text(committee.name),
        "chamber": text(committee.chamber),
        "committee_type": text(committee.type),
        "parent_system_code": text(parent_system_code),
        "is_subcommittee": flag(parent_system_code is not None),
        "snapshot_update_date": text(update_date),
        "referral_signal": text(referral_signal),
        "referral_rule": COMMITTEE_REFERRAL_RULE,
    }


def shape_bill_committee_activity(
    identity: object,
    committee: object,
    activity: object,
    *,
    occurrence: int,
    parent_system_code: str | None,
    update_date: str | None,
) -> Row:
    """One ``bill_committee_activities`` row: one activity item of a committee, counted among its exact repeats."""
    return {
        "bill_id": bill_id(identity),
        "system_code": text(committee.system_code),
        "activity_name": activity.name or "",
        "activity_date": activity.date or "",
        "occurrence": text(occurrence),
        "parent_system_code": text(parent_system_code),
        "snapshot_update_date": text(update_date),
    }


def shape_bill_publisher_summary(identity: object, summary: object) -> Row:
    """One ``bill_publisher_summaries`` row: the CRS summary the publisher states."""
    return {
        "bill_id": bill_id(identity),
        "summary_version_code": text(summary.version_code),
        "action_date": text(summary.action_date),
        "action_desc": text(summary.action_desc),
        "update_date": text(summary.update_date),
        "summary_html": text(summary.text),
        "summary_chars": text(len(summary.text)),
    }


__all__ = [
    "BILL_ACTIONS",
    "BILL_COMMITTEES",
    "BILL_COMMITTEE_ACTIVITIES",
    "BILL_PUBLISHER_SUMMARIES",
    "COMMITTEE_REFERRAL_RULE",
    "CONGRESS_BILLS",
    "latest_action_index",
    "shape_bill",
    "shape_bill_action",
    "shape_bill_committee",
    "shape_bill_committee_activity",
    "shape_bill_publisher_summary",
]


BILL_COSPONSORS = table_contract(
    "bill_cosponsors",
    grain="One cosponsor occurrence in one retained BILLSTATUS observation.",
    identity=("bill_id", "input_sha256", "cosponsor_index"),
    version_column=None,
    references=(
        Reference(("bill_id",), "congress_bills", ("bill_id",)),
        Reference(("bioguide_id",), "members", ("bioguide_id",)),
    ),
    columns={
        "bill_id": "The bill whose source lists the cosponsor.",
        "input_sha256": "Digest of the complete input XML bytes, not the reserialized item.",
        "cosponsor_index": "Zero-based position in the source cosponsors list, including repeated members.",
        "bioguide_id": "Source member identifier; its presence does not prove target resolution.",
        "full_name": "The source's fullName literal.",
        "sponsorship_date": "Literal sponsorshipDate; absent is NULL and present empty is an empty string.",
        "sponsorship_date_status": "Calendar spelling status: absent, empty, valid or invalid.",
        "is_original_raw": "Literal isOriginalCosponsor text, without Boolean coercion.",
        "sponsorship_withdrawn_date": "Literal sponsorshipWithdrawnDate; retained BILLSTATUS source observations include positive dates.",
        "sponsorship_withdrawn_date_status": "Calendar spelling status, not confirmation of a withdrawal event.",
        "party": "Party as the cosponsor entry states it.",
        "state": "State as the cosponsor entry states it.",
        "district": "District as the cosponsor entry states it.",
        "source_path": "XPath to the occurrence in the retained XML.",
        "source_xml": (
            "The cosponsor item's markup exactly as the publisher wrote it, from <item> through </item>, cut from "
            "the input bytes input_sha256 pins; it keeps every field, including those no column reads."
        ),
    },
)


#: The ``BillCosponsor`` fields a row copies as text, read by attribute so this module stays a leaf.
_COSPONSOR_FIELDS: tuple[str, ...] = (
    "bioguide_id",
    "full_name",
    "sponsorship_date",
    "sponsorship_date_status",
    "is_original_raw",
    "sponsorship_withdrawn_date",
    "sponsorship_withdrawn_date_status",
    "party",
    "state",
    "district",
)


def shape_bill_cosponsor(status: object, *, cosponsor_index: int) -> Row:
    """Project one parsed occurrence; never merge repeated member entries.

    Every refusal is a :class:`TableContractError`, which the bill family files against this row
    (``interpretation.bill_family.SHAPER_REFUSALS``) instead of aborting the bill's whole pass: a status without its
    input digest, an unread list, an index outside it, and an entry that is not a ``BillCosponsor`` (0.47.0 typed the
    list as ``BillSponsor``).
    """
    if not status.input_sha256:
        raise TableContractError("cosponsor projection requires the retained input digest")
    if type(cosponsor_index) is not int or cosponsor_index < 0:
        raise TableContractError("cosponsor_index must be a nonnegative integer")
    if status.cosponsors is None:
        raise TableContractError("cosponsor list was not read")
    if cosponsor_index >= len(status.cosponsors):
        raise TableContractError(f"cosponsor_index {cosponsor_index} is outside a list of {len(status.cosponsors)}")
    entry = status.cosponsors[cosponsor_index]
    try:
        values = {name: text(getattr(entry, name)) for name in _COSPONSOR_FIELDS}
        source_xml = entry.source_xml
    except AttributeError as error:
        raise TableContractError(f"cosponsor entry is a {type(entry).__name__} without {error.name}") from error
    return {
        "bill_id": bill_id(status.identity),
        "input_sha256": status.input_sha256,
        "cosponsor_index": text(cosponsor_index),
        **values,
        "source_path": f"/billStatus/bill/cosponsors/item[{cosponsor_index + 1}]",
        "source_xml": source_xml,
    }


__all__ += ["BILL_COSPONSORS", "shape_bill_cosponsor"]
