"""Shared structural event tree promoted from the worked DocumentCapture converter.

The tree preserves mixed text and original-byte coordinates. Source readers apply
publisher grammars; it does not assign legal meaning or acquire documents.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any

from spicy_docs.reading.markup import MarkupEvent, MarkupRead


@dataclass(frozen=True)
class Grammar:
    """A family's element roles. Anything unnamed is transparent; its text becomes a ``text`` leaf.

    Element names keep their prefix (``dc:title``), because a local name can
    collide with the family's own vocabulary: a bill's ``<title>`` is a
    division, its Dublin Core ``<dc:title>`` is metadata.
    """

    name: str
    containers: Mapping[str, str]
    leaves: Mapping[str, str]
    inline: frozenset[str]
    furniture: Mapping[str, str] = field(default_factory=dict)
    derivation: str = "native"
    heading_level: Callable[[Elem], int | None] | None = None

    def role(self, name: str) -> str | None:
        for table in (self.containers, self.leaves, self.furniture):
            if name in table:
                return table[name]
        return None


@dataclass
class Elem:
    name: str
    attributes: dict[str, str | None]
    byte_start: int
    byte_end: int | None
    path: str
    parts: list[Elem | MarkupEvent] = field(default_factory=list)
    namespace_uri: str = ""
    native_path: str = ""
    #: Memo for ``has_structure``. Without it the walk asks the same subtree
    #: once per enclosing level, which is O(n*depth) over one document.
    _structure: bool | None = field(default=None, repr=False, compare=False)

    def has_structure(self, grammar: Grammar) -> bool:
        if self._structure is None:
            self._structure = any(
                isinstance(part, Elem)
                and (
                    grammar.role(part.name) is not None
                    or (part.name not in grammar.inline and part.has_structure(grammar))
                )
                for part in self.parts
            )
        return self._structure


def element_tree(read: MarkupRead, body: bytes) -> Elem:
    """Fold the reader's flat events into a tree, keeping every text event and its byte span."""
    root = Elem("", {}, 0, len(body), "")
    stack: list[Elem] = [root]
    counts: list[dict[str, int]] = [{}]
    namespaces: list[dict[str, str]] = [{}]
    expanded_counts: list[dict[tuple[str, str], int]] = [{}]
    for event in read.events:
        if event.kind in ("start", "empty"):
            name = event.name or ""
            # Counted by local name, not by the prefixed name, so the index is
            # the one an XPath with no namespace context would compute. The
            # step keeps the publisher's own spelling; leaf_fragments rewrites
            # it to *[local-name()='...'] and the index still selects.
            local = name.rpartition(":")[2]
            counts[-1][local] = counts[-1].get(local, 0) + 1
            path = f"{stack[-1].path}/{name}[{counts[-1][local]}]"
            elem = Elem(name, dict(event.attributes), event.byte_start, None, path)
            scope = namespaces[-1] | dict(event.namespace_declarations)
            prefix = name.partition(":")[0] if ":" in name else ""
            elem.namespace_uri = scope.get(prefix, "")
            expanded = (elem.namespace_uri, local)
            expanded_counts[-1][expanded] = expanded_counts[-1].get(expanded, 0) + 1
            # XPath literals escape namespace URI quotes without trusting source text as code.
            uri = xpath_literal(elem.namespace_uri)
            step = f"*[local-name()={xpath_literal(local)} and namespace-uri()={uri}]"
            elem.native_path = f"{stack[-1].native_path}/{step}[{expanded_counts[-1][expanded]}]"
            stack[-1].parts.append(elem)
            if event.kind == "start":
                stack.append(elem)
                counts.append({})
                namespaces.append(scope)
                expanded_counts.append({})
            else:
                elem.byte_end = event.byte_end
        elif event.kind == "end":
            elem = stack.pop()
            counts.pop()
            namespaces.pop()
            expanded_counts.pop()
            tag = f"</{event.name}>".encode()
            end = event.byte_start + len(tag)
            elem.byte_end = end if body[event.byte_start : end] == tag else None
        elif event.kind == "text" and event.text:
            stack[-1].parts.append(event)
    return root


def xpath_literal(value: str) -> str:
    """An XPath 1.0 string literal, including source names containing both quote kinds."""
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    return "concat(" + ',"\'",'.join(f"'{part}'" for part in value.split("'")) + ")"


def locator(elem: Elem) -> dict[str, Any]:
    out: dict[str, Any] = {"coordinateSystem": "xml-node-path", "path": elem.path, "element": elem.name}
    if elem.attributes:
        out["attributes"] = elem.attributes
    if elem.byte_end is not None:
        out.update(start=elem.byte_start, end=elem.byte_end)
    return out


def text_source(event: MarkupEvent) -> dict[str, Any]:
    return {
        "coordinateSystem": "utf8-byte",
        "start": event.byte_start,
        "end": event.byte_end,
        "literal": event.is_literal,
    }
