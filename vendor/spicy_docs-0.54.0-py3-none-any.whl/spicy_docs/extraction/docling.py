"""Thin lazy adapter for Docling's rendered-page pipeline and stated table cells."""

from __future__ import annotations

import io
import math
import platform
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Literal

from .docling_markdown import CONVERSION, convert_markdown
from .model import ExtractionError, Raster, Recognition, TableCell, TableObservation


@dataclass(frozen=True, slots=True)
class _DoclingBaseSettings:
    document_timeout: float | None = None
    artifacts_path: str | None = None
    compact_tables: bool = False
    strict_text: bool = False
    include_annotations: bool = True

    def __post_init__(self):
        if self.document_timeout is not None and (
            not math.isfinite(self.document_timeout) or self.document_timeout <= 0
        ):
            raise ValueError("document_timeout must be finite and positive")

    def export_options(self):
        return {
            "compact_tables": self.compact_tables,
            "strict_text": self.strict_text,
            "include_annotations": self.include_annotations,
        }


@dataclass(frozen=True, slots=True)
class DoclingSettings(_DoclingBaseSettings):
    """Apple Vision, Egret Large and accurate TableFormer V1; RapidOCR is explicit."""

    ocr_engine: Literal["ocrmac", "rapidocr"] = "ocrmac"
    languages: tuple[str, ...] | None = None
    ocr_scale: float = 300 / 72
    ocr_mode: Literal["default", "full_page", "layout_regions", "pdf_aware_layout_regions"] = "full_page"
    layout_model: str = "layout_egret_large"
    layout_revision: str = "fff417c78abd6bab338c87706c95a8d79dc68f1e"
    table_engine: Literal["docling_tableformer", "docling_tableformer_v2"] = "docling_tableformer"
    table_mode: Literal["accurate", "fast"] = "accurate"
    cell_matching: bool = True
    do_tables: bool = True

    def __post_init__(self):
        _DoclingBaseSettings.__post_init__(self)
        if self.ocr_engine not in {"ocrmac", "rapidocr"}:
            raise ValueError("unsupported Docling OCR engine")
        if self.table_engine not in {"docling_tableformer", "docling_tableformer_v2"}:
            raise ValueError("unsupported Docling table engine")
        if self.table_mode not in {"accurate", "fast"}:
            raise ValueError("table_mode must be accurate or fast")
        if self.table_engine.endswith("v2") and self.table_mode != "accurate":
            raise ValueError("TableFormer v2 does not expose a fast/accurate mode")
        if not math.isfinite(self.ocr_scale) or self.ocr_scale <= 0:
            raise ValueError("ocr_scale must be finite and positive")

    def check_platform(self):
        if self.ocr_engine == "ocrmac" and platform.system() != "Darwin":
            raise ExtractionError(
                "Apple Vision requires macOS; select DoclingSettings(ocr_engine='rapidocr') elsewhere"
            )

    def options(self):
        from docling.datamodel.pipeline_options import (
            LayoutObjectDetectionOptions,
            OcrMacOptions,
            OcrMode,
            PdfPipelineOptions,
            RapidOcrOptions,
            TableFormerMode,
            TableStructureOptions,
            TableStructureV2Options,
        )

        engine = self.ocr_engine
        languages = self.languages
        if languages is None:
            languages = ("en-US",) if engine == "ocrmac" else ("en",)
        ocr_class = OcrMacOptions if engine == "ocrmac" else RapidOcrOptions
        ocr = ocr_class(lang=list(languages), scale=self.ocr_scale, mode=OcrMode(self.ocr_mode))
        table = (
            TableStructureV2Options(do_cell_matching=self.cell_matching)
            if self.table_engine.endswith("v2")
            else TableStructureOptions(do_cell_matching=self.cell_matching, mode=TableFormerMode(self.table_mode))
        )
        layout = LayoutObjectDetectionOptions.from_preset(self.layout_model).model_copy(deep=True)
        layout.model_spec.revision = self.layout_revision
        return PdfPipelineOptions(
            ocr_options=ocr,
            layout_options=layout,
            table_structure_options=table,
            do_ocr=True,
            do_table_structure=self.do_tables,
            document_timeout=self.document_timeout,
            artifacts_path=self.artifacts_path,
            generate_parsed_pages=True,
        )


@dataclass(frozen=True, slots=True)
class DoclingVlmSettings(_DoclingBaseSettings):
    """Full-page MLX alternatives; these replace separate OCR/layout/table stages."""

    model: Literal["glm-ocr", "lightonocr", "qwen2.5-vl-3b", "ovisocr2", "nuextract3"] = "glm-ocr"
    max_tokens: int = 4096
    image_scale: float = 300 / 72

    def __post_init__(self):
        _DoclingBaseSettings.__post_init__(self)
        if self.model not in {"glm-ocr", "lightonocr", "qwen2.5-vl-3b", "ovisocr2", "nuextract3"}:
            raise ValueError("unsupported Docling VLM model")
        if type(self.max_tokens) is not int or self.max_tokens < 1:
            raise ValueError("max_tokens must be a positive integer")
        if not math.isfinite(self.image_scale) or self.image_scale <= 0:
            raise ValueError("image_scale must be finite and positive")

    def check_platform(self):
        if platform.system() != "Darwin" or platform.machine() != "arm64":
            raise ExtractionError("Docling MLX alternatives require Apple Silicon macOS")

    def options(self):
        from docling.datamodel.pipeline_options import VlmConvertOptions, VlmPipelineOptions
        from docling.datamodel.pipeline_options_vlm_model import ResponseFormat
        from docling.datamodel.stage_model_specs import VlmModelSpec
        from docling.datamodel.vlm_engine_options import MlxVlmEngineOptions, VlmEngineType

        # Reuse Docling's prompts and pipeline, pinning the MLX weights tested here.
        existing = {
            "glm-ocr": ("glm_ocr", "24f15402e83baa0a80eeeaecf5480e172abc6f2e"),
            "lightonocr": ("lightonocr", "16e06849ba5c689f782473651914d6613d25d884"),
            "qwen2.5-vl-3b": ("qwen", "33765717028a7f0514ea1d213035cddf4b32c500"),
        }
        if self.model in existing:
            preset, revision = existing[self.model]
            vlm = VlmConvertOptions.from_preset(preset, engine_options=MlxVlmEngineOptions()).model_copy(deep=True)
            vlm.model_spec.engine_overrides[VlmEngineType.MLX].revision = revision
        else:
            from .docling_assets import ADDITIONAL_VLM_MODELS

            repo, revision, prompt = ADDITIONAL_VLM_MODELS[self.model]
            spec = VlmModelSpec(
                name=self.model,
                default_repo_id=repo,
                revision=revision,
                prompt=prompt,
                response_format=ResponseFormat.MARKDOWN,
                max_new_tokens=self.max_tokens,
                temperature=0,
            )
            vlm = VlmConvertOptions(model_spec=spec, engine_options=MlxVlmEngineOptions())
        vlm.model_spec.max_new_tokens = self.max_tokens
        vlm.model_spec.temperature = 0
        vlm.scale = self.image_scale
        return VlmPipelineOptions(
            vlm_options=vlm,
            document_timeout=self.document_timeout,
            artifacts_path=self.artifacts_path,
            images_scale=self.image_scale,
        )

    def prepare_artifacts(self, *, local_files_only: bool = False) -> dict:
        """Prepare pinned MLX assets for Docling and return their file identity."""
        if self.artifacts_path is None:
            raise ValueError("artifacts_path is required to prepare Docling VLM assets")
        from .docling_assets import prepare_vlm_artifacts

        options = self.options()
        spec = options.vlm_options.model_spec
        engine = options.vlm_options.engine_options.engine_type
        return prepare_vlm_artifacts(
            artifacts_path=self.artifacts_path,
            repo_id=spec.get_repo_id(engine),
            revision=spec.get_revision(engine),
            processor_compatibility=self.model in {"ovisocr2", "nuextract3"},
            local_files_only=local_files_only,
        )


def _dump(value):
    if hasattr(value, "model_dump"):
        return _dump(value.model_dump(mode="json", serialize_as_any=True))
    if isinstance(value, (list, tuple)):
        return [_dump(item) for item in value]
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise ExtractionError("Docling evidence contains unsupported non-string mapping keys")
        return {key: _dump(item) for key, item in value.items()}
    if isinstance(value, float) and not math.isfinite(value):
        return {
            "nonfinite_float": "nan"
            if math.isnan(value)
            else ("positive_infinity" if value > 0 else "negative_infinity")
        }
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise ExtractionError(f"Docling evidence contains unsupported value type: {type(value).__name__}")


def _versions():
    result = {}
    for name in (
        "docling",
        "docling-core",
        "docling-ibm-models",
        "docling-parse",
        "marko",
        "beautifulsoup4",
        "rapidocr",
        "ocrmac",
        "mlx-vlm",
        "mlx",
        "mlx-metal",
        "transformers",
        "torch",
        "tokenizers",
        "huggingface-hub",
        "safetensors",
        "numpy",
    ):
        try:
            result[name] = version(name)
        except PackageNotFoundError:
            result[name] = None
    return result


def adapt_tables(document: dict) -> tuple[TableObservation, ...]:
    """Keep stated cells and spans; unknown geometry remains unplaced.

    Docling's page-space boxes have not been qualified against displayed crops.
    Native coordinates, provenance, section flags and other fields remain in raw.
    A merged cell occupies its anchor only; covered positions remain unknown.
    """
    tables = []
    for table in document.get("tables", []):
        data = table.get("data", {})
        rows, columns = data.get("num_rows", 0), data.get("num_cols", 0)
        if not rows or not columns:
            continue
        cells = [[None for _ in range(columns)] for _ in range(rows)]
        details = []
        occupied = set()
        for cell in data.get("table_cells", []):
            row, column = cell["start_row_offset_idx"], cell["start_col_offset_idx"]
            end_row, end_column = cell["end_row_offset_idx"], cell["end_col_offset_idx"]
            if not (0 <= row < end_row <= rows and 0 <= column < end_column <= columns):
                raise ExtractionError("Docling table cell falls outside its stated grid", details=table)
            positions = {(r, c) for r in range(row, end_row) for c in range(column, end_column)}
            if positions & occupied:
                raise ExtractionError("Docling table has overlapping cell spans", details=table)
            occupied.update(positions)
            if (
                cell.get("row_span", end_row - row) != end_row - row
                or cell.get("col_span", end_column - column) != end_column - column
            ):
                raise ExtractionError("Docling table has inconsistent cell spans", details=table)
            # RichTableCell may contain references rather than a literal text field.
            text = cell.get("text")
            cells[row][column] = text
            details.append(
                TableCell(
                    row=row,
                    column=column,
                    text=text,
                    row_span=end_row - row,
                    column_span=end_column - column,
                    column_header=cell.get("column_header", False),
                    row_header=cell.get("row_header", False),
                    row_section=cell.get("row_section", False),
                )
            )
        tables.append(
            TableObservation(
                page=1,
                bbox=None,
                row_count=rows,
                column_count=columns,
                cells=tuple(tuple(row) for row in cells),
                cell_boxes=tuple(tuple(None for _ in range(columns)) for _ in range(rows)),
                raw=table,
                cell_details=tuple(details),
            )
        )
    return tuple(tables)


class Docling:
    """Reusable rendered-page converter; only explicit SUCCESS completes a read."""

    def __init__(
        self,
        *,
        settings: DoclingSettings | DoclingVlmSettings | None = None,
        converter=None,
        converter_identity: dict | None = None,
        model_identity: dict | None = None,
    ):
        if converter is not None and settings is not None:
            raise ValueError("configure an injected Docling converter before passing it")
        if converter_identity is not None and not converter_identity:
            raise ValueError("converter_identity must contain explicit processing identity")
        self.settings = settings or DoclingSettings()
        self._converter, self._injected = converter, converter is not None
        self.converter_identity = _dump(converter_identity)
        self.model_identity = _dump(model_identity)
        self._options: Any = None

    def require_reproducible_identity(self):
        if self._injected and self.converter_identity is None:
            raise ValueError("retained Docling runs require explicit converter_identity for an injected converter")
        if not self._injected and not self.model_identity:
            raise ValueError("retained Docling runs require explicit model_identity for selected model artifacts")
        return self.configuration()

    def configuration(self):
        if not self._injected and self._options is None:
            self._options = self.settings.options()
        standard = not self._injected and isinstance(self.settings, DoclingSettings)
        vlm = not self._injected and isinstance(self.settings, DoclingVlmSettings)
        return {
            "backend": "docling",
            "version": _versions()["docling"],
            "versions": _versions(),
            "platform": platform.platform(),
            "python": platform.python_version(),
            "engine_injected": self._injected,
            "converter_identity": self.converter_identity,
            "model_identity": self.model_identity,
            "model_identity_resolved": bool(self.converter_identity if self._injected else self.model_identity),
            "pipeline": "standard" if standard else ("vlm" if vlm else None),
            "markdown_conversion": CONVERSION if vlm else None,
            "ocr_engine": self._options.ocr_options.kind if standard else None,
            "table_engine": self._options.table_structure_options.kind
            if standard and self._options.do_table_structure
            else None,
            "vlm_model": self._options.vlm_options.model_spec.get_repo_id(
                self._options.vlm_options.engine_options.engine_type
            )
            if vlm
            else None,
            "vlm_revision": self._options.vlm_options.model_spec.get_revision(
                self._options.vlm_options.engine_options.engine_type
            )
            if vlm
            else None,
            "pipeline_options": None
            if self._injected
            else self._options.model_dump(mode="json", serialize_as_any=True),
            "export_options": self.settings.export_options(),
        }

    def recognize(self, image: Raster) -> Recognition:
        if not self._injected:
            self.settings.check_platform()
        from docling.datamodel.base_models import DocumentStream

        configuration = {**self.configuration(), "media_type": image.media_type}
        if self._converter is None:
            from docling.datamodel.base_models import InputFormat
            from docling.document_converter import DocumentConverter, ImageFormatOption

            if isinstance(self.settings, DoclingVlmSettings):
                from docling.pipeline.vlm_pipeline import VlmPipeline

                format_option = ImageFormatOption(pipeline_cls=VlmPipeline, pipeline_options=self._options)
            else:
                format_option = ImageFormatOption(pipeline_options=self._options)
            self._converter = DocumentConverter(format_options={InputFormat.IMAGE: format_option})
        suffix = {"image/png": "png", "image/jpeg": "jpg", "image/tiff": "tif"}.get(image.media_type)
        if suffix is None:
            raise ExtractionError("Docling rendered-page input requires PNG, JPEG or TIFF")
        result = self._converter.convert(
            DocumentStream(name=f"page.{suffix}", stream=io.BytesIO(image.data)),
            raises_on_error=False,
        )
        status = getattr(result, "status", None)
        status_name = getattr(status, "name", None)
        if status_name is None and isinstance(status, str):
            status_name = status.upper()
        document = getattr(result, "document", None)
        raw = {
            "status": status_name,
            "errors": _dump(getattr(result, "errors", [])),
            "document": _dump(document.export_to_dict()) if document is not None else None,
            "pages": _dump(getattr(result, "pages", [])),
            "timings": _dump(getattr(result, "timings", {})),
            "confidence": _dump(getattr(result, "confidence", None)),
            "version": _dump(getattr(result, "version", None)),
            "configuration": configuration,
        }
        try:
            text = document.export_to_markdown(**self.settings.export_options()) if document is not None else None
        except Exception as exc:
            raw["export_error"] = {"type": type(exc).__name__}
            raise ExtractionError("Docling Markdown export failed", details=raw) from exc
        raw["text"] = text
        if status_name != "SUCCESS" or document is None or not isinstance(text, str):
            raise ExtractionError("Docling conversion failed or did not complete", details=raw)
        if not self._injected and isinstance(self.settings, DoclingVlmSettings):
            for page in raw["pages"]:
                prediction = page.get("predictions", {}).get("vlm_response")
                if prediction is None:
                    raise ExtractionError("Docling VLM returned no prediction", details=raw)
                # Docling's MLX engine counts stream events, including a final event,
                # and currently reports unspecified even at the token limit.
                count = prediction.get("num_tokens")
                if prediction.get("stop_reason") in {
                    "length",
                    "content_filter",
                    "content_filtered",
                    "inference_error",
                } or (isinstance(count, int) and count > self.settings.max_tokens):
                    raise ExtractionError("Docling VLM generation may be incomplete", details=raw)
            if not raw["pages"]:
                raise ExtractionError("Docling VLM returned no page predictions", details=raw)
            # These full-page alternatives emit Markdown. Reparse the retained response
            # through GFM so nested HTML survives and malformed pipe rows remain text.
            # Keep upstream output separately; it can already have dropped source rows.
            if len(raw["pages"]) != 1:
                raise ExtractionError("Docling rendered-page VLM returned multiple page predictions", details=raw)
            source = raw["pages"][0]["predictions"]["vlm_response"].get("text")
            if not isinstance(source, str) or not source.strip():
                raise ExtractionError("Docling VLM returned no prediction text", details=raw)
            raw["upstream_document"], raw["upstream_text"] = raw["document"], raw["text"]
            try:
                document, receipt = convert_markdown(source)
                raw["document"] = _dump(document.export_to_dict())
                raw["markdown_conversion"] = receipt
                text = document.export_to_markdown(**self.settings.export_options())
                raw["text"] = text
            except ExtractionError as exc:
                raw["conversion_error"] = exc.details
                raise ExtractionError(str(exc), details=raw) from exc
            except Exception as exc:
                raw["conversion_error"] = {"type": type(exc).__name__}
                raise ExtractionError("Docling generated Markdown conversion failed", details=raw) from exc
        try:
            tables = adapt_tables(raw["document"])
        except ExtractionError as exc:
            raw["table_error"] = exc.details
            raise ExtractionError(str(exc), details=raw) from exc
        return Recognition(text, configuration, raw, tables=tables, text_format="markdown")
