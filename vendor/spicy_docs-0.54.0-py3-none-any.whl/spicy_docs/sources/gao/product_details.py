"""What a GAO product page states beyond its topic: recommendation and matter counts, page count, subject terms.

The CetiAlphaFive/gao R package (commit 6f61230) gives ``gao_reports`` these columns for the reports it lists; this
reader states them for any product page, so a host can fill them for reports issued after that copy. A product page
states them in three places (findings over 14 pages on 2026-09-29 and 23 on 2026-10-04:
``corpora/gao-product-pages-2026-09-29/FINDINGS.md``, ``corpora/gao-product-pages-2026-10-04/``):

- each recommendations view, ``<section class="view--recommendations--block-N">``: block 1 is "Recommendations for
  Executive Action" (Agency Affected / Recommendation / Status), block 3 "Matter for Congressional Consideration"
  (Matter / Status / Comments), one table row per recommendation or matter, all of them on the page (gao-04-49 lists
  239, the package's largest count). A page without the view makes none: GAO prints the section only for a product
  that makes one, and that equals the package's 0 on every page compared;
- the full-reports group: the ``(N pages)`` of the file labelled ``Full Report``, never another file's (the
  "Accessible PDF" of gao-16-75sp-0 runs 114 pages to the report's 92);
- the Topics block, ``block-views-blockproducts-block-8``: each row's topic link and its subject-term ``<span>``s.

The requester type, committees and members the package states are **not fields of the page**: it read them from the
report's PDF. A summary's prose sometimes names a requesting committee ("The Chair and Ranking Member of the Senate
Committee on Rules and Administration requested", gao-26-108653) and more often only "GAO was asked" (gao-10-126);
no page names the package's requesting members. This reader states none.

``www.gao.gov`` refuses plain clients, so :class:`GaoProductPageAcquirer` reads a page through the Zyte transport its
caller injects, one request per product, paced. The page must be the one asked for (its canonical link is the
product's page); a section this reader does not know, a table whose columns or heading changed, a paged table, two
different Full Report page counts or a page count that does not read refuses rather than guessing, with the check
that failed on the error's ``reason``.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from html.parser import HTMLParser
from typing import TYPE_CHECKING, Final

from spicy_docs.reading.markup import HTML_VOID_TAGS, decode_html_page, feed_html
from spicy_docs.sources.gao.month_in_review import CRAWL_DELAY_SECONDS
from spicy_docs.sources.gao.native import MAX_PAGE_BYTES, gao_product_id, gao_product_url
from spicy_docs.sources.gao.product_metadata import FULL_REPORT_LABEL
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_byte_bound, check_timing, utc_now

if TYPE_CHECKING:
    import httpx

#: The rule a host records beside the values it fills from this reader.
PRODUCT_PAGE_DETAILS_RULE: Final = "gao-product-page-details/1"
#: Each recommendations view this reader knows: its heading and its columns, as GAO prints them on every page read.
RECOMMENDATION_VIEWS: Final = {
    "1": ("Recommendations for Executive Action", ("Agency Affected", "Recommendation", "Status")),
    "3": ("Matter for Congressional Consideration", ("Matter", "Status", "Comments")),
}
_VIEW_CLASS: Final = re.compile(r"view--recommendations--block-(\d+)")
_TOPICS_CLASS: Final = "block-views-blockproducts-block-8"
_PAGES: Final = re.compile(r"\((\d+) pages?\)")
#: The text each role's element holds; any other element inside a block only nests.
_TEXT_ROLES: Final = frozenset({"topic", "term", "heading", "column", "agency", "label", "pages"})
_LABEL: Final = "GAO product page"


class GaoProductDetailsError(ValueError):
    """A product page that cannot establish its details; ``reason`` names which check failed."""

    def __init__(self, message: str, reason: str = "acquisition") -> None:
        super().__init__(message)
        self.reason = reason


class GaoProductPageUnavailableError(GaoProductDetailsError):
    """GAO answered 404 or 410 for the product page."""

    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"{_LABEL} answered HTTP {capture.status_code}", "unavailable")
        self.capture = capture


@dataclass(frozen=True, slots=True)
class GaoProductDetails:
    """What one product page states; a list the page does not state is None, never empty."""

    product_id: str
    #: Rows of "Recommendations for Executive Action"; 0 where the page prints no such view.
    recommendation_count: int
    #: Rows of "Matter for Congressional Consideration"; 0 where the page prints no such view.
    matters_for_congress_count: int
    #: Each distinct "Agency Affected" cell, in page order; None without recommendations.
    agencies_affected: tuple[str, ...] | None
    #: The ``(N pages)`` of the file labelled Full Report; None where the page links none or states no count.
    page_count: int | None
    #: Each topic the Topics block links, in page order.
    topics: tuple[str, ...] | None
    #: Each subject term the Topics block lists, in page order, as GAO spells it.
    subject_terms: tuple[str, ...] | None


class _DetailsHtml(HTMLParser):
    """The canonical links; inside the three blocks read, each element with the role its text takes."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.canonicals: list[str] = []
        self.topic_blocks = 0
        self.topics: list[list[str]] = []
        self.terms: list[list[str]] = []
        #: Each recommendations view: its number, headings, columns, rows (each row's agency cells) and tables.
        self.views: list[dict] = []
        self.report_groups = 0
        #: Each link in the full-reports group: its label and page-count text, as parts.
        self.report_links: list[dict[str, list[list[str]]]] = []
        self._block: str | None = None
        #: Open elements inside the block, each with its role; the block's own element first.
        self._stack: list[tuple[str, str | None]] = []
        self._text: list[str] | None = None

    @property
    def unclosed(self) -> bool:
        return self._block is not None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == "link" and (attributes.get("rel") or "").casefold() == "canonical":
            self.canonicals.append(attributes.get("href") or "")
        if tag in HTML_VOID_TAGS:
            return
        classes = (attributes.get("class") or "").split()
        if self._block is None:
            self._open_block(tag, classes)
            return
        roles = {role for _, role in self._stack}
        role = self._role(tag, attributes, classes, roles)
        if role in _TEXT_ROLES:
            if roles & _TEXT_ROLES:
                raise GaoProductDetailsError(f"{_LABEL} nests a {role} inside other text it reads", "nested-text")
            self._text = self._new_text(role)
        self._stack.append((tag, role))

    def _open_block(self, tag: str, classes: list[str]) -> None:
        if tag == "section" and (match := next(filter(None, map(_VIEW_CLASS.fullmatch, classes)), None)):
            self._block = "recommendations"
            self.views.append({"number": match[1], "headings": [], "columns": [], "rows": [], "tables": 0})
        elif tag == "section" and "full-reports-group" in classes:
            self._block = "reports"
            self.report_groups += 1
        elif tag == "div" and _TOPICS_CLASS in classes:
            self._block = "topics"
            self.topic_blocks += 1
        else:
            return
        self._stack = [(tag, self._block)]

    def _role(self, tag: str, attributes: dict[str, str | None], classes: list[str], roles: set) -> str | None:
        if self._block == "recommendations":
            view = self.views[-1]
            if any("pager" in name for name in classes):
                raise GaoProductDetailsError(
                    f"{_LABEL} view {view['number']} is paged; its table may not be whole", "paged"
                )
            if tag == "table":
                view["tables"] += 1
            elif tag == "h2":
                return "heading"
            elif tag == "th":
                return "column"
            elif tag == "tbody":
                return "tbody"
            elif tag == "tr" and "tbody" in roles:
                view["rows"].append([])
                return "row"
            elif tag == "td" and "row" in roles and "views-field-name" in classes:
                return "agency"
        elif self._block == "reports":
            if tag == "a" and attributes.get("href"):
                self.report_links.append({"label": [], "pages": []})
                return "link"
            if tag == "div" and "link" in roles:
                if "field--name-field-link-label" in classes:
                    return "label"
                if "field--name-file_type_num_pages_only" in classes:
                    return "pages"
        elif tag == "a" and "topic-field" in roles:
            return "topic"
        elif tag == "span" and "terms-field" in roles:
            return "term"
        elif tag == "div" and "views-field-field-topic" in classes:
            return "topic-field"
        elif tag == "div" and "views-field-field-subject-term" in classes:
            return "terms-field"
        return None

    def _new_text(self, role: str) -> list[str]:
        text: list[str] = []
        if role in ("topic", "term"):
            (self.topics if role == "topic" else self.terms).append(text)
        elif role in ("heading", "column"):
            self.views[-1]["headings" if role == "heading" else "columns"].append(text)
        elif role == "agency":
            self.views[-1]["rows"][-1].append(text)
        else:
            self.report_links[-1][role].append(text)
        return text

    def handle_endtag(self, tag: str) -> None:
        if self._block is None or tag in HTML_VOID_TAGS:
            return
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index][0] == tag:
                if any(role in _TEXT_ROLES for _, role in self._stack[index:]):
                    self._text = None
                del self._stack[index:]
                break
        if not self._stack:
            self._block = None

    def handle_data(self, data: str) -> None:
        if self._text is not None:
            self._text.append(data)


def _spelled(parts: list[str]) -> str:
    return " ".join("".join(parts).split())


def _listed(items: list[list[str]]) -> tuple[str, ...] | None:
    values = tuple(value for value in map(_spelled, items) if value)
    return values or None


def _counts(views: list[dict]) -> tuple[dict[str, int], tuple[str, ...] | None]:
    """Rows per known view, and the distinct agencies the recommendations name; each view checked against its shape."""
    counts = dict.fromkeys(RECOMMENDATION_VIEWS, 0)
    seen: set[str] = set()
    agencies: dict[str, None] = {}
    for view in views:
        number = view["number"]
        if number not in RECOMMENDATION_VIEWS:
            raise GaoProductDetailsError(
                f"{_LABEL} prints recommendations view {number}, which this reader does not know", "unknown-view"
            )
        if number in seen:
            raise GaoProductDetailsError(f"{_LABEL} prints recommendations view {number} twice", "repeated-view")
        seen.add(number)
        heading, columns = RECOMMENDATION_VIEWS[number]
        if [_spelled(parts) for parts in view["headings"]] != [heading] or view["tables"] != 1:
            raise GaoProductDetailsError(f"{_LABEL} view {number} is not one table headed {heading!r}", "changed-view")
        if tuple(_spelled(parts) for parts in view["columns"]) != columns:
            raise GaoProductDetailsError(f"{_LABEL} view {number}'s columns are not {columns}", "changed-view")
        counts[number] = len(view["rows"])
        for row in view["rows"]:
            agencies.update(dict.fromkeys(name for name in map(_spelled, row) if name))
    return counts, tuple(agencies) if counts["1"] and agencies else None


def _page_count(links: list[dict[str, list[list[str]]]]) -> int | None:
    stated = set()
    for link in links:
        if [_spelled(parts) for parts in link["label"]] != [FULL_REPORT_LABEL]:
            continue
        for parts in link["pages"]:
            text = _spelled(parts)
            match = _PAGES.fullmatch(text)
            if match is None or int(match[1]) < 1:
                raise GaoProductDetailsError(
                    f"{_LABEL} states its Full Report's length as {text!r}", "unreadable-page-count"
                )
            stated.add(int(match[1]))
    if len(stated) > 1:
        raise GaoProductDetailsError(
            f"{_LABEL} states its Full Report's length as {sorted(stated)} pages", "conflicting-page-count"
        )
    return stated.pop() if stated else None


def read_product_details(body: bytes, *, product_id: str, max_bytes: int = MAX_PAGE_BYTES) -> GaoProductDetails:
    """The details a product page's HTML states (a fresh capture, or ``product.html`` from a release's evidence ZIP).

    One pass over the page, O(page). Refusals carry a ``reason``: ``not-this-page``, ``incomplete``, ``nested-text``,
    ``paged``, ``unknown-view``, ``repeated-view``, ``changed-view``, ``repeated-block``, ``unreadable-page-count``
    and ``conflicting-page-count``.
    """
    product_id = gao_product_id(product_id)
    text = decode_html_page(body, max_bytes, label=_LABEL, cap=MAX_PAGE_BYTES, error_type=GaoProductDetailsError)
    page = _DetailsHtml()
    feed_html(page, text, label=_LABEL, error_type=GaoProductDetailsError)
    if page.unclosed:
        raise GaoProductDetailsError(f"{_LABEL} markup is incomplete", "incomplete")
    if page.canonicals != [gao_product_url(product_id)]:
        raise GaoProductDetailsError(f"{_LABEL}'s canonical link is not {gao_product_url(product_id)}", "not-this-page")
    if page.topic_blocks > 1 or page.report_groups > 1:
        raise GaoProductDetailsError(f"{_LABEL} prints its Topics block or full-reports group twice", "repeated-block")
    counts, agencies = _counts(page.views)
    return GaoProductDetails(
        product_id,
        counts["1"],
        counts["3"],
        agencies,
        _page_count(page.report_links),
        _listed(page.topics),
        _listed(page.terms),
    )


@dataclass(frozen=True, slots=True)
class GaoProductPageBudget:
    """Bounds for one page's capture; the run's Zyte spend is the transport's own ``ZyteBudget``.

    The spacing defaults to ``robots.txt``'s 420-second ``Crawl-delay``, as the listing walk's does; a host states a
    shorter one as its own run decision.
    """

    max_page_bytes: int = MAX_PAGE_BYTES
    timeout_seconds: float = 90.0
    min_request_interval_seconds: float = CRAWL_DELAY_SECONDS

    def __post_init__(self) -> None:
        check_byte_bound(self.max_page_bytes, "max_page_bytes", MAX_PAGE_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


class GaoProductPageAcquirer(SourceAcquirer):
    """One product page per call, one attempt, paced; the transport is Zyte's, injected by the caller."""

    def __init__(
        self,
        *,
        budget: GaoProductPageBudget,
        transport: httpx.BaseTransport,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, GaoProductPageBudget):
            raise TypeError("budget must be a GaoProductPageBudget")
        self.budget = budget
        super().__init__(
            max_requests=1,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-gao-product-page/1.0",
            label=_LABEL,
            error_type=GaoProductDetailsError,
            context_key="gao_product_page_acquisition",
            transport=transport,
            clock=clock,
        )

    def acquire_details(self, product_id: str) -> tuple[GaoProductDetails, CapturedBodyResponse]:
        """The product's page, captured and read; 404/410 raise :class:`GaoProductPageUnavailableError`."""
        url = gao_product_url(product_id)

        def parse(response: CapturedBodyResponse, limit: int) -> GaoProductDetails:
            # The capture refuses any status but 200 before this runs, and 404/410 as unavailable.
            return read_product_details(response.body, product_id=product_id, max_bytes=limit)

        return self.capture_validated(
            url,
            media_types=("text/html",),
            parse=parse,
            max_bytes=self.budget.max_page_bytes,
            unavailable=GaoProductPageUnavailableError,
            context={"operation": "product-page", "product_id": product_id, "url": url},
        )


__all__ = [
    "PRODUCT_PAGE_DETAILS_RULE",
    "RECOMMENDATION_VIEWS",
    "GaoProductDetails",
    "GaoProductDetailsError",
    "GaoProductPageAcquirer",
    "GaoProductPageBudget",
    "GaoProductPageUnavailableError",
    "read_product_details",
]
