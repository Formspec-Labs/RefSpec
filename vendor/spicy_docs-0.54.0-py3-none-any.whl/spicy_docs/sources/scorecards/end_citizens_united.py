"""End Citizens United's complete 2026 federal HTML grade lists.

The publisher states qualitative scoring criteria, not item-specific results or
weights. Preserve those criteria and literal grades without inventing a vote grid.
"""

import re

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "end-citizens-united-2026-html/2"
INDEX = "https://www.endcitizensunited.org/end-citizens-united-scorecard"
HOSTS = ("www.endcitizensunited.org",)
EDITION = ScorecardEdition(
    "end_citizens_united",
    "2026",
    INDEX,
    "End Citizens United 2026 Anti-Corruption Scorecard",
    year="2026",
    congress="119",
    chamber="both",
)
HEADINGS = {"U.S. SENATE": "Senate", "U.S. HOUSE OF REPRESENTATIVES": "House"}
GRADE = r"(?P<grade>[A-F][+-]?|N/A)"
SENATE = re.compile(r"(?P<name>.+?)\s*\[\s*(?P<party>[A-Z])-\s*(?P<state>[A-Z]{2})\s*\]\s*-\s*" + GRADE)
HOUSE = re.compile(
    r"(?P<name>.+?)\s*,\s*(?P<state>[A-Z]{2})-\s*(?P<district>AL|\d(?:\s?\d)?)\s*"
    r"\(\s*(?P<party>[A-Z])\s*\)\s*-\s*" + GRADE
)


def _page(document):
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("ECU HTML does not reach its document end")
    html = soup(document)
    title = " ".join(h.get_text(" ", strip=True) for h in html.select("h1"))
    if "End Citizens United 2026" not in title or "Anti-Corruption Scorecard" not in title:
        raise ScorecardSourceError("ECU edition title changed")
    if "119th Congress" not in html.get_text(" ", strip=True):
        raise ScorecardSourceError("ECU congressional scope changed")
    headings = html.select("h2")
    if [h.get_text(" ", strip=True) for h in headings] != [*HEADINGS, "SCORING CRITERIA"]:
        raise ScorecardSourceError("ECU chamber or methodology sections changed")
    rows, identities = [], set()
    for heading in headings[:2]:
        label = heading.get_text(" ", strip=True)
        chamber = HEADINGS[label]
        section = heading.find_parent("section")
        if section is None or len(section.select("h2")) != 1:
            raise ScorecardSourceError("ECU member section boundaries changed")
        entries = section.select("li")
        if not entries:
            raise ScorecardSourceError("ECU member list is empty")
        for position, entry in enumerate(entries, 1):
            text = entry.get_text("", strip=False).strip()
            match = (SENATE if chamber == "Senate" else HOUSE).fullmatch(text)
            if match is None:
                raise ScorecardSourceError("ECU member grade row shape changed")
            fields = match.groupdict()
            fields["name"] = fields["name"].strip()
            identifier = key(chamber, fields["state"], fields.get("district") or "Senate", fields["name"])
            if identifier in identities:
                raise ScorecardSourceError("ECU repeats a member identity")
            identities.add(identifier)
            rows.append((identifier, chamber, position, fields))
    method_section = headings[-1].find_parent("section")
    paragraphs = method_section.select("h5") if method_section else []
    if len(paragraphs) != 1 or not paragraphs[0].get_text(" ", strip=True):
        raise ScorecardSourceError("ECU scoring criteria are missing or split")
    return rows, paragraphs[0].get_text(" ", strip=True)


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _page(context.read(INDEX, stage="scorecards:ecu:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("ECU reader supports the explicit 2026 edition")
    primary = context.read(INDEX, stage="scorecards:ecu:grades", hosts=HOSTS)
    rows, method = _page(primary)
    repeated = context.read(INDEX, stage="scorecards:ecu:stable-reread", hosts=HOSTS)
    if _page(repeated) != (rows, method):
        raise ScorecardSourceError("ECU member grades or methodology changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="End Citizens United",
        parser_version=parser_version,
        rendition_rule="ecu-complete-html-chamber-lists/1",
        homepage="https://www.endcitizensunited.org/",
    )
    bundle.use(primary, "members_and_grades", "methodology")
    bundle.use(repeated, "members_and_grades", "methodology", role="corroboration")
    bundle.add(
        "scorecard_methodologies",
        primary,
        "(//h2[normalize-space(.)='SCORING CRITERIA']/ancestor::section[1]//h5)[1]",
        methodology_id="published-criteria",
        methodology_text=method,
        methodology_url=INDEX,
        disclosure_status="partial",
    )
    for chamber in HEADINGS.values():
        bundle.metric(
            primary,
            chamber.lower() + ":grade",
            "2026 Anti-Corruption Grade",
            path=f"//h2[normalize-space(.)='{next(h for h, c in HEADINGS.items() if c == chamber)}']",
            chamber=chamber,
            unit="grade",
        )
        bundle.tables["scorecard_metrics"][-1]["methodology_id"] = "published-criteria"
    for identifier, chamber, position, fields in rows:
        label = next(h for h, c in HEADINGS.items() if c == chamber)
        path = f"(//h2[normalize-space(.)='{label}']/ancestor::section[1]//li)[{position}]"
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=identifier,
            member_name=fields["name"],
            chamber_text=chamber,
            state=fields["state"],
            district=fields.get("district"),
            party=fields["party"],
        )
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path,
            publisher_member_key=identifier,
            metric_id=chamber.lower() + ":grade",
            value_text=fields["grade"],
            value_number=None,
        )
    return bundle.finish(
        "Complete HTML reached document EOF; all member entries in both explicit chamber lists parsed; "
        "all identities unique; repeated member lists, grades and criteria agree",
        declared={"members": len(rows), "ratings": len(rows), "member_counts_basis": "complete source HTML lists"},
    )
