"""Chamber's archived original 2019-named composite scorecard and literal component inputs."""

import re
from urllib.parse import parse_qs, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "us-chamber-2019-archived-composite-json/2"
ORIGIN = "https://www.uschamber.com"
INDEX = ORIGIN + "/how-they-voted/2019"
METHOD = ORIGIN + "/how-they-voted-methodology"
SCRIPT_PATH = "/sites/all/modules/custom/htv_vue/js/dist/static/js/app.js"
JSON_PATH = "/sites/all/modules/custom/htv_vue/json/2019/"
HOSTS = ("web.archive.org",)
EDITION = ScorecardEdition(
    "us_chamber", "2019", INDEX, "How They Voted 2019", year="2019", congress="116", chamber="both", is_current=False
)
ORIGINALS = {
    "index": INDEX,
    "renderer": ORIGIN + SCRIPT_PATH,
    "method": METHOD,
    **{name: ORIGIN + JSON_PATH + name + ".json" for name in ("house", "senate", "bills/house", "bills/senate")},
}
URLS = {
    name: "https://web.archive.org/web/"
    + ("20201103223906" if name in {"renderer", "method"} else "20201103223909")
    + "id_/"
    + url
    for name, url in ORIGINALS.items()
}
MEMBER_FIELDS = {
    "chamber",
    "uniqueid",
    "last_name",
    "first_name",
    "party",
    "state",
    "votesscore",
    "bipartisanshipscore",
    "leadershipscore",
    "annual",
    "cumulative",
    "specialdesignations",
    "facts",
    "leader",
}
ITEM_FIELDS = {
    "bill_id",
    "number",
    "roll",
    "type",
    "action",
    "bill",
    "position",
    "title",
    "short_title",
    "letter_link",
    "summary",
    "link",
}
VOTE_LEGEND = {
    "+": '"Correct" vote',
    "-": '"Wrong" vote',
    "p": "Voted Present",
    "?": "No recorded vote",
    "s": "Speaker did not vote",
    "": "No Recorded Vote",
}
LEADER_LEGEND = {
    "+": "Cosponsored Chamber-endorsed bill",
    "-": "Cosponsored Chamber-opposed bill",
    "": "",
    "s": "Speaker",
}
MISSING_GRID = {"house": {"hl41"}, "senate": set()}
PERIOD = "from the beginning of the 116th Congress through the Senate vote on the U.S.-Mexico-Canada Free Trade Agreement in January of 2020"
COMPOSITE = "The Annual score has three components: Legislative (80%), Leadership (10%), and Bipartisanship (10%)."
BONUS = "These members received additional credit for their strong engagement in helping pass the USMCA."
ADVISORY = "IMPORTANT ADVISORY: Historically, party leaders cosponsor very few bills and as a result have lower Leadership and Bipartisanship scores. Their scores do not reflect the complete measure of their leadership or bipartisan actions on pro-growth legislation."
METRICS = {
    "annual": "Annual Score",
    "cumulative": "Lifetime Score",
    "votesscore": "Legislative Score",
    "leadershipscore": "Legislative Leadership Score",
    "bipartisanshipscore": "Bipartisanship Score",
}
DISPLAY_RULES = (
    'voteLegend:{"+":["support","Support"],"-":["oppose","Oppose"],p:["present","Voted Present"],"?":["novote","No Recorded Vote"],s:["speaker","Speaker"],"":["novote","No Recorded Vote"]}',
    'leaderLegend:{"+":["endorsed","Endorsed"],"-":["opposed","Opposed"],"":["novote",""],s:["speaker","Speaker"]}',
    'a="2019";t&&t.length>1&&(a=t[1])',
    'house:"/sites/all/modules/custom/htv_vue/json/"+(i=a)+"/house.json"',
    'senate:"/sites/all/modules/custom/htv_vue/json/"+i+"/senate.json"',
    'houseBills:"/sites/all/modules/custom/htv_vue/json/"+i+"/bills/house.json"',
    'senateBills:"/sites/all/modules/custom/htv_vue/json/"+i+"/bills/senate.json"',
    "if(t&&4===t.length)",
    "return e.bill_id===t",
    "var t=/[hs][l]?[0-9]+/",
    '"Leadership"===c?e.leaderLegend[n]:e.voteLegend[n]',
    ' = "Correct" vote',
    ' = "Wrong" vote',
    "Cosponsored Chamber-endorsed bill",
    "Cosponsored Chamber-opposed bill",
    "Lifetime Score",
    "80% of the Annual Score",
    "Legislative Leadership Score (10%) and Bipartisan Engagement Score (10%)",
    "members of their own party",
    ADVISORY,
)


def _custody(document, name):
    match = re.fullmatch(
        r"https://web\.archive\.org/web/(\d{14})id_/(https://www\.uschamber\.com/[^?#]+)", document.url
    )
    if match is None or match[2] != ORIGINALS[name] or document.response.requested_url != URLS[name]:
        raise ScorecardSourceError("Chamber composite archive escaped selected original publisher identity")
    return {"original_publisher_url": match[2], "archive_url": document.url, "archive_timestamp": match[1]}


def _html(document, name):
    _custody(document, name)
    if not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("Chamber composite original HTML is incomplete")
    return soup(document)


def _index(document):
    html = _html(document, "index")
    titles = html.select("h1.page-title")
    canonical = html.select("link[rel='canonical']")
    if (
        len(titles) != 1
        or titles[0].get_text(" ", strip=True) != "How They Voted 2019"
        or len(canonical) != 1
        or canonical[0].get("href") != INDEX
        or len(html.select("#htv_app")) != 1
        or SCRIPT_PATH.replace("/", "\\/").removeprefix("\\/") not in document.body.decode("utf-8")
    ):
        raise ScorecardSourceError("Chamber composite edition title or original application declaration changed")


def _renderer(document):
    _custody(document, "renderer")
    try:
        text = document.body.decode("utf-8")
    except UnicodeError as error:
        raise ScorecardSourceError("Chamber composite renderer is not UTF-8") from error
    if any(rule not in text for rule in DISPLAY_RULES):
        raise ScorecardSourceError(
            "Chamber composite file selection, symbol interpretation or component display changed"
        )


def _method(document):
    html = _html(document, "method")
    sections = html.select(".field-name-body")
    if len(sections) != 1:
        raise ScorecardSourceError("Chamber composite original methodology is missing or repeated")
    literal = sections[0].get_text("\n", strip=True)
    text = " ".join(literal.split())
    if (
        COMPOSITE not in text
        or PERIOD not in text
        or "includes 18 House and nine Senate votes" not in text
        or "It does not reset for a break in service or from a move from one chamber to the other." not in text
        or "performance of all other members of their party" not in text
        or BONUS not in text
    ):
        raise ScorecardSourceError(
            "Chamber composite period, declared counts, weights, cohort or extra-credit disclosure changed"
        )
    return literal


def _roll_context(item, chamber):
    if item["type"] == "Leadership":
        if item["roll"] != "" or item["link"] != "" or item["action"] != "":
            raise ScorecardSourceError("Chamber leadership item gained an unqualified action or roll reference")
        return None, None, None
    url = urlsplit(item["link"])
    if chamber == "house":
        match = re.fullmatch(r"/evs/2019/roll(\d{3})\.xml", url.path)
        if (
            match is None
            or url.scheme != "http"
            or url.netloc != "clerk.house.gov"
            or url.query
            or type(item["roll"]) is not int
        ):
            raise ScorecardSourceError("Chamber composite House official roll reference changed")
        congress, session, number = None, None, str(int(match[1]))
    else:
        values = parse_qs(url.query)
        if (
            url.scheme != "https"
            or url.netloc != "www.senate.gov"
            or url.path != "/legislative/LIS/roll_call_lists/roll_call_vote_cfm.cfm"
            or set(values) != {"congress", "session", "vote"}
            or values["congress"] != ["116"]
            or values["session"] not in (["1"], ["2"])
            or len(values["vote"]) != 1
            or re.fullmatch(r"\d{5}", values["vote"][0]) is None
        ):
            raise ScorecardSourceError("Chamber composite Senate official roll reference changed")
        congress, session, number = "116", values["session"][0], str(int(values["vote"][0]))
        if isinstance(item["roll"], str) and item["roll"] != number + " (2nd session)":
            raise ScorecardSourceError("Chamber source compound roll text changed")
        if isinstance(item["roll"], str) and session != "2":
            raise ScorecardSourceError("Chamber source compound roll session conflicts with its official reference")
    native_roll = re.match(r"\d+", str(item["roll"]))
    if native_roll is None or int(native_roll[0]) != int(number):
        raise ScorecardSourceError("Chamber native composite roll and official link disagree")
    return congress, session, number


def _items(document, chamber):
    _custody(document, "bills/" + chamber)
    rows = json_data(document)
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("Chamber composite complete item array is absent")
    seen = set()
    prefix = "h" if chamber == "house" else "s"
    for item in rows:
        if (
            not isinstance(item, dict)
            or set(item) != ITEM_FIELDS
            or any(not isinstance(value, str) for field, value in item.items() if field != "roll")
            or type(item["roll"]) not in {str, int}
            or item["type"] not in {"Vote Score", "Leadership"}
            or re.fullmatch(prefix + ("l" if item["type"] == "Leadership" else "") + r"[1-9]\d*", item["bill_id"])
            is None
            or item["bill_id"] in seen
            or not item["title"]
            or not item["number"]
            or item["position"] not in {"Support", "Oppose"}
        ):
            raise ScorecardSourceError("Chamber composite item identity, type or target changed")
        seen.add(item["bill_id"])
        _roll_context(item, chamber)
    if sum(item["type"] == "Vote Score" for item in rows) != (18 if chamber == "house" else 9):
        raise ScorecardSourceError("Chamber composite item array does not reconcile to its declared vote count")
    return rows


def _member_key(member):
    return key(
        EDITION.scorecard_id,
        member["chamber"],
        member["state"],
        str(member.get("district", "senate")),
        member["first_name"],
        member["last_name"],
    )


def _members(document, chamber, items):
    _custody(document, chamber)
    rows = json_data(document)
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("Chamber composite complete member array is absent")
    catalog = {item["bill_id"]: item for item in items}
    columns = set(catalog) - MISSING_GRID[chamber]
    expected = MEMBER_FIELDS | columns | ({"district"} if chamber == "house" else set())
    if not MISSING_GRID[chamber] <= set(catalog):
        raise ScorecardSourceError("Chamber composite catalog-only item disposition changed")
    seen = set()
    for member in rows:
        if (
            not isinstance(member, dict)
            or set(member) != expected
            or any(not isinstance(value, str) for field, value in member.items() if field != "district")
            or member["chamber"] != chamber
            or re.fullmatch(r"[A-Z]\d{6}", member["uniqueid"]) is None
            or not member["first_name"]
            or not member["last_name"]
            or re.fullmatch(r"[A-Z]{2}", member["state"]) is None
            or member["party"] not in {"R", "D", "I"}
            or member["leader"] not in {"yes", ""}
            or (chamber == "house" and (type(member["district"]) is not int or member["district"] < 0))
            or any(re.fullmatch(r"(?:\d+%|(?i:n/?a))", member[field]) is None for field in METRICS)
        ):
            raise ScorecardSourceError("Chamber composite full member context or metric fields changed")
        identity = _member_key(member)
        if identity in seen:
            raise ScorecardSourceError("Chamber composite exact member context repeats")
        seen.add(identity)
        for column in columns:
            item, literal = catalog[column], member[column]
            legend = LEADER_LEGEND if item["type"] == "Leadership" else VOTE_LEGEND
            if literal not in legend:
                raise ScorecardSourceError("Chamber composite member item symbol changed")
    return rows


def list_scorecards(context: ScorecardContext):
    _index(context.read(URLS["index"], stage="chamber-2019-index", hosts=HOSTS))
    _renderer(context.read(URLS["renderer"], stage="chamber-2019-renderer", hosts=HOSTS))
    _method(context.read(URLS["method"], stage="chamber-2019-method", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("Chamber composite reader only accepts the qualified 2019-named original rendition")
    documents = {name: context.read(url, stage="chamber-2019-" + name, hosts=HOSTS) for name, url in URLS.items()}
    for name, document in documents.items():
        _custody(document, name)
    _index(documents["index"])
    _renderer(documents["renderer"])
    method = _method(documents["method"])
    items = {chamber: _items(documents["bills/" + chamber], chamber) for chamber in ("house", "senate")}
    members = {chamber: _members(documents[chamber], chamber, rows) for chamber, rows in items.items()}
    source_conflicts = []
    for chamber, chamber_items in items.items():
        for item in chamber_items:
            if item["type"] != "Leadership":
                continue
            for member in members[chamber]:
                symbol = member.get(item["bill_id"])
                if symbol in {"+", "-"} and item["position"] != ("Support" if symbol == "+" else "Oppose"):
                    source_conflicts.append(
                        {
                            "chamber": chamber,
                            "uniqueid": member["uniqueid"],
                            "member_name": member["first_name"] + " " + member["last_name"],
                            "bill_id": item["bill_id"],
                            "native_symbol": symbol,
                            "native_position": item["position"],
                            "publisher_symbol_label": LEADER_LEGEND[symbol],
                        }
                    )
    repeats = {}
    for name, url in URLS.items():
        repeat = context.read(url, stage="chamber-2019-stable-" + name, hosts=HOSTS)
        _custody(repeat, name)
        if repeat.body != documents[name].body or repeat.url != documents[name].url:
            raise ScorecardSourceError("Chamber composite archived source changed during acquisition")
        repeats[name] = repeat
    bundle = Bundle(
        edition,
        context,
        documents["index"],
        publisher_name="U.S. Chamber of Commerce",
        parser_version=parser_version,
        homepage=ORIGIN,
        rendition_rule="2019-named archived original publisher application, contemporaneous methodology and all four complete native JSON files; no later/current methodology substituted",
    )
    periods = json_column(
        [
            {
                "occurrence_id": "legislative-period",
                "period_text": PERIOD,
                "source_path": ".field-name-body/Legislative (80%)",
                "kind": "explicit",
                "congress_text": "116",
            }
        ]
    )
    bundle.tables["scorecards"][0].update(methodology_url=METHOD, timespan_text=PERIOD, periods_json=periods)
    for name, document in documents.items():
        bundle.use(document, "native-" + name)
        bundle.use(repeats[name], "native-" + name, role="corroboration")
    bundle.add(
        "scorecard_methodologies",
        documents["method"],
        ".field-name-body",
        methodology_id="published-method",
        methodology_text=method,
        methodology_url=METHOD,
        disclosure_status="partial",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["renderer"],
        "script/display-rules-and-custody",
        methodology_id="native-display",
        methodology_text=json_column(
            {
                "source_display_expressions": list(DISPLAY_RULES),
                "source_custody": {name: _custody(document, name) for name, document in documents.items()},
                "vote_symbol_key": VOTE_LEGEND,
                "leadership_symbol_key": LEADER_LEGEND,
                "catalog_without_disclosed_cells": {name: sorted(values) for name, values in MISSING_GRID.items()},
                "native_leadership_position_symbol_conflicts": source_conflicts,
                "identity_rule": "Exact chamber/state/district/first_name/last_name context; preserve literal uniqueid without asserting its namespace.",
                "reproduction": "Source formulas, ranks and undisclosed credit amounts are not reproduced; literal published values remain primary.",
            }
        ),
        methodology_url=ORIGINALS["renderer"],
        disclosure_status="partial",
    )
    for field, name in METRICS.items():
        bundle.metric(documents["renderer"], field, name, path="script/" + field, unit="%", primary=field == "annual")
        bundle.tables["scorecard_metrics"][-1].update(
            methodology_id="published-method",
            period_text="a Member’s entire tenure in Congress" if field == "cumulative" else PERIOD,
            periods_json="[]" if field == "cumulative" else periods,
            rank_population_text="members of their own party"
            if field in {"leadershipscore", "bipartisanshipscore"}
            else None,
        )
    for field, weight in (("votesscore", "80"), ("leadershipscore", "10"), ("bipartisanshipscore", "10")):
        bundle.add(
            "scorecard_metric_components",
            documents["method"],
            ".field-name-body/ANNUAL SCORE",
            parent_metric_id="annual",
            component_metric_id=field,
            weight_text=weight + "%",
            weight_number=weight,
            combination_rule_text=COMPOSITE,
        )
    cells = 0
    for chamber, chamber_items in items.items():
        item_document, member_document = documents["bills/" + chamber], documents[chamber]
        native = {}
        for ordinal, item in enumerate(chamber_items):
            path = "/" + str(ordinal)
            item_id = key(edition.scorecard_id, chamber, item["bill_id"])
            metric = "leadershipscore" if item["type"] == "Leadership" else "votesscore"
            native[item["bill_id"]] = (item_id, metric, item)
            congress, session, roll = _roll_context(item, chamber)
            references = []
            if item["bill"]:
                references.append(
                    {
                        "occurrence_id": "bill",
                        "citation_text": item["bill"],
                        "kind": "bill",
                        "source_path": path + "/bill",
                        "bill_citation_text": item["bill"],
                    }
                )
            if item["link"]:
                references.append(
                    {
                        "occurrence_id": "roll-link",
                        "citation_text": item["link"],
                        "kind": "roll_call",
                        "source_path": path + "/link",
                        "congress_text": congress,
                        "session_text": session,
                        "roll_number_text": roll,
                        "chamber_text": chamber,
                    }
                )
            bundle.add(
                "scorecard_items",
                item_document,
                path,
                item_id=item_id,
                publisher_item_id=item["bill_id"],
                item_kind_text=item["type"],
                title=item["title"],
                chamber_text=chamber,
                congress_text=congress,
                session_text=session,
                roll_number_text=str(item["roll"]) if item["roll"] != "" else None,
                bill_citation_text=item["bill"] or None,
                references_json=json_column(references),
                publisher_position_text=item["position"],
                position_basis="explicit native position field",
                position_source_path=path + "/position",
            )
            methodology = key(chamber, item["bill_id"])
            bundle.add(
                "scorecard_methodologies",
                item_document,
                path,
                methodology_id=methodology,
                chamber_text=chamber,
                methodology_text=json_column(item),
                methodology_url=item["letter_link"] or None,
                disclosure_status="partial",
            )
            bundle.add(
                "scorecard_metric_items",
                item_document,
                path,
                metric_id=metric,
                item_id=item_id,
                participation_id="native-component",
                methodology_id=methodology,
                publisher_position_text=item["position"],
                position_basis="explicit native position field",
            )
        for ordinal, member in enumerate(members[chamber]):
            path = "/" + str(ordinal)
            identity = _member_key(member)
            metadata = {field: value for field, value in member.items() if field not in native}
            metadata["source_party_leader_advisory"] = ADVISORY if member["leader"] == "yes" else None
            bundle.add(
                "scorecard_members",
                member_document,
                path,
                publisher_member_key=identity,
                publisher_member_id=member["uniqueid"],
                identifiers_json="[]",
                member_name=member["first_name"] + " " + member["last_name"],
                chamber_text=chamber,
                state=member["state"],
                district=str(member["district"]) if chamber == "house" else None,
                party=member["party"],
                period_text=PERIOD,
                notes_text=json_column(metadata),
            )
            for field in METRICS:
                value = "N/A" if member[field].lower() in {"na", "n/a"} else member[field]
                bundle.add(
                    "scorecard_member_ratings",
                    member_document,
                    path + "/" + field,
                    metric_id=field,
                    publisher_member_key=identity,
                    value_text=value,
                    value_number=decimal_text(value),
                    value_status_text="N/A" if value == "N/A" else None,
                    notes_text=json_column(
                        {
                            "literal_source_value": member[field],
                            "specialdesignations": member["specialdesignations"],
                            "leader": member["leader"],
                            "additional_credit_disclosure": BONUS
                            if "USMCA Leader" in member["specialdesignations"].split(", ") and field == "annual"
                            else None,
                        }
                    ),
                )
            for column, (item_id, metric, item) in native.items():
                if column not in member:
                    continue
                cells += 1
                value = member[column]
                leadership = item["type"] == "Leadership"
                bundle.add(
                    "scorecard_member_item_results",
                    member_document,
                    path + "/" + column,
                    result_id="native-cell",
                    metric_id=metric,
                    item_id=item_id,
                    participation_id="native-component",
                    publisher_member_key=identity,
                    result_text=value,
                    action_text=LEADER_LEGEND[value] if leadership and value in {"+", "-"} else None,
                    reason_text=LEADER_LEGEND[value] if leadership else VOTE_LEGEND[value],
                )
    result = bundle.finish(
        "Contemporaneous original methodology declares vote counts, weights and period; original index/application select all four complete native JSON files. JSON reaches EOF, exact source member contexts and component columns reconcile to complete item catalogs, official roll links reconcile to native identifiers, and all seven original inputs repeat byte-for-byte with unchanged archive custody. Catalog-only hl41 is retained without manufactured cells; absent bipartisanship inputs and extra-credit amounts are not invented.",
        declared={
            "legislative_votes": {"house": 18, "senate": 9},
            "native_members": {chamber: len(rows) for chamber, rows in members.items()},
            "native_items": {chamber: len(rows) for chamber, rows in items.items()},
            "member_item_cells": cells,
            "catalog_without_disclosed_cells": {chamber: sorted(values) for chamber, values in MISSING_GRID.items()},
            "explicit_source_population_count": None,
        },
    )
    return result
