"""FreedomWorks' original archived annual print tables, including non-roll-call key votes."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from urllib.parse import parse_qs, urljoin, urlsplit

from bs4 import BeautifulSoup

from spicy_docs.interpretation.citations import BILL_NUMBER_PATTERN, CITATION_RULES_BY_NAME
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text

# /4 reads every printed bill through the shared bill grammar and leaves the
# unstated primary-metric designation NULL; /3 remains a private candidate.
parser_version = "freedomworks-archived-print/4"
HOME = "http://congress.freedomworks.org/"
ARCHIVE_ROOT = "https://web.archive.org/web/20220821163800id_/"
INDEX = ARCHIVE_ROOT + HOME
HOSTS = ("web.archive.org",)


@dataclass(frozen=True, slots=True)
class PrintEdition:
    chamber: str
    year: int
    congress: str
    member_rows: int
    item_count: int

    @property
    def original(self):
        return HOME + f"keyvotes/{self.chamber.lower()}/{self.year}/print"

    @property
    def edition(self):
        return ScorecardEdition(
            "freedomworks",
            f"{self.year}-{self.chamber.lower()}-archived-print",
            ARCHIVE_ROOT + self.original,
            f"{self.year} {self.chamber} Key Votes",
            year=str(self.year),
            congress=self.congress,
            chamber=self.chamber,
            is_current=False,
        )


# Reviewed original print-table populations. These are not official congressional
# rosters and do not imply that an archived in-progress annual score is final.
PRINT_EDITIONS = tuple(
    PrintEdition(chamber, year, congress, members, items)
    for chamber, rows in (
        ("House", (
            (2005, "109", 437, 17), (2006, "109", 434, 12), (2007, "110", 438, 20), (2008, "110", 439, 16),
            (2009, "111", 439, 21), (2010, "111", 440, 18), (2011, "112", 439, 40), (2012, "112", 440, 20),
            (2013, "113", 438, 21), (2014, "113", 440, 21), (2015, "114", 437, 21), (2016, "114", 438, 19),
            (2017, "115", 441, 32), (2018, "115", 443, 28), (2019, "116", 437, 37), (2020, "116", 439, 12),
        )),
        ("Senate", (
            (2005, "109", 100, 15), (2006, "109", 100, 11), (2007, "110", 101, 12), (2008, "110", 100, 12),
            (2009, "111", 102, 12), (2010, "111", 105, 23), (2011, "112", 101, 18), (2012, "112", 101, 13),
            (2013, "113", 105, 21), (2014, "113", 101, 13), (2015, "114", 100, 14), (2016, "114", 101, 11),
            (2017, "115", 101, 23), (2018, "115", 103, 30), (2019, "116", 104, 22), (2020, "116", 100, 10),
        )),
    )
    for year, congress, members, items in rows
)  # fmt: skip
GLYPHS = {"ineligible": "⊘", "none": "☐", "with": "✔", "against": "✘"}

# Bills use the shared bill grammar. SpicyDocs has no amendment grammar, so
# the explicit H.Amdt./S.Amdt. label borrows its guards against a preceding
# letter, ``U.S.`` and a parenthesized subdivision. Neither assigns a Congress.
# The print headings also spell ``S.Amdt 19`` and ``H.Amdt 671`` without the
# period, as the bill grammar already allows ``H.J.Res 37``; a misspelled
# ``H.Admt.`` and the nonstandard ``S.C.Res.`` stay literal, untyped text.
BILL_CITATION = re.compile(BILL_NUMBER_PATTERN)
BILL_RULE = "spicy_docs.interpretation.citations:bill_number/" + CITATION_RULES_BY_NAME["bill_number"].version
AMENDMENT_CITATION = re.compile(r"(?<![A-Za-z]\.)(?<!U\.\s)(?<![A-Za-z])(?:H|S)\.\s*Amdt\.?\s*\d+\b(?!\()")
AMENDMENT_RULE = "freedomworks-explicit-amendment/2"


def citation_occurrences(fields):
    """Typed bill and amendment spans in each ``(field, text, locator, prefix)``, in source order."""
    occurrences = []
    for field, text, locator, prefix in fields:
        matches = [(match, "bill", BILL_RULE) for match in BILL_CITATION.finditer(text)]
        matches += [(match, "amendment", AMENDMENT_RULE) for match in AMENDMENT_CITATION.finditer(text)]
        matches.sort(key=lambda value: value[0].start())
        for index, (match, kind, rule) in enumerate(matches):
            occurrences.append(
                {
                    "occurrence_id": f"{prefix}-citation-{index}",
                    "kind": kind,
                    "citation_text": match[0],
                    "source_path": locator,
                    "start": match.start(),
                    "end": match.end(),
                    "source_text_field": field,
                    "offset_basis": "unicode_characters_in_retained_normalized_native_text",
                    "rule": rule,
                }
            )
    return occurrences


def citation_reference(occurrence):
    """The ``references_json`` form of one occurrence; offsets stay with the native text."""
    kind, literal = occurrence["kind"], occurrence["citation_text"]
    return {
        "occurrence_id": occurrence["occurrence_id"],
        "citation_text": literal,
        "kind": kind,
        "source_path": occurrence["source_path"],
        kind + "_citation_text": literal,
    }


def _item_citations(item, path):
    """Exact spans in the retained normalized heading and every summary text."""
    fields = [("heading", item["heading"], path + "/h4", "native-heading")]
    fields.extend(
        (f"summary_occurrences[{i}].text", summary["text"], summary["source_path"], f"native-summary-{i}")
        for i, summary in enumerate(item["summary_occurrences"])
    )
    return citation_occurrences(fields)


def _text(tag):
    return " ".join(tag.get_text(" ", strip=True).split())


def _attributes(tag):
    return dict(tag.attrs)


def _facts(source, spec):
    try:
        soup = BeautifulSoup(source.body.decode("utf-8"), "html.parser")
        headers = soup.select(".keyvotes-scorecard-header")
        if len(headers) != 1 or _text(headers[0].select_one("h2")) != spec.edition.title:
            raise ValueError
        if _text(headers[0].select_one("h3")) != spec.congress + "th Congress":
            raise ValueError
        form = soup.select_one("#keyvotes-scorecard-form")
        if form is None or form.get("action") != urlsplit(spec.original).path:
            raise ValueError
        for name in ("state", "party"):
            selected = form.select(f"select[name='{name}'] option[selected]")
            if len(selected) != 1 or selected[0].get("value") != "":
                raise ValueError
        if soup.select_one("#footer") is None or "FreedomWorks" not in _text(soup.select_one("#footer")):
            raise ValueError
        legend = headers[0].select_one(".keyvotes-legend")
        if legend is None:
            raise ValueError
        labels = legend.select(".label")
        if len(labels) != 4 or {_text(x.select_one(".swatch")) for x in labels} != set(GLYPHS.values()):
            raise ValueError
        methods = soup.select("#keyvotes-scoring")
        if len(methods) != 1 or "How Scoring Works" not in _text(methods[0]):
            raise ValueError
        methodology = _text(methods[0])
        scales = re.findall(r"\bWe use a scale of \d+(?:\.\d+)?\b", methodology)
        if len(scales) != 1:
            raise ValueError
        exclusions = []
        for ordinal, member in enumerate(methods[0].select(".suppressed .leg")):
            native_id = member.get("rel")
            if not isinstance(native_id, str) or not native_id.isdecimal() or member.select_one("h5") is None:
                raise ValueError
            exclusions.append(
                {"id": native_id, "name": _text(member.select_one("h5")), "text": _text(member), "ordinal": ordinal}
            )
        if len({x["id"] for x in exclusions}) != len(exclusions):
            raise ValueError
        items = []
        descriptions = soup.select("#keyvotes-descriptions .keyvote-description")
        if len(descriptions) != spec.item_count:
            raise ValueError
        for ordinal, item in enumerate(descriptions, 1):
            if item.get("rel") != str(ordinal) or item.get("data-value") not in {"1", "2", "3"}:
                raise ValueError
            preferred = item.get("data-preferred")
            h4, meta, scored = item.select_one("h4"), item.select_one(".meta"), item.select_one(".scored")
            if preferred not in {"Yea", "Nay"} or h4 is None or meta is None or scored is None:
                raise ValueError
            heading = _text(h4)
            prefix = f"Key Vote {ordinal}: "
            if not heading.startswith(prefix) or f'"{preferred}" votes scored.' not in _text(scored):
                raise ValueError
            type_tag, bill_tag = meta.select_one(".type"), meta.select_one(".bill")
            roll = _text(type_tag) if type_tag else None
            if roll is not None and re.fullmatch(r"Roll Call \d+", roll) is None:
                raise ValueError
            links = [{"text": _text(a), "href": str(a["href"])} for a in meta.select("a[href]")]
            publisher_ids = {n for a in links for n in parse_qs(urlsplit(a["href"]).query).get("keyvote", [])}
            if len(publisher_ids) > 1:
                raise ValueError
            summaries = item.select(".summary")
            summary = summaries[0] if summaries else None
            path = f"html:#keyvotes-descriptions/.keyvote-description[rel={ordinal}]"
            summary_occurrences = []
            for index, summary_node in enumerate(summaries):
                summary_path = path + f"/.summary[{index}]"
                summary_occurrences.append(
                    {
                        "occurrence_id": f"native-summary-{index}",
                        "text": _text(summary_node),
                        "attributes": _attributes(summary_node),
                        "source_path": summary_path,
                        "prefixes": [
                            {
                                "text": _text(prefix),
                                "attributes": _attributes(prefix),
                                "source_path": summary_path + f"/.prefix[{i}]",
                            }
                            for i, prefix in enumerate(summary_node.select(".prefix"))
                        ],
                        "links": [
                            {
                                "text": _text(link),
                                "href": str(link["href"]),
                                "attributes": _attributes(link),
                                "source_path": summary_path + f"/a[{i}]",
                            }
                            for i, link in enumerate(summary_node.select("a[href]"))
                        ],
                    }
                )
            items.append(
                {
                    "ordinal": str(ordinal),
                    "publisher_id": next(iter(publisher_ids), None),
                    "title": heading[len(prefix) :],
                    "heading": heading,
                    "roll": roll,
                    "bill": _text(bill_tag) if bill_tag else None,
                    "links": links,
                    "summary": _text(summary) if summary else None,
                    "summary_occurrences": summary_occurrences,
                    "scored": _text(scored),
                    "preferred": preferred,
                    "weight": item["data-value"],
                    "attributes": _attributes(item),
                    "augmentations": [_attributes(a) | {"text": _text(a)} for a in item.select(".mini-augmentation")],
                }
            )
        tables = soup.select("table.keyvotes-scorecard-table")
        if len(tables) != (spec.member_rows + 19) // 20 or len(soup.select("table")) != len(tables):
            raise ValueError
        members = []
        columns = [str(i) for i in range(1, spec.item_count + 1)]
        for table_index, table in enumerate(tables):
            if [_text(x) for x in table.select("thead .vote-nums .offset a")] != columns:
                raise ValueError
            if _text(table.select_one("thead .score")) != "Score":
                raise ValueError
            rows = table.select("tbody tr")
            expected_rows = min(20, spec.member_rows - table_index * 20)
            if len(rows) != expected_rows:
                raise ValueError
            for row_index, row in enumerate(rows):
                cells = row.find_all("td", recursive=False)
                node = row.get("rel")
                if len(cells) != 4 or not isinstance(node, str) or not node.isdecimal():
                    raise ValueError
                link = cells[1].select_one("a[href]")
                role = cells[1].select_one(".role")
                if link is None or link["href"] != "/node/" + node or role is None:
                    raise ValueError
                context = _text(role)
                match = re.fullmatch(r"([A-Z]{2})(?: (\d+|at large))? - ([RDI])", context)
                if match is None:
                    raise ValueError
                name = " ".join(str(x) for x in link.find_all(string=True) if x.find_parent("span") is not role).strip()
                if not name:
                    raise ValueError
                score = _text(cells[3])
                if score not in {"NA", "N/A"} and re.fullmatch(r"\d+(?:\.\d+)?", score) is None:
                    raise ValueError
                swatches = cells[2].select(".offset > a")
                if len(swatches) != spec.item_count:
                    raise ValueError
                actions = []
                for ordinal, cell in enumerate(swatches, 1):
                    cell_rel = cell.get("rel")
                    cell_rel = " ".join(cell_rel) if isinstance(cell_rel, list) else cell_rel
                    classes = cell.get("class")
                    if (
                        cell_rel != str(ordinal)
                        or not isinstance(classes, list)
                        or len(classes) != 1
                        or classes[0] not in GLYPHS
                    ):
                        raise ValueError
                    if _text(cell) != GLYPHS[classes[0]]:
                        raise ValueError
                    actions.append({"ordinal": str(ordinal), "glyph": _text(cell), "attributes": _attributes(cell)})
                flags = [
                    {
                        "attributes": _attributes(x),
                        "text": _text(x),
                        "images": [_attributes(i) for i in x.select("img")],
                    }
                    for x in cells[0].select(".flag")
                ]
                members.append(
                    {
                        "id": node,
                        "name": name,
                        "role": context,
                        "state": match[1],
                        "district": match[2],
                        "party": match[3],
                        "score": score,
                        "table": table_index,
                        "row": row_index,
                        "classes": row.get("class"),
                        "flags": flags,
                        "actions": actions,
                    }
                )
        if len(members) != spec.member_rows or len({m["id"] for m in members}) != spec.member_rows:
            raise ValueError
        return {
            "members": members,
            "items": items,
            "exclusions": exclusions,
            "legend": [_text(x) for x in labels],
            "methodology": methodology,
            "scale_text": scales[0],
        }
    except (ValueError, TypeError, AttributeError, KeyError) as error:
        raise ScorecardSourceError(
            "FreedomWorks print table is incomplete or has an unreviewed source shape"
        ) from error


def list_scorecards(context):
    source = context.read(INDEX, stage="scorecards:freedomworks:index", hosts=HOSTS)
    soup = BeautifulSoup(source.body, "html.parser")
    wanted = {urlsplit(s.original.removesuffix("/print")).path for s in PRINT_EDITIONS}
    found = {
        str(a["href"])
        for a in soup.select("a[href]")
        if re.fullmatch(r"/keyvotes/(?:house|senate)/\d{4}", str(a["href"]))
    }
    if found != wanted or soup.title is None or "Congressional Scorecard - FreedomWorks" not in _text(soup.title):
        raise ScorecardSourceError("FreedomWorks original index does not reconcile the reviewed annual editions")
    return tuple(s.edition for s in PRINT_EDITIONS)


def acquire_scorecard(edition, context):
    spec = next((s for s in PRINT_EDITIONS if s.edition == edition), None)
    if spec is None:
        raise ScorecardSourceError("FreedomWorks edition has not been shape-qualified")
    source = context.read(edition.source_url, stage="scorecards:freedomworks:edition", hosts=HOSTS)
    facts = _facts(source, spec)
    end = context.read(edition.source_url, stage="scorecards:freedomworks:edition-end", hosts=HOSTS)
    if _facts(end, spec) != facts:
        raise ScorecardSourceError("FreedomWorks source facts changed during the complete print-table reread")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="FreedomWorks",
        parser_version=parser_version,
        rendition_rule="freedomworks-original-annual-print-archived/1",
        homepage="https://www.freedomworks.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "member_results", "methodology")
    bundle.use(end, "members_and_scores", "scored_items", "member_results", "methodology", role="corroboration")
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = HOME
    bundle.tables["scorecards"][0].update(methodology_url=source.url, timespan_text=str(spec.year))
    method = "native-scoring"
    bundle.add(
        "scorecard_methodologies",
        source,
        "html:#keyvotes-scoring",
        methodology_id=method,
        chamber_text=spec.chamber,
        methodology_text=facts["methodology"],
        methodology_url=source.url,
        disclosure_status="Explicit publisher print scoring, weights and member exclusions",
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "html:.keyvotes-legend",
        methodology_id="native-legend",
        chamber_text=spec.chamber,
        methodology_text=json.dumps(facts["legend"], ensure_ascii=False),
        methodology_url=source.url,
        disclosure_status="Explicit publisher glyph legend",
    )
    bundle.add(
        "scorecard_methodologies",
        source,
        "/",
        methodology_id="archive-provenance",
        methodology_text=json.dumps(
            {
                "original_source_url": spec.original,
                "archival_replay_url": source.url,
                "final_annual_score_not_established": True,
            }
        ),
        methodology_url=source.url,
        disclosure_status="Complete named archived print rendition; no final-year claim",
    )
    # The print page has one Score and states no primary designation (is_primary NULL).
    bundle.add(
        "scorecard_metrics",
        source,
        "html:table[0]/thead/.score",
        metric_id="score",
        name="Score",
        chamber_text=spec.chamber,
        methodology_id=method,
        scale_text=facts["scale_text"],
        period_text=edition.title,
    )
    for item in facts["items"]:
        ident = "key-vote-" + item["ordinal"]
        path = f"html:#keyvotes-descriptions/.keyvote-description[rel={item['ordinal']}]"
        refs = [
            {
                "occurrence_id": f"native-link-{i}",
                "citation_text": urljoin(HOME, link["href"]),
                "kind": "publisher_url",
                "source_path": path + f"/.meta/a[{i}]",
            }
            for i, link in enumerate(item["links"])
        ]
        item["citation_occurrences"] = _item_citations(item, path)
        refs.extend(citation_reference(occurrence) for occurrence in item["citation_occurrences"])
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=ident,
            publisher_item_id=item["publisher_id"],
            item_kind_text="Roll Call" if item["roll"] else "Key Vote",
            title=item["title"],
            congress_text=spec.congress,
            chamber_text=spec.chamber,
            roll_number_text=item["roll"].removeprefix("Roll Call ") if item["roll"] else None,
            bill_citation_text=item["bill"],
            references_json=json.dumps(refs, ensure_ascii=False),
            publisher_position_text=item["preferred"],
            position_basis="explicit",
            position_source_path=path + "/@data-preferred",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            path + "/@data-value",
            metric_id="score",
            item_id=ident,
            participation_id="native-key-vote",
            methodology_id=method,
            publisher_position_text=item["preferred"],
            position_basis="explicit",
            weight_text=item["weight"],
            weight_number=item["weight"],
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id="native-item-" + item["ordinal"],
            chamber_text=spec.chamber,
            methodology_text=json.dumps(item, ensure_ascii=False),
            methodology_url=source.url,
            disclosure_status="Literal item description, native attributes, links and weights",
        )
    exclusions = {x["id"]: x for x in facts["exclusions"]}
    seen = set()
    for member in facts["members"]:
        seen.add(member["id"])
        path = f"html:table[{member['table']}]/tbody/tr[{member['row']}]"
        exclusion = exclusions.get(member["id"])
        bundle.add(
            "scorecard_members",
            source,
            path,
            publisher_member_key=member["id"],
            publisher_member_id=member["id"],
            identifiers_json="[]",
            member_name=member["name"],
            chamber_text=spec.chamber,
            state=member["state"],
            district=member["district"],
            party=member["party"],
            eligibility_text=exclusion["text"] if exclusion else None,
            notes_text=json.dumps(
                {
                    "native_role": member["role"],
                    "native_classes": member["classes"],
                    "native_flags": member["flags"],
                    "native_exclusion": exclusion,
                },
                ensure_ascii=False,
            ),
        )
        value = "N/A" if member["score"] == "NA" else member["score"]
        bundle.add(
            "scorecard_member_ratings",
            source,
            path + "/td.score",
            metric_id="score",
            publisher_member_key=member["id"],
            value_text=value,
            value_number=decimal_text(value),
            value_status_text="N/A" if value == "N/A" else None,
            notes_text=json.dumps({"native_score": member["score"]}),
        )
        for action in member["actions"]:
            bundle.add(
                "scorecard_member_item_results",
                source,
                path + f"/td.votes/a[rel={action['ordinal']}]",
                publisher_member_key=member["id"],
                metric_id="score",
                item_id="key-vote-" + action["ordinal"],
                participation_id="native-key-vote",
                result_id="native-glyph",
                action_text=action["glyph"],
                result_text=action["glyph"],
                reason_text=json.dumps(action, ensure_ascii=False),
            )
    for exclusion in facts["exclusions"]:
        if exclusion["id"] in seen:
            continue
        bundle.add(
            "scorecard_members",
            source,
            f"html:#keyvotes-scoring/.suppressed/.leg[{exclusion['ordinal']}]",
            publisher_member_key=exclusion["id"],
            publisher_member_id=exclusion["id"],
            identifiers_json="[]",
            member_name=exclusion["name"],
            chamber_text=spec.chamber,
            eligibility_text=exclusion["text"],
            notes_text=json.dumps({"native_exclusion": exclusion, "table_rating_absent": True}, ensure_ascii=False),
        )
    return bundle.finish(
        "Every reviewed original print-table member row, literal score, key-vote description, preferred position, "
        "weight, exclusion, flag and member glyph reconciles; all native table segments reach the footer, "
        "the unfiltered headers and reviewed source populations match, and selected facts are stable on reread. "
        "This is a complete archived source-defined print rendition, including non-roll-call key votes and "
        "publisher contradictions; final annual status, actual votes from alignment glyphs and official identities are not inferred."
    )
