"""Bounded workbook syntax and literal cells; publisher readers choose their meaning."""

import posixpath
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from io import BytesIO
from zipfile import BadZipFile, ZipFile

from spicy_docs.sources.scorecards.common import ScorecardSourceError

NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"


def _display_text(node):
    # OOXML rPh and phoneticPr describe pronunciation annotations, not displayed
    # cell text. Read only direct text or rich-text runs, in document order.
    result = []
    for child in node:
        if child.tag == "{" + NS["x"] + "}t":
            result.append(child.text or "")
        elif child.tag == "{" + NS["x"] + "}r":
            result.extend(text.text or "" for text in child.findall("x:t", NS))
    return "".join(result)


@dataclass(frozen=True)
class WorkbookCell:
    value: str | None
    formula: str | None


def literal_sheets(body: bytes) -> dict[str, dict[str, WorkbookCell]]:
    """Read complete ZIP entries, resolve internal worksheets, and retain cached formula values.

    Values remain source text. An absent cached value stays absent; this reader
    never evaluates a formula or infers an omitted cell.
    """
    try:
        with ZipFile(BytesIO(body)) as archive:
            infos = archive.infolist()
            if (
                len(infos) > 1000
                or sum(i.file_size for i in infos) > 100 * 1024**2
                or len({i.filename for i in infos}) != len(infos)
                or archive.testzip() is not None
            ):
                raise ScorecardSourceError("Workbook ZIP is incomplete, repeated or exceeds its expanded bound")

            def xml(path):
                raw = archive.read(path)
                if b"<!DOCTYPE" in raw or b"<!ENTITY" in raw:
                    raise ScorecardSourceError("Workbook XML contains unsupported declarations")
                return ET.fromstring(raw)

            strings = (
                [_display_text(n) for n in xml("xl/sharedStrings.xml")]
                if "xl/sharedStrings.xml" in archive.namelist()
                else []
            )
            relationships = {}
            relationship_ids = set()
            for relation in xml("xl/_rels/workbook.xml.rels"):
                identifier = relation.get("Id")
                if not identifier or identifier in relationship_ids:
                    raise ScorecardSourceError("Workbook relationship identities are missing or repeated")
                relationship_ids.add(identifier)
                if relation.get("TargetMode") == "External":
                    continue
                target = relation.get("Target", "")
                path = posixpath.normpath(target.lstrip("/") if target.startswith("/") else "xl/" + target)
                if not path.startswith("xl/") or path not in archive.namelist():
                    raise ScorecardSourceError("Workbook relationship leaves its retained ZIP")
                relationships[identifier] = path
            result = {}
            for sheet in xml("xl/workbook.xml").findall("x:sheets/x:sheet", NS):
                name = sheet.get("name")
                if not name or name in result or sheet.get(RID) not in relationships:
                    raise ScorecardSourceError("Workbook worksheet identities are missing or repeated")
                cells = {}
                root = xml(relationships[sheet.get(RID)])
                for node in root.findall("x:sheetData/x:row/x:c", NS):
                    coordinate = node.get("r")
                    if not coordinate or not re.fullmatch(r"[A-Z]+[1-9]\d*", coordinate) or coordinate in cells:
                        raise ScorecardSourceError("Workbook cell coordinates are missing or repeated")
                    value, formula = node.find("x:v", NS), node.find("x:f", NS)
                    text = value.text if value is not None else None
                    kind = node.get("t", "n")
                    if kind == "s":
                        if text is None or not re.fullmatch(r"[0-9]+", text):
                            raise ScorecardSourceError("Workbook shared-string reference is not a nonnegative index")
                        text = strings[int(text)]
                    elif kind == "inlineStr":
                        text = _display_text(node.find("x:is", NS))
                    elif kind not in {"n", "str", "e"}:
                        raise ScorecardSourceError("Workbook introduces an unsupported cell value encoding")
                    cells[coordinate] = WorkbookCell(text, formula.text if formula is not None else None)
                result[name] = cells
            return result
    except (BadZipFile, KeyError, IndexError, TypeError, ValueError, AttributeError, ET.ParseError) as error:
        if isinstance(error, ScorecardSourceError):
            raise
        raise ScorecardSourceError("Workbook cannot establish complete literal cells") from error


def column(number: int) -> str:
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result
