"""SBA's complete native grade catalog; profile JSON is a separate rendition."""

import re
from hashlib import sha256

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "sba-native-grade-catalog/1"
ORIGIN = "https://sbaprolife.org"
INDEX = ORIGIN + "/scorecard"
HOSTS = ("sbaprolife.org",)
JAVASCRIPT = ORIGIN + "/wp-content/plugins/sba-scorecard/assets/js/sba-scorecard.js?ver=1.0.0"
# This reviewed index client filters and paginates all supplied HTML rows locally.
# Profile pages load different scripts and expose a distinct JSON rendition.
JAVASCRIPT_SHA256 = "5fd2ca8580f15baddc3d0e6afe80dd23e61e6b15c72a7f052529c9ff19b4825f"
HEADERS = {
    "senate": ["Senator", "Party", "State", "Rating", "Status"],
    "house": ["Representative", "Party", "District", "Rating", "Status"],
}
PERIOD = "This Scorecard reflects where every member of Congress stood on key pro-life votes and activities during the 119th Congress."
TITLE = "National Pro-Life Scorecard"


def edition():
    return ScorecardEdition("sba", "119-grade-catalog", INDEX, TITLE, congress="119", chamber="both")


def list_scorecards(context: ScorecardContext):
    document = context.read(INDEX, stage="sba:catalog-list", hosts=HOSTS)
    _page(document)
    return (edition(),)


def _one(element, selector):
    found = element.select(selector)
    if len(found) != 1:
        raise ScorecardSourceError("SBA native catalog structure is missing or repeated: " + selector)
    return found[0]


def _page(document):
    if document.url != INDEX or not document.body.rstrip().lower().endswith(b"</html>"):
        raise ScorecardSourceError("SBA complete original catalog identity/trailer is missing")
    html = soup(document)
    if _one(html, "link[rel=canonical]").get("href") != INDEX or TITLE not in [
        x.get_text(" ", strip=True) for x in html.select("h1")
    ]:
        raise ScorecardSourceError("SBA original grade catalog heading/canonical identity changed")
    declarations = [p.get_text(" ", strip=True) for p in html.select("p") if "This Scorecard reflects" in p.get_text()]
    if declarations != [PERIOD] or len(html.select("table.sc_table")) != 2:
        raise ScorecardSourceError("SBA native grade catalog period or complete chamber inventory changed")
    if _one(html, "script#msp-script-js").get("src") != JAVASCRIPT:
        raise ScorecardSourceError("SBA native catalog application asset changed")
    members = []
    seen = set()
    for chamber, selector in (("senate", "#sc_dt_sen"), ("house", "#sc_dt_house")):
        table = _one(html, selector)
        if [th.get_text(" ", strip=True) for th in table.select("thead th")] != HEADERS[chamber]:
            raise ScorecardSourceError("SBA native catalog columns changed")
        rows = table.select("tr")
        if not rows or len(rows) != len(table.select("tr:has(td)")) + 1 or len(rows) <= 1:
            raise ScorecardSourceError("SBA complete native member table is empty or malformed")
        for ordinal, row in enumerate(rows[1:], 2):
            cells = row.find_all("td", recursive=False)
            if len(cells) != 5 or any(c.get("colspan") or c.get("rowspan") for c in cells):
                raise ScorecardSourceError("SBA full native member/rating row is incomplete")
            anchor = _one(cells[0], "a[href]")
            name = anchor.get_text(strip=True)
            profile_url = anchor.get("href")
            expected_path = "/senator/" if chamber == "senate" else "/representative/"
            if not isinstance(profile_url, str) or not re.fullmatch(
                re.escape(ORIGIN + expected_path) + r"[a-z0-9-]+/", profile_url
            ):
                raise ScorecardSourceError("SBA source member profile identity left its original chamber route")
            values = [c.get_text(" ", strip=True) for c in cells]
            grade = _one(cells[3], ".sc-rating").get_text(strip=True)
            if (
                not name
                or values[1] not in {"Democrat", "Republican", "Independent"}
                or values[4] not in {"Current", "Former"}
                or grade not in {"A+", "A", "B", "C", "D", "F", "NA", "N/A", "n/a"}
            ):
                raise ScorecardSourceError("SBA native member, rating or status shape changed")
            state = values[2]
            district = None
            if chamber == "house":
                match = re.fullmatch(r"([A-Z]{2})-(\d{2}|AL)", values[2])
                if match is None:
                    raise ScorecardSourceError("SBA literal House district context changed")
                state, district = match[1], match[2]
            elif not state:
                raise ScorecardSourceError("SBA literal Senate state is absent")
            member_key = key(chamber, profile_url)
            if member_key in seen:
                raise ScorecardSourceError("SBA native source member profile is repeated")
            seen.add(member_key)
            members.append(
                {
                    "key": member_key,
                    "name": name,
                    "profile_url": profile_url,
                    "state": state,
                    "district": district,
                    "party": values[1],
                    "grade": grade,
                    "status": values[4],
                    "literal_location": values[2],
                    "chamber": chamber,
                    "path": selector + " tr:nth-child(" + str(ordinal) + ")",
                }
            )
    return members


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    if selected != edition():
        raise ScorecardSourceError("SBA selection is outside the reviewed native grade catalog")
    document = context.read(INDEX, stage="sba:catalog", hosts=HOSTS)
    members = _page(document)
    asset = context.read(JAVASCRIPT, stage="sba:catalog-client", hosts=HOSTS)
    if asset.url != JAVASCRIPT or sha256(asset.body).hexdigest() != JAVASCRIPT_SHA256:
        raise ScorecardSourceError("SBA native catalog client changed and requires requalification")
    repeated = context.read(INDEX, stage="sba:catalog-repeat", hosts=HOSTS)
    if _page(repeated) != members:
        raise ScorecardSourceError("SBA complete native grade catalog changed on reread")
    bundle = Bundle(
        selected,
        context,
        document,
        publisher_name="Susan B. Anthony Pro-Life America",
        parser_version=parser_version,
        rendition_rule="Complete native HTML member grade catalog, including every Current and Former row; profile term/item JSON is an explicit separate pending rendition.",
        homepage=ORIGIN,
    )
    bundle.use(document, "native-catalog")
    bundle.use(repeated, "native-catalog", role="corroboration")
    bundle.use(asset, "catalog-renderer")
    bundle.tables["scorecards"][0].update(
        edition_label_text=TITLE,
        timespan_text=PERIOD,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "catalog-prologue",
                    "period_text": PERIOD,
                    "kind": "explicit",
                    "congress_text": "119",
                    "source_path": "p/catalog-prologue",
                }
            ]
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        "table.sc_table",
        methodology_id="native-catalog",
        disclosure_status="undocumented",
        methodology_text=json_column(
            {
                "literal_prologue": PERIOD,
                "literal_chamber_headers": HEADERS,
                "rendition_scope": "All original native HTML grade catalog rows, including source-labelled Current and Former. Source profile links are advertised, not acquired by this rendition.",
                "period_limit": "The prologue identifies 119th Congress, while the source also supplies Former member rows without their grading periods. No grade period is inferred for those rows; the profile API retains distinct historical term ratings.",
                "identity_rule": "Exact chamber and publisher profile URL. Source names, party labels, status and state/district spelling are retained; no official identity is assigned.",
                "remaining_renditions": "Publisher-linked profile pages and configured get_senator_data/get_representative_data JSON actions expose term ratings, votes and activities. Their full population and item ledgers require separate acquisition/qualification. Empty item tables here mean no item grid in this selected index rendition.",
            }
        ),
    )
    bundle.add(
        "scorecard_methodologies",
        asset,
        "document",
        methodology_id="catalog-client",
        disclosure_status="partial",
        methodology_text=json_column(
            {
                "reviewed_client_sha256": JAVASCRIPT_SHA256,
                "source_behavior": "Both DataTables consume the complete supplied native HTML rows. UI counts use api.data().length. Status filters select Current by default; Former is also selectable. Display pagination is client-side, not a server page boundary.",
            }
        ),
    )
    bundle.metric(document, "native-rating", "Rating", path="table.sc_table thead th:nth-child(4)", primary=True)
    bundle.tables["scorecard_metrics"][-1].update(methodology_id="native-catalog", periods_json="[]")
    for member in members:
        notes = {
            "literal_profile_url": member["profile_url"],
            "literal_status": member["status"],
            "literal_location": member["literal_location"],
            "literal_source_name": member["name"],
        }
        bundle.add(
            "scorecard_members",
            document,
            member["path"],
            publisher_member_key=member["key"],
            member_name=member["name"],
            chamber_text=member["chamber"].title(),
            state=member["state"],
            district=member["district"],
            party=member["party"],
            identifiers_json="[]",
            notes_text=json_column(notes),
        )
        grade = "N/A" if member["grade"] in {"NA", "N/A", "n/a"} else member["grade"]
        bundle.add(
            "scorecard_member_ratings",
            document,
            member["path"] + " td:nth-child(4) .sc-rating",
            metric_id="native-rating",
            publisher_member_key=member["key"],
            value_text=grade,
            value_status_text=grade if grade == "N/A" else None,
            notes_text=json_column(
                {
                    **notes,
                    "literal_source_value": member["grade"],
                    "grading_period": "Not separately stated by the source index row; see the separately acquired publisher profile term rendition.",
                }
            ),
        )
    return bundle.finish(
        "Original HTML reached its final trailer with both complete native chamber tables and every full member/status/grade row. The independently captured reviewed publisher client paginates these supplied rows locally. All native grade catalog facts reconcile with a stable full reread, including Current and Former; numeric publisher population counts are not separately declared.",
        declared={
            "publisher_declared_counts": None,
            "qualified_rendition": "complete_native_member_grade_catalog",
            "profile_item_rendition": "available_pending_separate_full_acquisition_and_qualification",
            "observed_native_rows": {
                ch: {
                    status: sum(m["chamber"] == ch and m["status"] == status for m in members)
                    for status in ("Current", "Former")
                }
                for ch in ("senate", "house")
            },
        },
    )
