"""CPAC's complete 2023 congressional PDF from pinned reviewed semantic facts.

The original native layer contains invisible and unrelated text. Qualification
uses shared page rendering and Gemini outcomes, checked against original source
cells. This reader consumes the reviewed private asset; it never calls a model.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "cpac-2023-qualified-rendered-pdf/1"
INDEX = "https://www.cpac.org/foundation/ratings/us"
PDF = "https://dea0d469-c1d7-4068-bddd-0a3895cc096b.usrfiles.com/ugd/dea0d4_244fd8b57e104873853aac1e36a44cd4.pdf"
HOSTS = ("dea0d469-c1d7-4068-bddd-0a3895cc096b.usrfiles.com",)
SOURCE_SHA256 = "50e84612f5cbe99d8bbd6f662b2befc819505bcd21d99509804a8f8e9b827354"
QUALIFIED_SHA256 = "250b1e3bd21179b7b56329dfc5715c71ffb0d0649f0940a0d4054ce1d6d781cc"
MEMBER_COUNTS = {"Senate": 101, "House": 437}
ITEM_COUNTS = {"Senate": 41, "House": 76}
PAGE_COUNTS = {
    8: 21,
    9: 20,
    10: 20,
    11: 20,
    12: 20,
    23: 28,
    25: 32,
    27: 27,
    29: 31,
    31: 28,
    33: 27,
    35: 27,
    37: 28,
    39: 26,
    41: 29,
    43: 28,
    45: 27,
    47: 25,
    49: 30,
    51: 26,
    53: 18,
}
EDITION = ScorecardEdition(
    "cpac", "2023", INDEX, "Ratings of Congress", year="2023", congress="118", chamber="both", is_current=False
)
METRICS = (
    ("2023", "annual:rating", "2023%"),
    ("2022", "prior:2022:rating", "2022%"),
    ("lifetime", "lifetime:rating", "Life time%"),
)


def _source(document: SourceDocument) -> None:
    if document.url != PDF or sha256(document.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("CPAC 2023 PDF differs from the reviewed original source")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    """Corroborate the supported immutable PDF, independent of the live Wix catalog."""
    _source(context.read(PDF, stage="cpac:2023:pdf:list", hosts=HOSTS))
    return (EDITION,)


@dataclass(frozen=True, slots=True)
class CPAC2023Reader:
    """Inject pinned private facts and a fresh private observation writer.

    The source is larger than the default acquisition bound. The host must
    explicitly provide a bound that admits the complete PDF (50 MiB suffices).
    """

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        return list_scorecards(context)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value: dict, *, schema: str) -> None:
    if (
        not isinstance(value["physical_page"], int)
        or not 1 <= value["physical_page"] <= 74
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or value["schema_version"] != schema
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body: bytes) -> dict:
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("CPAC 2023 observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "cpac-qualified-pdf-2023/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["physical_page_count"] != 74
            or data["member_counts"] != MEMBER_COUNTS
            or data["item_counts"] != ITEM_COUNTS
            or data["member_page_counts"] != {str(p): count for p, count in PAGE_COUNTS.items()}
            or data["front"]["field_pages"] != {"edition": 1, "selection": 3, "metrics": 8, "legend": 8}
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], schema="cpac-2023-edition-facts/1")
        if (
            front["title_text"] != EDITION.title
            or front["year_text"] != "2023"
            or front["congress_text"] != "118TH CONGRESS"
            or front["session_text"] != "FIRST SESSION"
            or front["metric_labels"] != [m[2] for m in METRICS]
            or front["item_weight_formula_text"] is not None
            or front["uncertainties"]
            or Counter(r["result_text"] for r in front["result_definitions"]) != Counter(("(+)", "(-)", "(x)"))
            or any(not r["meaning_text"] for r in front["result_definitions"])
            or not front["no_rating_meaning_text"]
        ):
            raise ValueError
        items: dict[tuple[str, str], dict] = {}
        for entry in data["items"]:
            chamber, record = entry["chamber"], entry["record"]
            evidence = entry["evidence"]
            _evidence(evidence, schema="cpac-2023-item-facts/1")
            roll = record["roll_number_text"]
            if (
                chamber not in ITEM_COUNTS
                or not re.fullmatch(r"[1-9]\d*", roll)
                or (chamber, roll) in items
                or not record["roll_citation_text"]
                or not record["title_text"]
                or not record["publisher_position_text"]
                or record["chamber_text"] not in {"U.S. " + chamber, "U.S. " + chamber.upper()}
                or any(
                    not isinstance(v, str) or not v
                    for field_name in ("bill_citations", "amendment_citations")
                    for v in record[field_name]
                )
                or not (
                    13 <= evidence["physical_page"] <= 22
                    if chamber == "Senate"
                    else 55 <= evidence["physical_page"] <= 71
                )
            ):
                raise ValueError
            items[chamber, roll] = record
        if Counter(chamber for chamber, _ in items) != ITEM_COUNTS:
            raise ValueError
        identities, results = set(), Counter()
        page_counts, member_counts = Counter(), Counter()
        for entry in data["members"]:
            chamber, record, evidence = entry["chamber"], entry["record"], entry["evidence"]
            _evidence(evidence, schema="cpac-2023-member-facts/1")
            _evidence(entry["corroboration_evidence"], schema="cpac-2023-member-facts/1")
            page = evidence["physical_page"]
            identity = chamber, record["state_text"], record["member_name_text"]
            expected_rolls = {roll for c, roll in items if c == chamber}
            if (
                chamber not in MEMBER_COUNTS
                or page not in PAGE_COUNTS
                or chamber != ("Senate" if page < 13 else "House")
                or identity in identities
                or not record["member_name_text"]
                or not record["state_text"]
                or record["district_text"] is not None
                or record["party_text"] not in {"R", "D", "I"}
                or set(record["ratings"]) != {m[0] for m in METRICS}
                or any(not re.fullmatch(r"(?:100|[1-9]?\d)%|N/A", v) for v in record["ratings"].values())
                or set(record["item_results"]) != expected_rolls
                or any(v not in {"+", "-", "x"} for v in record["item_results"].values())
            ):
                raise ValueError
            covered = set()
            for result_evidence in entry["result_evidence"]:
                _evidence(result_evidence, schema="cpac-2023-result-subsets/1")
                rolls = result_evidence["roll_numbers"]
                if (
                    result_evidence["physical_page"] not in ({page} if chamber == "Senate" else {page, page + 1})
                    or len(set(rolls)) != len(rolls)
                    or covered.intersection(rolls)
                ):
                    raise ValueError
                covered.update(rolls)
            if covered != expected_rolls:
                raise ValueError
            identities.add(identity)
            page_counts[page] += 1
            member_counts[chamber] += 1
            results.update(record["item_results"].values())
        if member_counts != MEMBER_COUNTS or page_counts != PAGE_COUNTS or results != data["result_counts"]:
            raise ValueError
    except (ValueError, TypeError, KeyError, AttributeError):
        raise ScorecardSourceError("CPAC 2023 qualified source scope is incomplete or inconsistent") from None
    return data


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
) -> ScorecardAcquisition:
    if edition != EDITION:
        raise ScorecardSourceError("CPAC PDF reader supports only the qualified 2023 federal edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "CPAC 2023 requires reviewed observations and an explicit private retention callback"
        )
    data = _qualified(qualified_observations)
    document = context.read(PDF, stage="cpac:2023:pdf", hosts=HOSTS)
    _source(document)
    observation_id = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="cpac:2023:qualified-observations",
    )
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="CPAC Foundation",
        parser_version=parser_version,
        rendition_rule="complete reviewed original 2023 PDF; independent rating crops and every rendered result cell reconciled; pinned semantic records; stable original PDF reread",
        homepage="https://www.cpac.org/",
    )
    bundle.use(document, "members", "metrics", "ratings", "items", "member-results", "methodology")

    def path(group: str, index: int | None = None, suffix: str = "", *, field_group: str | None = None) -> str:
        entry = data[group] if index is None else data[group][index]
        pointer = "/" + group if index is None else f"/{group}/{index}/record"
        page = entry["field_pages"][field_group] if field_group else entry["evidence"]["physical_page"]
        return f"pdf:page={page};observation={observation_id};{pointer}{suffix}"

    front = data["front"]["record"]
    scorecard = bundle.tables["scorecards"][0]
    scorecard.update(
        source_path=path("front"),
        edition_label_text=front["edition_label_text"],
        session_text=front["session_text"],
        methodology_url=PDF,
        periods_json=json_column(
            [
                {
                    "occurrence_id": "edition",
                    "period_text": front["congress_text"] + " " + front["session_text"],
                    "kind": "explicit",
                    "source_path": path("front"),
                    "congress_text": "118",
                    "session_text": "1",
                    "year_text": "2023",
                }
            ]
        ),
    )
    for identifier, text in (
        ("selection", front["selection_heading_text"]),
        ("no-rating", front["no_rating_meaning_text"]),
        *(("legend:" + r["result_text"], r["meaning_text"]) for r in front["result_definitions"]),
    ):
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front", suffix="/record", field_group="selection" if identifier == "selection" else "legend"),
            methodology_id=identifier,
            cohort_text=front["no_rating_label_text"] if identifier == "no-rating" else None,
            methodology_text=text,
            methodology_url=PDF,
            disclosure_status="partial" if identifier == "selection" else "explicit",
        )
    for field_name, identifier, label in METRICS:
        bundle.add(
            "scorecard_metrics",
            document,
            path("front", suffix="/record/metric_labels", field_group="metrics"),
            metric_id=identifier,
            name=label,
            value_unit_text="%",
            period_text="Life time" if field_name == "lifetime" else field_name,
            methodology_id="selection" if field_name == "2023" else None,
            is_primary="true" if field_name == "2023" else "false",
        )
    legends = {r["result_text"][1:-1]: r["meaning_text"] for r in front["result_definitions"]}
    for index, entry in enumerate(data["items"]):
        row, chamber = entry["record"], entry["chamber"]
        roll, location = row["roll_number_text"], path("items", index)
        identifier = key(chamber, roll)
        references = [
            {
                "occurrence_id": "roll",
                "citation_text": row["roll_citation_text"],
                "kind": "roll_call",
                "source_path": location + "/roll_citation_text",
                "congress_text": "118",
                "session_text": "1",
                "chamber_text": row["chamber_text"],
                "roll_number_text": roll,
            }
        ]
        for group, kind, column in (
            ("bill_citations", "bill", "bill_citation_text"),
            ("amendment_citations", "amendment", "amendment_citation_text"),
        ):
            references.extend(
                {
                    "occurrence_id": f"{kind}:{i}",
                    "citation_text": text,
                    "kind": kind,
                    "source_path": location + f"/{group}/{i}",
                    "congress_text": "118",
                    "chamber_text": row["chamber_text"],
                    column: text,
                }
                for i, text in enumerate(row[group])
            )
        target = row["publisher_position_text"]
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            publisher_item_id=row["roll_citation_text"],
            item_kind_text="roll call",
            title=row["title_text"],
            item_date_text=row["item_date_text"],
            congress_text="118",
            session_text="1",
            chamber_text=row["chamber_text"],
            roll_number_text=roll,
            bill_citation_text=row["bill_citations"][0] if len(row["bill_citations"]) == 1 else None,
            amendment_citation_text=row["amendment_citations"][0] if len(row["amendment_citations"]) == 1 else None,
            references_json=json_column(references),
            publisher_position_text=target,
            position_basis="explicit",
            position_source_path=location + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id="annual:rating",
            item_id=identifier,
            participation_id="printed-2023-grid",
            methodology_id="selection",
            publisher_position_text=target,
            position_basis="explicit",
            counts_toward_metric="true",
        )
    for index, entry in enumerate(data["members"]):
        row, chamber, location = entry["record"], entry["chamber"], path("members", index)
        member_key = key(chamber, row["state_text"], row["member_name_text"])
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=row["member_name_text"],
            identifiers_json="[]",
            chamber_text=chamber,
            state=row["state_text"],
            party=row["party_text"],
            period_text="2023",
        )
        for field_name, identifier, _ in METRICS:
            value = row["ratings"][field_name]
            bundle.add(
                "scorecard_member_ratings",
                document,
                location + "/ratings/" + field_name,
                publisher_member_key=member_key,
                metric_id=identifier,
                value_text=value,
                value_number=decimal_text(value),
            )
        for roll, glyph in row["item_results"].items():
            result_page = next(e["physical_page"] for e in entry["result_evidence"] if roll in e["roll_numbers"])
            result_path = (
                f"pdf:page={result_page};observation={observation_id};/members/{index}/record/item_results/{roll}"
            )
            bundle.add(
                "scorecard_member_item_results",
                document,
                result_path,
                result_id="printed-grid",
                publisher_member_key=member_key,
                item_id=key(chamber, roll),
                metric_id="annual:rating",
                participation_id="printed-2023-grid",
                result_text=glyph,
                reason_text=legends[glyph],
            )
    repeated = context.read(PDF, stage="cpac:2023:pdf:reread", hosts=HOSTS)
    _source(repeated)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete official PDF grids reconcile every printed member row and all item descriptions; selected semantic ratings and every result glyph qualify against original renders; complete PDF hash and stable reread",
        declared={
            "physical_pages": data["physical_page_count"],
            "members_by_chamber": data["member_counts"],
            "members_by_physical_page": data["member_page_counts"],
            "items_by_chamber": data["item_counts"],
            "result_glyph_counts": data["result_counts"],
            "source_counts_basis": "complete printed grid rows and unique described roll calls",
            "source_na_ratings": sum(
                value == "N/A" for e in data["members"] for value in e["record"]["ratings"].values()
            ),
            "source_absent_item_dates": data["review"]["source_absent_item_dates"],
            "publisher_citation_notes": data["review"]["publisher_citation_findings"],
        },
    )
