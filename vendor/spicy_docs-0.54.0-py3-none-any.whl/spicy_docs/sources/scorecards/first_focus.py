"""First Focus's published federal tier cohorts and disclosed scoring entries."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "first-focus-named-qualified-tier-pdf/1"
HOSTS = ("campaignforchildren.org",)
INDEX = "https://campaignforchildren.org/legislative-scorecard/"
TITLE = "CHAMPIONS AND DEFENDERS OF CHILDREN LEGISLATIVE SCORECARD"
COHORT = "CHAMPIONS AND DEFENDERS OF CHILDREN"
SPECS: dict[str, dict[str, Any]] = {
    "2026": {
        "url": "https://campaignforchildren.org/wp-content/uploads/sites/5/2026/09/UPDATED-LegislativeScorecard_9.28.2026-1.pdf",
        "source_sha256": "9dbbab6845d83eb0c385046e270bc56c8617aa36f06e21ef26cffa08b5e92ab4",
        "qualified_sha256": "7558786120ba420738d9d7fd58252f22c8e726b1620f74b5849315d400a7913d",
        "label": "119TH CONGRESS - FULL SESSION",
        "period": "January 3, 2025 to September 8th, 2026",
        "session": None,
        "page_count": 47,
        "member_counts": {"House": 80, "Senate": 40},
        "tier_counts": {"CHAMPIONS": 60, "DEFENDERS": 60},
        "item_counts": {"Key Vote": 21, "Key Bill": 267},
        "item_page_counts": {
            9: 7,
            10: 6,
            11: 2,
            13: 6,
            15: 6,
            16: 6,
            17: 8,
            18: 9,
            19: 9,
            20: 9,
            21: 9,
            22: 10,
            23: 9,
            24: 8,
            25: 9,
            26: 9,
            27: 9,
            28: 8,
            29: 9,
            30: 10,
            31: 10,
            32: 3,
            33: 6,
            34: 8,
            35: 9,
            36: 10,
            37: 9,
            38: 9,
            39: 9,
            40: 9,
            41: 7,
            42: 9,
            43: 9,
            44: 9,
            45: 10,
            46: 4,
        },
        "positions": {"SUPPORT", "OPPOSE", "MIXED"},
        "untitled_items": 1,
    },
    "2025": {
        "url": "https://campaignforchildren.org/wp-content/uploads/sites/5/2026/02/First-Focus-Campaign-For-Children-2025-Legislative-Scorecard-FINAL-1.pdf",
        "source_sha256": "0719cfa7719c54482810f1dab29d713ea658edb4309bbe16d95c634e46d89b69",
        "qualified_sha256": "d46f2cb63384752bd84300dad07dbcbcf2e397a75a88dcfaeb00b3a056f0f46a",
        "label": "119TH CONGRESS - FIRST SESSION",
        "period": "January 3, 2025 to December 5, 2025",
        "session": "1",
        "page_count": 29,
        "member_counts": {"House": 80, "Senate": 40},
        "tier_counts": {"CHAMPIONS": 60, "DEFENDERS": 60},
        "item_counts": {"Key Vote": 15, "Key Bill": 157},
        "item_page_counts": {
            7: 9,
            8: 6,
            10: 8,
            11: 10,
            12: 10,
            13: 10,
            14: 11,
            15: 11,
            16: 11,
            17: 11,
            18: 8,
            19: 9,
            20: 11,
            21: 10,
            22: 11,
            23: 11,
            24: 9,
            25: 6,
        },
        "positions": {"SUPPORT", "OPPOSE", "MONITOR"},
        "untitled_items": 0,
    },
}
EDITIONS = {
    year: ScorecardEdition(
        "first_focus",
        year,
        spec["url"],
        TITLE,
        year=year,
        congress="119",
        chamber="both",
        is_current=year == "2026",
    )
    for year, spec in SPECS.items()
}


def _spec(identifier):
    if identifier not in SPECS:
        raise ScorecardSourceError("First Focus requires a reviewed named federal edition")
    return SPECS[identifier]


def _source(document, spec):
    if document.url != spec["url"] or sha256(document.body).hexdigest() != spec["source_sha256"]:
        raise ScorecardSourceError("First Focus PDF differs from its reviewed original named edition")


@dataclass(frozen=True, slots=True)
class FirstFocusPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError("First Focus observations must identify a reviewed named edition") from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["url"], stage=f"first-focus:{self.edition_key}:list", hosts=HOSTS), spec)
        return (EDITIONS[self.edition_key],)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != EDITIONS.get(self.edition_key):
            raise ScorecardSourceError("First Focus requires its configured reviewed named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value, spec):
    if (
        not value["physical_pages"]
        or any(type(p) is not int or not 1 <= p <= spec["page_count"] for p in value["physical_pages"])
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or value["schema_version"]
        not in {
            "first-focus-members-facts/1",
            "first-focus-members-facts/2",
            "first-focus-items-facts/1",
            "first-focus-items-facts/2",
            "first-focus-front-facts/2",
        }
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("First Focus observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "first-focus-qualified-pdf/1"
            or data["edition_key"] != identifier
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["page_count"]
            or any(data[k] != spec[k] for k in ["member_counts", "tier_counts", "item_counts"])
            or data["item_page_counts"] != {str(p): n for p, n in spec["item_page_counts"].items()}
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["uncertainties"]
            or front["title_text"] != TITLE
            or front["edition_label_text"] != spec["label"]
            or front["period_text"] != spec["period"]
            or front["congress_text"] != "119th Congress"
            or front["cohort_text"] != COHORT
            or not front["source_methodology_text"]
            or any(
                front[k] is not False
                for k in [
                    "numeric_scores_disclosed",
                    "all_member_ratings_disclosed",
                    "member_item_grid_disclosed",
                ]
            )
        ):
            raise ValueError
        identities, chambers, tiers, pages = set(), Counter(), Counter(), Counter()
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r = e["record"]
            identity = (r["chamber_text"], r["state_text"], r["district_text"], r["member_name_text"])
            physical = e["evidence"]["physical_pages"]
            if (
                identity in identities
                or r["chamber_text"] not in spec["member_counts"]
                or not r["member_name_text"]
                or not r["publisher_label_text"]
                or r["party_text"] not in {"D", "R", "I"}
                or not re.fullmatch(r"[A-Z]{2}", r["state_text"])
                or r["tier_text"] not in spec["tier_counts"]
                or len(physical) != 1
                or physical[0] != (2 if r["tier_text"] == "CHAMPIONS" else 3)
                or (r["chamber_text"] == "Senate" and r["district_text"] is not None)
                or (identifier == "2025" and r["district_text"] is not None)
                or (
                    identifier == "2026"
                    and r["chamber_text"] == "House"
                    and (
                        not isinstance(r["district_text"], str) or not re.fullmatch(r"\d+|At Large", r["district_text"])
                    )
                )
            ):
                raise ValueError
            identities.add(identity)
            chambers[r["chamber_text"]] += 1
            tiers[r["tier_text"]] += 1
            pages[physical[0]] += 1
        if dict(chambers) != spec["member_counts"] or dict(tiers) != spec["tier_counts"]:
            raise ValueError
        occurrences, kinds, item_pages, untitled = set(), Counter(), Counter(), 0
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, physical, ordinal = e["record"], e["evidence"]["physical_pages"], e["source_ordinal_on_page"]
            if (
                len(physical) != 1
                or physical[0] not in spec["item_page_counts"]
                or type(ordinal) is not int
                or ordinal < 0
                or (physical[0], ordinal) in occurrences
                or r["item_kind_text"] not in spec["item_counts"]
                or r["chamber_text"] not in spec["member_counts"]
                or r["publisher_position_text"] not in spec["positions"]
                or not r["publisher_position_detail_text"].startswith("FFCC Position: " + r["publisher_position_text"])
                or any(not isinstance(c, str) or not c for f in ["bill_citations", "amendment_citations"] for c in r[f])
                or (
                    r["item_kind_text"] == "Key Vote"
                    and (
                        not r["title_text"]
                        or r["session_text"] not in {"1", "2"}
                        or not isinstance(r["roll_number_text"], str)
                        or not r["roll_number_text"].isdigit()
                        or r["lead_sponsors_text"] is not None
                    )
                )
                or (
                    r["item_kind_text"] == "Key Bill"
                    and (
                        r["session_text"] != spec["session"]
                        or r["roll_number_text"] is not None
                        or not r["lead_sponsors_text"]
                        or (r["title_text"] is None and (r["bill_citations"] or not r["source_shape_notes"]))
                        or (r["title_text"] is not None and not r["bill_citations"])
                    )
                )
            ):
                raise ValueError
            occurrences.add((physical[0], ordinal))
            kinds[r["item_kind_text"]] += 1
            item_pages[physical[0]] += 1
            untitled += r["title_text"] is None
        if (
            dict(kinds) != spec["item_counts"]
            or dict(item_pages) != spec["item_page_counts"]
            or untitled != spec["untitled_items"]
        ):
            raise ValueError
        if any({n for p, n in occurrences if p == page} != set(range(count)) for page, count in item_pages.items()):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "First Focus facts no longer establish the complete reviewed tier cohort and scoring entries"
        ) from error


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != EDITIONS[edition.edition_id]:
        raise ScorecardSourceError("First Focus requires the exact reviewed named federal edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("First Focus requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    document = context.read(spec["url"], stage=f"first-focus:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"first-focus:{edition.edition_id}:qualified-observations",
    )

    def path(group, index=None, suffix=""):
        e = data[group]["evidence"] if index is None else data[group][index]["evidence"]
        selected = f"/{group}" + ("" if index is None else f"/{index}")
        return f"pdf:pages={','.join(str(p) for p in e['physical_pages'])};observation={observation};{selected}/record{suffix}"

    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="First Focus Campaign for Children",
        parser_version=parser_version,
        rendition_rule="complete publisher-named Champions/Defenders cohort and every disclosed Key Vote/Key Bill; reviewed rendered-page facts reconciled with original encoded input and identical source reread",
        homepage="https://campaignforchildren.org/",
    )
    front = data["front"]["record"]
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        title=TITLE,
        edition_label_text=spec["label"],
        timespan_text=spec["period"],
        methodology_url=spec["url"],
        session_text=spec["session"],
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        path("front"),
        methodology_id="published-cohort",
        chamber_text="both",
        cohort_text=COHORT,
        methodology_url=spec["url"],
        disclosure_status="partial",
        methodology_text=json_column(
            {
                "published_methodology_text": front["source_methodology_text"],
                "published_rating_scope": "named Champions and Defenders only",
                "numeric_scores_disclosed": False,
                "all_member_ratings_disclosed": False,
                "member_item_grid_disclosed": False,
                "numeric_weights_disclosed": False,
            }
        ),
    )
    bundle.add(
        "scorecard_metrics",
        document,
        path("front"),
        metric_id="recognition",
        name=COHORT,
        value_unit_text="tier",
        chamber_text="both",
        cohort_text=COHORT,
        period_text=spec["period"],
        methodology_id="published-cohort",
        is_primary="true",
    )
    counters: Counter = Counter()
    for i, e in enumerate(data["items"]):
        r, location = e["record"], path("items", i)
        if r["item_kind_text"] == "Key Vote":
            base = key("vote", r["chamber_text"], r["session_text"], r["roll_number_text"])
        elif r["bill_citations"]:
            base = key("bill", r["bill_citations"][0])
        else:
            base = key(
                "unidentified-bill-entry", str(e["evidence"]["physical_pages"][0]), str(e["source_ordinal_on_page"])
            )
        counters[base] += 1
        identifier = key(base, str(counters[base]))
        references = [
            {
                "occurrence_id": f"{kind}:{j}",
                "citation_text": citation,
                "kind": kind,
                "source_path": location + f"/{field_name}/{j}",
                "congress_text": "119",
                output_field: citation,
            }
            for kind, field_name, output_field in [
                ("bill", "bill_citations", "bill_citation_text"),
                ("amendment", "amendment_citations", "amendment_citation_text"),
            ]
            for j, citation in enumerate(r[field_name])
        ]
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=identifier,
            chamber_text=r["chamber_text"],
            disclosure_status="partial",
            methodology_text=json_column(r),
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            item_kind_text=r["item_kind_text"],
            title=r["title_text"],
            congress_text="119",
            chamber_text=r["chamber_text"],
            session_text=r["session_text"],
            roll_number_text=r["roll_number_text"],
            bill_citation_text=next(iter(r["bill_citations"]), None),
            amendment_citation_text=next(iter(r["amendment_citations"]), None),
            references_json=json_column(references),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=location + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id="recognition",
            item_id=identifier,
            participation_id="published-scoring-entry",
            methodology_id=identifier,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
        )
    for i, e in enumerate(data["members"]):
        r, location = e["record"], path("members", i)
        member_key = key(
            r["chamber_text"],
            r["state_text"],
            *([r["district_text"]] if r["district_text"] else []),
            r["member_name_text"],
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=r["chamber_text"],
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text=spec["period"],
            identifiers_json="[]",
            notes_text=json_column({"publisher_label_text": r["publisher_label_text"]}),
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/tier_text",
            publisher_member_key=member_key,
            metric_id="recognition",
            value_text=r["tier_text"],
            value_number=None,
        )
    repeated = context.read(spec["url"], stage=f"first-focus:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete published tier cohort and all disclosed scoring entries reconcile original page populations, literal member labels, positions, legislative references and methodology; identical original PDF reread",
        declared={
            "physical_pages": spec["page_count"],
            "members_by_chamber": spec["member_counts"],
            "tiers": spec["tier_counts"],
            "scoring_entries_by_kind": spec["item_counts"],
            "scoring_entries_by_physical_page": spec["item_page_counts"],
            "rating_scope": "publisher-named Champions and Defenders only",
            "all_member_numeric_ratings": False,
            "member_item_results_available": False,
            "source_counts_basis": "complete original named lists and every printed FFCC Position entry",
        },
    )
