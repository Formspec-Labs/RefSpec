"""Original Chamber scorecard availability probe; absence never means an empty edition."""

from spicy_docs.sources.scorecards.common import ScorecardContext, ScorecardEdition, ScorecardSourceError, soup

parser_version = "us-chamber-original-rendition-availability/1"
INDEX = "https://www.uschamber.com/how-they-voted"
NOTICE = "https://www.uschamber.com/how-they-voted-the-us-chambers-annual-scorecard"
HOSTS = ("www.uschamber.com",)
EDITION = ScorecardEdition("us_chamber", "116", NOTICE, "How They Voted", congress="116", chamber="both")


class USChamberUnavailable(ScorecardSourceError):
    """The publisher explicitly reports one original scorecard rendition unavailable."""


def _availability(context):
    document = context.read(NOTICE, stage="scorecards:us-chamber:original-availability", hosts=HOSTS)
    main = soup(document).select("main")
    if len(main) != 1:
        raise ScorecardSourceError("U.S. Chamber original scorecard availability page changed")
    headings = [heading.get_text(" ", strip=True) for heading in main[0].select("h1")]
    paragraphs = [paragraph.get_text(" ", strip=True).replace("\xa0", " ") for paragraph in main[0].select("p")]
    if headings != ["How They Voted - The U.S. Chamber's Annual Scorecard"]:
        raise ScorecardSourceError("U.S. Chamber original scorecard title changed; require source requalification")
    unavailable = [
        text
        for text in paragraphs
        if text.startswith("The scorecard for the 116th Congress") and text.endswith("is temporarily unavailable.")
    ]
    if (
        len(unavailable) != 1
        or "We are currently working on bringing the complete scorecard back online." not in paragraphs
    ):
        raise ScorecardSourceError(
            "U.S. Chamber availability notice changed; qualify restored or alternate original scorecard data"
        )
    raise USChamberUnavailable(
        "Publisher reports the 116th Congress scorecard temporarily unavailable; preserve prior source rows. Alternate original historical routes require separate qualification."
    )


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    """Refuse the unavailable rendition, rather than returning zero scorecards."""
    return _availability(context)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError(
            "U.S. Chamber has no qualified current or historical rating rendition for this selection"
        )
    return _availability(context)
