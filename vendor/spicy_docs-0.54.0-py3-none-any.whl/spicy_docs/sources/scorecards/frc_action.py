"""FRC Action's publisher-linked public Quorum grids and literal vote narratives."""

import re
from urllib.parse import urljoin

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import quorum_public
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "frc-action-public-quorum/1"
INDEX = "https://www.frcaction.org/scorecard"
HOSTS = ("www.frcaction.org",)
EDITION = ScorecardEdition(
    "frc_action", "119-2-2026", INDEX, "FRC Action Vote Scorecard", year="2026", congress="119", chamber="both"
)
ROUTES = {
    chamber: "https://www.frcaction.org/get.cfm?c=FRCA_SCORECARD&scorecard=scorecard_" + chamber.lower()
    for chamber in ("House", "Senate")
}
NUMERIC_TYPES = {"percentage_of_columns", "votes_with_organization", "votes_against_organization", "sum_of_columns"}
PRIMARY = {"House": 2001580, "Senate": 2144167}
# These exact source title pairs were reviewed with their original descriptions
# and linked roll calls. They are not a general fuzzy title-matching rule.
ALIASES = {
    "House": {
        "1. Breaking the Gridlock Act": "1. Breaking the Gridlock Act",
        "2. Supporting Pregnant and Parenting Women and Families Act": "2. Supporting Pregnant and Parenting Women and Families Act",
        "3. Pregnant Students’ Rights Act": "3. Pregnant Students' Rights Act",
        "4. PROTECT Kids Act": "4. Stopping Indoctrination and Protecting Kids Act",
    },
    "Senate": {
        "1. Cloture on the Pregnant Students' Rights Act": "1. Cloture on the Pregnant Students' Rights Act",
        "2. Motion to Proceed on the Joint Resolution to Reinstate the Biden Administration’s Unlawful VA Abortion Rule": "2. Motion to Proceed on the Joint Resolution to Reinstate the Biden Administration's VA Abortion Rule",
        "3. Cloture on an Amendment to Protect Women and Girls in Athletics": "3. Cloture on an Amendment to Protect Women and Girls in Athletics",
        "4. Motion on an Amendment to Extend the Prohibition on Medicaid Funding for Abortion Providers": "4. Motion on an Amendment to Extend the Prohibition on Medicaid Funding for Abortion Providers",
    },
}
CITATION = re.compile(r"\b(?:H\.\s*R\.|S\.\s*(?:J\.\s*Res\.|Con\.\s*Res\.|Amdt\.)?)\s*\d+\b")


def _wrapper(document, chamber):
    slug = quorum_public.external_slug(document)
    html = soup(document)
    headers = html.select(".scorecard .header-text")
    captions = html.select(".scorecard-section > .hidden-xs > h4")
    if len(headers) != 1 or len(captions) != 1:
        raise ScorecardSourceError("FRC source edition header or narrative caption is missing")
    header = headers[0].get_text(" ", strip=True)
    caption = captions[0].get_text(" ", strip=True)
    if (
        not header.startswith(
            "Welcome to the FRC Action Vote Scorecard for 2026, the Second Session of the 119th Congress!"
        )
        or caption != chamber + " - 119th 1st Session Vote Descriptions"
    ):
        raise ScorecardSourceError("FRC current edition or reviewed conflicting caption changed")
    descriptions = []
    identities = set()
    for node in html.select(".modal[id^=modal_]"):
        titles = node.select("h4.modal-title")
        bodies = node.select(".modal-body")
        links = node.select(".modal-footer a[href]")
        if len(titles) != 1 or len(bodies) != 1 or len(links) != 1 or node["id"] in identities:
            raise ScorecardSourceError("FRC source vote narrative identity or official link changed")
        identities.add(node["id"])
        title = titles[0].get_text(" ", strip=True)
        text = bodies[0].get_text(" ", strip=True)
        dates = re.findall(r"(?:Passed|Failed) on (\d+/\d+/\d{4})", text)
        rolls = re.findall(r"Roll Call No\. (\d+)", text)
        targets = re.findall(r"FRC Action (?:supported|opposed) this [A-Za-z]+\.", text)
        if len(dates) != 1 or len(rolls) != 1 or len(targets) != 1:
            raise ScorecardSourceError("FRC vote narrative date, roll or explicit preferred position changed")
        url = links[0]["href"]
        senate = re.fullmatch(
            r"https://www\.senate\.gov/legislative/LIS/roll_call_votes/vote(\d+)(\d)/vote_\1_\2_0*(\d+)\.htm", url
        )
        house = re.fullmatch(r"https://clerk\.house\.gov/Votes/(\d{4})0*(\d+)", url)
        if (chamber == "House" and (house is None or house[2] != rolls[0])) or (
            chamber == "Senate" and (senate is None or senate[3] != rolls[0])
        ):
            raise ScorecardSourceError("FRC source narrative and linked roll-call identifiers disagree")
        references = []
        for ordinal, match in enumerate(CITATION.finditer(text), 1):
            literal = match[0]
            amendment = "Amdt." in literal
            references.append(
                {
                    "occurrence_id": str(ordinal),
                    "citation_text": literal,
                    "kind": "amendment" if amendment else "bill",
                    "source_path": f"#{node['id']}/.modal-body/text[{match.start()}:{match.end()}]",
                    "amendment_citation_text" if amendment else "bill_citation_text": literal,
                }
            )
        references.append(
            {
                "occurrence_id": "official-roll-link",
                "citation_text": url,
                "kind": "roll_call",
                "source_path": f"#{node['id']}/.modal-footer/a/@href",
                "roll_number_text": rolls[0],
                "chamber_text": chamber,
                **({"congress_text": senate[1], "session_text": senate[2]} if senate else {}),
            }
        )
        descriptions.append(
            {
                "id": node["id"],
                "title": title,
                "text": text,
                "url": url,
                "date": dates[0],
                "roll": rolls[0],
                "position": targets[0],
                "references": references,
                "congress": senate[1] if senate else None,
                "session": senate[2] if senate else None,
            }
        )
    if not descriptions or {row["title"] for row in descriptions} != set(ALIASES[chamber].values()):
        raise ScorecardSourceError("FRC narrative titles differ from the explicitly reviewed item mapping")
    return (
        slug,
        header,
        caption,
        descriptions,
        [node.get_text(" ", strip=True) for node in html.select(".legend-label")],
    )


def list_scorecards(context: ScorecardContext):
    document = context.read(INDEX, stage="frc-action:index", hosts=HOSTS)
    _wrapper(document, "Senate")
    editions = [EDITION]
    identities = set()
    links = soup(document).select(".scorecard .dropdown-menu a[href]")
    if not links:
        raise ScorecardSourceError("FRC advertised PDF archive list is missing")
    for link in links:
        label = link.get_text(" ", strip=True)
        match = re.fullmatch(r"(\d+)TH Congress(?: (First|Second) Session)?", label)
        url = urljoin(INDEX, link["href"])
        if match is None or not url.startswith("https://www.frcaction.org/index.cfm?i=") or "&f=PG21B08" not in url:
            raise ScorecardSourceError("FRC archive edition label or original route changed")
        identifier = match[1] + ("-1" if match[2] == "First" else "-2" if match[2] == "Second" else "")
        if identifier in identities:
            raise ScorecardSourceError("FRC archive repeats an edition identity")
        identities.add(identifier)
        editions.append(
            ScorecardEdition("frc_action", identifier, url, label, congress=match[1], chamber="both", is_current=False)
        )
    return tuple(editions)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError(
            "FRC historical PDF requires retained, qualified DocSpec/Gemini member/item/score outcomes before admission"
        )
    selected = {}
    for chamber, url in ROUTES.items():
        wrapper = context.read(url, stage="frc-action:" + chamber + ":wrapper", hosts=HOSTS)
        shape = _wrapper(wrapper, chamber)
        sheet = quorum_public.acquire(context, shape[0], "frc-action:" + chamber)
        if sheet.data["name"] != "119th Congress, Second Session, 2026 (" + chamber + ")":
            raise ScorecardSourceError("FRC public sheet period differs from the selected publisher edition")
        selected[chamber] = wrapper, shape, sheet
    bundle = Bundle(
        edition,
        context,
        selected["House"][0],
        publisher_name="FRC Action",
        parser_version=parser_version,
        rendition_rule="frc-action-quorum-csv-values-json-identities-html-narratives/1",
        homepage="https://www.frcaction.org/",
    )
    periods = []
    declared = {}
    for chamber, (wrapper, shape, sheet) in selected.items():
        slug, header, caption, descriptions, legend = shape
        jsondoc, csvdoc = sheet.json_document, sheet.csv_document
        bundle.use(wrapper, chamber + ":methods", chamber + ":narratives")
        bundle.use(jsondoc, chamber + ":members", chamber + ":items", chamber + ":configuration")
        bundle.use(csvdoc, chamber + ":ratings", chamber + ":results")
        bundle.add(
            "scorecard_methodologies",
            jsondoc,
            "$",
            methodology_id=key(chamber, "publisher-sheet-scope"),
            chamber_text=chamber,
            methodology_text=json_column(
                {field: value for field, value in sheet.data.items() if field not in {"columns", "row_data"}}
            ),
            disclosure_status="explicit",
        )
        periods.extend(
            [
                {
                    "occurrence_id": chamber + ":sheet",
                    "period_text": sheet.data["name"],
                    "kind": "explicit",
                    "source_path": jsondoc.url + "#$.name",
                    "congress_text": "119",
                    "session_text": "Second",
                    "year_text": "2026",
                    "chamber_text": chamber,
                },
                {
                    "occurrence_id": chamber + ":caption",
                    "period_text": caption,
                    "kind": "explicit",
                    "source_path": wrapper.url + "#.scorecard-section/h4",
                    "congress_text": "119",
                    "session_text": "1st",
                    "chamber_text": chamber,
                },
            ]
        )
        bundle.add(
            "scorecard_methodologies",
            wrapper,
            ".scorecard",
            methodology_id=key(chamber, "publisher-wrapper"),
            chamber_text=chamber,
            methodology_text=json_column(
                {"header": header, "caption": caption, "legend": legend, "descriptions": descriptions}
            ),
            disclosure_status="partial",
        )
        visible = {
            column["id"]: position
            for position, column in enumerate((c for c in sheet.columns if not c["should_hide_column_on_public"]), 1)
        }
        for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True)):
            identity = quorum_public.member_context(member, sheet, row)
            bundle.add(
                "scorecard_members",
                jsondoc,
                f"$.row_data[{ordinal}]",
                publisher_member_key=key(chamber, str(member["id"])),
                publisher_member_id=str(member["id"]),
                identifiers_json=json_column([{"scheme": "quorum", "value": str(member["id"])}]),
                member_name=identity["name"],
                chamber_text=chamber,
                state=identity["state"],
                district=identity["district"],
                party=identity["party"],
                period_text=sheet.data["name"],
                notes_text=json_column(
                    {"display_name": identity["display_name"], "csv_fields": identity["csv_values"]}
                ),
            )
        metrics = quorum_public.append_measurements(
            bundle,
            sheet,
            chamber,
            NUMERIC_TYPES,
            {PRIMARY[chamber]},
            {c["id"]: "%" for c in sheet.columns if c["column_type"] == "percentage_of_columns"},
        )
        items = [column for column in sheet.columns if column["column_type"] == "stance_record"]
        if not items or any(
            c["column_type"] not in NUMERIC_TYPES | {"stance_record", "field", "district_number"} for c in sheet.columns
        ):
            raise ScorecardSourceError("FRC sheet has an unreviewed column kind")
        narrative_by_title = {row["title"]: row for row in descriptions}
        matched = set()
        positions = {c["id"]: i for i, c in enumerate(sheet.data["columns"])}
        for column in items:
            if column["id"] not in visible or not column.get("vote_id"):
                raise ScorecardSourceError("FRC scoring item lacks a visible publisher vote grid")
            mapped = ALIASES[chamber].get(column["name"])
            narrative = narrative_by_title.get(mapped)
            if mapped:
                matched.add(mapped)
            path = f"$.columns[{positions[column['id']]}]"
            item_id = key(chamber, str(column["id"]))
            bundle.add(
                "scorecard_methodologies",
                jsondoc,
                path,
                methodology_id=key(chamber, "item-column", str(column["id"])),
                chamber_text=chamber,
                methodology_text=json_column(
                    quorum_public.column_metadata(column, {str(m["id"]) for m in sheet.data["row_data"]})
                ),
                disclosure_status="explicit",
            )
            refs = (
                [
                    {**reference, "source_path": wrapper.url + reference["source_path"]}
                    for reference in narrative["references"]
                ]
                if narrative
                else []
            )
            bills = {r["bill_citation_text"] for r in refs if "bill_citation_text" in r}
            amendments = {r["amendment_citation_text"] for r in refs if "amendment_citation_text" in r}
            target = narrative["position"] if narrative else None
            bundle.add(
                "scorecard_items",
                jsondoc,
                path,
                item_id=item_id,
                publisher_item_id=str(column["id"]),
                item_kind_text=column["column_type"],
                title=column["name"],
                chamber_text=chamber,
                item_date_text=narrative["date"] if narrative else None,
                congress_text=narrative["congress"] if narrative else None,
                session_text=narrative["session"] if narrative else None,
                roll_number_text=narrative["roll"] if narrative else None,
                bill_citation_text=next(iter(bills)) if len(bills) == 1 else None,
                amendment_citation_text=next(iter(amendments)) if len(amendments) == 1 else None,
                references_json=json_column(refs),
                publisher_position_text=target,
                position_basis="explicit" if target else "absent",
                position_source_path=wrapper.url + "#" + narrative["id"] + "/.modal-body" if narrative else None,
            )
            participation_id = "visible-publisher-grid"
            bundle.add(
                "scorecard_metric_items",
                jsondoc,
                path,
                metric_id=metrics[PRIMARY[chamber]],
                item_id=item_id,
                participation_id=participation_id,
                methodology_id=key(chamber, "item-column", str(column["id"])),
                publisher_position_text=target,
                position_basis="explicit" if target else "absent",
            )
            for ordinal, (member, row) in enumerate(zip(sheet.data["row_data"], sheet.csv_rows, strict=True), 2):
                value = row[visible[column["id"]]]
                bundle.add(
                    "scorecard_member_item_results",
                    csvdoc,
                    f"CSV/row={ordinal}/column={visible[column['id']] + 1}",
                    result_id=participation_id,
                    metric_id=metrics[PRIMARY[chamber]],
                    item_id=item_id,
                    participation_id=participation_id,
                    publisher_member_key=key(chamber, str(member["id"])),
                    result_text=value,
                    action_text=value or None,
                )
        if matched != set(narrative_by_title):
            raise ScorecardSourceError("FRC narrative cannot be matched through its reviewed exact source title pair")
        reread_wrapper = context.read(ROUTES[chamber], stage="frc-action:" + chamber + ":wrapper:reread", hosts=HOSTS)
        reread = quorum_public.acquire(context, slug, "frc-action:" + chamber + ":reread")
        if _wrapper(reread_wrapper, chamber) != shape or quorum_public.semantic_facts(
            reread
        ) != quorum_public.semantic_facts(sheet):
            raise ScorecardSourceError("FRC publisher source changed during complete acquisition")
        bundle.use(reread_wrapper, chamber + ":methods", chamber + ":narratives", role="corroboration")
        bundle.use(
            reread.json_document,
            chamber + ":members",
            chamber + ":items",
            chamber + ":configuration",
            role="corroboration",
        )
        bundle.use(reread.csv_document, chamber + ":ratings", chamber + ":results", role="corroboration")
        declared[chamber] = {
            "json_row_count": sheet.data["row_count"],
            "json_column_count": len(sheet.columns),
            "visible_scoring_column_count": len(items),
            "narrative_count": len(descriptions),
        }
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        session_text="Second",
        edition_label_text="119th Congress, Second Session, 2026",
        periods_json=json_column(periods),
    )
    return bundle.finish(
        "Each public JSON row_count equals its unique member population and complete CSV EOF in exact member/visible-column order; every visible item cell and reported numeric score copied literally; both chamber wrappers and complete JSON/CSV source facts agree on reread. HTML narratives map through reviewed exact title pairs; undisclosed item descriptions remain null; conflicting source period caption retained.",
        declared=declared,
    )
