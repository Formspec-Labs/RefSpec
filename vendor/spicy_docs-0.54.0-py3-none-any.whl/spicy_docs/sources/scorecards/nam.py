"""NAM's complete named Voting Record PDFs, from reviewed original source facts."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "nam-named-original-pdf/2"
HOSTS = ("web.archive.org",)
HOMEPAGE = "https://nam.org/"
INDEX = "https://nam.org/votingrecord"
SPECS: dict[str, dict[str, Any]] = {
    "113-2014": {
        "url": "https://web.archive.org/web/20141217094550id_/http://www.nam.org:80/Advocacy/Key-Manufacturing-Votes/113th-Congress/NAM-Voting-Record-for-the-113th-Congress/",
        "original_url": "http://www.nam.org:80/Advocacy/Key-Manufacturing-Votes/113th-Congress/NAM-Voting-Record-for-the-113th-Congress/",
        "source_sha256": "49cb264509c5fab07660a0702735c1a2a320492e145c1f5d4c8c22853fe3148a",
        "qualified_sha256": "9f60ad0c0ac3bba947ee9e13dae69d0dd1834c5a4c62af37569f8e5cb8154839",
        "title": "THE NAM VOTING RECORD",
        "label": "113TH CONGRESS",
        "period": "113th Congress (2013–2014)",
        "publication": "October 2014",
        "archive_timestamp": "20141217094550",
        "congress": "113",
        "year": "2014",
        "page_count": 30,
        "member_counts": {"House": 435, "Senate": 100},
        "item_counts": {"House": 29, "Senate": 9},
        "page_counts": {
            8: 31,
            9: 34,
            10: 32,
            11: 33,
            12: 33,
            13: 31,
            14: 30,
            15: 30,
            16: 30,
            17: 30,
            18: 30,
            19: 33,
            20: 30,
            21: 28,
            24: 24,
            25: 24,
            26: 22,
            27: 22,
            28: 8,
        },
    },
}
GLYPHS = {"+", "-", "?", "x", "P", "S", "**"}


def _spec(identifier):
    if identifier not in SPECS:
        raise ScorecardSourceError("NAM requires a reviewed named original Voting Record edition")
    return SPECS[identifier]


def _edition(identifier):
    spec = _spec(identifier)
    return ScorecardEdition(
        "nam",
        identifier,
        spec["url"],
        spec["title"],
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    if (
        document.url != spec["url"]
        or "pdf" not in (document.response.content_type or "").lower()
        or not document.body.startswith(b"%PDF-")
        or sha256(document.body).hexdigest() != spec["source_sha256"]
    ):
        raise ScorecardSourceError("NAM source differs from the reviewed archived original PDF")


@dataclass(frozen=True, slots=True)
class NAMPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError("NAM observations must identify a reviewed named edition") from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("NAM original PDF redistribution rights are not established")
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        _source(context.read(spec["url"], stage=f"nam:{self.edition_key}:list", hosts=HOSTS), spec)
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError("NAM reader requires its configured reviewed named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value, spec):
    if (
        not isinstance(value, dict)
        or not value["physical_pages"]
        or any(type(n) is not int or not 1 <= n <= spec["page_count"] for n in value["physical_pages"])
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or value["schema_version"]
        not in {
            "nam-113-source-members/1",
            "nam-113-source-member-groups/1",
            "nam-113-source-member-correction/1",
            "nam-113-source-items/1",
            "nam-original-native-front/1",
        }
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("NAM observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "nam-qualified-original-pdf/1"
            or data["edition_key"] != identifier
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["page_count"]
            or data["member_counts"] != spec["member_counts"]
            or data["item_counts"] != spec["item_counts"]
            or data["member_page_counts"] != {str(p): n for p, n in spec["page_counts"].items()}
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["title_text"] != spec["title"]
            or front["edition_label_text"] != spec["label"]
            or front["period_text"] != spec["period"]
            or front["publication_text"] != spec["publication"]
            or not isinstance(front["methodology_text"], str)
            or not front["methodology_text"]
            or not isinstance(front["page_footnotes"], dict)
            or any(
                not page.isdigit()
                or int(page) not in spec["page_counts"]
                or not isinstance(text, str)
                or not text.startswith("*")
                for page, text in front["page_footnotes"].items()
            )
        ):
            raise ValueError
        for chamber, count in spec["item_counts"].items():
            if (
                not isinstance(front["publisher_positions"][chamber], list)
                or len(front["publisher_positions"][chamber]) != count
                or any(v not in {"Y", "N"} for v in front["publisher_positions"][chamber])
            ):
                raise ValueError
            legend = front["legends"][chamber]
            if (
                not isinstance(legend, dict)
                or set(legend)
                != (
                    {"Y", "N", "+", "-", "?", "S", "x", "P", "•"}
                    if chamber == "House"
                    else {"Y", "N", "+", "-", "?", "x", "P", "•"}
                )
                or any(not isinstance(text, str) or not text for text in legend.values())
            ):
                raise ValueError
        items = set()
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            n = r["item_number_text"]
            if (
                chamber not in spec["item_counts"]
                or not isinstance(n, str)
                or not n.isdigit()
                or n != str(int(n))
                or not 1 <= int(n) <= spec["item_counts"][chamber]
                or (chamber, n) in items
                or not r["title_text"]
                or not r["description_text"]
                or r["publisher_position_text"] not in {"Yes.", "No."}
                or not isinstance(r["roll_number_text"], str)
                or not r["roll_number_text"].isdigit()
                or not isinstance(r["date_text"], str)
                or not r["date_text"]
                or not isinstance(r["source_paragraph_text"], str)
                or not r["source_paragraph_text"]
                or any(
                    not isinstance(r[f], list) or any(not isinstance(c, str) or not c for c in r[f])
                    for f in ("bill_citations", "amendment_citations", "public_law_citations")
                )
                or any(c.startswith("P.L.") for c in r["bill_citations"])
                or any(not re.fullmatch(r"P\.L\. \d+-\d+", c) for c in r["public_law_citations"])
            ):
                raise ValueError
            expected = "Y" if r["publisher_position_text"] == "Yes." else "N"
            if front["publisher_positions"][chamber][int(n) - 1] != expected:
                raise ValueError
            items.add((chamber, n))
        if dict(Counter(c for c, _ in items)) != spec["item_counts"]:
            raise ValueError
        identities, counts, pages = set(), Counter(), Counter()
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            page = e["evidence"]["physical_pages"]
            results = r["item_results"]
            vacant = r["member_name_text"] == "Vacant"
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or not isinstance(r["state_text"], str)
                or not r["state_text"]
                or r["party_text"] not in {"R", "D", "I", None}
                or r["award_marker_text"] not in {"•", None}
                or (r["name_annotation_text"] is not None and not re.fullmatch(r"\*+", r["name_annotation_text"]))
                or (chamber == "Senate" and r["district_text"] is not None)
                or (chamber == "House" and not re.fullmatch(r"\d+|AL", r["district_text"]))
                or len(page) != 1
                or page[0] not in spec["page_counts"]
                or not isinstance(results, dict)
                or set(results) != {n for c, n in items if c == chamber}
                or (
                    vacant
                    and (
                        r["value_text"] is not None
                        or r["party_text"] is not None
                        or r["award_marker_text"] is not None
                        or any(v is not None for v in results.values())
                    )
                )
                or (
                    not vacant
                    and (
                        not isinstance(r["value_text"], str)
                        or not re.fullmatch(r"\d+%", r["value_text"])
                        or any(v not in GLYPHS for v in results.values())
                    )
                )
                or (chamber == "Senate" and any(v == "S" for v in results.values()))
                or (
                    any(v == "**" for v in results.values())
                    and "**" not in front["page_footnotes"].get(str(page[0]), "")
                )
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[page[0]] += 1
        if dict(counts) != spec["member_counts"] or dict(pages) != spec["page_counts"]:
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError("NAM source facts do not establish a complete reviewed named edition") from error


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != _edition(edition.edition_id):
        raise ScorecardSourceError("NAM requires the exact reviewed named edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("NAM requires pinned reviewed facts and private observation retention")
    if context.evidence_policy == "full":
        raise ScorecardSourceError("NAM original PDF redistribution rights are not established")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    document = context.read(spec["url"], stage=f"nam:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"nam:{edition.edition_id}:qualified-observations",
    )

    def path(group, index=None, suffix=""):
        e = data[group]["evidence"] if index is None else data[group][index]["evidence"]
        selected = f"/{group}" + ("" if index is None else f"/{index}")
        return f"pdf:pages={','.join(str(p) for p in e['physical_pages'])};observation={observation};{selected}/record{suffix}"

    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="National Association of Manufacturers",
        parser_version=parser_version,
        rendition_rule="complete archived original federal Voting Record; every native source row and literal action reconciles reviewed data-shaped rendered page outcomes",
        homepage=HOMEPAGE,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        title=front["title_text"],
        edition_label_text=front["edition_label_text"],
        timespan_text=front["period_text"],
        methodology_url=document.url,
        published_at_text=front["publication_text"],
    )
    bundle.add(
        "scorecard_methodologies",
        document,
        path("front"),
        methodology_id="publisher-methodology",
        disclosure_status="explicit",
        methodology_text=front["methodology_text"],
    )
    for chamber in spec["member_counts"]:
        method = key(chamber, "source-legend")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front"),
            methodology_id=method,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(
                {"legend": front["legends"][chamber], "page_footnotes": front["page_footnotes"]}
            ),
        )
        for label, unit, primary in [("%", "%", True), ("Award", None, False)]:
            bundle.metric(
                document, key(chamber, label), label, path=path("front"), chamber=chamber, unit=unit, primary=primary
            )
    for i, e in enumerate(data["items"]):
        r, chamber = e["record"], e["chamber"]
        n, location = r["item_number_text"], path("items", i)
        identifier, methodology = key(chamber, n), key(chamber, n, "description")
        references = [
            {
                "occurrence_id": key(kind, str(j)),
                "kind": kind,
                "citation_text": citation,
                "source_path": location + "/" + field_name + "/" + str(j),
            }
            for kind, field_name in [
                ("bill", "bill_citations"),
                ("amendment", "amendment_citations"),
                ("public_law", "public_law_citations"),
            ]
            for j, citation in enumerate(r[field_name])
        ]
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=methodology,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=r["source_paragraph_text"],
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            publisher_item_id=n,
            item_kind_text="Key Manufacturing Vote",
            title=r["title_text"],
            item_date_text=r["date_text"],
            congress_text=spec["congress"],
            chamber_text=chamber,
            roll_number_text=r["roll_number_text"],
            bill_citation_text=next(iter(r["bill_citations"]), None),
            amendment_citation_text=next(iter(r["amendment_citations"]), None),
            references_json=json_column(references),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=location + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id=key(chamber, "%"),
            item_id=identifier,
            participation_id="printed-key-vote",
            methodology_id=methodology,
            counts_toward_metric="true",
            publisher_position_text=front["publisher_positions"][chamber][int(n) - 1],
            position_basis="explicit",
        )
    for i, e in enumerate(data["members"]):
        r, chamber = e["record"], e["chamber"]
        location = path("members", i)
        member_key = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            party=r["party_text"],
            state=r["state_text"],
            district=r["district_text"],
            chamber_text=chamber,
            period_text=front["period_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "name_annotation_text": r["name_annotation_text"],
                    "award_marker_text": r["award_marker_text"],
                    "page_footnotes": front["page_footnotes"].get(str(e["evidence"]["physical_pages"][0])),
                }
            ),
        )
        for label, value in [("%", r["value_text"]), ("Award", r["award_marker_text"])]:
            bundle.add(
                "scorecard_member_ratings",
                document,
                location + ("/value_text" if label == "%" else "/award_marker_text"),
                publisher_member_key=member_key,
                metric_id=key(chamber, label),
                value_text=value,
                value_number=decimal_text(value) if label == "%" else None,
            )
        legend = front["legends"][chamber]
        for n, glyph in r["item_results"].items():
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + "/item_results/" + n,
                result_id="printed-cell",
                publisher_member_key=member_key,
                item_id=key(chamber, n),
                metric_id=key(chamber, "%"),
                participation_id="printed-key-vote",
                result_text=glyph,
                reason_text=front["page_footnotes"].get(str(e["evidence"]["physical_pages"][0]))
                if glyph == "**"
                else legend[glyph]
                if glyph is not None
                else None,
            )
    repeated = context.read(spec["url"], stage=f"nam:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete named original PDF; every printed seat row, percentage, award symbol, numbered item, publisher position and available literal member action reconciles independently retained original input; identical original reread",
        declared={
            "physical_pages": spec["page_count"],
            "source_seat_rows_by_chamber": spec["member_counts"],
            "items_by_chamber": spec["item_counts"],
            "source_rows_by_physical_page": spec["page_counts"],
            "source_counts_basis": "complete original printed grids, including source-labelled vacant seats with blank fields",
        },
    )
