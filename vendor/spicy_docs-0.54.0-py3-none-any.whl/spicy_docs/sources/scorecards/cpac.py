"""CPAC's publisher-linked legacy GraphQL congressional scorecards.

The legacy service advertises historical annual editions. Its latest observed
federal year is older than the current CPAC.org PDF: an API year is never labelled
current. Anonymous request headers and the HTTP route come from the publisher's
application, not an administrative API. See docs/sources/scorecards-cpac.md.
"""

from __future__ import annotations

import json
import re
from typing import Any

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
)

parser_version = "cpac-legacy-federal-graphql/1"
API = "http://production.data.conservative.org/v1/graphql"
INDEX = "http://ratings.conservative.org"
HOSTS = ("production.data.conservative.org",)
REQUEST_HEADERS = {
    "Content-Type": "application/json",
    "X-Hasura-Role": "anonymous",
    "X-Hasura-User-Id": "-1",
}
MAX_ROWS = 200_000
ANNUAL_FIELDS = ("rating", "votes", "acuVotes", "total")
LIFETIME_FIELDS = ("rating", "totalVotes", "acuVotes")
YEARS_QUERY = (
    '{years:ratings_acuRatings(distinct_on:year,order_by:{year:desc_nulls_last},where:{state:{_eq:"US"}}){year}}'
)
MEMBER_FIELDS = """id name party role district state from opensecretsId votesmartId
history(where:{year:{_eq:YEAR}}){year chamber district party state from}
acuRatings(where:{year:{_eq:YEAR},state:{_eq:"US"}}){year rating state body total votes acuVotes}
acuLifetimeRatings(where:{year:{_eq:YEAR},state:{_eq:"US"}}){year rating state body totalVotes acuVotes}"""
ITEM_FIELDS = """id title description acuSummary summary year state body type acuVote weight
sessionId rollCallNumber billNumber amendment amendmentNumber statusDate url"""
VOTE_FIELDS = "articleId peopleId date points rating value vote withAcu year"


def edition_for_year(year: int) -> ScorecardEdition:
    if isinstance(year, bool) or not isinstance(year, int) or not 1900 <= year <= 2100:
        raise ScorecardSourceError("CPAC annual edition year is invalid")
    return ScorecardEdition(
        "cpac",
        str(year),
        INDEX,
        f"CPAC Congressional Ratings — {year}",
        year=str(year),
        chamber="both",
        is_current=False,
    )


def _read(context: ScorecardContext, query: str, stage: str):
    content = json.dumps({"query": query}, separators=(",", ":")).encode()
    document = context.read_request(
        API, method="POST", content=content, stage="scorecards:cpac:" + stage, hosts=HOSTS, allow_http=True
    )
    if (document.response.content_type or "").split(";", 1)[0].strip() != "application/json":
        raise ScorecardSourceError("CPAC GraphQL response is not JSON")
    data = json_data(document)
    if not isinstance(data, dict) or "errors" in data or not isinstance(data.get("data"), dict):
        raise ScorecardSourceError("CPAC GraphQL query did not return a complete data object")
    return document, data["data"]


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _, data = _read(context, YEARS_QUERY, "years")
    rows = data.get("years")
    if not isinstance(rows, list) or not rows or any(not isinstance(row, dict) or set(row) != {"year"} for row in rows):
        raise ScorecardSourceError("CPAC federal annual edition catalog is empty or malformed")
    editions = tuple(edition_for_year(row["year"]) for row in rows)
    if len({edition.edition_id for edition in editions}) != len(editions):
        raise ScorecardSourceError("CPAC federal edition catalog repeats a year")
    return editions


def counts_query(year: int) -> str:
    annual = f'{{state:{{_eq:"US"}},year:{{_eq:{year}}}}}'
    items = f'{{state:{{_eq:"US"}},year:{{_eq:{year}}},acuVote:{{_is_null:false}}}}'
    votes = f"{{year:{{_eq:{year}}},person:{{_or:[{{acuRatings:{annual}}},{{acuLifetimeRatings:{annual}}}]}}}}"
    return (
        "{"
        + f"annual:ratings_acuRatings_aggregate(where:{annual}){{aggregate{{count}}}}"
        + f"lifetime:ratings_acuLifetimeRatings_aggregate(where:{annual}){{aggregate{{count}}}}"
        + f"items:ratings_articles_aggregate(where:{items}){{aggregate{{count}}}}"
        + f"votes:ratings_votes_aggregate(where:{votes}){{aggregate{{count}}}}"
        + f"annual_members:ratings_acuRatings(limit:{MAX_ROWS + 1},distinct_on:peopleId,order_by:{{peopleId:asc}},where:{annual}){{peopleId}}"
        + f"lifetime_members:ratings_acuLifetimeRatings(limit:{MAX_ROWS + 1},distinct_on:peopleId,order_by:{{peopleId:asc}},where:{annual}){{peopleId}}"
        + "}"
    )


def _counts(data: dict[str, Any]) -> tuple[dict[str, int], set[str]]:
    if set(data) != {"annual", "lifetime", "items", "votes", "annual_members", "lifetime_members"}:
        raise ScorecardSourceError("CPAC edition count fields changed")
    result = {}
    for field in ("annual", "lifetime", "items", "votes"):
        entry = data[field]
        if not isinstance(entry, dict) or not isinstance(entry.get("aggregate"), dict):
            raise ScorecardSourceError("CPAC source count is malformed")
        result[field] = entry["aggregate"].get("count")
    identities = set()
    for group in ("annual", "lifetime"):
        members = data[group + "_members"]
        if (
            not isinstance(members, list)
            or any(
                not isinstance(member, dict)
                or set(member) != {"peopleId"}
                or not isinstance(member["peopleId"], str)
                or not member["peopleId"]
                for member in members
            )
            or len(members) != result[group]
            or len({member["peopleId"] for member in members}) != len(members)
        ):
            raise ScorecardSourceError("CPAC source rating count and member identity census do not reconcile")
        identities.update(member["peopleId"] for member in members)
    result["members"] = len(identities)
    if any(
        isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_ROWS for value in result.values()
    ):
        raise ScorecardSourceError("CPAC source count is invalid or exceeds the record bound")
    if not result["annual"] or not result["members"]:
        raise ScorecardSourceError("CPAC annual ratings and member census do not reconcile")
    return result, identities


def records_query(kind: str, year: int, count: int) -> str:
    limit = count + 1
    if kind == "members":
        field = MEMBER_FIELDS.replace("YEAR", str(year))
        scope = f'{{state:{{_eq:"US"}},year:{{_eq:{year}}}}}'
        return f"{{members:ratings_people(limit:{limit},order_by:{{id:asc}},where:{{_or:[{{acuRatings:{scope}}},{{acuLifetimeRatings:{scope}}}]}}){{{field}}}}}"
    if kind == "items":
        return f'{{items:ratings_articles(limit:{limit},order_by:{{id:asc}},where:{{state:{{_eq:"US"}},year:{{_eq:{year}}},acuVote:{{_is_null:false}}}}){{{ITEM_FIELDS}}}}}'
    if kind == "votes":
        scope = f'{{state:{{_eq:"US"}},year:{{_eq:{year}}}}}'
        return f"{{votes:ratings_votes(limit:{limit},order_by:[{{peopleId:asc}},{{articleId:asc}}],where:{{year:{{_eq:{year}}},person:{{_or:[{{acuRatings:{scope}}},{{acuLifetimeRatings:{scope}}}]}}}}){{{VOTE_FIELDS}}}}}"
    raise ScorecardSourceError("Unknown CPAC record query")


def _records(data: dict[str, Any], kind: str, declared: int) -> list[dict[str, Any]]:
    rows = data.get(kind)
    if (
        set(data) != {kind}
        or not isinstance(rows, list)
        or len(rows) != declared
        or any(not isinstance(row, dict) for row in rows)
    ):
        raise ScorecardSourceError(f"CPAC {kind} do not reconcile with the source count")
    return rows


def _text(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ScorecardSourceError("CPAC literal scalar changed type")
    return str(value)


def _require(row: dict[str, Any], fields: set[str], label: str) -> None:
    if not isinstance(row, dict) or not fields <= set(row):
        raise ScorecardSourceError(f"CPAC {label} fields changed")


def _period(row: dict[str, Any], year: int) -> None:
    if row.get("year") != year or row.get("state") != "US":
        raise ScorecardSourceError("CPAC response belongs to a different federal edition")


def _member(row: dict[str, Any], year: int):
    _require(
        row,
        {
            "id",
            "name",
            "history",
            "acuRatings",
            "acuLifetimeRatings",
            "state",
            "from",
            "role",
            "party",
            "district",
            "opensecretsId",
            "votesmartId",
        },
        "member",
    )
    if not isinstance(row["id"], str) or not row["id"] or not isinstance(row["name"], str) or not row["name"]:
        raise ScorecardSourceError("CPAC member identity or federal scope is malformed")
    histories, annual, lifetime = row["history"], row["acuRatings"], row["acuLifetimeRatings"]
    if (
        any(not isinstance(value, list) for value in (histories, annual, lifetime))
        or len(annual) > 1
        or len(lifetime) > 1
        or not (annual or lifetime)
    ):
        raise ScorecardSourceError("CPAC member requires a rating and at most one value per annual/lifetime metric")
    for history in histories:
        _require(history, {"year", "chamber", "district", "party", "state", "from"}, "historical member context")
        if history["year"] != year or history["state"] != "US":
            raise ScorecardSourceError("CPAC historical member context has a different edition")
    if len({json_column(history) for history in histories}) != len(histories):
        raise ScorecardSourceError("CPAC historical member contexts repeat an observation")
    for rating in annual:
        _require(rating, {"year", "state", "body", *ANNUAL_FIELDS}, "annual rating")
        _period(rating, year)
    for entry in lifetime:
        _require(entry, {"year", "state", "body", *LIFETIME_FIELDS}, "lifetime rating")
        _period(entry, year)
    return histories, annual, lifetime


def _historical_value(histories: list[dict[str, Any]], field: str, fallback=None):
    if not histories:
        return _text(fallback)
    values = {_text(history[field]) for history in histories}
    return next(iter(values)) if len(values) == 1 else None


def _item(row: dict[str, Any], year: int):
    _require(row, set(ITEM_FIELDS.split()), "item")
    _period(row, year)
    if not isinstance(row["id"], str) or not row["id"] or not isinstance(row["title"], str) or not row["title"]:
        raise ScorecardSourceError("CPAC item identity or title is empty")
    roll = _text(row["rollCallNumber"])
    extra = row["amendmentNumber"]
    match = re.fullmatch(r"Roll? Call ([0-9]+)", extra) if isinstance(extra, str) else None
    bill = row["billNumber"]
    bill_roll = re.fullmatch(r"RC ([0-9]+)", bill) if isinstance(bill, str) else None
    candidates = {
        value for value in (roll, match[1] if match else None, bill_roll[1] if bill_roll else None) if value is not None
    }
    if len(candidates) > 1:
        raise ScorecardSourceError("CPAC item roll-call identifiers disagree")
    roll = next(iter(candidates)) if candidates else None
    return roll, None if match else _text(extra), None if bill_roll else _text(bill)


def _references(item: dict[str, Any], path: str, roll: str | None, bill: str | None):
    result = []
    for field, kind in (("billNumber", "bill"), ("rollCallNumber", "roll_call"), ("amendmentNumber", "amendment")):
        value = _text(item[field])
        if not value:
            continue
        if (
            field == "billNumber"
            and bill is None
            or field == "amendmentNumber"
            and re.fullmatch(r"Roll? Call [0-9]+", value)
        ):
            kind = "roll_call"
        result.append(
            {
                "occurrence_id": field,
                "citation_text": value,
                "kind": kind,
                "source_path": path + "." + field,
                "chamber_text": _text(item["body"]),
                "roll_number_text": roll if kind == "roll_call" else None,
                "bill_citation_text": bill if kind == "bill" else None,
                "amendment_citation_text": value if kind == "amendment" else None,
            }
        )
    return json_column(result)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    try:
        year = int(edition.edition_id)
    except (TypeError, ValueError) as error:
        raise ScorecardSourceError("CPAC reader requires a publisher annual edition") from error
    if edition != edition_for_year(year):
        raise ScorecardSourceError("CPAC reader requires an explicit historical federal API edition")
    primary, raw_counts = _read(context, counts_query(year), "counts")
    declared, declared_members = _counts(raw_counts)
    documents, catalogs = {}, {}
    for kind in ("members", "items", "votes"):
        document, data = _read(context, records_query(kind, year, declared[kind]), kind)
        documents[kind] = document
        catalogs[kind] = _records(data, kind, declared[kind])
    # Every selected source value is reread, not just the count or row identities.
    for kind in ("members", "items", "votes"):
        document, data = _read(context, records_query(kind, year, declared[kind]), kind + ":reread")
        if _records(data, kind, declared[kind]) != catalogs[kind]:
            raise ScorecardSourceError(f"CPAC {kind} changed during the complete edition read")
        documents[kind + ":reread"] = document
    final, final_counts = _read(context, counts_query(year), "counts:reread")
    if _counts(final_counts) != (declared, declared_members):
        raise ScorecardSourceError("CPAC counts changed during the complete edition read")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="CPAC Foundation",
        parser_version=parser_version,
        rendition_rule="cpac-legacy-api-literals/1",
        homepage="https://www.cpac.org/",
    )
    bundle.use(primary, "source_counts")
    bundle.use(final, "source_counts", role="corroboration")
    for kind, document in documents.items():
        if kind.endswith(":reread"):
            bundle.use(document, kind.removesuffix(":reread"), role="corroboration")
        else:
            bundle.use(document, kind)
    member_doc, item_doc, vote_doc = (documents[kind] for kind in ("members", "items", "votes"))
    for group, fields in (("annual", ANNUAL_FIELDS), ("lifetime", LIFETIME_FIELDS)):
        source_group = "acuRatings" if group == "annual" else "acuLifetimeRatings"
        for field in fields:
            bundle.metric(
                member_doc,
                group + ":" + field,
                source_group + "." + field,
                path=f"$.data.members[*].{source_group}[*].{field}",
                primary=group == "annual" and field == "rating",
            )
    members = {}
    observed_annual = observed_lifetime = 0
    for position, member in enumerate(catalogs["members"]):
        histories, annual, lifetime = _member(member, year)
        identifier = member["id"]
        if identifier in members:
            raise ScorecardSourceError("CPAC member census repeats an identity")
        members[identifier] = member
        rating = (annual or lifetime)[0]
        observed_annual += len(annual)
        observed_lifetime += len(lifetime)
        path = f"$.data.members[{position}]"
        ids = [{"scheme": "cpac", "value": identifier}]
        if member["opensecretsId"]:
            ids.append({"scheme": "opensecrets", "value": _text(member["opensecretsId"])})
        if member["votesmartId"]:
            ids.append({"scheme": "votesmart", "value": _text(member["votesmartId"])})
        bundle.add(
            "scorecard_members",
            member_doc,
            path,
            publisher_member_key=identifier,
            publisher_member_id=identifier,
            member_name=member["name"],
            identifiers_json=json_column(ids),
            chamber_text=_historical_value(histories, "chamber", rating["body"]),
            state=_historical_value(histories, "from"),
            district=_historical_value(histories, "district"),
            party=_historical_value(histories, "party"),
            period_text=str(year),
            notes_text=json_column(
                {field: member[field] for field in ("role", "party", "district", "state", "from", "history")}
            ),
        )
        for source_group, group, entries, fields in (
            ("acuRatings", "annual", annual, ANNUAL_FIELDS),
            ("acuLifetimeRatings", "lifetime", lifetime, LIFETIME_FIELDS),
        ):
            for entry in entries:
                for field in fields:
                    value = _text(entry[field])
                    bundle.add(
                        "scorecard_member_ratings",
                        member_doc,
                        path + f".{source_group}[0].{field}",
                        publisher_member_key=identifier,
                        metric_id=group + ":" + field,
                        value_text=value,
                        value_number=decimal_text(value),
                    )
    if set(members) != declared_members or observed_annual != declared["annual"]:
        raise ScorecardSourceError("CPAC annual member identities do not reconcile with their source census")
    if observed_lifetime != declared["lifetime"]:
        raise ScorecardSourceError("CPAC member lifetime ratings do not reconcile with their source count")
    items = {}
    for position, item in enumerate(catalogs["items"]):
        roll, amendment, bill = _item(item, year)
        identifier = item["id"]
        if identifier in items:
            raise ScorecardSourceError("CPAC item catalog repeats an identity")
        items[identifier] = item
        path = f"$.data.items[{position}]"
        target, weight = _text(item["acuVote"]), _text(item["weight"])
        bundle.add(
            "scorecard_items",
            item_doc,
            path,
            item_id=identifier,
            publisher_item_id=identifier,
            item_kind_text=_text(item["type"]) or ("roll call" if roll else "bill action"),
            title=item["title"],
            item_date_text=_text(item["statusDate"]),
            chamber_text=_text(item["body"]),
            roll_number_text=roll,
            bill_citation_text=bill,
            amendment_citation_text=amendment,
            references_json=_references(item, path, roll, bill),
            publisher_position_text=target,
            position_basis="explicit",
            position_source_path=path + ".acuVote",
        )
        bundle.add(
            "scorecard_metric_items",
            item_doc,
            path,
            metric_id="annual:rating",
            item_id=identifier,
            participation_id="annual",
            publisher_position_text=target,
            position_basis="explicit",
            weight_text=weight,
            weight_number=decimal_text(weight),
        )
    seen = set()
    for position, vote in enumerate(catalogs["votes"]):
        _require(vote, set(VOTE_FIELDS.split()), "vote result")
        identifier, item_id = vote["peopleId"], vote["articleId"]
        if vote["year"] != year or identifier not in members or item_id not in items:
            raise ScorecardSourceError("CPAC vote result is outside its captured federal member/item scope")
        identity = (identifier, item_id)
        if identity in seen:
            raise ScorecardSourceError("CPAC vote results repeat a member/item identity")
        seen.add(identity)
        points = _text(vote["points"])
        bundle.add(
            "scorecard_member_item_results",
            vote_doc,
            f"$.data.votes[{position}]",
            result_id="vote",
            metric_id="annual:rating",
            participation_id="annual",
            item_id=item_id,
            publisher_member_key=identifier,
            action_text=_text(vote["vote"]),
            result_text=_text(vote["rating"]),
            contribution_text=points,
            contribution_number=decimal_text(points),
            reason_text=json_column({field: vote[field] for field in ("value", "withAcu", "date")}),
        )
    return bundle.finish(
        "Publisher federal year selected; source annual/lifetime/member/item/vote counts reconcile with complete EOF JSON; "
        "unique member/item/result identities reconcile; reported weighted rating counts remain separate from record counts; "
        "all selected values and counts are unchanged on reread",
        declared=declared,
    )
