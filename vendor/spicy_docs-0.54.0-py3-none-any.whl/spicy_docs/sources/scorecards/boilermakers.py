"""Boilermakers' named Reporter scorecards and their publisher corrections."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "boilermakers-named-original-reporter-pdf/1"
HOSTS = ("boilermakers.org",)
INDEX = "https://boilermakers.org/news/reporter/archives"
# Bounds are measured from the complete original printed tables, not an official
# congressional roster. In particular, the 1997 publisher omits source rows.
SPECS: dict[str, dict[str, Any]] = {
    "1997-jan-aug-corrected": {
        "year": "1997",
        "title": "1997 Congressional Scorecard",
        "label": "1997 Congressional Scorecard",
        "period": "Jan - Aug 1997",
        "annual_labels": {"House": "‘97%", "Senate": "‘97%"},
        "lifetime_label": "Life%",
        "lifetime_period": "Lifetime Vote In Office",
        "item_counts": {"House": 10, "Senate": 7},
        "glyphs": {"R", "A", "V", "W", "S"},
        "party_labels": {"Independents", "R", "D", "Republicans", "Democrats"},
        "disclosed_glyphs": {"W", "R", "A"},
        "roll_numbers": {
            "House": [None, None, None, None, None, None, None, None, None, None],
            "Senate": [None, None, None, None, None, None, None],
        },
        "roster_gaps": [
            "Main source omits New York district 4 and North Carolina district 3; the following issue supplies these two rows.",
            "Maryland district 4 and Missouri district 7 are absent from the printed tables and the observed correction; no row is invented.",
        ],
        "main_house_party_disclosed": False,
        "primary_issue": "v37n2",
        "sources": {
            "v37n2": {
                "url": "https://boilermakers.org/sites/default/files/reporter/V37N2_0.pdf",
                "sha256": "9559b155a96fe243bbcc203c476dbcbb854aad80f936698baf08a2f9363b8e0f",
                "page_count": 16,
                "publication_period": "March - April 1998",
            },
            "v37n3": {
                "url": "https://boilermakers.org/sites/default/files/reporter/V37N3_0.pdf",
                "sha256": "09d38b5eaa2bd8d8585430862ca27c5f7b6d2c90aea81218b59cf3c9e29d7753",
                "page_count": 24,
                "publication_period": "May - June 1998",
            },
        },
        "member_counts": {"Senate": 100, "House": 433},
        "page_counts": {"v37n2:7": 100, "v37n2:9": 106, "v37n2:10": 159, "v37n2:11": 166, "v37n3:8": 2},
        "glyph_counts": {"W": 2658, "R": 2251, "A": 100, "V": 14, "S": 7},
        "qualified_sha256": "e686f675bb1943a5e0f074bd5efad9e40bb95b5c9798406561260d22887706ab",
    },
    "1998-jan-sep": {
        "year": "1998",
        "title": "CONGRESSIONAL SCORECARD",
        "label": "CONGRESSIONAL SCORECARD",
        "period": "Jan. - Sep. 1998",
        "annual_labels": {"House": "‘98 %", "Senate": "‘98 %"},
        "lifetime_label": "Life %",
        "lifetime_period": {
            "House": "Percentage Right Over Lifetime In Office",
            "Senate": "Percentage of Correct Votes Over Lifetime In Office",
        },
        "item_counts": {"House": 6, "Senate": 3},
        "glyphs": {"R", "P", "A", "V", "W"},
        "party_labels": {"INDEPENDENT", "Republican", "Democrat"},
        "disclosed_glyphs": set(),
        "roll_numbers": {"House": ["78", "83", "317", "306", "466", "469"], "Senate": ["17", "141", "266"]},
        "roster_gaps": [],
        "main_house_party_disclosed": True,
        "primary_issue": "v37n5",
        "sources": {
            "v37n5": {
                "url": "https://boilermakers.org/sites/default/files/reporter/V37N5_0.pdf",
                "sha256": "faf44acbe0d3342362527045f92a4ae5ca08e8b0aa8d5259e571ffc5d6f2c5e6",
                "page_count": 16,
                "publication_period": "September - October 1998",
            }
        },
        "member_counts": {"House": 434, "Senate": 100},
        "page_counts": {"v37n5:9": 139, "v37n5:10": 220, "v37n5:11": 175},
        "glyph_counts": {"W": 1367, "A": 109, "R": 1416, "V": 8, "P": 4},
        "qualified_sha256": "2cc74bb4348bc5139f57e1db4d1ff99b481742d74ca6fb4359bcf989527e4028",
    },
    "1999": {
        "year": "1999",
        "title": "1999 Congressional Scorecard",
        "label": "1999 Congressional Scorecard",
        "period": "Jan-Dec 1999",
        "annual_labels": {"House": "‘99%", "Senate": "‘99%"},
        "lifetime_label": "Life%",
        "lifetime_period": "Lifetime Vote In Office",
        "item_counts": {"House": 5, "Senate": 7},
        "glyphs": {"R", "A", "V", "W", "S"},
        "party_labels": {"Independents", "Democrats", "Republicans"},
        "disclosed_glyphs": {"W", "R", "A"},
        "roll_numbers": {"House": [None, None, None, None, None], "Senate": [None, None, None, None, None, None, None]},
        "roster_gaps": [],
        "main_house_party_disclosed": True,
        "primary_issue": "v39n2",
        "sources": {
            "v39n2": {
                "url": "https://boilermakers.org/sites/default/files/reporter/V39N2_0.pdf",
                "sha256": "f551a40026ab1c417147be92687688b942e1f604a84fb7f802295ffb059fed55",
                "page_count": 16,
                "publication_period": "March - April 2000",
            }
        },
        "member_counts": {"Senate": 100, "House": 435},
        "page_counts": {"v39n2:7": 36, "v39n2:8": 102, "v39n2:9": 240, "v39n2:10": 157},
        "glyph_counts": {"W": 1437, "R": 1398, "A": 33, "V": 6, "S": 1},
        "qualified_sha256": "2bf7ad32aca84a5b3fd9d82607dcf27de1b58b8d35ff65542d00e02df7483d73",
    },
    "2001": {
        "year": "2001",
        "title": "2001 votes illustrate how legislators maneuver",
        "label": "Key votes for Boilermakers in 2001",
        "period": "Jan-Dec 2001",
        "annual_labels": {"House": "2001%", "Senate": "‘01%"},
        "lifetime_label": None,
        "lifetime_period": None,
        "item_counts": {"House": 5, "Senate": 10},
        "glyphs": {"*", "W", "R", "NV"},
        "party_labels": {"INDEPENDENTS", "Democrats", "Republicans"},
        "disclosed_glyphs": {"*", "W", "R", "NV"},
        "roll_numbers": {
            "House": [None, None, None, None, None],
            "Senate": [None, None, None, None, None, None, None, None, None, None],
        },
        "roster_gaps": [],
        "main_house_party_disclosed": True,
        "primary_issue": "v41n1",
        "sources": {
            "v41n1": {
                "url": "https://boilermakers.org/sites/default/files/reporter/V41N1_0.pdf",
                "sha256": "0b23584497c0aa1ad15d5c3f1cc98da6a290b6171b911c2cd1d934ab9baca78e",
                "page_count": 9,
                "publication_period": "January - February 2002",
            }
        },
        "member_counts": {"House": 442, "Senate": 100},
        "page_counts": {"v41n1:3": 221, "v41n1:4": 321},
        "glyph_counts": {"W": 959, "R": 2134, "NV": 75, "*": 42},
        "qualified_sha256": "77ee81d68c30e778f1a4ea2584dfa9a5f51491a04583f1f730a96336668e899e",
    },
}


def _spec(identifier: str) -> dict[str, Any]:
    if identifier not in SPECS:
        raise ScorecardSourceError("Boilermakers requires a reviewed named Reporter edition")
    return SPECS[identifier]


def _edition(identifier: str) -> ScorecardEdition:
    spec = _spec(identifier)
    return ScorecardEdition(
        "boilermakers",
        identifier,
        spec["sources"][spec["primary_issue"]]["url"],
        spec["title"],
        year=spec["year"],
        chamber="both",
        is_current=False,
    )


def _source(document, source):
    if (
        document.url != source["url"]
        or sha256(document.body).hexdigest() != source["sha256"]
        or not document.body.startswith(b"%PDF-")
        or b"%%EOF" not in document.body[-1024:]
    ):
        raise ScorecardSourceError("Boilermakers PDF differs from its reviewed original Reporter issue")


def _evidence(evidence, spec):
    issue = evidence["source_issue"]
    source = spec["sources"][issue]
    if (
        not evidence["physical_pages"]
        or any(type(p) is not int or not 1 <= p <= source["page_count"] for p in evidence["physical_pages"])
        or not isinstance(evidence["json_pointer"], str)
        or not evidence["json_pointer"].startswith("/")
        or evidence["schema_version"]
        not in {
            "boilermakers-pdf-members/1",
            "boilermakers-pdf-row-correction/1",
            "boilermakers-pdf-items/1",
            "boilermakers-pdf-item-correction/1",
        }
        or any(
            not isinstance(evidence[k], str) or not re.fullmatch(r"[0-9a-f]{64}", evidence[k])
            for k in ("outcome_sha256", "observation_sha256")
        )
    ):
        raise ValueError


def _qualified(body, identifier, spec):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != spec["qualified_sha256"]:
        raise ScorecardSourceError("Boilermakers observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "boilermakers-qualified-pdf/1"
            or data["edition_key"] != identifier
            or data["sources"] != spec["sources"]
            or data["member_counts"] != spec["member_counts"]
            or data["item_counts"] != spec["item_counts"]
            or data["member_page_counts"] != spec["page_counts"]
            or data["source_roster_gaps"] != spec["roster_gaps"]
            or data["uncertainties"]
        ):
            raise ValueError
        front = data["front"]["record"]
        _evidence(data["front"]["evidence"], spec)
        if (
            front["period_text"] != spec["period"]
            or front["house_annual_label_text"] != spec["annual_labels"]["House"]
            or front["senate_annual_label_text"] != spec["annual_labels"]["Senate"]
            or front["lifetime_label_text"] != spec["lifetime_label"]
            or not front["party_legend_text"]
            or not front["methodology_text"]
            or not front["source_scope_notes"]
        ):
            raise ValueError
        for chamber in spec["member_counts"]:
            legend = front[chamber.lower() + "_result_legend"]
            symbols = [v["symbol_text"] for v in legend]
            if len(symbols) != len(set(symbols)) or any(not v["meaning_text"] for v in legend):
                raise ValueError
            if set(symbols) != spec["disclosed_glyphs"]:
                raise ValueError
        item_ids, item_counts = set(), Counter()
        for entry in data["items"]:
            _evidence(entry["evidence"], spec)
            r, chamber = entry["record"], entry["chamber"]
            n = r["item_number_text"]
            if (
                chamber not in spec["item_counts"]
                or entry["evidence"]["source_issue"] != spec["primary_issue"]
                or not isinstance(n, str)
                or not re.fullmatch(r"[1-9]\d*", n)
                or not 1 <= int(n) <= spec["item_counts"][chamber]
                or (chamber, n) in item_ids
                or any(
                    not isinstance(r[f], str) or not r[f]
                    for f in ["title_text", "description_text", "publisher_position_text", "action_text"]
                )
                or r["position_basis_text"] != "explicit"
                or r["roll_number_text"] != spec["roll_numbers"][chamber][int(n) - 1]
                or any(not isinstance(v, str) or not v for f in ["bill_citations", "amendment_citations"] for v in r[f])
            ):
                raise ValueError
            item_ids.add((chamber, n))
            item_counts[chamber] += 1
        if dict(item_counts) != spec["item_counts"]:
            raise ValueError
        identities, counts, pages, glyphs = set(), Counter(), Counter(), Counter()
        for entry in data["members"]:
            _evidence(entry["evidence"], spec)
            r, chamber = entry["record"], entry["chamber"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            results, physical_pages = r["item_results"], entry["evidence"]["physical_pages"]
            source_page = entry["evidence"]["source_issue"] + ":" + str(physical_pages[0])
            if (
                chamber not in spec["member_counts"]
                or identity in identities
                or not isinstance(r["member_name_text"], str)
                or not r["member_name_text"]
                or not isinstance(r["state_text"], str)
                or not r["state_text"]
                or r["party_text"] not in spec["party_labels"] | {None}
                or (
                    not spec["main_house_party_disclosed"]
                    and chamber == "House"
                    and entry["evidence"]["source_issue"] == spec["primary_issue"]
                    and r["party_text"] is not None
                )
                or not isinstance(r["native_name_font"], str)
                or not r["native_name_font"]
                or not isinstance(r["native_name_compact"], str)
                or not r["native_name_compact"]
                or (chamber == "Senate" and r["district_text"] is not None)
                or (chamber == "House" and not re.fullmatch(r"\d+(?:st|nd|rd|th)?|AL", r["district_text"]))
                or len(physical_pages) != 1
                or source_page not in spec["page_counts"]
                or not isinstance(results, dict)
                or set(results) != {n for c, n in item_ids if c == chamber}
                or any(v not in spec["glyphs"] | {None} for v in results.values())
                or not (r["annual_value_text"] is None or re.fullmatch(r"\d+%|NA|N/A|—|–", r["annual_value_text"]))
                or (spec["lifetime_label"] is None and r["lifetime_value_text"] is not None)
                or (
                    spec["lifetime_label"] is not None
                    and not (r["lifetime_value_text"] is None or re.fullmatch(r"\d+%|—|–", r["lifetime_value_text"]))
                )
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[source_page] += 1
            glyphs.update("source-blank" if glyph is None else glyph for glyph in results.values())
        if (
            dict(counts) != spec["member_counts"]
            or dict(pages) != spec["page_counts"]
            or dict(glyphs) != spec["glyph_counts"]
        ):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "Boilermakers facts do not establish the complete reviewed printed rendition"
        ) from error


@dataclass(frozen=True, slots=True)
class BoilermakersPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    @property
    def edition_key(self) -> str:
        try:
            identifier = json.loads(self.qualified_observations)["edition_key"]
            if not isinstance(identifier, str):
                raise TypeError
            _spec(identifier)
            return identifier
        except (ValueError, TypeError, KeyError) as error:
            raise ScorecardSourceError("Boilermakers observations must identify a reviewed named edition") from error

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        if context.evidence_policy == "full":
            raise ScorecardSourceError("Boilermakers PDF redistribution rights are not established")
        spec = _spec(self.edition_key)
        _qualified(self.qualified_observations, self.edition_key, spec)
        for issue, source in spec["sources"].items():
            _source(
                context.read(source["url"], stage=f"boilermakers:{self.edition_key}:{issue}:list", hosts=HOSTS), source
            )
        return (_edition(self.edition_key),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        if edition != _edition(self.edition_key):
            raise ScorecardSourceError("Boilermakers reader requires its exact configured named edition")
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    spec = _spec(edition.edition_id)
    if edition != _edition(edition.edition_id):
        raise ScorecardSourceError("Boilermakers requires the exact reviewed named edition")
    if context.evidence_policy == "full":
        raise ScorecardSourceError("Boilermakers PDF redistribution rights are not established")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("Boilermakers requires pinned reviewed facts and private observation retention")
    data = _qualified(qualified_observations, edition.edition_id, spec)
    documents = {}
    for issue, source in spec["sources"].items():
        document = context.read(source["url"], stage=f"boilermakers:{edition.edition_id}:{issue}:pdf", hosts=HOSTS)
        _source(document, source)
        documents[issue] = document
    primary = documents[spec["primary_issue"]]
    observation = retain_qualified(
        primary,
        qualified_observations,
        retain_observations,
        source_sha256=spec["sources"][spec["primary_issue"]]["sha256"],
        observations_sha256=spec["qualified_sha256"],
        stage=f"boilermakers:{edition.edition_id}:qualified-observations",
    )

    def location(entry, pointer):
        evidence = entry["evidence"]
        return (
            f"pdf:pages={','.join(str(p) for p in evidence['physical_pages'])};"
            f"observation={observation};{pointer}/record"
        )

    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="International Brotherhood of Boilermakers",
        parser_version=parser_version,
        rendition_rule="complete named original Reporter printed scorecard and disclosed correction; source rows, font legends, every cell and source roster gaps reconciled against original text and renders",
        homepage="https://boilermakers.org/",
    )
    for issue, document in documents.items():
        if issue != spec["primary_issue"]:
            bundle.use(document, "members:" + issue)
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        methodology_url=primary.url,
        timespan_text=front["period_text"],
        edition_label_text=spec["label"],
    )
    front_path = location(data["front"], "/front")
    for chamber in spec["member_counts"]:
        method_id = key(chamber, "legend")
        bundle.add(
            "scorecard_methodologies",
            primary,
            front_path,
            methodology_id=method_id,
            chamber_text=chamber,
            methodology_url=primary.url,
            disclosure_status="partial",
            methodology_text=json_column(front),
        )
        periods = [("annual", front[chamber.lower() + "_annual_label_text"], front["period_text"])]
        if spec["lifetime_label"] is not None:
            lifetime_period = spec["lifetime_period"]
            if isinstance(lifetime_period, dict):
                lifetime_period = lifetime_period[chamber]
            periods.append(("lifetime", front["lifetime_label_text"], lifetime_period))
        for period, label, span in periods:
            bundle.add(
                "scorecard_metrics",
                primary,
                front_path,
                metric_id=key(chamber, period),
                name=label,
                value_unit_text="%",
                chamber_text=chamber,
                period_text=span,
                methodology_id=method_id,
            )
    for i, entry in enumerate(data["items"]):
        r, chamber = entry["record"], entry["chamber"]
        path = location(entry, f"/items/{i}")
        n = r["item_number_text"]
        item_id, method_id = key(chamber, n), key(chamber, "item", n)
        references = [
            {
                "occurrence_id": f"{kind}:{j}",
                "citation_text": citation,
                "kind": kind,
                "source_path": path + f"/{field_name}/{j}",
                "chamber_text": chamber,
                output_field: citation,
            }
            for kind, field_name, output_field in [
                ("bill", "bill_citations", "bill_citation_text"),
                ("amendment", "amendment_citations", "amendment_citation_text"),
            ]
            for j, citation in enumerate(r[field_name])
        ]
        bundle.add(
            "scorecard_methodologies",
            primary,
            path,
            methodology_id=method_id,
            chamber_text=chamber,
            disclosure_status="explicit",
            methodology_text=json_column(r),
        )
        bundle.add(
            "scorecard_items",
            primary,
            path,
            item_id=item_id,
            publisher_item_id=n,
            item_kind_text="Key Vote",
            title=r["title_text"],
            item_date_text=r["date_text"],
            chamber_text=chamber,
            roll_number_text=r["roll_number_text"],
            bill_citation_text=next(iter(r["bill_citations"]), None),
            amendment_citation_text=next(iter(r["amendment_citations"]), None),
            references_json=json_column(references),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=path + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            primary,
            path,
            metric_id=key(chamber, "annual"),
            item_id=item_id,
            participation_id="printed-key-vote",
            methodology_id=method_id,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
        )
    for i, entry in enumerate(data["members"]):
        r, chamber = entry["record"], entry["chamber"]
        document = documents[entry["evidence"]["source_issue"]]
        path = location(entry, f"/members/{i}")
        member_key = key(
            chamber, r["state_text"], *([r["district_text"]] if r["district_text"] else []), r["member_name_text"]
        )
        bundle.add(
            "scorecard_members",
            document,
            path,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text=front["period_text"],
            identifiers_json="[]",
            notes_text=json_column(
                {
                    "native_name_font": r["native_name_font"],
                    "native_name_compact": r["native_name_compact"],
                    "party_basis_text": r["party_basis_text"],
                    "original_annual_value_text": r["annual_value_text"],
                    "source_issue": entry["evidence"]["source_issue"],
                    "source_member_context_text": r["source_member_context_text"],
                }
            ),
        )
        for period in ["annual"] + (["lifetime"] if spec["lifetime_label"] is not None else []):
            value = r[period + "_value_text"]
            # User-directed missing-value spelling; retain the literal NA in
            # private observations and the native member notes above.
            if value == "NA":
                value = "N/A"
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + "/" + period + "_value_text",
                publisher_member_key=member_key,
                metric_id=key(chamber, period),
                value_text=value,
                value_number=decimal_text(value) if value is not None else None,
                value_status_text=value if value in {"N/A", "—", "–"} else None,
            )
        meanings = {v["symbol_text"]: v["meaning_text"] for v in front[chamber.lower() + "_result_legend"]}
        for n, glyph in r["item_results"].items():
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + "/item_results/" + n,
                result_id="printed-cell",
                publisher_member_key=member_key,
                item_id=key(chamber, n),
                metric_id=key(chamber, "annual"),
                participation_id="printed-key-vote",
                result_text=glyph,
                reason_text=meanings.get(glyph),
            )
    for issue, source in spec["sources"].items():
        repeated = context.read(
            source["url"], stage=f"boilermakers:{edition.edition_id}:{issue}:pdf:reread", hosts=HOSTS
        )
        _source(repeated, source)
        bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete original printed scorecard, disclosed correction, every native annual/lifetime rating and every action cell; original PDFs reread identically; recorded source roster gaps remain outside the printed rendition",
        declared={
            "members_by_chamber": spec["member_counts"],
            "members_by_source_page": spec["page_counts"],
            "items_by_chamber": spec["item_counts"],
            "glyph_counts": spec["glyph_counts"],
            "source_roster_gaps": spec["roster_gaps"],
            "source_counts_basis": "measured complete original printed tables; no official roster completeness claim",
        },
    )
