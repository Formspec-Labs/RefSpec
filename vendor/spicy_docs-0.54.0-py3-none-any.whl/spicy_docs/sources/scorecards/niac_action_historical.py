"""NIAC's publisher-selected 117th Congress sheet, including native action glyphs."""

from __future__ import annotations

import json
import re
from collections import Counter

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "niac-action-117-published-sheet/2"
INDEX = "https://niacouncil.org/congressional-scorecard-117th-congress/"
SHEET = "https://docs.google.com/spreadsheets/d/e/2PACX-1vR2qUhsjJgaA_MmeuH7yACsl8hT9uvtIPDwN_ok8iM3gAuTdg4tfelgaTA9z7b8KYSroIHISLQUFmVk/pubhtml"
HOSTS = ("niacouncil.org", "docs.google.com")
TABS = {"House": ("1662494998", "U.S. House of Representatives"), "Senate": ("2145489087", "U.S. Senate")}
COUNTS = {"House": 441, "Senate": 100}
EDITION = ScorecardEdition(
    "niac_action",
    "117-published-sheet",
    INDEX,
    "117th Congressional Scorecard",
    congress="117",
    chamber="both",
    is_current=False,
)
ITEM_HEADERS = {
    "House": [
        "✅ Humanitarian Sanctions Relief Letter (February '21)",
        "✅ Internet Freedom Letter (October '21)",
        "✅ Restore the Deal Letter (December '20)",
        "❌ AIPAC Anti-Deal Letter (March '21)",
        "✅ 2002 AUMF Repeal (H.R. 256) Vote (June '21)",
        "❌ Republican Anti-Diplomacy Letter (February '22)",
        '❌ "Bipartisan Concerns" Letter (March \'22)',
        "❌ Anti-Deal Press Statement (April '21)",
        "JCPOA 2015 Votes",
        "Diplomacy statements",
        "✅ NO BAN Act (H.R. 1333) Vote (April '21)",
        "✅ Diversity Visa Relief Vote (July '21)",
        "✅ Access to Counsel Act (H.R. 1573) Vote (April '21)",
    ],
    "Senate": [
        "✅ Humanitarian Sanctions Relief Letter (February '21)",
        "✅ Restore the Deal Letter (April '21)",
        "❌ AIPAC Anti-Deal Senate Letter (March '21)",
        "✅ Iran Diplomacy Act (S. 434)",
        "❌ Ted Cruz Treaty Letter (February '22)",
        "❌ Republican Anti-Deal Letter (March '22)",
        "JCPOA 2015 Vote",
        "Diplomacy Statements",
        "✅ NO BAN Act (S. 1891) Cosponsor",
        "✅ Access to Counsel Act (S. 1912) Cosponsor",
    ],
}
NARRATIVE_STEMS = {
    "House": [
        "Humanitarian Sanctions Relief Letter",
        "Internet Freedom Letter",
        "Restore the Deal Letter",
        "AIPAC Anti-Deal Letter",
        "2002 AUMF Repeal",
        "House Republican Anti-Diplomacy Letter",
        "“Bipartisan Concerns” Letter",
        "AIPAC Anti-Deal Press Statement",
        "JCPOA 2015 Vote",
        "Diplomacy Statements",
        "NO BAN Act",
        "Diversity Visa Relief in House HS Approps",
        "Access to Counsel Act",
    ],
    "Senate": [
        "Humanitarian Sanctions Relief Letter",
        "Restore the Deal Letter",
        "AIPAC Anti-Deal Senate Letter",
        "Iran Diplomacy Act",
        "Ted Cruz Treaty Letter",
        "49 Republicans Anti-Deal Letter",
        "JCPOA 2015 Vote",
        "Diplomacy Statements",
        "NO BAN Act",
        "Access to Counsel Act",
    ],
}


def _literal(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _page(source):
    if b"</html>" not in source.body.lower():
        raise ScorecardSourceError("NIAC historical publisher HTML is incomplete")
    document = soup(source)
    if not any(h.get_text(" ", strip=True) == EDITION.title for h in document.find_all("h1")):
        raise ScorecardSourceError("NIAC historical scorecard edition identity changed")
    intro = [p for p in document.find_all("p") if p.get_text(" ", strip=True).startswith("NIAC Action grades")]
    if len(intro) != 1:
        raise ScorecardSourceError("NIAC historical methodology introduction changed")
    body = intro[0].parent
    if not any(a.get("href") == SHEET for a in body.find_all("a")):
        raise ScorecardSourceError("NIAC historical publisher sheet selection changed")
    paragraphs = [p.get_text(" ", strip=True) for p in body.find_all("p", recursive=False)]
    if "✅ = NIAC ACTION SUPPORTS" not in paragraphs or "❌ = NIAC ACTION OPPOSES" not in paragraphs:
        raise ScorecardSourceError("NIAC historical preferred-position legend changed")
    chamber, category, narratives = None, None, {"House": [], "Senate": []}
    for p in body.find_all("p", recursive=False):
        text = p.get_text(" ", strip=True)
        if text in {"U.S. HOUSE OF REPRESENTATIVES", "U.S. SENATE"}:
            chamber = "House" if text == "U.S. HOUSE OF REPRESENTATIVES" else "Senate"
            category = None
        elif text in {"Civil and Human Rights", "Peace and Diplomacy", "Equitable Immigration"}:
            category = text
        elif chamber and text.startswith(("✅", "❌")):
            if not category:
                raise ScorecardSourceError("NIAC historical item lacks its source topic heading")
            narratives[chamber].append(
                {"text": text, "category": category, "links": [a["href"] for a in p.find_all("a", href=True)]}
            )
    for chamber, stems in NARRATIVE_STEMS.items():
        values = narratives[chamber]
        if len(values) != len(stems) or any(
            not row["text"].lstrip("✅❌ ").startswith(stem) for row, stem in zip(values, stems, strict=True)
        ):
            raise ScorecardSourceError("NIAC historical narrative-to-sheet item order or explicit mapping changed")
    return paragraphs, narratives


def _tabs(source):
    document = soup(source)
    if (
        document.select_one("#doc-title .name") is None
        or document.select_one("#doc-title .name").get_text(" ", strip=True)
        != "NIAC Action Congressional Scorecard (updated 4.13.2022)"
    ):
        raise ScorecardSourceError("NIAC historical published sheet identity changed")
    text = source.body.decode("utf-8")
    entries = re.findall(r'items\.push\(\{name: "([^"]+)", pageUrl: "([^"]+)", gid: "(\d+)"', text)
    if {(name, gid) for name, _, gid in entries} != {(name, gid) for gid, name in TABS.values()} or len(entries) != 2:
        raise ScorecardSourceError("NIAC historical published sheet tab set is missing or duplicated")
    result = {}
    for name, escaped, gid in entries:
        url = escaped.replace(r"\/", "/").replace(r"\x3d", "=")
        expected = SHEET + "/sheet?headers=false&gid=" + gid
        if url != expected:
            raise ScorecardSourceError("NIAC historical sheet selected an unreviewed tab URL")
        result[next(chamber for chamber, (sid, label) in TABS.items() if (gid, name) == (sid, label))] = url
    return result


def _sheet(source, chamber):
    if b"</html>" not in source.body.lower():
        raise ScorecardSourceError("NIAC historical sheet HTML is incomplete")
    tables = soup(source).select("table.waffle")
    if len(tables) != 1:
        raise ScorecardSourceError("NIAC historical sheet complete grid is missing")
    rows = tables[0].find_all("tr")
    widths = 20 if chamber == "House" else 16
    cells = [[cell.get_text(" ", strip=True) for cell in row.find_all(["td", "th"], recursive=False)] for row in rows]
    if len(cells) != COUNTS[chamber] + 3 or any(len(row) != widths for row in cells):
        raise ScorecardSourceError("NIAC historical sheet source-defined grid dimensions changed")
    start = 7 if chamber == "House" else 6
    headers = cells[1]
    prefix = (
        ["1", "Lieu, Ted", "Grade", "", "Party", "State", "District"]
        if chamber == "House"
        else ["1", "Member", "GRADE", "", "Party", "State"]
    )
    if headers[:start] != prefix or headers[start:] != ITEM_HEADERS[chamber] or any(cells[0]) or any(cells[2]):
        raise ScorecardSourceError("NIAC historical sheet headers or spacer rows changed")
    members = []
    for row_number, (tag, values) in enumerate(zip(rows[3:], cells[3:], strict=True), 4):
        row_header = tag.find("th", recursive=False)
        if (
            values[0] != str(row_number)
            or row_header is None
            or row_header.get("id") != TABS[chamber][0] + "R" + str(row_number - 1)
            or not values[1]
            or not values[5]
            or values[3]
            or values[2] not in {"A+", "A", "B", "C", "D", "F", "N/A", "NA", "Incomplete"}
            or (not values[4] and values[1] != "Vacant")
            or any(v not in {"", "(+)", "(-)"} for v in values[start:])
        ):
            raise ScorecardSourceError("NIAC historical sheet member row, native grade or action glyph changed")
        members.append(
            {
                "name": values[1],
                "grade": values[2],
                "party": values[4] or None,
                "state": values[5],
                "district": values[6] if chamber == "House" else None,
                "actions": values[start:],
                "row_number": str(row_number),
            }
        )
    return members


def list_scorecards(context):
    _page(context.read(INDEX, stage="scorecards:niac-117:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition, context):
    if edition != EDITION:
        raise ScorecardSourceError("NIAC historical sheet reader requires its named 117th Congress scope")
    page = context.read(INDEX, stage="scorecards:niac-117:publisher-start", hosts=HOSTS)
    profile = _page(page)
    catalog = context.read(SHEET, stage="scorecards:niac-117:sheet-index-start", hosts=HOSTS)
    tabs = _tabs(catalog)
    documents = {
        chamber: context.read(url, stage="scorecards:niac-117:sheet-start", hosts=HOSTS)
        for chamber, url in tabs.items()
    }
    facts = {chamber: _sheet(document, chamber) for chamber, document in documents.items()}
    ends = {
        chamber: context.read(url, stage="scorecards:niac-117:sheet-end", hosts=HOSTS) for chamber, url in tabs.items()
    }
    catalog_end = context.read(SHEET, stage="scorecards:niac-117:sheet-index-end", hosts=HOSTS)
    page_end = context.read(INDEX, stage="scorecards:niac-117:publisher-end", hosts=HOSTS)
    if _page(page_end) != profile or _tabs(catalog_end) != tabs or any(_sheet(ends[c], c) != facts[c] for c in tabs):
        raise ScorecardSourceError("NIAC historical sheet or methodology changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        page,
        publisher_name="NIAC Action",
        parser_version=parser_version,
        rendition_rule="niac-117-original-published-sheet-grades-and-literal-glyphs/1",
        homepage="https://niacouncil.org/",
    )
    bundle.tables["scorecards"][0].update(
        methodology_url=page.url, updated_at_text="4.13.2022", series_id=key("niac_action", "Congressional Scorecard")
    )
    bundle.use(page, "methodology", "narrative_items")
    bundle.use(catalog, "sheet_selection")
    bundle.use(page_end, "methodology", "narrative_items", role="corroboration")
    bundle.use(catalog_end, "sheet_selection", role="corroboration")
    paragraphs, narratives = profile
    for ordinal, text in enumerate(paragraphs):
        bundle.add(
            "scorecard_methodologies",
            page,
            f"publisher-body/p/{ordinal}",
            methodology_id=key("paragraph", str(ordinal)),
            methodology_text=text,
            methodology_url=page.url,
            disclosure_status="literal publisher methodology, narrative, category or legend; no numerical score reproduction",
        )
    for chamber, document in documents.items():
        bundle.use(document, chamber + "_grades", chamber + "_items", chamber + "_action_grid")
        bundle.use(
            ends[chamber], chamber + "_grades", chamber + "_items", chamber + "_action_grid", role="corroboration"
        )
        metric_id = key(chamber, "Grade")
        bundle.metric(
            document,
            metric_id,
            "Grade" if chamber == "House" else "GRADE",
            path="table/row/1/column/2",
            chamber=chamber,
            unit="grade",
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = "117th Congress"
        start = 7 if chamber == "House" else 6
        for ordinal, (title, narrative) in enumerate(zip(ITEM_HEADERS[chamber], narratives[chamber], strict=True)):
            identifier, path = key(chamber, "column", title), f"table/row/1/column/{start + ordinal}"
            position = (
                "NIAC ACTION SUPPORTS"
                if title.startswith("✅")
                else "NIAC ACTION OPPOSES"
                if title.startswith("❌")
                else None
            )
            bill = re.search(r"(?:H\.R\.|S\.)\s*\d+", title)
            references = [{"occurrence_id": "sheet-title", "kind": "text", "citation_text": title, "source_path": path}]
            for index, url in enumerate(narrative["links"]):
                references.append(
                    {
                        "occurrence_id": key("native-link", str(index)),
                        "kind": "url",
                        "citation_text": url,
                        "source_path": f"capture:{page.capture_id}#publisher-body/{chamber}/item/{ordinal}/a/{index}",
                    }
                )
            bundle.add(
                "scorecard_items",
                document,
                path,
                item_id=identifier,
                title=title,
                chamber_text=chamber,
                bill_citation_text=bill[0] if bill else None,
                references_json=_literal(references),
                publisher_position_text=position,
                position_basis="explicit" if position else "absent",
                position_source_path=path if position else None,
            )
            bundle.add(
                "scorecard_metric_items",
                document,
                path,
                metric_id=metric_id,
                item_id=identifier,
                participation_id=key(chamber, "grade-item", title),
                publisher_position_text=position,
                position_basis="explicit" if position else "absent",
                contribution_rule_text=narrative["text"],
            )
        duplicates = Counter()
        for member in facts[chamber]:
            identity = (chamber, member["state"], member["district"] or "Senate", member["name"])
            duplicates[identity] += 1
            member_key = key(*identity, str(duplicates[identity]))
            path = "table/row/" + member["row_number"]
            bundle.add(
                "scorecard_members",
                document,
                path,
                publisher_member_key=member_key,
                member_name=member["name"],
                chamber_text=chamber,
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text="117th Congress",
                identifiers_json="[]",
                notes_text="Literal published sheet context; Vacant is retained as the publisher's row label."
                if member["name"] == "Vacant"
                else None,
            )
            grade = member["grade"]
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + "/column/2",
                metric_id=metric_id,
                publisher_member_key=member_key,
                value_text="N/A" if grade == "NA" else grade,
                value_status_text="N/A" if grade in {"N/A", "NA"} else grade if grade == "Incomplete" else None,
                notes_text=_literal({"native_value": grade}) if grade == "NA" else None,
            )
            for ordinal, action in enumerate(member["actions"]):
                title = ITEM_HEADERS[chamber][ordinal]
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    path + f"/column/{start + ordinal}",
                    result_id=key(member_key, "column", title),
                    metric_id=metric_id,
                    item_id=key(chamber, "column", title),
                    participation_id=key(chamber, "grade-item", title),
                    publisher_member_key=member_key,
                    result_text=action or None,
                    reason_text="Literal empty published sheet cell; source meaning is unstated."
                    if not action
                    else None,
                )
    return bundle.finish(
        "Complete publisher-selected 117th Congress published sheet: exact named House/Senate tabs; finite full source grids and contiguous native row coordinates; every reported grade and every item-result cell; exact reviewed sheet-to-narrative item order; stable rereads. Native +/− glyphs and blank cells do not assert official actions; no item weights, sub-scores, invented legislative IDs or score reproduction."
    )
