"""Consume retained Docling page observations; never select or implement an OCR engine.

The host injects the existing extraction.Extractor and a private evidence writer.
Raw observations, rendered pages and configuration stay with that writer. Public
table rows contain only source facts and opaque page/table/cell locators.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass, replace
from urllib.parse import quote
from uuid import UUID

from spicy_docs.extraction.model import PageResult, TableObservation
from spicy_docs.sources.scorecards.common import ScorecardSourceError


@dataclass(frozen=True, slots=True)
class ExtractedPage:
    number: int
    text: str
    tables: tuple[TableObservation, ...]
    extraction_id: str
    observation_id: str

    def path(self, *, table: int | None = None, row: int | None = None, column: int | None = None) -> str:
        path = (
            f"PDF/page[{self.number}]/extraction[{quote(self.extraction_id, safe='')}]"
            f"/observation[{quote(self.observation_id, safe='')}]"
        )
        for label, value in (("table", table), ("row", row), ("column", column)):
            if value is not None:
                path += f"/{label}[{value}]"
        return path


@dataclass(frozen=True, slots=True)
class ExtractedPDF:
    pages: tuple[ExtractedPage, ...]

    @property
    def page_count(self) -> int:
        return len(self.pages)

    def __getitem__(self, index: int) -> ExtractedPage:
        return self.pages[index]

    def __iter__(self):
        return iter(self.pages)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False


def extract_pdf(source, context, *, expected_pages: int | None) -> ExtractedPDF:
    if context is None or context.pdf_extractor is None or context.retain_extraction is None:
        raise ScorecardSourceError(
            "PDF scorecards require an injected Docling extractor and private extraction retention"
        )
    pages = []
    ids = set()
    total = None
    digest = hashlib.sha256(source.body).hexdigest()  # Private input binding, never an output identity.
    stream = None
    try:
        stream = context.pdf_extractor.extract(source.body, media_type="application/pdf")
        for result in stream:
            if not isinstance(result, PageResult):
                raise ScorecardSourceError("PDF extractor returned an unsupported page observation")
            # Retain each observation before checking it, including refused/truncated pages.
            receipt = context.retain_extraction(source, result, stage="scorecards:pdf:extraction")
            extraction_id = receipt.get("extraction_id") if isinstance(receipt, Mapping) else None
            try:
                parsed_id = UUID(extraction_id) if isinstance(extraction_id, str) else None
            except ValueError:
                parsed_id = None
            if parsed_id is None or parsed_id.version != 4 or str(parsed_id) != extraction_id or extraction_id in ids:
                raise ScorecardSourceError("Private extraction retention must return a unique opaque extraction_id")
            ids.add(extraction_id)
            metadata = result.metadata
            number, page_count = metadata.get("page"), metadata.get("page_count")
            if (
                type(number) is not int
                or number != len(pages) + 1
                or type(page_count) is not int
                or page_count < number
                or page_count > 500
                or (total is not None and page_count != total)
                or (expected_pages is not None and page_count != expected_pages)
            ):
                raise ScorecardSourceError("PDF extraction has missing, reordered or inconsistent pages")
            total = page_count
            if (
                metadata.get("source_sha256") != digest
                or metadata.get("source_size_bytes") != len(source.body)
                or metadata.get("media_type") != "application/pdf"
            ):
                raise ScorecardSourceError("PDF extraction does not describe the selected source bytes")
            observations = result.content.observations
            if len(observations) != 1:
                raise ScorecardSourceError("PDF scorecard pages require one complete Docling observation")
            observed = observations[0]
            identity = observed.configuration.get("converter_identity") or observed.configuration.get("model_identity")
            if (
                not observed.id
                or observed.configuration.get("backend") != "docling"
                or observed.configuration.get("model_identity_resolved") is not True
                or not isinstance(identity, dict)
                or not identity
                or not isinstance(observed.raw, dict)
                or observed.raw.get("status") != "SUCCESS"
                or observed.issues
            ):
                raise ScorecardSourceError("PDF observation lacks complete, identified Docling processing")
            expected_tables = tuple(replace(table, page=number) for table in observed.tables)
            if result.tables != expected_tables:
                raise ScorecardSourceError("PDF tables must come from the retained Docling observation")
            if result.text != observed.text:
                raise ScorecardSourceError("PDF page text differs from its retained observation")
            pages.append(ExtractedPage(number, result.text, expected_tables, extraction_id, observed.id))
    except ScorecardSourceError:
        raise
    except Exception as error:
        # Provider errors can include private paths/prompts/bytes. The cause remains
        # available to the host's private refusal writer, never interpolated publicly.
        raise ScorecardSourceError("Scorecard PDF extraction failed; no alternate engine was attempted") from error
    finally:
        if stream is not None and hasattr(stream, "close"):
            stream.close()
    if not pages or len(pages) != total:
        raise ScorecardSourceError("PDF extraction ended before every source page completed")
    return ExtractedPDF(tuple(pages))
