"""AFGE recent annual PDFs with grouped topics and distinct scoring columns."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "afge-recent-grouped-qualified-pdf/1"
INDEX = "https://www.afge.org/take-action/afge-on-capitol-hill/issue-papers--voting-records/"
HOSTS = ("www.afge.org",)
QUALIFIED_EDITIONS: dict[str, dict[str, Any]] = {
    "2024": {
        "url": "https://www.afge.org/globalassets/documents/events/legcon/2025/voting-record-2024_jan21.pdf",
        "source_sha256": "4134922e27ab0bb8d7e9c0c7dfa481e12d4603f77e9025201ebe291a403d2a4a",
        "observations_sha256": "34135cd85010101a5f46ded7c389741f4fef937ed0db8fdab3cdf849a41c2004",
        "pages": 51,
        "members": {"House": 442, "Senate": 100},
        "items": {"House": 12, "Senate": 4},
        "columns": {"House": 12, "Senate": 7},
        "member_pages": {
            "House": {
                "12": 14,
                "13": 15,
                "14": 18,
                "15": 18,
                "16": 17,
                "17": 14,
                "18": 18,
                "19": 17,
                "20": 15,
                "21": 16,
                "22": 14,
                "23": 16,
                "24": 16,
                "25": 16,
                "26": 15,
                "27": 15,
                "28": 16,
                "29": 17,
                "30": 16,
                "31": 16,
                "32": 16,
                "33": 15,
                "34": 16,
                "35": 17,
                "36": 18,
                "37": 14,
                "38": 16,
                "39": 11,
            },
            "Senate": {"43": 12, "44": 13, "45": 13, "46": 12, "47": 13, "48": 13, "49": 12, "50": 12},
        },
        "mapping": {
            "House": [(3, 2), (9, 0), (10, 0), (7, 0), (11, 0), (6, 0), (8, 0), (4, 0), (3, 1), (1, 0), (5, 0), (2, 0)],
            "Senate": [(4, 0), (2, 1), (1, 0), (3, 0), (1, 2), (1, 1), (2, 0)],
        },
        "year": "2024",
        "congress": "118",
        "congress_label": "118th Congress",
        "session": "2",
        "session_label": "second session",
    },
}
LEGEND = {
    "R": "Voted With AFGE",
    "W": "Voted Against AFGE",
    "?": "Did Not Vote",
    "I": "Not In Office or Not Eligible to Vote",
}
GLYPHS = set(LEGEND) | {"(W)"}
CITATION = re.compile(
    r"\b(?:H\.\s*(?:R\.|(?:J\.|Con\.)?\s*Res\.|Amdt\.)|S\.\s*(?:(?:J\.|Con\.)\s*Res\.|Amdt\.)?)\s*\d+\b|\bPN\s*\d+\b"
)
SCHEMAS = {
    "afge-recent-pdf-front-facts/1",
    "afge-recent-pdf-grouped-item-facts/1",
    "afge-recent-pdf-member-facts/1",
    "afge-recent-pdf-native-reviewed-facts/1",
}


def _edition(identifier):
    spec = QUALIFIED_EDITIONS[identifier]
    return ScorecardEdition(
        "afge",
        identifier,
        spec["url"],
        spec["year"] + " VOTING RECORD",
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document, spec):
    if (
        document.url != spec["url"]
        or not document.body.startswith(b"%PDF-")
        or b"%%EOF" not in document.body[-4096:]
        or sha256(document.body).hexdigest() != spec["source_sha256"]
    ):
        raise ScorecardSourceError("AFGE recent PDF differs from the complete reviewed original")


def _evidence(e, spec):
    pages = e["physical_pages"]
    if (
        not isinstance(pages, list)
        or not pages
        or len(pages) != len(set(pages))
        or any(type(p) is not int or not 1 <= p <= spec["pages"] for p in pages)
        or e["schema_version"] not in SCHEMAS
        or not isinstance(e["json_pointer"], str)
        or not e["json_pointer"].startswith("/")
        or any(not re.fullmatch(r"[0-9a-f]{64}", e[k]) for k in ["outcome_sha256", "observation_sha256"])
    ):
        raise ValueError


def _qualified(body):
    try:
        if not isinstance(body, bytes):
            raise TypeError
        data = json.loads(body)
        spec = QUALIFIED_EDITIONS[data["edition_key"]]
        if (
            sha256(body).hexdigest() != spec["observations_sha256"]
            or data["format_version"] != "afge-qualified-recent-pdf/1"
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["pages"]
            or data["member_counts"] != spec["members"]
            or data["item_counts"] != spec["items"]
            or data["action_column_counts"] != spec["columns"]
            or data["member_page_counts"] != spec["member_pages"]
        ):
            raise ValueError
        _evidence(data["front"]["evidence"], spec)
        front = data["front"]["record"]
        if (
            front["title_text"] != spec["year"] + " VOTING RECORD"
            or front["year_text"] != spec["year"]
            or front["congress_text"] != spec["congress_label"]
            or front["session_text"] != spec["session_label"]
            or front["score_label_text"] != "AFGE Score (%)"
            or front["score_unit_text"] != "%"
            or not front["period_statements"]
            or len(front["legend"]) != len(LEGEND)
            or {r["token_text"]: r["meaning_text"] for r in front["legend"]} != LEGEND
            or not front["annotation_statements"]
            or not front["priority_legislation"]
        ):
            raise ValueError
        items = {}
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            number = r["item_number_text"].removesuffix(".")
            plain = " ".join(r["source_narrative_text"].split())
            if (
                chamber not in spec["items"]
                or not number.isdigit()
                or not 1 <= int(number) <= spec["items"][chamber]
                or r["item_number_text"] != number + "."
                or (chamber, int(number)) in items
                or not r["title_text"]
                or not plain.startswith(r["title_text"])
                or not r["actions"]
            ):
                raise ValueError
            for action in r["actions"]:
                if (
                    not action["title_text"]
                    or action["title_text"] not in plain
                    or action["preferred_vote_text"] not in {"Yes", "No", "Yea"}
                    or (action["date_text"] is not None and action["date_text"] not in plain)
                    or (
                        action["roll_number_text"] is not None
                        and not re.fullmatch(r"#?\d+", action["roll_number_text"])
                    )
                ):
                    raise ValueError
            items[chamber, int(number)] = r
        if dict(Counter(ch for ch, _ in items)) != spec["items"]:
            raise ValueError
        columns = {ch: {} for ch in spec["columns"]}
        for r in data["participations"]:
            ch, ordinal = r["chamber"], r["column_ordinal"]
            n, index = spec["mapping"][ch][ordinal - 1]
            action = items[ch, n]["actions"][index]
            if (
                type(ordinal) is not int
                or not 1 <= ordinal <= spec["columns"][ch]
                or ordinal in columns[ch]
                or r["item_number_text"] != str(n) + "."
                or r["action_index"] != index
                or not re.fullmatch(r"\d+", r["roll_number_text"])
                or r["column_title_text"] != data["column_titles"][ch][ordinal - 1]
                or not r["column_title_text"].endswith("(" + r["roll_number_text"] + ")")
                or r["publisher_position_text"] != action["preferred_vote_text"]
                or r["date_text"] != action["date_text"]
                or (
                    action["roll_number_text"] is not None
                    and action["roll_number_text"].removeprefix("#") != r["roll_number_text"]
                )
            ):
                raise ValueError
            columns[ch][ordinal] = r
        if any(
            set(columns[ch]) != set(range(1, count + 1)) or len(data["column_titles"][ch]) != count
            for ch, count in spec["columns"].items()
        ):
            raise ValueError
        identities, members, pages = set(), Counter(), {ch: Counter() for ch in spec["members"]}
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, ch = e["record"], e["chamber"]
            physical = e["evidence"]["physical_pages"]
            identity = (ch, tuple(physical), e["evidence"]["json_pointer"])
            if (
                ch not in spec["members"]
                or identity in identities
                or len(physical) != 1
                or str(physical[0]) not in spec["member_pages"][ch]
                or not r["member_name_text"]
                or not r["source_display_name_text"]
                or not r["state_text"]
                or r["party_text"] not in {"D", "R", "I", "E"}
                or not re.fullmatch(r"\d+%", r["score_text"])
                or (
                    ch == "House"
                    and r["district_text"] is not None
                    and not re.fullmatch(r"AL|\d{1,2}", r["district_text"])
                )
                or (ch == "Senate" and r["district_text"] is not None)
                or r["annotation_text"] not in {None, "*"}
                or type(r["name_is_bold"]) is not bool
                or set(r["item_results"]) != {str(n) for n in columns[ch]}
                or any(token not in GLYPHS for token in r["item_results"].values())
                or not re.fullmatch(r"[0-9a-f]{64}", e["evidence"]["native_text_sha256"])
                or not e["evidence"]["json_pointer"].startswith("/members/")
                or type(e["evidence"]["state_heading_physical_page"]) is not int
                or not 1 <= e["evidence"]["state_heading_physical_page"] <= physical[0]
            ):
                raise ValueError
            identities.add(identity)
            members[ch] += 1
            pages[ch][str(physical[0])] += 1
        if dict(members) != spec["members"] or any(dict(pages[ch]) != spec["member_pages"][ch] for ch in pages):
            raise ValueError
        return data, spec
    except (ValueError, KeyError, TypeError, AttributeError, IndexError) as error:
        raise ScorecardSourceError("AFGE recent facts do not establish the pinned complete reviewed edition") from error


@dataclass(frozen=True, slots=True)
class AFGERecentPDFReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        data, spec = _qualified(self.qualified_observations)
        _source(context.read(spec["url"], stage=f"afge:{data['edition_key']}:pdf:list", hosts=HOSTS), spec)
        return (_edition(data["edition_key"]),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _references(r, path, chamber, spec, participations):
    refs = []
    for n, m in enumerate(CITATION.finditer(r["source_narrative_text"])):
        text = m[0]
        kind = "nomination" if text.startswith("PN") else "amendment" if "Amdt" in text else "bill"
        occurrence = {
            "occurrence_id": str(n),
            "citation_text": text,
            "kind": kind,
            "source_path": path + f"/source_narrative_text/offset={m.start()}",
        }
        if kind in {"bill", "amendment"}:
            occurrence[kind + "_citation_text"] = text
        refs.append(occurrence)
    for n, action in enumerate(r["actions"]):
        if action["roll_number_text"] is not None:
            refs.append(
                {
                    "occurrence_id": f"action:{n}",
                    "citation_text": action["roll_number_text"],
                    "kind": "roll_call",
                    "roll_number_text": action["roll_number_text"].removeprefix("#"),
                    "congress_text": spec["congress"],
                    "session_text": spec["session"],
                    "chamber_text": chamber,
                    "source_path": path + f"/actions/{n}/roll_number_text",
                }
            )
    for p in participations:
        refs.append(
            {
                "occurrence_id": f"grid:{p['column_ordinal']}",
                "citation_text": p["column_title_text"],
                "kind": "roll_call",
                "roll_number_text": p["roll_number_text"],
                "congress_text": spec["congress"],
                "session_text": spec["session"],
                "chamber_text": chamber,
                "source_path": path + f"/source-grid-column/{p['column_ordinal']}",
            }
        )
    return refs


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AFGE recent PDF requires pinned reviewed facts and private observation retention")
    data, spec = _qualified(qualified_observations)
    if edition != _edition(data["edition_key"]):
        raise ScorecardSourceError("AFGE recent PDF selection differs from the qualified named edition")
    document = context.read(spec["url"], stage=f"afge:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["observations_sha256"],
        stage=f"afge:{edition.edition_id}:qualified-observations",
    )
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="American Federation of Government Employees",
        parser_version=parser_version,
        homepage="https://www.afge.org/",
        rendition_rule="complete recent named annual PDF; reviewed grouped topics, separate grid participation and all native rows/cells/annotations; stable original reread",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX

    def path(group, n=None, suffix=""):
        e = data[group] if n is None else data[group][n]
        pages = ",".join(str(p) for p in e["evidence"]["physical_pages"])
        return (
            f"pdf:pages={pages};observation={observation};/{group}"
            + ("" if n is None else f"/{n}")
            + "/record"
            + suffix
        )

    front = data["front"]["record"]
    bundle.tables["scorecards"][0].update(
        edition_label_text=front["title_text"],
        methodology_url=document.url,
        timespan_text=front["period_statements"][0],
        congress_text=front["congress_text"],
        session_text=front["session_text"],
        periods_json=json_column(
            [
                {
                    "occurrence_id": str(i),
                    "kind": "explicit",
                    "period_text": text,
                    "year_text": spec["year"] if "session" in text else None,
                    "congress_text": front["congress_text"],
                    "session_text": front["session_text"] if "session" in text else None,
                    "source_path": path("front", suffix=f"/period_statements/{i}"),
                }
                for i, text in enumerate(front["period_statements"])
            ]
        ),
    )
    for ch in spec["members"]:
        method = key(ch, "printed-method")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front"),
            methodology_id=method,
            chamber_text=ch,
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "source_methodology_statements": front["source_methodology_statements"],
                    "source_senate_methodology_statements": front["senate_methodology_statements"]
                    if ch == "Senate"
                    else [],
                    "source_legend": front["legend"],
                    "source_annotation_statements": front["annotation_statements"],
                    "priority_period_statements": [text for text in front["period_statements"] if "cosponsor" in text],
                    "priority_legislation": [r for r in front["priority_legislation"] if r["chamber_text"] == ch],
                    "source_column_titles": data["column_titles"][ch],
                    "source_observations": data["source_observations"],
                    "source_formula_text": None,
                    "source_weight_text": None,
                }
            ),
        )
        bundle.add(
            "scorecard_metrics",
            document,
            path("front", suffix="/score_label_text"),
            metric_id=ch,
            methodology_id=method,
            name=front["score_label_text"],
            value_unit_text=front["score_unit_text"],
            chamber_text=ch,
            period_text=spec["year"],
            is_primary="true",
        )
    for n, e in enumerate(data["items"]):
        r, ch = e["record"], e["chamber"]
        item, location = key(ch, r["item_number_text"].removesuffix(".")), path("items", n)
        participations = [
            p for p in data["participations"] if p["chamber"] == ch and p["item_number_text"] == r["item_number_text"]
        ]
        refs = _references(r, location, ch, spec, participations)
        bills = {v["bill_citation_text"] for v in refs if "bill_citation_text" in v}
        amendments = {v["amendment_citation_text"] for v in refs if "amendment_citation_text" in v}
        only = r["actions"][0] if len(r["actions"]) == 1 else None
        method = key(ch, "item", r["item_number_text"].removesuffix("."))
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=method,
            chamber_text=ch,
            disclosure_status="explicit",
            methodology_text=json_column(
                {
                    "source_item_number_text": r["item_number_text"],
                    "source_actions": [{k: v for k, v in a.items() if k != "uncertainties"} for a in r["actions"]],
                    "member_names_with_explicit_rules": r["member_names_with_explicit_rules"],
                    "source_grid_participations": participations,
                }
            ),
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=item,
            publisher_item_id=r["item_number_text"],
            title=r["title_text"],
            item_kind_text="Congressional vote topic",
            item_date_text=only["date_text"] if only else None,
            congress_text=spec["congress"],
            session_text=spec["session"],
            chamber_text=ch,
            roll_number_text=only["roll_number_text"].removeprefix("#")
            if only and only["roll_number_text"] is not None
            else None,
            bill_citation_text=next(iter(bills)) if len(bills) == 1 else None,
            amendment_citation_text=next(iter(amendments)) if len(amendments) == 1 else None,
            references_json=json_column(refs),
            publisher_position_text=only["preferred_vote_text"] if only else None,
            position_basis="explicit" if only else None,
            position_source_path=location + "/actions/0/preferred_vote_text" if only else None,
        )
        for p in participations:
            bundle.add(
                "scorecard_metric_items",
                document,
                location + f"/source-grid-column/{p['column_ordinal']}",
                metric_id=ch,
                item_id=item,
                participation_id=key(ch, str(p["column_ordinal"])),
                methodology_id=method,
                publisher_position_text=p["publisher_position_text"],
                position_basis="explicit",
            )
    for n, e in enumerate(data["members"]):
        r, ch = e["record"], e["chamber"]
        location = path("members", n)
        member = key(
            ch,
            str(e["evidence"]["physical_pages"][0]),
            e["evidence"]["json_pointer"],
            r["state_text"],
            *([r["district_text"]] if r["district_text"] else []),
            r["member_name_text"],
        )
        notes = json_column(
            {
                "source_display_name_text": r["source_display_name_text"],
                "source_annotation_text": r["annotation_text"],
                "source_name_is_bold": r["name_is_bold"],
                "source_annotation_statements": front["annotation_statements"]
                if r["annotation_text"] or r["name_is_bold"]
                else [],
            }
        )
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            chamber_text=ch,
            period_text=spec["year"],
            identifiers_json="[]",
            notes_text=notes,
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/score_text",
            publisher_member_key=member,
            metric_id=ch,
            value_text=r["score_text"],
            value_number=decimal_text(r["score_text"]),
            notes_text=notes,
        )
        for p in (p for p in data["participations"] if p["chamber"] == ch):
            token = r["item_results"][str(p["column_ordinal"])]
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + f"/item_results/{p['column_ordinal']}",
                publisher_member_key=member,
                item_id=key(ch, p["item_number_text"].removesuffix(".")),
                metric_id=ch,
                participation_id=key(ch, str(p["column_ordinal"])),
                result_id=key(ch, str(p["column_ordinal"])),
                result_text=token,
                reason_text=LEGEND.get(token),
            )
    repeated = context.read(spec["url"], stage=f"afge:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Every original named row, source percentage, annotation, topic, action and grid cell reconciles reviewed native/semantic facts; original source reread identical",
        declared={
            "physical_pages": spec["pages"],
            "members_by_chamber": spec["members"],
            "members_by_physical_page": spec["member_pages"],
            "publisher_topics_by_chamber": spec["items"],
            "source_grid_action_columns": spec["columns"],
            "source_described_actions": sum(len(e["record"]["actions"]) for e in data["items"]),
            "count_basis": "complete source-defined named populations and original topic/grid scopes; no official membership substitution",
            "grid_topic_mapping_rule_version": "afge2024-reviewed-topic-grid/1",
            "source_native_rendition_observations": data["source_observations"],
        },
    )
