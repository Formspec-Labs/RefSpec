"""Arts Action Fund's 2026 federal PDF, from reviewed semantic source facts."""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "arts-action-2026-qualified-rendered-pdf/1"
INDEX = "https://www.artsactionfund.org/2026-congressional-arts-report-card"
PDF = "https://www.artsactionfund.org/sites/artsactionfund.org/files/2026-09/2026%20Congressional%20Arts%20Report%20Card%20_0.pdf"
HOSTS = ("www.artsactionfund.org",)
SOURCE_SHA256 = "f340c5827f89fef5bb7fddbb58e1b544a1ca52390cee1b7b68d5c4ee1743cfc4"
QUALIFIED_SHA256 = "99e1379cd57c2eed25c30ca252e8d62c6a282acd878ec431eeaa014464e8e3d6"
MEMBER_COUNTS = {"House": 440, "Senate": 100}
ITEM_COUNTS = {"House": 16, "Senate": 9}
POSITIVE_COUNTS = {"House": 251, "Senate": 69}
PAGE_COUNTS = {
    5: 31,
    6: 37,
    7: 31,
    8: 33,
    9: 31,
    10: 29,
    11: 34,
    12: 31,
    13: 34,
    14: 31,
    15: 32,
    16: 33,
    17: 31,
    18: 22,
    21: 22,
    22: 22,
    23: 22,
    24: 22,
    25: 12,
}
EDITION = ScorecardEdition(
    "arts_action", "2026", INDEX, "Congressional Arts Report Card 2026", year="2026", chamber="both"
)
RATINGS = {"single thumbs up", "double thumbs up", "N/A", None}
KINDS = {
    "Nay": "roll call",
    "Yes": "legislative action",
    "Member": "caucus membership",
    "Signatory": "letter signatory",
    "Cosponsor": "cosponsorship",
    "Leadership": "leadership",
}
LEGEND = {
    "✓": "Pro-arts position",
    "x": "Opposing or No action taken",
    "Ø": "Not Voting",
    "o": "Not in office yet, or abstained due to leadership or Appropriations Committee position",
}


def _source(document):
    if document.url != PDF or sha256(document.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("Arts Action Fund 2026 PDF differs from the reviewed original source")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _source(context.read(PDF, stage="arts-action:2026:pdf:list", hosts=HOSTS))
    return (EDITION,)


@dataclass(frozen=True, slots=True)
class ArtsAction2026Reader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        return list_scorecards(context)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value):
    if (
        type(value["physical_page"]) is not int
        or not 1 <= value["physical_page"] <= 25
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or value["schema_version"]
        not in {
            "arts-2026-member-facts/1",
            "arts-2026-full-row-correction/1",
            "arts-2026-indicator-facts/1",
            "arts-2026-leadership-facts/1",
        }
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("Arts Action Fund observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if (
            data["format_version"] != "arts-action-qualified-pdf-2026/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["physical_page_count"] != 25
            or data["member_counts"] != MEMBER_COUNTS
            or data["item_counts"] != ITEM_COUNTS
            or data["member_page_counts"] != {str(p): n for p, n in PAGE_COUNTS.items()}
            or data["source_declared_positive_ratings"] != POSITIVE_COUNTS
            or {r["result_text"]: r["meaning_text"] for r in data["result_definitions"]} != LEGEND
        ):
            raise ValueError
        items = set()
        for e in data["items"]:
            _evidence(e["evidence"])
            r, chamber = e["record"], e["chamber"]
            identifier = r["item_number_text"]
            if (
                chamber not in ITEM_COUNTS
                or not isinstance(identifier, str)
                or not identifier.isdigit()
                or not 1 <= int(identifier) <= ITEM_COUNTS[chamber]
                or (chamber, identifier) in items
                or r["pro_arts_position_text"] not in KINDS
                or not r["title_text"]
                or not r["description_text"]
                or r["congress_text"] not in {None, "118"}
                or (
                    r["roll_number_text"] is not None
                    and (chamber != "House" or identifier != "1" or r["congress_text"] != "118")
                )
            ):
                raise ValueError
            items.add((chamber, identifier))
        if Counter(c for c, _ in items) != ITEM_COUNTS:
            raise ValueError
        identities, counts, pages, positive = set(), Counter(), Counter(), Counter()
        for e in data["members"]:
            _evidence(e["evidence"])
            r, chamber = e["record"], e["chamber"]
            identity = (chamber, r["state_text"], r["district_text"], r["member_name_text"])
            if (
                chamber not in MEMBER_COUNTS
                or identity in identities
                or not r["member_name_text"]
                or not r["state_text"]
                or r["party_text"] not in {"R", "D", "I"}
                or r["published_rating"] not in RATINGS
                or type(r["appropriations_member"]) is not bool
                or (chamber == "Senate" and r["district_text"] is not None)
                or (
                    chamber == "House" and (not isinstance(r["district_text"], str) or not r["district_text"].isdigit())
                )
                or set(r["item_results"]) != {n for c, n in items if c == chamber}
                or any(v not in LEGEND for v in r["item_results"].values())
                or e["evidence"]["physical_page"] not in PAGE_COUNTS
            ):
                raise ValueError
            identities.add(identity)
            counts[chamber] += 1
            pages[e["evidence"]["physical_page"]] += 1
            if r["published_rating"] in {"single thumbs up", "double thumbs up"}:
                positive[chamber] += 1
        if dict(counts) != MEMBER_COUNTS or dict(pages) != PAGE_COUNTS or dict(positive) != POSITIVE_COUNTS:
            raise ValueError
        leadership = set()
        for e in data["leadership"]:
            _evidence(e["evidence"])
            r, chamber = e["record"], e["chamber"]
            if (
                chamber not in MEMBER_COUNTS
                or chamber in leadership
                or r["uncertainties"]
                or not r["leadership_designations"]
            ):
                raise ValueError
            if any(
                not row["designation_text"] or not row["members_text"] or any(not name for name in row["members_text"])
                for row in r["leadership_designations"]
            ):
                raise ValueError
            leadership.add(chamber)
        if leadership != set(MEMBER_COUNTS):
            raise ValueError
        return data
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError(
            "Arts Action Fund qualified facts no longer establish a complete reviewed edition"
        ) from error


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if edition != EDITION:
        raise ScorecardSourceError("Arts Action Fund reader supports only its reviewed 2026 edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError(
            "Arts Action Fund PDF requires pinned reviewed facts and private observation retention"
        )
    data = _qualified(qualified_observations)
    document = context.read(PDF, stage="arts-action:2026:pdf", hosts=HOSTS)
    _source(document)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="arts-action:2026:qualified-observations",
    )

    def path(group, index, suffix=""):
        e = data[group][index]["evidence"]
        return f"pdf:page={e['physical_page']};observation={observation};/{group}/{index}/record{suffix}"

    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="Americans for the Arts Action Fund",
        parser_version=parser_version,
        rendition_rule="complete original federal PDF; reviewed semantic outcomes, every member/action cell and rendered rating icon reconciled; source-declared positive tiers and stable original reread",
        homepage="https://www.artsactionfund.org/",
    )
    bundle.tables["scorecards"][0].update(
        methodology_url=PDF, edition_label_text="September 2026", timespan_text="Notes as of 9/15/26"
    )
    for glyph, meaning in LEGEND.items():
        bundle.add(
            "scorecard_methodologies",
            document,
            "pdf:page=5;legend",
            methodology_id="legend:" + glyph,
            methodology_text=meaning,
            disclosure_status="explicit",
        )
    for i, e in enumerate(data["leadership"]):
        chamber = e["chamber"]
        bundle.add(
            "scorecard_methodologies",
            document,
            path("leadership", i),
            methodology_id=key(chamber, "leadership"),
            chamber_text=chamber,
            methodology_text=json_column(e["record"]),
            methodology_url=PDF,
            disclosure_status="partial",
        )
        bundle.add(
            "scorecard_metrics",
            document,
            "pdf:page=1;table-of-contents",
            metric_id=key(chamber, "arts-grade"),
            name="Arts Grades",
            value_unit_text="tier",
            chamber_text=chamber,
            period_text="2026",
            methodology_id=key(chamber, "leadership"),
            is_primary="true",
        )
    for i, e in enumerate(data["items"]):
        r, chamber = e["record"], e["chamber"]
        location = path("items", i)
        identifier = key(chamber, r["item_number_text"])
        methodology = key(chamber, "indicator", r["item_number_text"])
        references = []
        for kind, field_name in [("bill", "bill_citation_text"), ("roll_call", "roll_number_text")]:
            if r[field_name] is not None:
                references.append(
                    {
                        "occurrence_id": kind,
                        "citation_text": r[field_name],
                        "kind": kind,
                        "source_path": location + "/" + field_name,
                        "congress_text": r["congress_text"],
                        "chamber_text": chamber,
                        field_name: r[field_name],
                    }
                )
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=methodology,
            chamber_text=chamber,
            methodology_text=json_column(
                {
                    "description_text": r["description_text"],
                    "date_text": r["date_text"],
                    "source_result_text": r["result_text"],
                }
            ),
            disclosure_status="explicit",
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            publisher_item_id=r["item_number_text"],
            item_kind_text=KINDS[r["pro_arts_position_text"]],
            title=r["title_text"],
            item_date_text=r["date_text"],
            chamber_text=chamber,
            congress_text=r["congress_text"],
            roll_number_text=r["roll_number_text"],
            bill_citation_text=r["bill_citation_text"],
            references_json=json_column(references),
            publisher_position_text=r["pro_arts_position_text"],
            position_basis="explicit",
            position_source_path=location + "/pro_arts_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            metric_id=key(chamber, "arts-grade"),
            item_id=identifier,
            participation_id="printed-indicator",
            methodology_id=methodology,
            publisher_position_text=r["pro_arts_position_text"],
            position_basis="explicit",
        )
    for i, e in enumerate(data["members"]):
        r, chamber = e["record"], e["chamber"]
        location = path("members", i)
        member_key = key(
            chamber,
            r["state_text"],
            *([r["district_text"]] if r["district_text"] is not None else []),
            r["member_name_text"],
        )
        metric = key(chamber, "arts-grade")
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member_key,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            district=r["district_text"],
            party=r["party_text"],
            period_text="2026",
            identifiers_json="[]",
            notes_text=json_column(
                {"source_notes": r["notes_text"], "appropriations_member": r["appropriations_member"]}
            ),
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/published_rating",
            publisher_member_key=member_key,
            metric_id=metric,
            value_text=r["published_rating"],
        )
        for number, glyph in r["item_results"].items():
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + "/item_results/" + number,
                result_id="printed-cell",
                publisher_member_key=member_key,
                item_id=key(chamber, number),
                metric_id=metric,
                participation_id="printed-indicator",
                result_text=glyph,
                reason_text=LEGEND[glyph],
            )
    repeated = context.read(PDF, stage="arts-action:2026:pdf:reread", hosts=HOSTS)
    _source(repeated)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete original federal PDF; all source member rows, 25 indicator definitions, individual action glyphs and published rating icons reconcile independent original observations; publisher-declared positive tier counts and identical source reread",
        declared={
            "physical_pages": 25,
            "members_by_chamber": MEMBER_COUNTS,
            "members_by_physical_page": PAGE_COUNTS,
            "items_by_chamber": ITEM_COUNTS,
            "source_positive_ratings_by_chamber": POSITIVE_COUNTS,
            "source_blank_ratings": sum(e["record"]["published_rating"] is None for e in data["members"]),
            "source_na_ratings": sum(e["record"]["published_rating"] == "N/A" for e in data["members"]),
            "source_counts_basis": "complete printed grid rows; cover declares positive tier population separately",
        },
    )
