"""National Parks Action Fund's complete historical 2024 PDF scorecard rendition."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "national-parks-action-2024-qualified-semantic/1"
HOSTS = ("drive.usercontent.google.com",)
INDEX = "https://nationalparksaction.org/scorecard/"
DRIVE_ID = "1JGDZy4aagimqgNK8xHwAgiRabE8SVusf"
URL = "https://drive.usercontent.google.com/download?id=" + DRIVE_ID + "&export=download"
SOURCE_SHA256 = "bc0d1185fea6ae2994d86873a8d870ba779169270608e6ff15bd611aa6948a9f"
QUALIFIED_SHA256 = "563f51c4f9cbea4edcdbe578572e8784f3370e4340cba448026eef563b576575"
EDITION = ScorecardEdition(
    "national_parks_action",
    "2024-pdf",
    URL,
    "2024 Congressional Scorecard",
    year="2024",
    congress="118",
    chamber="House",
    is_current=False,
)
PAGE_MEMBERS = dict(enumerate((22, 33, 32, 30, 25, 28, 24, 28, 23, 29, 28, 26, 27, 30, 31, 25), 10))
TOKENS = {
    "Pro-Parks Vote",
    "Anti-Parks Vote",
    "Member Absent or Did Not Vote",
    "Not Applicable (N/A) or Ineligible to Vote",
}
ITEM_IDENTITIES = (
    ("63", "H.R. 21", "Amendment No. 75", "January 27, 2023", 6),
    ("344", "H.R. 3935", "Amendment No. 33", "July 19, 2023", 6),
    ("575", "H.R. 4832", "Amendment No. 74", "November 2, 2023", 7),
    ("580", "H.R. 4832", "Amendment No. 86", "November 2, 2023", 7),
    ("588", "H.R. 4832", "Amendment No. 110", "November 2, 2023", 7),
    ("592", "H.R. 4832", "Amendment No. 116", "November 2, 2023", 8),
    ("597", "H.R. 4832", None, "November 3, 2023", 8),
)


@dataclass(frozen=True, slots=True)
class NationalParksActionReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    listing = context.read(INDEX, stage="scorecards:national_parks_action:listing", hosts=("nationalparksaction.org",))
    if "drive.google.com/file/d/" + DRIVE_ID not in listing.body.decode("utf-8"):
        raise ScorecardSourceError(
            "National Parks publisher no longer links the qualified 2024 PDF; requalification required"
        )
    return (EDITION,)


def _facts(data):
    try:
        if data["format_version"] != "national_parks_action-qualified-source-facts/1" or data["sources"] != {
            "pdf-2024-content": {"sha256": SOURCE_SHA256, "page_count": 28}
        }:
            raise ValueError
        counts, identities = dict.fromkeys(PAGE_MEMBERS, 0), set()
        for entry in data["members"]:
            record, evidence = entry["record"], entry["evidence"]
            page, ordinal = evidence["physical_page"], evidence["source_ordinal"]
            identity = (record["state_text"], record["district_text"], record["member_name_text"])
            if (
                page not in counts
                or ordinal != counts[page]
                or identity in identities
                or entry["chamber"] != "House"
                or evidence["source_label"] != "pdf-2024-content"
                or re.fullmatch(r"[A-Z]{2}|NMI", record["state_text"]) is None
                or re.fullmatch(r"All|\d+", record["district_text"] or "") is None
                or not record["member_name_text"]
                or record["party_text"] not in {"Republican", "Democrat", "Independent"}
                or set(record["results"]) != {str(i) for i in range(1, 8)}
                or any(v not in TOKENS for v in record["results"].values())
                or record["grade_text"] not in {"A", "B", "C", "D", "F", "N/A"}
                or (
                    record["score_text"] != "N/A"
                    and (
                        re.fullmatch(r"\d{1,3}%", record["score_text"]) is None or int(record["score_text"][:-1]) > 100
                    )
                )
                or (record["score_text"] == "N/A") != (record["grade_text"] == "N/A")
            ):
                raise ValueError
            counts[page] += 1
            identities.add(identity)
        if (
            counts != PAGE_MEMBERS
            or len(data["items"]) != 7
            or [e["evidence"]["physical_page"] for e in data["methodology"]] != [3, 4, 8, 11]
        ):
            raise ValueError
        for i, entry in enumerate(data["items"]):
            item, evidence = entry["record"], entry["evidence"]
            roll, bill, amendment, date, page = ITEM_IDENTITIES[i]
            target = (
                "A vote in favor of the amendment is the pro-parks vote."
                if i == 0
                else "A vote against the bill is the pro-parks vote."
                if i == 6
                else "A vote against the amendment is the pro-parks vote."
            )
            if (
                entry["chamber"] != "House"
                or item["publisher_item_key_text"] != str(i + 1)
                or evidence["chart_ordinal"] != i + 1
                or evidence["physical_page"] != page
                or item["source_pages"] != [page]
                or item["roll_number_text"] != roll
                or item["bill_citation_text"] != bill
                or item["amendment_citation_text"] != amendment
                or item["item_date_text"] != date
                or item["item_kind_text"] != "roll_call"
                or not item["title_text"]
                or not item["methodology_text"]
                or item["publisher_position_text"] != target
                or item["position_basis"] != "explicit"
            ):
                raise ValueError
        if any(not e["record"]["methodology_text"] for e in data["methodology"]):
            raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("National Parks semantic facts fail the complete qualified 2024 PDF shape") from None


def _references(item, loc):
    references = []
    for i, ref in enumerate(item["references"]):
        value = {
            "occurrence_id": str(i),
            "kind": ref["kind"],
            "citation_text": ref["citation_text"],
            "source_path": loc + f"/references/{i}",
        }
        if ref["kind"] in {"bill", "amendment"}:
            value["bill_citation_text" if ref["kind"] == "bill" else "amendment_citation_text"] = ref["citation_text"]
        references.append(value)
    return json.dumps(references, ensure_ascii=False)


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("National Parks PDF requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:national_parks_action:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="national_parks_action:qualified-2024-pdf",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="National Parks Action Fund",
        parser_version=parser_version,
        rendition_rule="national-parks-action-complete-2024-downloadable-pdf-historical-roster/1",
        homepage="https://nationalparksaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(session_text="1", methodology_url=URL)
    bundle.use(source, "members_and_scores", "member_results", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}/record"),
            methodology_id=f"source-{i}",
            methodology_text=entry["record"]["methodology_text"],
            methodology_url=URL,
            disclosure_status="explicit: House-only scope, first-session votes, attendance eligibility, denominator, reported grades, exclusions and color legend",
        )
    for metric, title, unit, primary in (("percent", "%", "percent", True), ("grade", "Rating", "grade", False)):
        bundle.metric(
            source,
            key("House", metric),
            title,
            path=path(10, "/score-heading/" + metric),
            chamber="House",
            unit=unit,
            primary=primary,
        )
    for i, entry in enumerate(data["items"]):
        item = entry["record"]
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        item_id = key("House", item["publisher_item_key_text"])
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=item["publisher_item_key_text"],
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            congress_text="118",
            session_text="1",
            chamber_text="House",
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            references_json=_references(item, loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            loc + "/methodology_text",
            methodology_id="item-" + item["publisher_item_key_text"],
            methodology_text=item["methodology_text"],
            methodology_url=URL,
            disclosure_status="explicit original PDF narrative; printed H.R. 4832 differs from publisher API H.R. 4821",
        )
        for metric in ("percent", "grade"):
            bundle.add(
                "scorecard_metric_items",
                source,
                loc,
                metric_id=key("House", metric),
                item_id=item_id,
                participation_id="first-session-118",
                methodology_id="source-1",
                publisher_position_text=item["publisher_position_text"],
                position_basis="explicit",
            )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        identity = key("House", record["state_text"], record["district_text"], record["member_name_text"])
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=record["district_text"],
            party=record["party_text"],
            chamber_text="House",
            notes_text=record["notes_text"] or None,
        )
        for metric, field_name in (("percent", "score_text"), ("grade", "grade_text")):
            value = record[field_name]
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + "/" + field_name,
                metric_id=key("House", metric),
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value) if metric == "percent" else None,
            )
        for ordinal, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + ordinal,
                item_id=key("House", ordinal),
                metric_id=key("House", "percent"),
                participation_id="first-session-118",
                publisher_member_key=identity,
                result_id="publisher-color-legend",
                result_text=value,
            )
    return bundle.finish(
        "Complete publisher-linked 2024 PDF rendition: all historical House records, separately reported percent and grade, seven original vote narratives, eligibility/exclusion methodology and every action cell reconcile against exact embedded source text and vector colors through the printed legend. Source All districts, N/A ratings, names, typos and H.R. 4832 citations remain literal. Publisher online API is a distinct rendition; no inferred Senate ratings, official actions or score reproduction."
    )
