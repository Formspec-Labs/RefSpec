"""NTU's original historical HTML ratings and separately published weighted vote lists.

This names the HTML rendition explicitly. Publisher introductory counts can
disagree with its finite vote list; neither observation supplies invented rows.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from urllib.parse import urljoin

from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, key, soup

parser_version = "ntu-historical-native-html/1"
HOSTS = ("www.ntu.org",)
BASE = "https://www.ntu.org"
INDEX = BASE + "/ratecongress/page/past-congressional-ratings"
# These are measured qualification bounds for the original finite HTML
# renditions, not expectations about the official congressional roster.
REVIEWED = {
    "2017": (100, 440, 91, 198),
    "2018": (100, 437, 37, 166),
    "2019": (100, 436, 43, 153),
    "2020": (101, 435, 17, 78),
    "2021": (100, 434, 85, 121),
    "2022": (100, 435, 75, 172),
}
STATES = frozenset(
    [
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming",
    ]
)


def _literal(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _html(source):
    if b"</html>" not in source.body.lower() or "html" not in (source.response.content_type or "").lower():
        raise ScorecardSourceError("NTU historical source is not a complete HTML response")
    return soup(source)


def _catalog(source):
    document = _html(source)
    if not any("Past Congressional Ratings" in h.get_text(" ", strip=True) for h in document.select("h1")):
        raise ScorecardSourceError("NTU historical archive identity changed")
    entries = {}
    for link in document.select(".rich-text-content a[href]"):
        match = re.fullmatch(
            r"https://www\.ntu\.org/ratecongress/page/ntu-rates-congress-(1st|2nd)-session-of-the-(\d{3})th-congress",
            urljoin(BASE, str(link["href"])),
        )
        label = re.fullmatch(
            r"(\d{4}):\s+(1st|2nd)\s+Session of the (\d{3})th Congress", link.get_text(" ", strip=True)
        )
        year = label[1] if label else None
        if not match or not label or year not in REVIEWED:
            continue
        if label.groups()[1:] != match.groups():
            raise ScorecardSourceError("NTU archive edition text and original URL disagree")
        if year in entries:
            raise ScorecardSourceError("NTU archive repeats a historical edition")
        entries[year] = ScorecardEdition(
            "ntu",
            year + "-html-ratings-items",
            match[0],
            f"NTU Rates Congress: {match[1]} Session of the {match[2]}th Congress",
            year=year,
            congress=match[2],
            chamber="both",
            is_current=False,
        )
    if set(entries) != set(REVIEWED):
        raise ScorecardSourceError("NTU historical archive no longer offers every qualified HTML edition")
    return tuple(entries[year] for year in sorted(entries))


def list_scorecards(context):
    return _catalog(context.read(INDEX, stage="scorecards:ntu-history:listing", hosts=HOSTS))


def _grid(row, width):
    cells = []
    for ordinal, cell in enumerate(row.find_all(["td", "th"], recursive=False), 1):
        try:
            span = int(cell.get("colspan", 1))
            if int(cell.get("rowspan", 1)) != 1 or not 1 <= span <= width:
                raise ValueError
        except (TypeError, ValueError):
            raise ScorecardSourceError("NTU HTML table has an unreviewed merged cell") from None
        cells.extend([(cell.get_text(" ", strip=True), ordinal), *[("", ordinal)] * (span - 1)])
    if len(cells) != width:
        raise ScorecardSourceError("NTU HTML table row width changed")
    return cells


def _ratings(source, edition):
    document = _html(source)
    title = next(
        (h.get_text(" ", strip=True) for h in document.select("h1") if "NTU Rates Congress:" in h.get_text()), ""
    )
    if " ".join(title.split()) != edition.title:
        raise ScorecardSourceError("NTU historical rating response belongs to a different edition")
    root = document.select_one(".rich-text-content")
    tables = root.find_all("table") if root else []
    if len(tables) != 2:
        raise ScorecardSourceError("NTU historical rendition needs its complete Senate and House tables")
    members, aggregates = [], []
    width = 4 if edition.year == "2022" else 3
    for ti, (table, chamber) in enumerate(zip(tables, ["Senate", "House"], strict=True), 1):
        heading = table.find_previous(["h1", "h2", "h3"])
        if heading is None or heading.get_text(" ", strip=True) != chamber:
            raise ScorecardSourceError("NTU historical rating chamber heading changed")
        states, seen_states, closed = [None] * 3, set(), [False] * 3
        for row_number, row in enumerate(table.find_all("tr"), 1):
            grid = _grid(row, 3 * width)
            for column in range(3):
                group = grid[column * width : (column + 1) * width]
                values = [cell[0] for cell in group]
                if not any(values):
                    continue
                names, score, grade = values[:-2], values[-2], values[-1]
                name = " ".join(x for x in names if x)
                path = f"table[{ti}]/tr[{row_number}]/td[{group[0][1]}]"
                if name in STATES and not score and not grade:
                    if name in seen_states:
                        raise ScorecardSourceError("NTU historical table repeats a state heading")
                    states[column], closed[column] = name, False
                    seen_states.add(name)
                    continue
                if name in {"State Average", "Total Average"}:
                    if name == "State Average" and (states[column] is None or closed[column]):
                        raise ScorecardSourceError("NTU historical state average has no unique state group")
                    aggregates.append(
                        {
                            "chamber": chamber,
                            "state": states[column] if name == "State Average" else None,
                            "label": name,
                            "score": score,
                            "grade": grade,
                            "path": path,
                        }
                    )
                    if name == "State Average":
                        closed[column] = True
                    continue
                if not name and score and not grade and re.fullmatch(r"\d+%", score):
                    # The source has isolated percentages with no row label.
                    # Keep their literal empty label and surrounding state;
                    # do not assign them to a member or infer an average.
                    aggregates.append(
                        {
                            "chamber": chamber,
                            "state": states[column],
                            "label": "",
                            "score": score,
                            "grade": grade,
                            "path": path,
                        }
                    )
                    continue
                if states[column] is None or closed[column] or not name:
                    raise ScorecardSourceError("NTU historical member lies outside its source state group")
                if (
                    score
                    and not re.fullmatch(r"(?:\d+%\*{0,2}|N/A|NA)", score)
                    or grade
                    and not re.fullmatch(r"[A-F][+-]?|N/A|NA", grade)
                    or score
                    and score not in {"N/A", "NA"}
                    and int(score.split("%", 1)[0]) > 100
                ):
                    raise ScorecardSourceError("NTU historical rating value has an unreviewed form")
                members.append(
                    {
                        "chamber": chamber,
                        "state": states[column],
                        "name": name,
                        "name_fields": names,
                        "score": score,
                        "grade": grade,
                        "path": path,
                        "score_path": f"table[{ti}]/tr[{row_number}]/td[{group[-2][1]}]",
                        "grade_path": f"table[{ti}]/tr[{row_number}]/td[{group[-1][1]}]",
                    }
                )
        if seen_states != STATES:
            raise ScorecardSourceError("NTU historical table does not contain every reviewed source state group")
    expected = dict(zip(["Senate", "House"], REVIEWED[edition.year][:2], strict=True))
    if Counter(m["chamber"] for m in members) != expected:
        raise ScorecardSourceError("NTU historical member counts differ from the qualified source rendition")
    anonymous = Counter(a["chamber"] for a in aggregates if not a["label"])
    expected_anonymous = {"2019": {"House": 1}, "2020": {"House": 1}, "2022": {"Senate": 1}}.get(edition.year, {})
    if anonymous != expected_anonymous:
        raise ScorecardSourceError("NTU historical unlabeled percentage observations changed")
    links = {urljoin(BASE, str(a["href"])) for a in root.select("a[href]")}
    vote_links = [
        url
        for url in links
        if re.fullmatch(BASE + rf"/ratecongress/page/{edition.year}(?:-ntu)?-rates-congress-vote-list", url)
    ]
    if len(vote_links) != 1:
        raise ScorecardSourceError("NTU historical rating page does not identify one original vote list")
    paragraphs = [
        (f".rich-text-content/{p.name}[{n}]", p.get_text(" ", strip=True))
        for n, p in enumerate(root.find_all(["p", "li"]))
        if not p.find_parent("table") and p.get_text(" ", strip=True)
    ]
    if not paragraphs:
        raise ScorecardSourceError("NTU historical methodology and introductory observations are absent")
    text = root.get_text(" ", strip=True)
    counts = re.search(r"includes (\d+)\s+votes in the Senate and (\d+) votes in the House", text)
    counts2 = re.search(r"A total of (\d+) Senate and (\d+) House votes were selected", text)
    declared_counts = counts or counts2
    declared = {"Senate": int(declared_counts[1]), "House": int(declared_counts[2])} if declared_counts else {}
    return {
        "native_title": title,
        "members": members,
        "aggregates": aggregates,
        "paragraphs": paragraphs,
        "vote_url": vote_links[0],
        "declared_votes": declared,
    }


def _votes(source, edition):
    document = _html(source)
    root = document.select_one(".rich-text-content")
    tables = root.find_all("table") if root else []
    headings = [" ".join(h.get_text(" ", strip=True).split()) for h in document.select("h1")]
    if len(tables) != 1 or not any(edition.year in h and "Vote List" in h for h in headings):
        raise ScorecardSourceError("NTU historical weighted vote list identity or table shape changed")
    rows, votes, seen, finished = tables[0].find_all("tr"), [], set(), {"Senate": False, "House": False}
    start = {"2017": 5, "2018": 2, "2019": 2, "2020": 2, "2021": 2, "2022": 1}[edition.year]
    width = 9 if edition.year == "2018" else 7
    prefix_rows = {
        "2017": [
            ["", "HOUSE", "", "", "", "SENATE", ""],
            [],
            [],
            ["Column1", "Column2", "Column3", "Column4", "Column5", "Column6", "Column7"],
        ],
        "2018": [["", "Senate", "", "", "", "House", ""]],
        "2019": [["House", "", "Senate"]],
        "2020": [["House", "", "Senate"]],
        "2021": [["House Votes", "", "Senate Votes"]],
        "2022": [],
    }
    actual_prefix = [
        [cell.get_text(" ", strip=True) for cell in row.find_all(["td", "th"], recursive=False)]
        for row in rows[: start - 1]
    ]
    if actual_prefix != prefix_rows[edition.year]:
        raise ScorecardSourceError("NTU historical weighted vote list has unreviewed leading rows")
    header = _grid(rows[start - 1], width)
    header_text = [c[0] for c in header]
    groups = (
        (("Senate", (0, 2, 3)), ("House", (5, 6, 8))) if width == 9 else (("House", (0, 1, 2)), ("Senate", (4, 5, 6)))
    )
    for _, positions in groups:
        labels = [header_text[p] for p in positions]
        if not (
            labels[0] in {"Vote Number", "House Vote", "Vote #", "House Roll Call #", "Senate Roll Call #"}
            and labels[1] in {"Taxpayers’ Position", "Taxpayers' Position", "NTU Position"}
            and labels[2] in {"Weight", "NTU Weight"}
        ):
            raise ScorecardSourceError("NTU historical weighted vote headers changed")
    for row_number, row in enumerate(rows[start:], start + 1):
        cells = _grid(row, width)
        used = set()
        for chamber, positions in groups:
            used.update(positions)
            values = [cells[p][0] for p in positions]
            if not any(values):
                finished[chamber] = True
                continue
            vote, target, weight = values
            if (
                finished[chamber]
                or not re.fullmatch(r"(?:[sh]\d{4}-\d+|\d+-\d+|\d+)", vote)
                or target.lower() not in {"yes", "no", "y", "n"}
                or not re.fullmatch(r"[1-9]\d*", weight)
                or (chamber, vote) in seen
            ):
                raise ScorecardSourceError("NTU historical weighted vote row is partial, repeated or unsupported")
            seen.add((chamber, vote))
            code = "s" if chamber == "Senate" else "h"
            # The complete native label always survives. Only an exact source
            # year/chamber prefix is split; e.g. 2019 House `119-7` stays literal.
            prefix = re.fullmatch(rf"(?:{code})?{edition.year}-(\d+)", vote)
            roll = prefix[1] if prefix else vote
            base = f"table[1]/tr[{row_number}]"
            votes.append(
                {
                    "chamber": chamber,
                    "vote": vote,
                    "roll": roll,
                    "target": target,
                    "weight": weight,
                    "path": base + f"/td[{cells[positions[0]][1]}]",
                    "target_path": base + f"/td[{cells[positions[1]][1]}]",
                    "weight_path": base + f"/td[{cells[positions[2]][1]}]",
                }
            )
        if any(cells[p][0] for p in set(range(width)) - used):
            raise ScorecardSourceError("NTU historical weighted vote list has unreviewed extra cells")
    expected = dict(zip(["Senate", "House"], REVIEWED[edition.year][2:], strict=True))
    if Counter(v["chamber"] for v in votes) != expected:
        raise ScorecardSourceError("NTU historical vote list differs from the complete qualified native table")
    return votes


def acquire_scorecard(edition, context):
    catalog = context.read(INDEX, stage="scorecards:ntu-history:archive-start", hosts=HOSTS)
    entries = _catalog(catalog)
    if edition not in entries:
        raise ScorecardSourceError("Selected NTU historical HTML edition is absent or changed")
    source = context.read(edition.source_url, stage="scorecards:ntu-history:ratings-start", hosts=HOSTS)
    facts = _ratings(source, edition)
    vote_source = context.read(facts["vote_url"], stage="scorecards:ntu-history:votes-start", hosts=HOSTS)
    votes = _votes(vote_source, edition)
    vote_end = context.read(facts["vote_url"], stage="scorecards:ntu-history:votes-end", hosts=HOSTS)
    source_end = context.read(edition.source_url, stage="scorecards:ntu-history:ratings-end", hosts=HOSTS)
    archive_end = context.read(INDEX, stage="scorecards:ntu-history:archive-end", hosts=HOSTS)
    if _votes(vote_end, edition) != votes or _ratings(source_end, edition) != facts or _catalog(archive_end) != entries:
        raise ScorecardSourceError("NTU historical edition, vote list or archive changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="National Taxpayers Union",
        parser_version=parser_version,
        rendition_rule="ntu-original-finite-html-ratings-and-observed-weighted-vote-list/1",
        homepage=BASE,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0]["title"] = facts["native_title"]
    bundle.tables["scorecards"][0]["session_text"] = "1" if "1st Session" in edition.title else "2"
    bundle.use(source, "ratings", "methodology")
    bundle.use(vote_source, "observed_weighted_votes")
    bundle.use(catalog, "archive")
    bundle.use(vote_end, "observed_weighted_votes", role="corroboration")
    bundle.use(source_end, "edition", "ratings", "methodology", role="corroboration")
    bundle.use(archive_end, "archive", role="corroboration")
    for ordinal, (path, text) in enumerate(facts["paragraphs"], 1):
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id=key("paragraph", str(ordinal)),
            methodology_text=text,
            disclosure_status="literal original HTML introduction, legend or methodology",
        )
    for ordinal, observation in enumerate(facts["aggregates"], 1):
        bundle.add(
            "scorecard_methodologies",
            source,
            observation["path"],
            methodology_id=key("aggregate", str(ordinal)),
            chamber_text=observation["chamber"],
            cohort_text=observation["state"],
            methodology_text=_literal({k: observation[k] for k in ("label", "score", "grade")}),
            disclosure_status="literal source aggregate; not a member rating",
        )
    for chamber in ("Senate", "House"):
        bundle.metric(
            source, key(chamber, "score"), "Score", path=".rich-text-content", chamber=chamber, unit="percent"
        )
        bundle.metric(
            source,
            key(chamber, "grade"),
            "Grade",
            path=".rich-text-content",
            chamber=chamber,
            unit="grade",
            primary=False,
        )
    occurrences = Counter()
    for member in facts["members"]:
        # A source occurrence is required: abbreviated same-state names do not
        # establish a unique person. No official or publisher ID is invented.
        identity = (member["chamber"], member["state"], member["name"])
        occurrences[identity] += 1
        identifier = key(*identity, str(occurrences[identity]))
        bundle.add(
            "scorecard_members",
            source,
            member["path"],
            publisher_member_key=identifier,
            member_name=member["name"],
            chamber_text=member["chamber"],
            state=member["state"],
            identifiers_json="[]",
            notes_text=_literal(
                {
                    "native_name_fields": member["name_fields"],
                    "native_score_text": member["score"],
                    "native_grade_text": member["grade"],
                }
            ),
        )
        for field_name in ("score", "grade"):
            value = member[field_name]
            if not value:
                continue  # A source blank is preserved in member context, not made into a reported grade.
            number = re.fullmatch(r"(\d+)%\*{0,2}", value) if field_name == "score" else None
            bundle.add(
                "scorecard_member_ratings",
                source,
                member[field_name + "_path"],
                metric_id=key(member["chamber"], field_name),
                publisher_member_key=identifier,
                value_text="N/A" if value == "NA" else value,
                value_number=number[1] if number else None,
            )
    session = bundle.tables["scorecards"][0]["session_text"]
    for vote in votes:
        identifier = key(vote["chamber"], vote["vote"])
        reference = {
            "occurrence_id": "native-roll",
            "kind": "roll_call",
            "citation_text": vote["vote"],
            "source_path": vote["path"],
            "congress_text": edition.congress,
            "chamber_text": vote["chamber"],
            "session_text": session,
            "roll_number_text": vote["roll"],
        }
        bundle.add(
            "scorecard_items",
            vote_source,
            vote["path"],
            item_id=identifier,
            publisher_item_id=vote["vote"],
            item_kind_text="roll call",
            congress_text=edition.congress,
            chamber_text=vote["chamber"],
            session_text=session,
            roll_number_text=vote["roll"],
            references_json=_literal([reference]),
            publisher_position_text=vote["target"],
            position_basis="explicit",
            position_source_path=vote["target_path"],
        )
        bundle.add(
            "scorecard_metric_items",
            vote_source,
            vote["weight_path"],
            metric_id=key(vote["chamber"], "score"),
            item_id=identifier,
            participation_id="weighted-vote",
            publisher_position_text=vote["target"],
            position_basis="explicit",
            weight_text=vote["weight"],
            weight_number=vote["weight"],
            counts_toward_metric="true",
        )
    return bundle.finish(
        "Complete named original HTML rendition: every reviewed state group and source member occurrence, "
        "reported score/grade and finite native weighted vote-list row is parsed; complete rereads agree. "
        "Introductory vote totals are separate literal observations: differences from the native list remain "
        "unresolved, and no complete full-edition item methodology or member-action grid is claimed.",
        declared={"introductory_vote_counts": facts["declared_votes"]},
    )
