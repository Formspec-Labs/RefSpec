"""Complete publisher-native Parks API detail arrays, including sponsorship and neutral actions."""

from __future__ import annotations

import json
import re
from dataclasses import replace
from hashlib import sha256

from spicy_docs.sources.scorecards import national_parks_action_api as native
from spicy_docs.sources.scorecards.common import Bundle, ScorecardSourceError, decimal_text, key

parser_version = "national-parks-action-native-api-details/1"
SPONSOR_FIELDS = {"billID", "stateBillID", "billName", "billSummary", "sponsorType", "primarySponsor"}


def _action_key(kind, facts):
    # JSON object property order is presentation, not source action identity.
    canonical = json.dumps(facts, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return kind + ":" + sha256(canonical.encode()).hexdigest()


def _edition(card):
    return replace(native._edition(card), edition_id="api-details:" + card["scorecardID"])


def list_scorecards(context):
    source = context.read(native.BASE + "bills/", stage="scorecards:parks-api-details:listing", hosts=native.HOSTS)
    return tuple(_edition(entry["scorecard"]) for entry in native._catalog(source))


def _details(source, bills):
    """Accept only finite native arrays with reviewed vote and sponsorship field shapes."""
    data = native._json(source)
    try:
        if (
            data["statusCode"] != "200"
            or data["message"] != "Success"
            or not isinstance(data["billVotes"], list)
            or not isinstance(data["sponsoredBills"], list)
        ):
            raise ValueError
        ids = {bill["billID"] for bill in bills}
        for vote in data["billVotes"]:
            if (
                set(vote) != native.VOTE_FIELDS
                or not all(isinstance(v, str) for v in vote.values())
                or vote["billID"] not in ids
                or not vote["stateBillID"]
                or not vote["motion"]
                or not vote["vote"]
                or re.fullmatch(r"-?\d+(?:\.\d+)?", vote["voteRating"]) is None
            ):
                raise ValueError
        for sponsor in data["sponsoredBills"]:
            if (
                set(sponsor) != SPONSOR_FIELDS
                or not all(isinstance(v, str) for k, v in sponsor.items() if k != "primarySponsor")
                or not isinstance(sponsor["primarySponsor"], bool)
                or sponsor["billID"] not in ids
                or not sponsor["stateBillID"]
                or not sponsor["billName"]
                or sponsor["sponsorType"] not in {"primary sponsor", "cosponsor"}
            ):
                raise ValueError
        return data["billVotes"], data["sponsoredBills"]
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("National Parks detail arrays have incomplete or unreviewed native fields") from None


def _vote(bundle, source, member_key, vote, ordinal, action_ids):
    path = f"/billVotes/{ordinal}"
    facts = {k: v for k, v in vote.items() if k != "vote"}
    item_id = _action_key("native-vote", facts)
    if item_id not in action_ids:
        action_ids.add(item_id)
        nomination = vote["stateBillID"].startswith("PN")
        roll = re.search(r"\bRC#\s*(\d+)\b", vote["motion"])
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item_id,
            item_kind_text="publisher_vote",
            title=vote["billName"] + " — " + vote["motion"],
            congress_text=bundle.edition.congress,
            item_date_text=vote["voteDate"],
            roll_number_text=roll[1] if roll else None,
            bill_citation_text=None if nomination else vote["stateBillID"],
            references_json=native._reference(vote["stateBillID"], path + "/stateBillID"),
            publisher_position_text=vote["comment"] or None,
            position_basis="explicit" if vote["comment"] else None,
            position_source_path=path + "/comment" if vote["comment"] else None,
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id=item_id,
            methodology_text=native._literal_json(facts),
            methodology_url=source.url,
            disclosure_status="literal native action metadata including signed voteRating; neutral and UI-hidden records retained; metric participation, legislative chamber and session remain unstated",
        )
    # The detail endpoint also reports neutral/hidden actions. Do not assign every action to vote_index.
    bundle.add(
        "scorecard_member_item_results",
        source,
        path + "/vote",
        item_id=item_id,
        publisher_member_key=member_key,
        result_id="vote:" + str(ordinal),
        result_text=vote["vote"],
        action_text=vote["vote"],
    )


def _sponsorship(bundle, source, member_key, sponsor, ordinal, action_ids):
    path = f"/sponsoredBills/{ordinal}"
    facts = {k: v for k, v in sponsor.items() if k not in {"sponsorType", "primarySponsor"}}
    item_id = _action_key("native-sponsorship", facts)
    if item_id not in action_ids:
        action_ids.add(item_id)
        nomination = sponsor["stateBillID"].startswith("PN")
        bundle.add(
            "scorecard_items",
            source,
            path,
            item_id=item_id,
            item_kind_text="publisher_sponsorship",
            title=sponsor["billName"],
            congress_text=bundle.edition.congress,
            bill_citation_text=None if nomination else sponsor["stateBillID"],
            references_json=native._reference(sponsor["stateBillID"], path + "/stateBillID"),
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path,
            methodology_id=item_id,
            methodology_text=native._literal_json(facts),
            methodology_url=source.url,
            disclosure_status="native sponsored bill metadata; sponsorType and primarySponsor remain member results; source bill catalog rating fields are preserved separately without invented score participation",
        )
    bundle.add(
        "scorecard_member_item_results",
        source,
        path,
        item_id=item_id,
        publisher_member_key=member_key,
        result_id="sponsorship:" + str(ordinal),
        result_text=sponsor["sponsorType"],
        action_text=sponsor["sponsorType"],
        reason_text=native._literal_json({"primarySponsor": sponsor["primarySponsor"]}),
    )


def acquire_scorecard(edition, context):
    directory_source = context.read(
        native.BASE + "legislators/", stage="scorecards:parks-api-details:directory-start", hosts=native.HOSTS
    )
    catalog_source = context.read(
        native.BASE + "bills/", stage="scorecards:parks-api-details:catalog-start", hosts=native.HOSTS
    )
    styles_source = context.read(
        native.BASE + "styles/", stage="scorecards:parks-api-details:styles-start", hosts=native.HOSTS
    )
    catalog = native._catalog(catalog_source)
    matches = [(i, entry) for i, entry in enumerate(catalog) if _edition(entry["scorecard"]) == edition]
    if len(matches) != 1:
        raise ScorecardSourceError("Selected Parks detail edition is no longer present exactly once")
    card_index, selected = matches[0]
    card, bills = selected["scorecard"], selected["bills"]
    directory = native._directory(directory_source, catalog)
    styles = native._json(styles_source)
    if (
        not isinstance(styles, dict)
        or styles.get("score_type_to_display") != "voteindex"
        or not styles.get("header_subtxt")
        or not styles.get("info")
    ):
        raise ScorecardSourceError("National Parks API methodology/display settings changed")
    bundle = Bundle(
        edition,
        context,
        catalog_source,
        publisher_name="National Parks Action Fund",
        parser_version=parser_version,
        rendition_rule="parks-api-native-directory-score-fields-complete-vote-and-sponsored-bill-arrays/1",
        homepage="https://nationalparksaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = native.INDEX
    bundle.tables["scorecards"][0].update(
        published_at_text=card["createDate"], updated_at_text=card["updateDate"], methodology_url=styles_source.url
    )
    bundle.use(directory_source, "native_directory_and_score_fields")
    bundle.use(catalog_source, "bill_catalog")
    bundle.use(styles_source, "methodology")
    bundle.add(
        "scorecard_methodologies",
        styles_source,
        "/",
        methodology_id="publisher-api-settings",
        methodology_text=native._literal_json(styles),
        methodology_url=styles_source.url,
        disclosure_status="explicit native API configuration; UI grade, lifetime, rounding and attendance transformations are not native published scores in this rendition",
    )
    for metric in native.METRICS:
        bundle.metric(directory_source, metric, metric, path="/score_sets/" + metric, primary=metric == "vote_index")
    for bill_index, bill in enumerate(bills):
        native._catalog_item(bundle, catalog_source, bill, card_index, bill_index, edition.congress)
    expected = vote_count = sponsor_count = 0
    action_ids = set()
    for index, member in enumerate(directory):
        member_key, path = key("native-directory", member["id"]), f"/{index}"
        bundle.add(
            "scorecard_members",
            directory_source,
            path,
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            member_name=member["first_name"] + " " + member["last_name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["sub_district"],
            party=member["party"],
            notes_text=native._literal_json(
                {k: member[k] for k in ("legislatorKey", "legislatorKeySimple", "districtCode")}
            ),
        )
        sets = [(i, score) for i, score in enumerate(member["score_sets"]) if score["id"] == card["scorecardID"]]
        if not sets:
            continue
        expected += 1
        score_index, score = sets[0]
        if score["niceTitle"] != edition.congress + "th":
            raise ScorecardSourceError("National Parks score-set period contradicts its catalog")
        for metric in native.METRICS:
            bundle.add(
                "scorecard_member_ratings",
                directory_source,
                path + f"/score_sets/{score_index}/{metric}",
                metric_id=metric,
                publisher_member_key=member_key,
                value_text=score[metric],
                value_number=decimal_text(score[metric]),
                notes_text=native._literal_json({k: score[k] for k in ("id", "sessionid", "niceTitle", "adjustment")}),
            )
        url = native.BASE + f"legislators/detail/?legislatorId={member['id']}&scorecardId={card['scorecardID']}"
        source = context.read(url, stage="scorecards:parks-api-details:detail-" + member["id"], hosts=native.HOSTS)
        votes, sponsors = _details(source, bills)
        bundle.use(source, "member_detail:" + member["id"])
        vote_count += len(votes)
        sponsor_count += len(sponsors)
        for ordinal, vote in enumerate(votes):
            _vote(bundle, source, member_key, vote, ordinal, action_ids)
        for ordinal, sponsor in enumerate(sponsors):
            _sponsorship(bundle, source, member_key, sponsor, ordinal, action_ids)
    if not expected:
        raise ScorecardSourceError("National Parks period unexpectedly has no native score-set records")
    for label, before, route, group in (
        ("directory", directory_source, "legislators/", "native_directory_and_score_fields"),
        ("catalog", catalog_source, "bills/", "bill_catalog"),
        ("styles", styles_source, "styles/", "methodology"),
    ):
        after = context.read(
            native.BASE + route, stage="scorecards:parks-api-details:" + label + "-end", hosts=native.HOSTS
        )
        if after.body != before.body:
            raise ScorecardSourceError(
                "National Parks API source changed during complete detail enumeration; preserve prior scope"
            )
        bundle.use(after, group, role="corroboration")
    return bundle.finish(
        "Complete native API detail rendition for one publisher catalog period: finite current directory and catalog arrays, declared bill count, every available member-period vote and sponsorship array, and byte-identical directory/catalog/styles rereads. Current directory identities remain beside historical score sets; no complete historical roster, UI grade/lifetime conversion, or undisclosed metric participation is invented. All neutral/hidden actions, source placeholder dates, signed voteRating metadata and primarySponsor booleans remain literal. Any failed detail refuses the entire scope.",
        declared={
            "catalog_bills": len(bills),
            "native_directory_members": len(directory),
            "available_period_score_sets": expected,
            "native_vote_results": vote_count,
            "native_sponsorship_results": sponsor_count,
        },
    )
