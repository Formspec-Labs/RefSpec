"""NTU's qualified 2025 federal PDF, publisher catalog and weighted roll calls.

The catalog supplies publisher identity and its literal context. The PDF supplies
complete ratings and metric chamber scopes; stale catalog chamber labels remain
unchanged. Reviewed private semantic observations are mandatory and hash-pinned.
"""

from __future__ import annotations

import json
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar
from urllib.parse import quote, unquote, urljoin, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
    soup,
    validate_url,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified
from spicy_docs.sources.scorecards.workbooks import literal_sheets

parser_version = "ntu-2025-qualified-pdf-html-xlsx/1"
HOSTS = ("www.ntu.org",)
BASE = "https://www.ntu.org"
INDEX = BASE + "/ratecongress"
CATALOG = BASE + "/ratecongress/legislator/SearchResult/?name=&house=&state="
PDF = BASE + "/library/doclib/2026/05/2025-NTURC.pdf"
WORKBOOK = BASE + "/library/doclib/2026/05/NTURC2025rollcalls.xlsx"
SOURCE_SHA256 = "b684633da390a4f714f2556aa381b9af0556f574a1364b7eff02fe63bd687c52"
QUALIFIED_SHA256 = "ad6798ab2c6b3ed4d292457cf2acf4f602e875d14e4c2439919707dae3b645d7"
EDITION = ScorecardEdition(
    "ntu", "2025", INDEX, "National Taxpayers Union Rates Congress", year="2025", congress="119", chamber="both"
)
CHAMBERS = {"House": "United States House of Representatives", "Senate": "United States Senate"}


def _index(document: SourceDocument):
    html = soup(document)
    links = {urljoin(INDEX, str(a["href"])) for a in html.select("a[href]")}
    text = html.get_text(" ", strip=True)
    counts = re.search(r"A total of (\d+) Senate and (\d+) House votes", text)
    if PDF not in links or WORKBOOK not in links or counts is None or "119th Congress" not in text:
        raise ScorecardSourceError("NTU index no longer declares the qualified 2025 assets and item counts")
    sections = html.select("div.Section0")
    if len(sections) != 2 or "assigned a weight to each roll call" not in sections[1].get_text(" ", strip=True):
        raise ScorecardSourceError("NTU source methodology section changed")
    return {"Senate": int(counts[1]), "House": int(counts[2])}, sections[1].get_text("\n", strip=True)


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context.read(INDEX, stage="ntu:index", hosts=HOSTS))
    return (EDITION,)


@dataclass(frozen=True, slots=True)
class NTUReader:
    """Inject reviewed source facts and an explicit private observation writer."""

    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext):
        return list_scorecards(context)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _qualified(body: bytes):
    if not isinstance(body, bytes) or sha256(body).hexdigest() != QUALIFIED_SHA256:
        raise ScorecardSourceError("NTU semantic observations differ from their reviewed qualification pin")
    try:
        data = json.loads(body)
        if data["format_version"] != "ntu-qualified-2025/1" or data["source_sha256"] != SOURCE_SHA256:
            raise ValueError
        rows = data["members"]
        if not isinstance(rows, list) or not rows:
            raise ValueError
        seen = set()
        for entry in rows:
            record, evidence = entry["record"], entry["evidence"]
            if (
                entry["chamber"] not in CHAMBERS
                or not isinstance(record["name_text"], str)
                or not record["name_text"]
                or not isinstance(record["state_text"], str)
                or not record["state_text"]
                or not re.fullmatch(r"\d+%|N/A", record["score_text"])
                or not re.fullmatch(r"[A-F][+-]?|N/A", record["grade_text"])
                or record["annotation_text"] not in {None, "*", "**"}
                or not 5 <= evidence["physical_page"] <= 15
                or entry["chamber"] != ("Senate" if evidence["physical_page"] <= 8 else "House")
                or not evidence["json_pointer"].startswith("/members/")
                or evidence["schema_version"] != "ntu-2025-source-facts/1"
                or any(not re.fullmatch(r"[0-9a-f]{64}", evidence[k]) for k in ("outcome_sha256", "observation_sha256"))
            ):
                raise ValueError
            identity = entry["chamber"], record["state_text"], record["name_text"]
            if identity in seen:
                raise ValueError
            seen.add(identity)
        if Counter(e["chamber"] for e in rows) != data["member_counts"]:
            raise ValueError
    except (ValueError, TypeError, KeyError, AttributeError):
        raise ScorecardSourceError("NTU qualified PDF roster is incomplete or inconsistent") from None
    return data


def _page(document: SourceDocument, number: int, page_size: int | None = None):
    html = soup(document)
    summaries, tables = html.select("span.pagination-items"), html.select("table.table-block")
    active = html.select("ul.pagination li.active a")
    if len(summaries) != 1 or len(tables) != 1 or len(active) != 1 or active[0].get_text(strip=True) != str(number):
        raise ScorecardSourceError("NTU catalog page identity or table count changed")
    count = re.fullmatch(r"Items (\d+) - (\d+) of (\d+)", summaries[0].get_text(strip=True))
    if count is None:
        raise ScorecardSourceError("NTU catalog count is missing")
    start, end, total = map(int, count.groups())
    if start != (number - 1) * (page_size or end) + 1 or not start <= end <= total:
        raise ScorecardSourceError("NTU catalog page range is incomplete")
    rows = tables[0].find_all("tr", recursive=False)
    if not rows or [n.get_text(strip=True) for n in rows[0].find_all("th", recursive=False)] != [
        "Name",
        "Chamber",
        "State",
        "Year",
        "Score",
    ]:
        raise ScorecardSourceError("NTU catalog headers changed")
    result = []
    for index, tr in enumerate(rows[1:], 2):
        cells = tr.find_all("td", recursive=False)
        if len(cells) != 5:
            raise ScorecardSourceError("NTU catalog row has a different field shape")
        links, parties, mobile = (
            cells[0].select("a.linkedname[href]"),
            cells[0].select("span"),
            cells[0].select("#mobileOnly"),
        )
        if len(links) != 1 or len(parties) != 1 or len(mobile) != 1:
            raise ScorecardSourceError("NTU catalog member context is missing")
        href = str(links[0]["href"])
        url = urljoin(BASE, quote(href, safe="/%"))
        validate_url(url, HOSTS)
        path = unquote(urlsplit(url).path)
        state_name, separator, mobile_chamber = mobile[0].get_text(strip=True).rpartition(" - ")
        if not separator and mobile[0].get_text(strip=True) in CHAMBERS:
            state_name, separator, mobile_chamber = "", " - ", mobile[0].get_text(strip=True)
        values = [cell.get_text(strip=True) for cell in cells[1:]]
        if (
            not re.fullmatch(r"/ratecongress/legislator/[^/]+", path)
            or not separator
            or values[0] not in CHAMBERS
            or mobile_chamber != values[0]
            or not re.fullmatch(r"[A-Z]{2}|", values[1])
            or not re.fullmatch(r"\d{4}", values[2])
            or not re.fullmatch(r"\d+(?:\.\d+)?%?|N/A|NA|n/a|n\.a\.", values[3])
            or not links[0].get_text(strip=True)
        ):
            raise ScorecardSourceError("NTU catalog member fields changed")
        result.append(
            {
                "key": path.removeprefix("/ratecongress/legislator/"),
                "href": href,
                "name": links[0].get_text(strip=True),
                "party": parties[0].get_text(strip=True),
                "chamber": values[0],
                "state": values[1],
                "state_name": state_name,
                "year": values[2],
                "score": values[3],
                "path": f"table.table-block/tr[{index}]",
            }
        )
    if len(result) != end - start + 1 or (page_size is not None and len(result) != min(page_size, total - start + 1)):
        raise ScorecardSourceError("NTU catalog rows do not reconcile to the declared page range")
    return result, total


def _catalog(context: ScorecardContext, *, stage: str):
    first = context.read(CATALOG, stage=f"ntu:{stage}:page:1", hosts=HOSTS)
    rows, total = _page(first, 1)
    size = len(rows)
    documents = [(first, rows)]
    for number in range(2, (total + size - 1) // size + 1):
        document = context.read(CATALOG + "&page=" + str(number), stage=f"ntu:{stage}:page:{number}", hosts=HOSTS)
        page, page_total = _page(document, number, size)
        if page_total != total:
            raise ScorecardSourceError("NTU catalog count changed during acquisition")
        rows.extend(page)
        documents.append((document, page))
    if (
        len(rows) != total
        or len({(r["key"], r["year"], r["name"], r["chamber"], r["state"], r["score"]) for r in rows}) != total
    ):
        raise ScorecardSourceError("NTU catalog is incomplete or repeats an identical publisher occurrence")
    return documents, rows, total


def _rollcalls(document: SourceDocument, counts: dict[str, int]):
    sheets = literal_sheets(document.body)
    if set(sheets) != {"Sheet1"}:
        raise ScorecardSourceError("NTU roll-call workbook worksheet layout changed")
    cells = sheets["Sheet1"]
    headers = {
        "A1": "House Roll Call",
        "B1": "NTU Position",
        "C1": "Weight",
        "E1": "Senate Roll Call",
        "F1": "NTU Position",
        "G1": "Weight",
    }
    if any(
        cells.get(c) is None or cells[c].value != value or cells[c].formula is not None for c, value in headers.items()
    ):
        raise ScorecardSourceError("NTU roll-call workbook headers changed")
    if any(
        c.formula is not None
        or (
            c.value not in {None, ""}
            and coordinate not in headers
            and not re.fullmatch(r"[ABCEFG][2-9]\d*|[ABCEFG]1\d+", coordinate)
        )
        for coordinate, c in cells.items()
    ):
        raise ScorecardSourceError("NTU roll-call workbook contains unsupported nonblank cells or formulas")
    result = []
    max_row = max(int(coordinate.lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) for coordinate in cells)
    for chamber, columns in (("House", "ABC"), ("Senate", "EFG")):
        seen = set()
        ended = False
        for number in range(2, max_row + 1):
            values = [cells[c + str(number)].value if c + str(number) in cells else None for c in columns]
            if all(v in {None, ""} for v in values):
                ended = True
                continue
            roll, target, weight = values
            if (
                ended
                or roll is None
                or not re.fullmatch(r"[1-9]\d*", roll)
                or roll in seen
                or target not in {"y", "n"}
                or weight is None
                or decimal_text(weight) is None
                or weight.endswith("%")
            ):
                raise ScorecardSourceError("NTU roll-call rows are partial, repeated or unsupported")
            seen.add(roll)
            result.append(
                {
                    "chamber": chamber,
                    "roll": roll,
                    "target": target,
                    "weight": weight,
                    "row": number,
                    "columns": columns,
                }
            )
        if len(seen) != counts[chamber]:
            raise ScorecardSourceError("NTU roll-call counts do not reconcile to the official index")
    return result


def _normalized(text: str):
    return " ".join(
        "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c)).casefold().split()
    )


def _join(pdf_members, catalog):
    current = [m for m in catalog if m["year"] == "2025"]
    if len(current) != len(pdf_members):
        raise ScorecardSourceError("NTU current catalog does not reconcile to the complete PDF roster")
    used, result = set(), []
    for entry in pdf_members:
        record = entry["record"]
        surname = _normalized(record["name_text"].split(",", 1)[0])
        candidates = [
            m
            for m in current
            if m["state_name"] == record["state_text"]
            and m["score"] == record["score_text"]
            and (_normalized(m["name"]) == surname or _normalized(m["name"]).endswith(" " + surname))
        ]
        if len(candidates) != 1 or candidates[0]["key"] in used:
            raise ScorecardSourceError("NTU publisher renditions do not have an exact unique name/state/score link")
        used.add(candidates[0]["key"])
        result.append((entry, candidates[0]))
    return result


def acquire_scorecard(
    edition: ScorecardEdition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
) -> ScorecardAcquisition:
    if edition != EDITION:
        raise ScorecardSourceError("NTU reader supports only the qualified 2025 federal edition")
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("NTU requires reviewed observations and an explicit private retention callback")
    data = _qualified(qualified_observations)
    index = context.read(INDEX, stage="ntu:index", hosts=HOSTS)
    counts, methodology = _index(index)
    pdf = context.read(PDF, stage="ntu:pdf", hosts=HOSTS)
    observation_id = retain_qualified(
        pdf,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="ntu:qualified-observations",
    )
    workbook = context.read(WORKBOOK, stage="ntu:rollcalls", hosts=HOSTS)
    items = _rollcalls(workbook, counts)
    documents, catalog, total = _catalog(context, stage="catalog")
    joined = _join(data["members"], catalog)
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="National Taxpayers Union",
        parser_version=parser_version,
        rendition_rule="2025 reviewed PDF ratings; literal HTML publisher identities; exact unique source name/state/score join; original XLSX items; all source fields stable reread",
        homepage=BASE,
    )
    bundle.use(index, "methodology")
    bundle.use(pdf, "ratings", "metrics")
    bundle.use(workbook, "items")
    for page, (document, rows) in enumerate(documents, 1):
        bundle.use(document, f"catalog-page:{page}")
    for chamber, chamber_text in CHAMBERS.items():
        bundle.add(
            "scorecard_methodologies",
            index,
            "div.Section0[2]",
            methodology_id=chamber,
            chamber_text=chamber_text,
            methodology_text=methodology,
            methodology_url=INDEX,
            disclosure_status="explicit",
        )
        for metric, name, unit in (("score", "Score", "%"), ("grade", "Grade", "grade")):
            bundle.add(
                "scorecard_metrics",
                pdf,
                f"pdf:pages={'9-15' if chamber == 'House' else '5-8'};observation={observation_id}",
                metric_id=chamber.lower() + ":" + metric,
                name=name,
                value_unit_text=unit,
                chamber_text=chamber_text,
                methodology_id=chamber,
                is_primary="true" if metric == "score" else "false",
            )
    sources = {member["key"]: document for document, rows in documents for member in rows if member["year"] == "2025"}
    disagreements = 0
    for index_number, (entry, member) in enumerate(joined):
        document, record, chamber = sources[member["key"]], entry["record"], entry["chamber"]
        notes = json_column(
            {
                "pdf_name_text": record["name_text"],
                "pdf_state_text": record["state_text"],
                "pdf_chamber_text": CHAMBERS[chamber],
                "publisher_profile_url": urljoin(BASE, quote(member["href"], safe="/%")),
                "rendition_link_rule": "ntu-unique-normalized-name-suffix-state-score/1",
            }
        )
        disagreements += member["chamber"] != chamber
        bundle.add(
            "scorecard_members",
            document,
            member["path"],
            publisher_member_key=member["key"],
            publisher_member_id=member["key"],
            identifiers_json=json_column([{"scheme": "ntu_slug", "value": member["key"]}]),
            member_name=member["name"],
            chamber_text=member["chamber"],
            state=member["state"],
            party=member["party"],
            period_text=member["year"],
            notes_text=notes,
        )
        path = (
            f"pdf:page={entry['evidence']['physical_page']};observation={observation_id};/members/{index_number}/record"
        )
        for metric in ("score", "grade"):
            value = record[metric + "_text"]
            bundle.add(
                "scorecard_member_ratings",
                pdf,
                path + "/" + metric + "_text",
                publisher_member_key=member["key"],
                metric_id=chamber.lower() + ":" + metric,
                value_text=value,
                value_number=decimal_text(value),
                notes_text=record["annotation_text"],
            )
    for item in items:
        chamber, roll, columns, number = item["chamber"], item["roll"], item["columns"], item["row"]
        identifier = key(chamber, roll)
        path = f"xlsx:Sheet1!{columns[0]}{number}"
        position_path = f"xlsx:Sheet1!{columns[1]}{number}"
        bundle.add(
            "scorecard_items",
            workbook,
            path,
            item_id=identifier,
            publisher_item_id=roll,
            item_kind_text="roll call",
            congress_text="119",
            session_text="1",
            chamber_text=chamber,
            roll_number_text=roll,
            references_json=json_column(
                [
                    {
                        "occurrence_id": "roll",
                        "citation_text": roll,
                        "kind": "roll_call",
                        "source_path": path,
                        "congress_text": "119",
                        "session_text": "1",
                        "chamber_text": chamber,
                        "roll_number_text": roll,
                    }
                ]
            ),
            publisher_position_text=item["target"],
            position_basis="explicit",
            position_source_path=position_path,
        )
        bundle.add(
            "scorecard_metric_items",
            workbook,
            f"xlsx:Sheet1!{columns[0]}{number}:{columns[2]}{number}",
            item_id=identifier,
            metric_id=chamber.lower() + ":score",
            participation_id="weighted-vote",
            methodology_id=chamber,
            publisher_position_text=item["target"],
            position_basis="explicit",
            weight_text=item["weight"],
            weight_number=item["weight"],
            counts_toward_metric="true",
        )
    repeated_index = context.read(INDEX, stage="ntu:index:reread", hosts=HOSTS)
    if _index(repeated_index) != (counts, methodology):
        raise ScorecardSourceError("NTU index changed during acquisition")
    bundle.use(repeated_index, role="corroboration")
    for url, original, stage in ((PDF, pdf, "pdf"), (WORKBOOK, workbook, "rollcalls")):
        reread = context.read(url, stage=f"ntu:{stage}:reread", hosts=HOSTS)
        if reread.body != original.body:
            raise ScorecardSourceError("NTU asset changed during acquisition")
        bundle.use(reread, role="corroboration")
    repeated_docs, repeated, repeated_total = _catalog(context, stage="catalog:reread")
    if repeated != catalog or repeated_total != total:
        raise ScorecardSourceError("NTU catalog changed during acquisition")
    for document, _ in repeated_docs:
        bundle.use(document, role="corroboration")
    return bundle.finish(
        "Complete official PDF roster reconciled one-to-one to current-year catalog; every catalog range and final total reconciled; official XLSX reaches complete EOF and reconciles both chamber item counts; full catalog and assets stable reread",
        declared={
            "catalog_rows": total,
            "catalog_unique_profile_links": len({r["key"] for r in catalog}),
            "catalog_latest_year_partitions": dict(sorted(Counter(r["year"] for r in catalog).items())),
            "pdf_members_by_chamber": data["member_counts"],
            "rollcalls_by_chamber": counts,
            "catalog_pdf_chamber_disagreements": disagreements,
            "source_na_scores": sum(e["record"]["score_text"] == "N/A" for e in data["members"]),
        },
    )
