"""Mechanics of the public rds-bt50-scorecard plugin observed on IJM and AFP.

This is not a publisher detector. Explicit adapters supply the publisher, current
edition and original host. API literals are authoritative; browser rounding and
calculated lifetime values are not recreated here.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace
from urllib.parse import urlsplit

from .common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
    soup,
    validate_scorecard_bundle,
)


@dataclass(frozen=True)
class Publisher:
    id: str
    name: str
    homepage: str
    index: str
    native_id: int
    title: str
    parser_version: str
    range_grade_configuration: bool = False
    rendered_api_json: bool = False

    @property
    def host(self):
        return urlsplit(self.index).hostname

    @property
    def api(self):
        return f"https://{self.host}/wp-json/rds-bt50-scorecard/v1/"

    @property
    def edition(self):
        return ScorecardEdition(self.id, str(self.native_id), self.index, self.title, congress="119", chamber="both")


def _object(value, fields):
    if not isinstance(value, dict) or not set(fields) <= value.keys():
        raise ScorecardSourceError("Scorecard API object lost required fields")
    return value


def _list(value):
    if not isinstance(value, list):
        raise ScorecardSourceError("Scorecard API expected a complete array")
    return value


def _id(value):
    if type(value) is not int or value < 1:
        raise ScorecardSourceError("Scorecard API identifier is not a positive integer")
    return str(value)


def _text(value):
    if not isinstance(value, str):
        raise ScorecardSourceError("Scorecard API literal is not text")
    return value


def _number(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ScorecardSourceError("Scorecard API measurement changed type")
    literal = str(value)
    if decimal_text(literal) is None:
        raise ScorecardSourceError("Scorecard API measurement is not a literal decimal")
    return literal


def _read(context, publisher, suffix, rendered=None):
    source = context.read(publisher.api + suffix, stage=f"scorecards:{publisher.id}:{suffix}", hosts=(publisher.host,))
    if source.body.lstrip().startswith(b"<"):
        # A browser DOM is a distinct captured rendition, never substituted raw API bytes.
        media_type = (source.response.content_type or "").split(";", 1)[0].lower()
        if not publisher.rendered_api_json or media_type not in {"", "text/html"}:
            raise ScorecardSourceError("Publisher does not allow this rendered API rendition")
        html = soup(source)
        pres = html.select("body > pre")
        if (
            not source.body.rstrip().endswith(b"</html>")
            or b"</body>" not in source.body
            or b"</pre>" not in source.body
            or len(pres) != 1
            or len(html.select("pre")) != 1
            or len(html.select("body")) != 1
            or html.html is None
            or pres[0].find() is not None
            or html.select("script, iframe, form")
        ):
            raise ScorecardSourceError("Rendered API JSON must be one complete literal pre element")
        for child in html.body.children:
            if child is pres[0]:
                continue
            if getattr(child, "name", None) is None and not str(child).strip():
                continue
            if (
                getattr(child, "name", None) == "div"
                and child.get("class") == ["json-formatter-container"]
                and not child.contents
            ):
                continue
            raise ScorecardSourceError("Rendered API JSON contains additional body content")
        # A transient decoding view reuses the strict JSON parser. Only `source`,
        # with its original DOM and capture identity, is retained or returned.
        view = replace(source, response=replace(source.response, body=pres[0].get_text().encode("utf-8")))
        value = json_data(view)
        if rendered is not None:
            rendered.add(source.capture_id)
        return source, value
    return source, json_data(source)


def _catalog(value, publisher):
    editions = _list(_object(value, ("scorecards",))["scorecards"])
    if not editions:
        raise ScorecardSourceError("Empty scorecard catalog is not deletion")
    first = _object(editions[0], ("scorecard", "bills"))
    info = _object(first["scorecard"], ("scorecardID", "stateCode", "scorecardName", "ratedBills", "publicFlag"))
    if (
        info["scorecardID"] != publisher.native_id
        or info["stateCode"] != "US"
        or info["scorecardName"] != publisher.title
    ):
        raise ScorecardSourceError("Current federal scorecard identity changed; historical scope is unqualified")
    bills = _list(first["bills"])
    if type(info["ratedBills"]) is not int or not bills or len(bills) != info["ratedBills"]:
        raise ScorecardSourceError("Declared rated bill count differs from complete catalog")
    ids = []
    for bill in bills:
        _object(
            bill,
            (
                "billID",
                "stateCode",
                "stateBillID",
                "billName",
                "voteRating",
                "sponsorRating",
                "cosponsorRating",
                "comments",
            ),
        )
        ids.append(_id(bill["billID"]))
        if bill["stateCode"] != "US":
            raise ScorecardSourceError("State bill escaped the federal scorecard")
        for field in ("stateBillID", "billName", "comments"):
            _text(bill[field])
        for field in ("voteRating", "sponsorRating", "cosponsorRating"):
            if _number(bill[field]) is None:
                raise ScorecardSourceError("Bill scoring field is missing")
    if len(set(ids)) != len(ids):
        raise ScorecardSourceError("Scorecard bill catalog repeats identifiers")
    return info, bills


def _members(value, publisher):
    members = _list(value)
    if not members:
        raise ScorecardSourceError("Empty member response cannot establish a complete edition")
    ids, current = set(), []
    for index, member in enumerate(members):
        _object(
            member,
            (
                "id",
                "first_name",
                "last_name",
                "score_sets",
                "chamber",
                "state",
                "sub_district",
                "party",
                "legislatorKey",
                "legislatorKeySimple",
            ),
        )
        identity = _id(member["id"])
        if identity in ids:
            raise ScorecardSourceError("Repeated publisher member identity")
        ids.add(identity)
        scores = _list(member["score_sets"])
        score_ids = [_id(_object(s, ("id",))["id"]) for s in scores]
        if len(set(score_ids)) != len(score_ids):
            raise ScorecardSourceError("Repeated member score-set identity")
        selected = [s for s in scores if s["id"] == publisher.native_id]
        if member["chamber"] not in {"House", "Senate"}:
            raise ScorecardSourceError("Member roster does not identify a federal chamber")
        for field in (
            "first_name",
            "last_name",
            "state",
            "sub_district",
            "party",
            "legislatorKey",
            "legislatorKeySimple",
        ):
            _text(member[field])
        if not selected:
            current.append((index, member, None))
            continue  # Preserve the public ungraded member, without a zero rating.
        score = _object(
            selected[0],
            ("sessionid", "niceTitle", "score", "vote_index", "presence_score", "possible_score", "adjustment"),
        )
        if score["sessionid"] != 959 or score["niceTitle"] != "119th" or member["chamber"] not in {"House", "Senate"}:
            raise ScorecardSourceError("Member score set does not identify current federal scope")
        if score["adjustment"] != []:
            raise ScorecardSourceError("Nonempty publisher adjustment ledger is an unsupported source shape")
        for field in (
            "first_name",
            "last_name",
            "state",
            "sub_district",
            "party",
            "legislatorKey",
            "legislatorKeySimple",
        ):
            _text(member[field])
        for field in ("score", "vote_index", "presence_score", "possible_score"):
            _number(score[field])
        current.append((index, member, score))
    if not any(score is not None for _, _, score in current):
        raise ScorecardSourceError("No members have the selected current score set")
    return current


def _styles(value, publisher):
    _object(
        value,
        (
            "loggedIn",
            "hiddenLegislatorIds",
            "score_type_to_display",
            "hideMostRecentScorecardScores",
            "displayLifetimeScoreAsPrimaryScore",
            "info",
        ),
    )
    if (
        value["loggedIn"] != "0"
        or value["hiddenLegislatorIds"] != []
        or value["hideMostRecentScorecardScores"] is not False
        or value["displayLifetimeScoreAsPrimaryScore"] is not False
        or value["score_type_to_display"] not in {"voteindex", "totalscore"}
    ):
        raise ScorecardSourceError("Publisher public-display scope or primary score configuration changed")
    if value.get("dispayRangeLettergrades") is not publisher.range_grade_configuration:
        raise ScorecardSourceError("Publisher grade configuration changed from the qualified API rendition")
    if publisher.range_grade_configuration:
        configurations = _list(value.get("rangeConfigurations"))
        if len(configurations) != 1:
            raise ScorecardSourceError("Publisher default grade configuration scope changed")
        configuration = _object(
            configurations[0], ("scorecardId", "rangeSplits", "lettergrades", "dispayRangeLettergrades")
        )
        if configuration["scorecardId"] is not None or configuration["dispayRangeLettergrades"] is not True:
            raise ScorecardSourceError("Publisher default grade configuration identity changed")
        thresholds = _list(configuration["rangeSplits"])
        labels = _list(configuration["lettergrades"])
        if not thresholds or len(labels) != len(thresholds) + 1:
            raise ScorecardSourceError("Publisher grade thresholds and labels are incomplete")
        for threshold in thresholds:
            if _number(threshold) is None:
                raise ScorecardSourceError("Publisher grade threshold is missing")
        if any(not _text(label) for label in labels):
            raise ScorecardSourceError("Publisher grade label is empty")
    _text(value["info"])
    return value


def _site(context, publisher):
    index = context.read(publisher.index, stage=f"scorecards:{publisher.id}:index", hosts=(publisher.host,))
    html = soup(index)
    app = html.select_one('#scorecard-app[data-loggedin="false"]')
    scripts = [html.select_one(f"script#rds-bt50-scorecard-{name}-js[src]") for name in ("app", "common")]
    if app is None or any(script is None for script in scripts):
        raise ScorecardSourceError("Publisher public scorecard application disappeared")
    documents = []
    for name, script in zip(("app", "common"), scripts, strict=True):
        document = context.read(
            script["src"], stage=f"scorecards:{publisher.id}:script-{name}", hosts=(publisher.host,)
        )
        documents.append(document)
    if any(
        marker not in documents[0].body
        for marker in (
            b"scorecards.slice(0,1)",
            b"e.slice(0,this.state.page*this.state.pageSize)",
            b"billVotes",
            b"sponsoredBills",
        )
    ):
        raise ScorecardSourceError("Publisher application catalog/pagination behavior changed")
    if any(
        marker not in documents[1].body
        for marker in (
            b'baseURL:"/wp-json/rds-bt50-scorecard/v1/"',
            b'i.get("legislators")',
            b'i.get("bills")',
            b'i.get("styles")',
            b"legislators/detail/?legislatorId=",
        )
    ):
        raise ScorecardSourceError("Publisher application API routes changed")
    return index, documents


def list_current(context, publisher):
    _site(context, publisher)
    _, catalog = _read(context, publisher, "bills")
    _catalog(catalog, publisher)
    _, settings = _read(context, publisher, "styles")
    _styles(settings, publisher)
    return (publisher.edition,)


def acquire_current(edition, context, publisher):
    if edition != publisher.edition:
        raise ScorecardSourceError("Only the observed current federal edition is supported")
    index, scripts = _site(context, publisher)
    rendered = set()
    bill_source, catalog = _read(context, publisher, "bills", rendered)
    info, bills = _catalog(catalog, publisher)
    member_source, raw_members = _read(context, publisher, "legislators", rendered)
    members = _members(raw_members, publisher)
    style_source, raw_style = _read(context, publisher, "styles", rendered)
    settings = _styles(raw_style, publisher)
    bundle = Bundle(
        edition,
        context,
        bill_source,
        publisher_name=publisher.name,
        parser_version=publisher.parser_version,
        rendition_rule="rds-bt50-api-literals-not-browser-rounding/1",
        homepage=publisher.homepage,
    )
    bundle.use(bill_source, "bill_catalog")
    bundle.use(member_source, "member_scores")
    bundle.use(style_source, "methodology")
    bundle.use(index, "public_application")
    for number, script in enumerate(scripts):
        bundle.use(script, f"application_behavior_{number}")
    bundle.tables["scorecards"][0].update(
        updated_at_text=info.get("updateDate"), published_at_text=info.get("createDate")
    )
    bundle.add(
        "scorecard_methodologies",
        style_source,
        "$.info",
        methodology_id="publisher-info",
        methodology_text=settings["info"],
        disclosure_status="API literals; browser rounding and calculated lifetime values are outside this rendition",
    )
    if publisher.range_grade_configuration:
        bundle.add(
            "scorecard_methodologies",
            style_source,
            "$.rangeConfigurations",
            methodology_id="publisher-grade-configuration",
            methodology_text=json.dumps(settings["rangeConfigurations"], ensure_ascii=False),
            disclosure_status="Publisher range thresholds and grade labels retained; browser grade calculation is outside this API-literal rendition",
        )
    primary = "vote_index" if settings["score_type_to_display"] == "voteindex" else "score"
    fields = ("score", "vote_index", "presence_score", "possible_score")
    for field in fields:
        bundle.metric(member_source, field, field, path=f"$[*].score_sets[*].{field}", primary=field == primary)
    for offset, member, score in members:
        member_id = _id(member["id"])
        path = f"$[{offset}]"
        identifiers = [{"scheme": field, "value": member[field]} for field in ("legislatorKey", "legislatorKeySimple")]
        bundle.add(
            "scorecard_members",
            member_source,
            path,
            publisher_member_key=member_id,
            publisher_member_id=member_id,
            member_name=member["first_name"] + " " + member["last_name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["sub_district"],
            party=member["party"],
            identifiers_json=json.dumps(identifiers),
        )
        for field in fields if score is not None else ():
            literal = _number(score[field])
            bundle.add(
                "scorecard_member_ratings",
                member_source,
                path + f".score_sets[{member['score_sets'].index(score)}].{field}",
                metric_id=field,
                publisher_member_key=member_id,
                value_text=literal,
                value_number=literal,
            )
    bill_map = {_id(b["billID"]): b for b in bills}
    known_items = {}

    def item(
        document,
        path,
        identifier,
        kind,
        bill,
        *,
        target=None,
        target_field="voteRating",
        date=None,
        motion=None,
        chamber=None,
    ):
        references = []
        for field, reference_kind in (("referenceUrl", "url"), ("referenceUrlText", "title")):
            literal = bill.get(field)
            if literal is not None:
                _text(literal)
            if literal:
                references.append(
                    {
                        "occurrence_id": field,
                        "citation_text": literal,
                        "kind": reference_kind,
                        "source_path": path + "." + field,
                    }
                )
        value = {
            "item_id": identifier,
            "publisher_item_id": _id(bill["billID"]),
            "item_kind_text": kind,
            "title": motion or bill["billName"],
            "bill_citation_text": bill["stateBillID"],
            "congress_text": "119",
            "chamber_text": chamber,
            "item_date_text": date,
            "references_json": json.dumps(references),
            "roll_number_text": (
                re.search(r"RC# (\d+)$", motion).group(1) if motion and re.search(r"RC# (\d+)$", motion) else None
            ),
        }
        signature = {**value, "weight": target, "weight_field": target_field}
        signature["references_json"] = [(r["kind"], r["citation_text"]) for r in references]
        if identifier in known_items:
            if known_items[identifier] != signature:
                raise ScorecardSourceError("Member detail disagrees on shared item fields")
            return
        known_items[identifier] = signature
        bundle.add("scorecard_items", document, path, **value)
        if kind == "bill":
            return
        bundle.add(
            "scorecard_metric_items",
            document,
            path + "." + target_field,
            metric_id=primary,
            item_id=identifier,
            participation_id="source-item",
            weight_text=target,
            weight_number=target,
        )

    for offset, bill in enumerate(bills):
        identifier = key("bill", _id(bill["billID"]))
        path = f"$.scorecards[0].bills[{offset}]"
        item(bill_source, path, identifier, "bill", bill)
        for field in ("voteRating", "sponsorRating", "cosponsorRating"):
            literal = _number(bill[field])
            bundle.add(
                "scorecard_metric_items",
                bill_source,
                path + "." + field,
                metric_id=primary,
                item_id=identifier,
                participation_id=field,
                weight_text=literal,
                weight_number=literal,
            )
    details = []
    for _, member, _ in members:
        member_id = _id(member["id"])
        suffix = f"legislators/detail/?legislatorId={member_id}&scorecardId={publisher.native_id}"
        document, raw = _read(context, publisher, suffix, rendered)
        _object(raw, ("statusCode", "message", "billVotes", "sponsoredBills"))
        if raw["statusCode"] != 200 or raw["message"] != "Success":
            raise ScorecardSourceError("Publisher member detail did not succeed")
        bundle.use(document, "member_actions_" + member_id)
        seen = set()
        for field in ("billVotes", "sponsoredBills"):
            for offset, action in enumerate(_list(raw[field])):
                _object(action, ("billID", "stateBillID", "billName"))
                billid = _id(action["billID"])
                if billid not in bill_map or action["stateBillID"] != bill_map[billid]["stateBillID"]:
                    raise ScorecardSourceError("Detail action is outside selected bill catalog")
                path = f"$.{field}[{offset}]"
                if field == "billVotes":
                    _object(action, ("motion", "voteDate", "voteRating", "vote"))
                    motion, date = _text(action["motion"]), _text(action["voteDate"])
                    target = _number(action["voteRating"])
                    identifier = key("vote", billid, member["chamber"], date, motion)
                    item(
                        document,
                        path,
                        identifier,
                        "roll_call",
                        action,
                        target=target,
                        date=date,
                        motion=motion,
                        chamber=member["chamber"],
                    )
                    result = _text(action["vote"])
                else:
                    _object(action, ("sponsorType", "primarySponsor"))
                    result = _text(action["sponsorType"])
                    if (
                        result not in ("primary sponsor", "cosponsor")
                        or type(action["primarySponsor"]) is not bool
                        or action["primarySponsor"] != (result == "primary sponsor")
                    ):
                        raise ScorecardSourceError("Publisher sponsorship identity changed")
                    kind = "sponsorship" if action["primarySponsor"] else "cosponsorship"
                    identifier = key(kind, billid)
                    field_name = "sponsorRating" if action["primarySponsor"] else "cosponsorRating"
                    target = _number(bill_map[billid][field_name])
                    # Sponsorship target is located on the catalog, not inferred from member action.
                    catalog_index = bills.index(bill_map[billid])
                    item(
                        bill_source,
                        f"$.scorecards[0].bills[{catalog_index}]",
                        identifier,
                        kind,
                        bill_map[billid],
                        target=target,
                        target_field=field_name,
                    )
                if identifier in seen:
                    raise ScorecardSourceError("Repeated member action occurrence")
                seen.add(identifier)
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    path,
                    item_id=identifier,
                    publisher_member_key=member_id,
                    result_id=identifier,
                    metric_id=primary,
                    participation_id="source-item",
                    action_text=result,
                    result_text=result,
                    reason_text=action.get("comment"),
                )
        details.append((suffix, raw, document))
    # Every detail and catalog is read twice; UI pagination only slices these complete arrays.
    for suffix, raw, first in details:
        document, repeated = _read(context, publisher, suffix, rendered)
        if repeated != raw:
            raise ScorecardSourceError("Member detail changed during complete snapshot acquisition")
        bundle.use(document, "member_actions_" + suffix.split("legislatorId=")[1].split("&")[0], role="corroboration")
    for suffix, raw, group in (
        ("bills", catalog, "bill_catalog"),
        ("legislators", raw_members, "member_scores"),
        ("styles", raw_style, "methodology"),
    ):
        document, repeated = _read(context, publisher, suffix, rendered)
        if repeated != raw:
            raise ScorecardSourceError("Publisher catalog or display configuration changed during snapshot acquisition")
        bundle.use(document, group, role="corroboration")
    if rendered:
        bundle.rendition_rule = "rds-bt50-api-literals-with-ijm-rendered-pre-json/1"
    result = bundle.finish(
        "Complete observed current federal API edition: publisher app consumes unpaginated member/bill arrays; current score-set membership selected explicitly, declared ratedBills reconciled, all member detail arrays succeeded and repeated unchanged, and entire catalogs/display configuration repeated unchanged. API numeric literals are authoritative; browser-rounded scores and calculated lifetime values are not reproduced.",
        declared={"ratedBills": info["ratedBills"]},
    )
    if rendered:
        prefix = "html:body/pre[1]::json:"
        for rows in result.tables.values():
            for row in rows:
                if row["capture_id"] not in rendered:
                    continue
                row["source_path"] = prefix + row["source_path"]
                if row.get("position_source_path"):
                    row["position_source_path"] = prefix + row["position_source_path"]
                for field in ("references_json", "periods_json"):
                    if row.get(field):
                        occurrences = json.loads(row[field])
                        for occurrence in occurrences:
                            occurrence["source_path"] = prefix + occurrence["source_path"]
                        row[field] = json.dumps(occurrences)
        validate_scorecard_bundle(result.tables)
    return result
