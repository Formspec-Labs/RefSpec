"""Heritage Action's current public scorecard API and complete displayed member catalog.

Historical member URLs are refused: the 118th route was observed returning the current
roster. Item-attached ``score`` is the overall rating, never an item contribution.
"""

from __future__ import annotations

import json
import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    soup,
)

parser_version = "heritage-action-current-119/1"
HOSTS = ("heritageaction.com",)
BASE = "https://heritageaction.com"
EDITION = ScorecardEdition(
    "heritage_action",
    "119",
    BASE + "/scorecard/members/119",
    "Heritage Action Scorecard — 119th Congress",
    congress="119",
    chamber="both",
)


def _members(document):
    html = soup(document)
    node = html.select_one("members-search-results")
    if node is None or not re.search(rb"activeCongressionalSession\s*=\s*119\b", document.body):
        raise ScorecardSourceError("Heritage current edition identity or member component changed")
    try:
        data = json.loads(node[":members"])
    except (KeyError, ValueError) as error:
        raise ScorecardSourceError("Heritage member component is malformed") from error
    required = {"congId", "name", "chamber", "state", "district", "party", "score"}
    if (
        not isinstance(data, list)
        or not data
        or any(
            not isinstance(member, dict)
            or not required <= set(member)
            or any(not isinstance(member[field], str) for field in required - {"district"})
            or (member["district"] is not None and not isinstance(member["district"], str))
            or not member["congId"]
            for member in data
        )
    ):
        raise ScorecardSourceError("Heritage member catalog fields changed")
    if len({m["congId"] for m in data}) != len(data):
        raise ScorecardSourceError("Heritage member catalog is empty or repeated")
    return data


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _members(context.read(EDITION.source_url, stage="scorecards:heritage:listing", hosts=HOSTS))
    return (EDITION,)


def _catalog(document, kind):
    data = json_data(document)
    rows = data.get("data") if isinstance(data, dict) else None
    if not isinstance(rows, list) or not rows:
        raise ScorecardSourceError("Heritage item catalog is empty or malformed")
    if kind == "vote":
        meta = data.get("meta", {})
        if meta.get("total") != len(rows) or meta.get("last_page") != 1 or data.get("links", {}).get("next"):
            raise ScorecardSourceError("Heritage vote catalog pagination is incomplete")
    elif len(rows) >= 25 or set(data) != {"data", "message"} or data.get("message") != "success":
        raise ScorecardSourceError("Heritage cosponsorship catalog may reach the application limit")
    field = "roll_id" if kind == "vote" else "identifier"
    period = "session_title" if kind == "vote" else "session"
    if any(str(row.get(period)) != "119" or not row.get(field) for row in rows):
        raise ScorecardSourceError("Heritage item catalog has a different edition")
    if len({row[field] for row in rows}) != len(rows):
        raise ScorecardSourceError("Heritage item catalog repeats an identity")
    return rows


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("Heritage reader supports only the explicitly qualified current 119th edition")
    primary = context.read(edition.source_url, stage="scorecards:heritage:members", hosts=HOSTS)
    live = _members(primary)
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Heritage Action for America",
        parser_version=parser_version,
        rendition_rule="heritage-live-member-text-api-former-and-items/1",
        homepage=BASE,
    )
    bundle.use(primary, "live_members_and_ratings")
    bundle.metric(primary, "overall", "Score", path="members-search-results/@:members/*/score")
    members = {}
    for position, member in enumerate(live):
        identifier = member["congId"]
        path = f"members-search-results/@:members/{position}"
        bundle.add(
            "scorecard_members",
            primary,
            path,
            publisher_member_key=identifier,
            publisher_member_id=identifier,
            identifiers_json=json_column([{"scheme": "cong_id", "value": identifier}]),
            member_name=member["name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["district"],
            party=member["party"],
        )
        value = member["score"]
        if not isinstance(value, str):
            raise ScorecardSourceError("Heritage displayed score is no longer literal text")
        bundle.add(
            "scorecard_member_ratings",
            primary,
            path + "/score",
            publisher_member_key=identifier,
            metric_id="overall",
            value_text=value,
            value_number=decimal_text(value),
        )
        members[identifier] = (member, value)
    catalogs = []
    for kind, route, parameter, identity_field, groups in (
        ("vote", "votes", "rollId", "roll_id", ("yesBallots", "noBallots", "notVotingBallots")),
        ("cosponsor", "cosponsorships", "identifier", "identifier", ("sponsors", "nonSponsors")),
    ):
        catalog_url = BASE + f"/api/scorecard/{route}?session=119"
        catalog = context.read(catalog_url, stage=f"scorecards:heritage:{route}", hosts=HOSTS)
        rows = _catalog(catalog, kind)
        bundle.use(catalog, kind + "_catalog")
        catalogs.append((catalog_url, catalog, rows, kind))
        for source_item in sorted(rows, key=lambda row: row[identity_field]):
            identity = source_item[identity_field]
            detail_route = "vote" if kind == "vote" else "cosponsorship"
            document = context.read(
                BASE + f"/api/scorecard/{detail_route}?{parameter}={identity}",
                stage=f"scorecards:heritage:{kind}:detail",
                hosts=HOSTS,
            )
            bundle.use(document, "item:" + identity)
            response = json_data(document)
            if not isinstance(response, dict):
                raise ScorecardSourceError("Heritage detail response is not an object")
            data = response.get("data")
            period_field = "session_title" if kind == "vote" else "session"
            if (
                not isinstance(data, dict)
                or data.get(identity_field) != identity
                or str(data.get(period_field)) != "119"
            ):
                raise ScorecardSourceError("Heritage detail identity does not match its catalog")
            if any(data.get(field) != source_item.get(field) for field in ("title", "chamber", period_field)):
                raise ScorecardSourceError("Heritage detail and catalog disagree")
            observed_groups = {k for k, v in data.items() if isinstance(v, dict) and "data" in v}
            if observed_groups != set(groups):
                raise ScorecardSourceError("Heritage member result groups changed")
            position_field = "preferred_vote" if kind == "vote" else "sponsor_position"
            bundle.add(
                "scorecard_items",
                document,
                "$.data",
                item_id=identity,
                publisher_item_id=identity,
                item_kind_text="roll call" if kind == "vote" else "cosponsorship",
                title=data["title"],
                item_date_text=data.get("date", data.get("introduced_date")),
                congress_text=data[period_field],
                chamber_text=data["chamber"],
                bill_citation_text=data.get("number"),
                publisher_position_text=data.get(position_field),
                position_basis="explicit",
                position_source_path="$.data." + position_field,
            )
            bundle.add(
                "scorecard_metric_items",
                document,
                "$.data",
                metric_id="overall",
                item_id=identity,
                participation_id="scorecard",
                publisher_position_text=data.get(position_field),
                position_basis="explicit",
            )
            seen = set()
            for group in groups:
                records = data[group]["data"]
                if not isinstance(records, list):
                    raise ScorecardSourceError("Heritage member result group is malformed")
                for index, member in enumerate(records):
                    member_id = member["cong_id"]
                    path = f"$.data.{group}.data[{index}]"
                    if not member_id or member_id in seen:
                        raise ScorecardSourceError("Heritage item repeats a member across result groups")
                    seen.add(member_id)
                    raw_score = member.get("score")
                    if raw_score is not None and (isinstance(raw_score, bool) or not isinstance(raw_score, (str, int))):
                        raise ScorecardSourceError("Heritage API score changed representation")
                    value = None if raw_score is None else str(raw_score)
                    if member_id in members:
                        previous, reported = members[member_id]
                        if reported != value and not (reported == "N/A" and value is None):
                            raise ScorecardSourceError("Heritage overall scores changed during acquisition")
                        if member["chamber"] != previous["chamber"] or member["state"] != previous["state"]:
                            raise ScorecardSourceError("Heritage member context changed during acquisition")
                    else:
                        bundle.add(
                            "scorecard_members",
                            document,
                            path,
                            publisher_member_key=member_id,
                            publisher_member_id=member_id,
                            member_name=member["name"],
                            identifiers_json=json_column([{"scheme": "cong_id", "value": member_id}]),
                            chamber_text=member["chamber"],
                            state=member["state"],
                            district=member["district"],
                            party=member["party"],
                        )
                        bundle.add(
                            "scorecard_member_ratings",
                            document,
                            path + ".score",
                            metric_id="overall",
                            publisher_member_key=member_id,
                            value_text=value,
                            value_number=decimal_text(value),
                        )
                        members[member_id] = (member, value)
                    bundle.add(
                        "scorecard_member_item_results",
                        document,
                        path,
                        item_id=identity,
                        publisher_member_key=member_id,
                        result_id="reported",
                        metric_id="overall",
                        participation_id="scorecard",
                        result_text=group,
                    )
            if not seen:
                raise ScorecardSourceError("Heritage item has no disclosed member results")
    for url, document, rows, kind in catalogs:
        repeat = context.read(url, stage="scorecards:heritage:catalog-recheck", hosts=HOSTS)
        if _catalog(repeat, kind) != rows:
            raise ScorecardSourceError("Heritage item catalog changed during acquisition")
        bundle.use(repeat, kind + "_catalog", role="corroboration")
    repeat = context.read(edition.source_url, stage="scorecards:heritage:members-recheck", hosts=HOSTS)
    if _members(repeat) != live:
        raise ScorecardSourceError("Heritage member catalog changed during acquisition")
    bundle.use(repeat, "live_members_and_ratings", role="corroboration")
    return bundle.finish(
        "Current member catalog and terminal API catalogs repeated unchanged; every listed item "
        "acquired with disjoint complete reported groups; all attached overall scores reconciled. "
        "Scope is the publisher's observed 119th catalog, including former members in item groups.",
        declared={"votes": len(catalogs[0][2])},
    )
