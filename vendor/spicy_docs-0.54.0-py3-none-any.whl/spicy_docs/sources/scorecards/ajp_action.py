"""AJP Action's original 2026 workbook, including each published worksheet metric.

Cached workbook scores are publisher results, never calculations by this reader.
Bill headers do not identify an official roll call or a particular Congress.
"""

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)
from spicy_docs.sources.scorecards.workbooks import WorkbookCell, column, literal_sheets

parser_version = "ajp-action-2026-literal-workbook/2"
INDEX = "https://ajpaction.org/scorecard2026/"
WORKBOOK = "https://ajpaction.org/wp-content/uploads/2026/05/AJP-Action-Congressional-Scorecard-2026.xlsx"
HOSTS = ("ajpaction.org",)
EDITION = ScorecardEdition(
    "ajp_action", "2026", INDEX, "AJP Action Congressional Scorecard 2026", year="2026", chamber="both"
)
PREFIX = ("Name", "State", "Party", "Chamber", "First Elected")
SHEETS = ("All Members", "House", "Senate")
EMPTY = WorkbookCell(None, None)
CITATION = re.compile(r"^([HS]\s*\.?\s*(?:J\s*\.?\s*Res|Res|R)\s*\.?\s*\d+)", re.IGNORECASE)


def _periods(methods):
    observations = []
    for coordinate, text in methods:
        chamber = (
            "House"
            if text.startswith("House Letter Grades")
            else "Senate"
            if text.startswith("Senate grades")
            else None
        )
        if chamber is None:
            continue
        for index, match in enumerate(re.finditer(r"\b(\d{3})th(?:\s+Congress)?\b", text)):
            observations.append(
                {
                    "occurrence_id": key(coordinate, "congress", str(index)),
                    "period_text": match[0],
                    "kind": "explicit",
                    "congress_text": match[1],
                    "chamber_text": chamber,
                    "source_path": f"XLSX/Explainer/{coordinate}",
                }
            )
    return observations


def _exclusions(methods, member):
    matches = []
    for coordinate, text in methods:
        if not text.startswith("Members Intentionally Excluded"):
            continue
        heading = text.splitlines()[0]
        prefix = f"{member['Name']}, {member['State']}, {member['Party']} |"
        for line in text.splitlines():
            if line.startswith(prefix):
                matches.append({"heading": heading, "text": line, "source_path": f"XLSX/Explainer/{coordinate}"})
    return matches


def _workbook(document):
    sheets = literal_sheets(document.body)
    if set(sheets) != {"Explainer", *SHEETS}:
        raise ScorecardSourceError("AJP workbook worksheet set changed")
    parsed = {}
    all_identities = set()
    for name in SHEETS:
        cells = sheets[name]
        header_coordinates = [c for c in cells if re.fullmatch(r"[A-Z]+1", c)]
        headers = [cells.get(column(n) + "1", EMPTY).value for n in range(1, len(header_coordinates) + 1)]
        prefix = (*PREFIX, "District") if name != "Senate" else PREFIX
        if (
            headers[: len(prefix)] != list(prefix)
            or headers[-2:] != ["Score", "Grade"]
            or any(not h for h in headers)
            or len(set(headers)) != len(headers)
        ):
            raise ScorecardSourceError("AJP workbook headers changed or repeat an item")
        named = []
        identities = set()
        row_numbers = sorted({int(c.lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) for c in cells} - {1})
        for number in row_numbers:
            values = [cells.get(column(n) + str(number), EMPTY).value for n in range(1, len(headers) + 1)]
            if not values[0]:
                # The publisher's template fills some action columns with zero
                # below the named population, including a cached zero total.
                # Identity/grade cells must be empty; nonzero points refuse.
                if any(v not in {None, ""} for v in values[: len(prefix)] + values[-1:]) or any(
                    v not in {None, "", "0"} for v in values[len(prefix) : -1]
                ):
                    raise ScorecardSourceError("AJP workbook has data without a named member")
                continue
            record = dict(zip(headers, values, strict=True))
            if any(not record[field] for field in PREFIX[:4]) or record["Chamber"] not in {
                "Senate",
                "House of Representatives",
            }:
                raise ScorecardSourceError("AJP member identity fields changed")
            if name != "All Members" and record["Chamber"] != (
                "Senate" if name == "Senate" else "House of Representatives"
            ):
                raise ScorecardSourceError("AJP chamber worksheet contains a different chamber")
            district_key = record.get("District") if record["Chamber"] != "Senate" else "Senate"
            member_name, state = record["Name"], record["State"]
            if not isinstance(member_name, str) or not isinstance(state, str):
                raise ScorecardSourceError("AJP member identity is not literal source text")
            identifier = key(record["Chamber"], state, district_key or "unspecified", member_name)
            if identifier in identities:
                raise ScorecardSourceError("AJP worksheet repeats a member identity")
            identities.add(identifier)
            named.append((number, identifier, record))
        if not named:
            raise ScorecardSourceError("AJP workbook has an empty member worksheet")
        if name == "All Members":
            all_identities = identities
        elif not identities <= all_identities:
            raise ScorecardSourceError("AJP chamber members are absent from the complete member sheet")
        parsed[name] = (headers, len(prefix), named)
    method = [(c, cell.value) for c, cell in sheets["Explainer"].items() if cell.value]
    if not method or not method[0][1].startswith("Methodology"):
        raise ScorecardSourceError("AJP methodology is missing")
    return parsed, method


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    index = context.read(INDEX, stage="scorecards:ajp:listing", hosts=HOSTS)
    if not any(a.get("href") == WORKBOOK for a in soup(index).select("a[href]")):
        raise ScorecardSourceError("AJP original index does not link the selected 2026 workbook")
    return (EDITION,)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("AJP reader supports the explicit 2026 workbook")
    primary = context.read(WORKBOOK, stage="scorecards:ajp:workbook", hosts=HOSTS)
    parsed, methods = _workbook(primary)
    repeated = context.read(WORKBOOK, stage="scorecards:ajp:stable-reread", hosts=HOSTS)
    if _workbook(repeated) != (parsed, methods):
        raise ScorecardSourceError("AJP workbook facts changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Americans for Justice in Palestine Action",
        parser_version=parser_version,
        rendition_rule="ajp-original-workbook-each-worksheet/1",
        homepage="https://ajpaction.org/",
    )
    bundle.use(primary, "all_worksheet_members_metrics_and_results", "methodology")
    bundle.use(repeated, "all_worksheet_members_metrics_and_results", "methodology", role="corroboration")
    periods = _periods(methods)
    bundle.tables["scorecards"][0]["periods_json"] = json_column(periods)
    for coordinate, text in methods:
        bundle.add(
            "scorecard_methodologies",
            primary,
            f"XLSX/Explainer/{coordinate}",
            methodology_id=coordinate,
            methodology_text=text,
            methodology_url=WORKBOOK,
            disclosure_status="partial",
        )
    headers, prefix, all_members = parsed["All Members"]
    for number, identifier, member in all_members:
        exclusions = _exclusions(methods, member)
        bundle.add(
            "scorecard_members",
            primary,
            f"XLSX/All Members/A{number}:F{number}",
            publisher_member_key=identifier,
            member_name=member["Name"],
            state=member["State"],
            party=member["Party"],
            chamber_text=member["Chamber"],
            district=member.get("District"),
            eligibility_text="\n".join(observation["heading"] for observation in exclusions) or None,
            notes_text=json_column(
                {
                    "first_elected": {"text": member["First Elected"], "source_path": f"XLSX/All Members/E{number}"},
                    "exclusions": exclusions,
                }
            ),
        )
    for name, (headers, prefix, members) in parsed.items():
        metric_ids = {label: key(name, label) for label in ("Score", "Grade")}
        for label, metric_id in metric_ids.items():
            bundle.metric(
                primary,
                metric_id,
                label,
                path=f"XLSX/{name}/{column(headers.index(label) + 1)}1",
                chamber=name if name != "All Members" else None,
                unit="points" if label == "Score" else "grade",
            )
            bundle.tables["scorecard_metrics"][-1].update(
                methodology_id="A1",
                cohort_text=name,
                periods_json=json_column(
                    [
                        observation
                        for observation in periods
                        if name == "All Members" or observation["chamber_text"] == name
                    ]
                ),
            )
        for offset, title in enumerate(headers[prefix:-2], prefix + 1):
            item_id = key(name, title)
            reference = CITATION.match(title)
            citation = reference[1] if reference else None
            path = f"XLSX/{name}/{column(offset)}1"
            refs = (
                []
                if citation is None
                else [
                    {
                        "occurrence_id": "header-bill",
                        "kind": "bill",
                        "citation_text": citation,
                        "source_path": path,
                        "bill_citation_text": citation,
                    }
                ]
            )
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=item_id,
                title=title,
                item_kind_text="letter" if title.startswith("Letter:") else "bill or resolution",
                bill_citation_text=citation,
                references_json=json_column(refs),
            )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id=metric_ids["Score"],
                item_id=item_id,
                participation_id="worksheet-column",
                methodology_id="A1",
                counts_toward_metric="true",
            )
            for number, identifier, member in members:
                value = member[title]
                if value not in {None, ""}:
                    if decimal_text(value) is None:
                        raise ScorecardSourceError("AJP action points are no longer numeric literals")
                    bundle.add(
                        "scorecard_member_item_results",
                        primary,
                        f"XLSX/{name}/{column(offset)}{number}",
                        item_id=item_id,
                        publisher_member_key=identifier,
                        result_id="worksheet-cell",
                        result_text=value,
                        contribution_text=value,
                        contribution_number=value,
                        metric_id=metric_ids["Score"],
                        participation_id="worksheet-column",
                    )
        for number, identifier, member in members:
            for label, metric_id in metric_ids.items():
                value = member[label]
                if value not in {None, ""}:
                    bundle.add(
                        "scorecard_member_ratings",
                        primary,
                        f"XLSX/{name}/{column(headers.index(label) + 1)}{number}",
                        metric_id=metric_id,
                        publisher_member_key=identifier,
                        value_text=value,
                        value_number=decimal_text(value) if label == "Score" else None,
                    )
    return bundle.finish(
        "Complete original workbook ZIP and all worksheet cells read; both chamber populations are subsets "
        "of All Members; every named member retained including ungraded members; stable reread facts agree",
        declared={
            "named_members_by_sheet": {n: len(v[2]) for n, v in parsed.items()},
            "count_basis": "complete source worksheet cells through ZIP EOF",
        },
    )
