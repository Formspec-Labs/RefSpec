"""GOA's publisher-linked VoterVoice federal edition and scoring arrays.

The detailed rendition also reads every named criterion and its source action
groups. The aggregate rendition deliberately selects only the complete chamber
table's native fields; failed detail requests never become an empty edition.
"""

from __future__ import annotations

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)

parser_version = "goa-votervoice-detailed-federal/1"
aggregate_parser_version = "goa-votervoice-aggregate-federal/1"
INDEX = "https://www.gunowners.org/scorecard/"
PLUGIN = "https://www.votervoice.net/Scripts/BhEAAAAAAAA/Plugin.js?app=scorecards"
APP = "https://www.votervoice.net/iframes/GunOwners/Scorecard"
API = "https://www.votervoice.net/Api"
HOSTS = ("www.votervoice.net",)
TYPES = {"M": "Roll Call Votes", "S": "Sponsorship", "C": "Custom Action"}


from spicy_docs.sources.scorecards.votervoice_public import (
    Application,
    _array,
    _identifier,
    _scalar,
    bootstrap,
    criterion,
    read_api,
    scorings,
)

APPLICATION = Application("goa", INDEX, PLUGIN, APP, "GunOwners", "4358", "Gun Owners of America")


def _bootstrap(context):
    return bootstrap(context, APPLICATION)


def _read(context, path, headers, stage):
    return read_api(context, path, headers, stage, APPLICATION)


def _scorings(context, edition, headers, suffix=""):
    return scorings(context, edition, headers, APPLICATION, suffix)


def _criterion(context, identity, headers, suffix=""):
    return criterion(context, identity, headers, APPLICATION, suffix)


def _editions(context, headers, suffix=""):
    governments, data = _read(
        context, "/Governments?association=GunOwners&activeScorecards=true", headers, "governments" + suffix
    )
    rows = _array(data, "government list")
    if [row for row in rows if row.get("name") == "Federal"] != [{"name": "Federal", "uri": "./USA"}]:
        raise ScorecardSourceError("GOA federal government selection changed")
    document, data = _read(
        context,
        "/Scorecards?association=GunOwners&government=./USA&active=true",
        headers,
        "editions" + suffix,
    )
    rows = _array(data, "federal edition list")
    seen, congresses, editions = set(), set(), []
    for row in rows:
        identity = _identifier(row.get("id"), r"4358-\d+")
        title = row.get("name")
        if not isinstance(title, str):
            raise ScorecardSourceError("GOA edition period is absent")
        congress = re.fullmatch(r"(\d{4})-(\d{4}) Regular Session \((\d+)th\)", title)
        historical = re.fullmatch(r"(\d+)th Congress \((\d{4})-(\d{4})\)", title)
        if congress:
            period = (congress[1], congress[2], congress[3])
        elif historical:
            period = (historical[2], historical[3], historical[1])
        else:
            raise ScorecardSourceError("GOA federal edition label changed shape")
        if int(period[1]) != int(period[0]) + 1 or identity in seen or period[2] in congresses:
            raise ScorecardSourceError("GOA federal edition period or identity is repeated")
        seen.add(identity)
        congresses.add(period[2])
        criteria = _array(row.get("criteria"), "edition criterion list")
        item_ids = []
        for item in criteria:
            cid = _identifier(item.get("id"), r"[MSC]-4358-\d+")
            if not isinstance(item.get("name"), str) or not item["name"]:
                raise ScorecardSourceError("GOA scoring item is unnamed")
            if "billNumber" in item and not isinstance(item["billNumber"], str):
                raise ScorecardSourceError("GOA source bill citation changed type")
            item_ids.append(cid)
        if len(set(item_ids)) != len(item_ids):
            raise ScorecardSourceError("GOA edition repeats a scoring item identity")
        editions.append(
            ScorecardEdition("goa", identity, INDEX, title, congress=period[2], chamber="both", is_current=False)
        )
    current = max(int(e.congress or "0") for e in editions)
    editions = [
        ScorecardEdition(
            e.publisher_id,
            e.edition_id,
            e.source_url,
            e.title,
            congress=e.congress,
            chamber=e.chamber,
            is_current=int(e.congress or "0") == current,
        )
        for e in editions
    ]
    return governments, document, rows, tuple(editions)


class GOAReader:
    """Complete named federal edition with every publisher criterion detail."""

    detailed = True
    parser_version = parser_version

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        _, headers = _bootstrap(context)
        return _editions(context, headers)[3]

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        boot, headers = _bootstrap(context)
        governments, primary, catalog, editions = _editions(context, headers)
        if edition not in editions:
            raise ScorecardSourceError("GOA selected edition is not in the original federal catalog")
        source = next(row for row in catalog if row["id"] == edition.edition_id)
        scoring_document, rows = _scorings(context, edition, headers)
        criteria = {item["id"]: item for item in source["criteria"]}
        if any(f["criterionId"] not in criteria for r in rows for f in r["factors"]):
            raise ScorecardSourceError("GOA factor refers to an undisclosed edition item")
        details = {}
        if self.detailed:
            details = {cid: _criterion(context, cid, headers) for cid in criteria}
            if any(str(r["official"]["id"]) not in details[f["criterionId"]][2] for r in rows for f in r["factors"]):
                raise ScorecardSourceError("GOA aggregate factor is absent from the complete criterion action groups")
        repeated_details = {cid: _criterion(context, cid, headers, ":reread") for cid in details}
        repeated_scoring, repeated_rows = _scorings(context, edition, headers, ":reread")
        final_governments, final, repeated_catalog, repeated_editions = _editions(context, headers, ":reread")
        if (
            catalog != repeated_catalog
            or editions != repeated_editions
            or rows != repeated_rows
            or any(details[cid][1] != repeated_details[cid][1] for cid in details)
        ):
            raise ScorecardSourceError(
                "GOA federal edition, scoring population or criterion detail changed during reread"
            )
        bundle = Bundle(
            edition,
            context,
            primary,
            publisher_name="Gun Owners of America",
            parser_version=self.parser_version,
            rendition_rule=(
                "Complete federal chamber scoring arrays plus every named criterion detail"
                if self.detailed
                else "Complete federal chamber scoring arrays; criterion details and profile cumulative scores outside this rendition"
            ),
            homepage="https://www.gunowners.org/",
        )
        for number, doc in enumerate(boot):
            bundle.use(doc, "publisher-application:" + str(number))
        bundle.use(governments, "government-selection")
        bundle.use(final_governments, "government-selection", role="corroboration")
        bundle.use(scoring_document, "member-scoring-arrays")
        bundle.use(repeated_scoring, "member-scoring-arrays", role="corroboration")
        bundle.use(final, "edition", role="corroboration")
        edition_path = "$[id=" + source["id"] + "]"
        card = bundle.tables["scorecards"][0]
        card.update(edition_label_text=source["name"], timespan_text=source["name"], source_path=edition_path)
        bundle.add(
            "scorecard_metrics",
            primary,
            edition_path + ".criteria",
            metric_id="score",
            name="Score",
            period_text=source["name"],
            is_primary="true",
            cohort_text="Publisher's federal chamber scoring-array population",
        )
        for ordinal, item in enumerate(source["criteria"]):
            cid = item["id"]
            path = edition_path + f".criteria[{ordinal}]"
            doc, native, _actions = details.get(cid, (primary, item, {}))
            if cid in details:
                bundle.use(doc, "criterion:" + cid)
                bundle.use(repeated_details[cid][0], "criterion:" + cid, role="corroboration")
            motion = native.get("legislativeMotion")
            stance = None if motion is None else str(motion["associationStance"]["supportsMotion"]).lower()
            refs = []
            if motion:
                for group, urls in [
                    ("motion", motion["externalUrls"]),
                    ("bill", motion["legislativeProposal"]["externalUrls"]),
                ]:
                    for n, url in enumerate(urls):
                        field_path = "$.legislativeMotion." + ("legislativeProposal." if group == "bill" else "")
                        refs.append(
                            {
                                "occurrence_id": f"{group}:{n}",
                                "kind": "url",
                                "citation_text": url,
                                "source_path": f"capture:{doc.capture_id}#{field_path}externalUrls[{n}]",
                            }
                        )
            bundle.add(
                "scorecard_items",
                primary,
                path,
                item_id=cid,
                publisher_item_id=cid,
                item_kind_text=TYPES[cid[0]],
                title=item["name"],
                congress_text=edition.congress,
                item_date_text=date[1] if (date := re.search(r"\((\d{1,2}/\d{1,2}/\d{4})\)$", item["name"])) else None,
                roll_number_text=roll[1]
                if (roll := re.search(r"(?:Roll\s+[Nn]o\.?|Record Vote Number:)\s*(\d+)", item["name"]))
                else None,
                bill_citation_text=item.get("billNumber"),
                references_json=json_column(refs),
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                position_source_path=f"capture:{doc.capture_id}#$.legislativeMotion.associationStance.supportsMotion"
                if stance is not None
                else None,
            )
            if cid in details:
                bundle.add(
                    "scorecard_methodologies",
                    doc,
                    "$",
                    methodology_id="item:" + cid,
                    methodology_text=json_column(
                        {field: value for field, value in native.items() if field != "positions"}
                    ),
                    disclosure_status="partial",
                )
            bundle.add(
                "scorecard_metric_items",
                primary,
                path,
                metric_id="score",
                item_id=cid,
                participation_id="factor",
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                contribution_rule_text="Native factors[].effect; no weight or score formula disclosed by this rendition",
            )
        for ordinal, row in enumerate(rows):
            path = f"$[{ordinal}]"
            member, office = row["official"], row["official"]["office"]
            mid = str(member["id"])
            name = " ".join(v for v in [member["givenNames"], member["surname"], member.get("suffix")] if v)
            bundle.add(
                "scorecard_members",
                scoring_document,
                path + ".official",
                publisher_member_key=mid,
                publisher_member_id=mid,
                member_name=name,
                chamber_text=office["electedBody"],
                state=office["state"],
                district=office["electoralDistrict"] or None,
                party=member["party"],
                period_text=source["name"],
                identifiers_json=json_column(
                    [
                        {"scheme": "votervoice_occupancy_id", "value": mid},
                        {"scheme": "votervoice_politician_id", "value": str(member["politicianId"])},
                    ]
                ),
                notes_text=json_column(member),
            )
            value = _scalar(row["score"]) if "score" in row else "N/A"
            bundle.add(
                "scorecard_member_ratings",
                scoring_document,
                path + ".score",
                metric_id="score",
                publisher_member_key=mid,
                value_text=value,
                value_number=decimal_text(value),
                value_status_text=None if "score" in row else "Source client displays N/A for absent score",
                notes_text="Cumulative politician/office profile score is a separate measurement and is not used here",
            )
            for fno, factor in enumerate(row["factors"]):
                cid = factor["criterionId"]
                action = details[cid][2][mid][0] if cid in details else _scalar(factor.get("position"))
                result_path = path + f".factors[{fno}]"
                if cid in details:
                    result_path += f";action_source=capture:{details[cid][0].capture_id}#{details[cid][2][mid][1]}"
                effect = _scalar(factor["effect"])
                bundle.add(
                    "scorecard_member_item_results",
                    scoring_document,
                    result_path,
                    publisher_member_key=mid,
                    item_id=cid,
                    result_id=key(mid, cid),
                    metric_id="score",
                    participation_id="factor",
                    action_text=action,
                    result_text=_scalar(factor.get("position")),
                    contribution_text=effect,
                    contribution_number=decimal_text(effect),
                    reason_text=json_column(factor),
                )
        return bundle.finish(
            "Complete source arrays reached EOF; unique edition/member/item/factor identities; all factors belong to the advertised edition; "
            + ("every factor reconciles to its complete criterion position group; " if self.detailed else "")
            + "entire federal catalog, selected scoring array and selected detail objects agree on independent reread",
            declared={
                "member_contexts": len(rows),
                "items": len(criteria),
                "member_factors": sum(len(r["factors"]) for r in rows),
                "native_numeric_scores": sum("score" in r for r in rows),
                "rendition": "detailed" if self.detailed else "aggregate",
                "count_basis": "Lengths of complete publisher JSON arrays, not separately stated numeric totals",
            },
        )


class GOAAggregateReader(GOAReader):
    """Complete chamber scoring arrays, independently selectable from details."""

    detailed = False
    parser_version = aggregate_parser_version


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    return GOAReader().list_scorecards(context)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    return GOAReader().acquire_scorecard(edition, context)
