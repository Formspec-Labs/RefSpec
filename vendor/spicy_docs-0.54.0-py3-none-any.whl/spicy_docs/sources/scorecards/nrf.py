"""NRF's publisher-listed federal HTML grids; no aggregate rating is invented."""

import re
from urllib.parse import urljoin, urlsplit

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    key,
    soup,
)

parser_version = "nrf-federal-native-html/1"
ORIGIN = "https://nrf.com"
INDEX = ORIGIN + "/advocacy/action-center/congressional-voting-scorecard"
HOSTS = ("nrf.com",)
GRID = "/advocacy/action-center/vv-congressional-scorecard/"
LEGEND = "Legend: = supports NRF's position; = opposes NRF's position; = absent; blank = no data;"
SYMBOLS = {
    "supports nrf's position": "/assets/green-check-circle.svg",
    "opposes nrf's position": "/assets/red-X-circle.svg",
    "absent": "/assets/gray-dash-circle.svg",
}
CITATION = re.compile(r"(?:H\.(?:R\.|Con\.Res\.|J\.Res\.|Res\.)|S\.(?:Amdt\.|J\.Res\.|Con\.Res\.|Res\.)?)\s*\d+")
ITEM_ID = re.compile(r"[MCS]-2391-\d+")
MEMBER = re.compile(r"(.+) \(([A-Z]+|null)-(.+?)(?:-(\d+))?\)")


def _one(element, selector):
    values = element.select(selector)
    if len(values) != 1:
        raise ScorecardSourceError("NRF required source structure is missing or repeated: " + selector)
    return values[0]


def _html(document, url):
    if document.url != url or b"</html>" not in document.body.lower() or b"</main>" not in document.body.lower():
        raise ScorecardSourceError("NRF complete original HTML route is missing")
    html = soup(document)
    _one(html, "main")
    # Next streaming HTML appends source content after </html>. Netlify appends
    # instrumentation too; requiring </html> at byte EOF would refuse valid pages.
    if html.select("main table") and html.main.parent.get("hidden") is not None:
        target = html.main.parent.get("id")
        if not target or ('"' + target + '")').encode() not in document.body:
            raise ScorecardSourceError("NRF streamed source grid was not completed")
    return html


def _index(document):
    html = _html(document, INDEX)
    if _one(html, "title").get_text(" ", strip=True) != "Congressional Voting Scorecard":
        raise ScorecardSourceError("NRF scorecard index identity changed")
    main = html.main
    if _one(main, "h1").get_text(" ", strip=True) != "Congressional Voting Scorecard":
        raise ScorecardSourceError("NRF index heading changed")
    entries = []
    seen = set()
    for heading in main.select("h2"):
        label = heading.get_text(" ", strip=True)
        period = re.fullmatch(r"(\d{4})-(\d{4}) Regular Session \((\d+)(?:st|nd|rd|th)\)", label)
        if period:
            start, end, congress = period.groups()
        else:
            period = re.fullmatch(r"(\d+)(?:st|nd|rd|th) Congress \((\d{4})-(\d{4})\)", label)
            if period is None:
                raise ScorecardSourceError("NRF index edition period shape changed")
            congress, start, end = period.groups()
        links = heading.parent.select("ul li a")
        paths = {}
        code = None
        for link in links:
            href = link.get("href", "")
            match = re.fullmatch(re.escape(GRID) + r"(2391-\d+)/(house|senate)", href)
            if (
                match is None
                or match[2] in paths
                or link.get_text(" ", strip=True) != {"house": "U.S. House", "senate": "U.S. Senate"}[match[2]]
            ):
                raise ScorecardSourceError("NRF original edition chamber links changed")
            if code is not None and code != match[1]:
                raise ScorecardSourceError("NRF chambers name different publisher editions")
            code = match[1]
            paths[match[2]] = ORIGIN + href
        if set(paths) != {"house", "senate"} or congress in seen or int(end) != int(start) + 1:
            raise ScorecardSourceError("NRF edition chamber scope is incomplete or repeated")
        seen.add(congress)
        entries.append({"congress": congress, "label": label, "code": code, "paths": paths})
    if not entries:
        raise ScorecardSourceError("NRF index cannot establish source editions")
    return entries


def _edition(entry, current):
    return ScorecardEdition(
        "nrf", entry["congress"], INDEX, entry["label"], congress=entry["congress"], chamber="both", is_current=current
    )


def list_scorecards(context: ScorecardContext):
    document = context.read(INDEX, stage="nrf:index-discovery", hosts=HOSTS)
    entries = _index(document)
    current = max(int(entry["congress"]) for entry in entries)
    return tuple(_edition(entry, int(entry["congress"]) == current) for entry in entries)


def _page(document, entry, chamber):
    html = _html(document, entry["paths"][chamber])
    main = html.main
    title = "NRF | Congressional Scorecards | " + entry["label"] + " - " + chamber
    if _one(html, "title").get_text(" ", strip=True) != title:
        raise ScorecardSourceError("NRF selected edition or chamber title changed")
    page = _one(main, "#pageTop")
    if len(main.find_all(recursive=False)) != 1:
        raise ScorecardSourceError("NRF selected main source scope changed")
    if _one(page, "h1").get_text(" ", strip=True) != entry["label"]:
        raise ScorecardSourceError("NRF selected source period changed")
    no_data = "No data is available for the " + chamber + " of this congress."
    if not page.select("table"):
        if page.get_text(" ", strip=True) != entry["label"] + " " + no_data:
            raise ScorecardSourceError("NRF absent grid lacks an explicit publisher no-data statement")
        return {"availability": no_data, "legend": None, "items": [], "members": []}
    if page.select("input, select, [aria-label*='pag'], [class*='pager'], [class*='pagination']"):
        raise ScorecardSourceError("NRF grid now exposes filtering or pagination")
    buttons = _one(page, "[class*='_buttons__']")
    if {(a.get_text(" ", strip=True), urljoin(ORIGIN, a.get("href", ""))) for a in buttons.select("a")} != {
        ("Senate", entry["paths"]["senate"]),
        ("House of Representatives", entry["paths"]["house"]),
    }:
        raise ScorecardSourceError("NRF grid chamber selector changed")
    legend = _one(page, "[class*='_legend__']")
    if (
        legend.get_text(" ", strip=True) != LEGEND
        or {(image.get("alt"), image.get("src")) for image in legend.select("img")} != set(SYMBOLS.items())
        or len(legend.select("img")) != len(SYMBOLS)
    ):
        raise ScorecardSourceError("NRF literal image legend changed")
    table = _one(page, "table")
    direct = page.find_all(recursive=False)
    if [child.name for child in direct] != ["h1", "div", "div", "table", "div"] or not all(
        marker in " ".join(direct[offset].get("class", []))
        for offset, marker in ((1, "_buttons__"), (2, "_legend__"), (4, "_billDescription__"))
    ):
        raise ScorecardSourceError("NRF whole grid rendition contains an unreviewed source section")
    headings = _one(table, "thead tr").find_all("th", recursive=False)
    if len(headings) < 2 or headings[0].get_text(" ", strip=True) != "Name":
        raise ScorecardSourceError("NRF complete member/item grid header changed")
    items = []
    for heading in headings[1:]:
        anchor = _one(heading, "a")
        native_id = anchor.get("href", "").removeprefix("#")
        if not anchor.get("href", "").startswith("#") or ITEM_ID.fullmatch(native_id) is None:
            raise ScorecardSourceError("NRF publisher item identity changed")
        detail = _one(page, "[id='" + native_id + "']")
        name = _one(detail, "[class*='_bill_name__']").get_text(" ", strip=True)
        description = _one(detail, "[class*='_bill_desc__']")
        if not name or not description.get_text(" ", strip=True):
            raise ScorecardSourceError("NRF item title or complete description is empty")
        positions = [
            x.get_text(" ", strip=True)
            for x in description.select("strong")
            if re.match(r"NRF\s+POSITION\s*:", x.get_text(" ", strip=True), re.IGNORECASE)
        ]
        if len(positions) > 1 or any(
            re.fullmatch(r"NRF\s+POSITION\s*:\s*(?:SUPPORT|OPPOSE)\.?", position, re.IGNORECASE) is None
            for position in positions
        ):
            raise ScorecardSourceError("NRF explicit publisher position changed")
        links = [{"text": a.get_text(" ", strip=True), "url": a.get("href")} for a in description.select("a")]
        if any(
            not isinstance(a["url"], str)
            or urlsplit(a["url"]).scheme not in {"http", "https"}
            or urlsplit(a["url"]).username
            or urlsplit(a["url"]).password
            for a in links
        ):
            raise ScorecardSourceError("NRF original item letter link changed")
        items.append(
            {
                "id": native_id,
                "header": anchor.get_text(" ", strip=True),
                "title": name,
                "description": description.get_text(" ", strip=True),
                "description_html": str(description),
                "position": positions[0] if positions else None,
                "links": links,
            }
        )
    ids = [item["id"] for item in items]
    described = [d.get("id") for d in page.select("[class*='_billDescription_bill__']")]
    if len(set(ids)) != len(ids) or set(ids) != set(described) or len(ids) != len(described):
        raise ScorecardSourceError("NRF table columns and full item description inventory disagree")
    rows = _one(table, "tbody").find_all("tr", recursive=False)
    if not rows or len(table.select("tr")) != len(rows) + 1:
        raise ScorecardSourceError("NRF complete member grid is missing or nested")
    members = []
    seen = set()
    for row in rows:
        cells = row.find_all("td", recursive=False)
        if len(cells) != len(items) + 1:
            raise ScorecardSourceError("NRF member grid has missing or extra item cells")
        anchor = _one(cells[0], "a")
        display = anchor.get_text(" ", strip=True)
        name = MEMBER.fullmatch(display)
        href = anchor.get("href", "")
        identity = re.fullmatch(r"/advocacy/action-center/find-officials/official/([A-Z]{2})/(\d+)", href)
        if name is None or identity is None or (chamber == "senate" and name[4] is not None):
            raise ScorecardSourceError("NRF source member context or publisher identity changed")
        member_key = key(chamber, identity[2], identity[1], name[4] or "no-district")
        if member_key in seen:
            raise ScorecardSourceError("NRF publisher member context is repeated")
        seen.add(member_key)
        outcomes = []
        for cell in cells[1:]:
            images = cell.select("img")
            if not images and not cell.get_text(strip=True) and not cell.find():
                outcomes.append("")
            elif (
                len(images) == 1
                and len(cell.find_all()) == 1
                and not cell.get_text(strip=True)
                and images[0].get("alt") in SYMBOLS
                and images[0].get("src") == SYMBOLS[images[0]["alt"]]
            ):
                outcomes.append(images[0]["alt"])
            else:
                raise ScorecardSourceError("NRF source cell no longer matches its literal image legend")
        members.append(
            {
                "key": member_key,
                "id": identity[2],
                "name": name[1],
                "display": display,
                "state": identity[1],
                "state_name": name[3],
                "district": name[4],
                "party": name[2],
                "url": ORIGIN + href,
                "outcomes": outcomes,
            }
        )
    return {"availability": None, "legend": LEGEND, "items": items, "members": members}


def _item_fields(item, entry, chamber):
    title = item["title"]
    roll = re.search(r"\((?:Record Vote Number:|Roll no\.) (\d+)\)", title)
    date = re.search(r"\((\d{1,2}/\d{1,2}/\d{4})\)$", title)
    if "Committee" in title and "vote on" in title:
        kind = "committee_action"
    elif re.search(r"Co[- ]?Sponsor", title, re.IGNORECASE):
        kind = "cosponsorship"
    elif "Co-Signers" in title:
        kind = "letter_signing"
    elif roll:
        kind = "roll_call"
    else:
        kind = "bill"
    refs = []
    path = "main #" + item["id"]
    for location, text in (("table-header", item["header"]), ("title", title), ("description", item["description"])):
        for match in CITATION.finditer(text):
            literal = match[0]
            refs.append(
                {
                    "occurrence_id": key(location, str(match.start())),
                    "citation_text": literal,
                    "kind": "amendment" if literal.startswith("S.Amdt.") else "bill",
                    "congress_text": entry["congress"],
                    "source_path": path + "/" + location,
                    "amendment_citation_text" if literal.startswith("S.Amdt.") else "bill_citation_text": literal,
                }
            )
    if roll:
        refs.append(
            {
                "occurrence_id": "title-roll",
                "citation_text": roll[0],
                "kind": "roll_call",
                "congress_text": entry["congress"],
                "chamber_text": chamber.title(),
                "roll_number_text": roll[1],
                "source_path": path + "/title",
            }
        )
    primary_bill = next((r["bill_citation_text"] for r in refs if r["kind"] == "bill"), None)
    return {
        "item_kind_text": kind,
        "item_date_text": date[1] if date else None,
        "congress_text": entry["congress"],
        "chamber_text": chamber.title(),
        "roll_number_text": roll[1] if roll else None,
        "bill_citation_text": primary_bill,
        "references_json": json_column(refs),
    }


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    index = context.read(INDEX, stage="nrf:index", hosts=HOSTS)
    entries = _index(index)
    selected = [e for e in entries if e["congress"] == edition.edition_id]
    if len(selected) != 1 or edition != _edition(
        selected[0], int(selected[0]["congress"]) == max(int(e["congress"]) for e in entries)
    ):
        raise ScorecardSourceError("NRF caller selection does not match the publisher edition inventory")
    entry = selected[0]
    documents = {}
    pages = {}
    for chamber in ("house", "senate"):
        documents[chamber] = context.read(entry["paths"][chamber], stage="nrf:" + chamber, hosts=HOSTS)
        pages[chamber] = _page(documents[chamber], entry, chamber)
    repeats = {}
    for chamber in ("house", "senate"):
        repeats[chamber] = context.read(entry["paths"][chamber], stage="nrf:" + chamber + "-repeat", hosts=HOSTS)
        if _page(repeats[chamber], entry, chamber) != pages[chamber]:
            raise ScorecardSourceError("NRF full source member/item grid changed during acquisition")
    repeated_index = context.read(INDEX, stage="nrf:index-repeat", hosts=HOSTS)
    if _index(repeated_index) != entries:
        raise ScorecardSourceError("NRF publisher edition inventory changed during acquisition")
    bundle = Bundle(
        edition,
        context,
        index,
        publisher_name="National Retail Federation",
        parser_version=parser_version,
        rendition_rule="Publisher-listed original HTML chamber grids with literal image alt outcomes; explicit no-data chambers retained.",
        homepage=ORIGIN,
    )
    bundle.use(repeated_index, "edition", role="corroboration")
    bundle.tables["scorecards"][0].update(
        edition_label_text=entry["label"],
        timespan_text=entry["label"],
        periods_json=json_column(
            [
                {
                    "occurrence_id": "publisher-edition",
                    "period_text": entry["label"],
                    "kind": "explicit",
                    "congress_text": entry["congress"],
                    "source_path": "main h2",
                }
            ]
        ),
    )
    counts = {}
    for chamber, page in pages.items():
        document = documents[chamber]
        bundle.use(document, chamber + "-grid")
        bundle.use(repeats[chamber], chamber + "-grid", role="corroboration")
        counts[chamber] = {
            "source_declared_member_count": None,
            "source_declared_item_count": None,
            "observed_complete_html_member_rows": len(page["members"]),
            "observed_complete_html_item_columns": len(page["items"]),
            "explicit_no_data_statement": page["availability"],
        }
        bundle.add(
            "scorecard_methodologies",
            document,
            "main #pageTop",
            methodology_id=key(chamber, "literal-grid"),
            chamber_text=chamber.title(),
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "publisher_no_data_statement": page["availability"],
                    "literal_legend": page["legend"],
                    "publisher_native_edition_code": entry["code"],
                    "observation": "No aggregate score or scoring formula is disclosed on this rendition. Image alt text describes publisher alignment; absent is not converted to an official action. Blank means no data. Item identity prefixes carry no inferred action semantics.",
                }
            ),
        )
        for item in page["items"]:
            path = "main #" + item["id"]
            bundle.add(
                "scorecard_items",
                document,
                path,
                item_id=item["id"],
                publisher_item_id=item["id"],
                title=item["title"],
                publisher_position_text=item["position"],
                position_basis="explicit" if item["position"] else None,
                position_source_path=path + " [class*='_bill_desc__'] strong" if item["position"] else None,
                **_item_fields(item, entry, chamber),
            )
            bundle.add(
                "scorecard_methodologies",
                document,
                path + " [class*='_bill_desc__']",
                methodology_id=key(chamber, item["id"]),
                chamber_text=chamber.title(),
                disclosure_status="partial",
                methodology_text=json_column(
                    {
                        "title_text": item["title"],
                        "table_header_text": item["header"],
                        "description_text": item["description"],
                        "description_html": item["description_html"],
                        "publisher_position_text": item["position"],
                        "linked_source_letters": item["links"],
                        "linked_letters_acquired": False,
                    }
                ),
            )
        for ordinal, member in enumerate(page["members"], 1):
            path = "main table tbody tr:nth-child(" + str(ordinal) + ")"
            bundle.add(
                "scorecard_members",
                document,
                path + " td:first-child a",
                publisher_member_key=member["key"],
                publisher_member_id=member["id"],
                identifiers_json="[]",
                member_name=member["name"],
                chamber_text=chamber.title(),
                state=member["state"],
                district=member["district"],
                party=member["party"],
                period_text=entry["label"],
                notes_text=json_column(
                    {
                        "literal_source_display": member["display"],
                        "state_name_text": member["state_name"],
                        "publisher_member_url": member["url"],
                    }
                ),
            )
            for offset, (item, outcome) in enumerate(zip(page["items"], member["outcomes"], strict=True), 2):
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    path + " td:nth-child(" + str(offset) + ")",
                    item_id=item["id"],
                    result_id="native-grid",
                    publisher_member_key=member["key"],
                    result_text=outcome,
                    reason_text="blank = no data;" if outcome == "" else "Literal publisher image alt; " + LEGEND,
                )
    return bundle.finish(
        "Publisher index names both selected chamber routes; each complete HTML grid reconciles every column to exactly one full item description and every member to its rectangular cells. Literal no-data chamber statements are retained. Full source rows, columns, descriptions, image legends and availability agree on an independent reread; index edition links agree too. No aggregate ratings are inferred.",
        declared={"chambers": counts},
    )
