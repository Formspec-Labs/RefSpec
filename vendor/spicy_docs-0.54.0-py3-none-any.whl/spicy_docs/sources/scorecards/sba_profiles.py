"""SBA's complete continuing profile catalog and literal native term ledgers."""

import json
import re
from hashlib import sha256
from urllib.parse import urlencode

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import sba as catalog
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    json_data,
    key,
    soup,
)

parser_version = "sba-complete-native-profile-catalog/2"
API = catalog.ORIGIN + "/wp-admin/admin-ajax.php"
HEADERS = {"Content-Type": "application/x-www-form-urlencoded"}
ASSETS = {
    "senate": (
        catalog.ORIGIN + "/wp-content/plugins/sba-scorecard/assets/js/senator-details.js?ver=1.0.0",
        "daca684bb852ed19af2e629b911d6faf7a391a471d6fe8a2f3a7e176636ff90a",
        "senator-details-js",
        "SenatorAjax",
        "get_senator_data",
        "senator_id",
    ),
    "house": (
        catalog.ORIGIN + "/wp-content/plugins/sba-scorecard/assets/js/representative-details.js?ver=1.0.0",
        "b7fa3ee77dd1a1606f05ea0dddf729c42b5f92e977305933a49e3bcb6de16a8e",
        "representative-details-js",
        "RepresentativeAjax",
        "get_representative_data",
        "representative_id",
    ),
}
# The measured original catalog consumes 2402 captures. The caller owns the
# budget; a bounded margin accommodates additions without accepting partial reads.
RECOMMENDED_MAX_REQUESTS = 3200
MAX_CATALOG_MEMBERS = 1000
MAX_TERMS_PER_MEMBER = 32
MAX_ITEMS_PER_COLLECTION = 512
OBJECT_ID = re.compile(r"[0-9a-f]{24}")
BILL = re.compile(r"\b(?:H\s*\.\s*R|S|[HS]\s*\.\s*(?:J\s*\.\s*Res|Con\s*\.\s*Res|Res))\s*\.?\s*\d+\b", re.IGNORECASE)
AMENDMENT = re.compile(r"\b(?:Amendment\s*#?\s*\d+|Amdt\.?\s*\d+)\b", re.IGNORECASE)
COLLECTIONS = (("votesScore", "voteId"), ("pastVotesScore", "voteId"), ("activitiesScore", "activityId"))
UNRATED_NOTICE = "This member has not yet received a scorecard rating as a result of when the member joined Congress, relative to our latest scored votes and activity. The member will receive a rating in the next Scorecard update."


def edition():
    return ScorecardEdition("sba", "119-profile-catalog", catalog.INDEX, catalog.TITLE, chamber="both")


def list_scorecards(context: ScorecardContext):
    document = context.read(catalog.INDEX, stage="sba-profiles:catalog-list", hosts=catalog.HOSTS)
    catalog._page(document)
    return (edition(),)


def _require(condition, message):
    if not condition:
        raise ScorecardSourceError("SBA profile " + message)


def _id(value):
    _require(isinstance(value, str) and OBJECT_ID.fullmatch(value), "native object identity is missing or changed")
    return value


def _text(value, *, nullable=False):
    _require(isinstance(value, str) or (nullable and value is None), "literal text field has changed type")
    return value


def _request(document, member):
    chamber = member["chamber"]
    asset, _, script_id, variable, action, field = ASSETS[chamber]
    _require(
        document.url == member["profile_url"].rstrip("/") or document.url == member["profile_url"],
        "resolved member locator is outside its original profile",
    )
    _require(document.body.rstrip().lower().endswith(b"</html>"), "full member page trailer is missing")
    html = soup(document)
    profile = catalog._one(html, ".senator-info[data-id]")
    member_id = _id(profile.get("data-id"))
    _require(
        catalog._one(html, "script#" + script_id).get("src") == asset, "publisher-configured member renderer changed"
    )
    for selector in ("#termDropdown", "#termYears"):
        catalog._one(html, selector)
    score_selectors = ("#termRating", "#termSummary", "#votesTable", "#activitiesTable") + (
        ("#pastVotesTable",) if chamber == "senate" else ()
    )
    notice = None
    if html.select(".senator-info-row.newMember"):
        _require(not any(html.select(s) for s in score_selectors), "unrated member page has inconsistent score widgets")
        notices = [p.get_text(" ", strip=True) for p in profile.select("p")]
        _require(notices == [UNRATED_NOTICE], "unrated member source notice changed")
        notice = notices[0]
    else:
        for selector in score_selectors:
            catalog._one(html, selector)
    declarations = [s.get_text() for s in html.select("script") if "var " + variable + " =" in s.get_text()]
    _require(len(declarations) == 1, "publisher-configured public request declaration is missing or repeated")
    match = re.search(r"var " + variable + r"\s*=\s*(\{.*?\});", declarations[0])
    if match is None:
        raise ScorecardSourceError("SBA publisher request configuration is malformed")
    try:
        config = json.loads(match[1])
    except (ValueError, TypeError) as error:
        raise ScorecardSourceError("SBA public request configuration is malformed") from error
    _require(
        isinstance(config, dict) and set(config) == {"ajax_url", "nonce"} and config["ajax_url"] == API,
        "publisher-selected request endpoint changed",
    )
    _require(
        isinstance(config["nonce"], str) and re.fullmatch(r"[a-z0-9]+", config["nonce"]),
        "public page-issued nonce is missing or changed",
    )
    return member_id, urlencode({"action": action, "nonce": config["nonce"], field: member_id}).encode(), notice


def _decode(document, member, member_id):
    _require(
        document.url == API and document.response.content_type.lower().startswith("application/json"),
        "original JSON endpoint/media identity changed",
    )
    payload = json_data(document)
    _require(
        isinstance(payload, dict) and payload.get("success") is True and isinstance(payload.get("data"), dict),
        "original JSON query did not report successful data",
    )
    data = payload["data"]
    native_key = "senator" if member["chamber"] == "senate" else "house"
    _require(
        set(data) == {"message", native_key, "currentTerm", "pastTerms", "dataSource", "hasHistoricalData"},
        "complete member JSON fields changed",
    )
    native = data[native_key]
    _require(
        isinstance(native, dict) and _id(native.get("_id")) == member_id,
        "JSON member identity differs from its original page",
    )
    _require(
        native.get("name") == ("Sen. " if member["chamber"] == "senate" else "Rep. ") + member["name"],
        "JSON member name differs from the complete native catalog",
    )
    location = "state" if member["chamber"] == "senate" else "district"
    _require(native.get(location) == member["literal_location"], "JSON state/district differs from the native catalog")
    _require(native.get("party") == member["party"].lower(), "JSON party differs from the native catalog")
    _require(
        isinstance(data["pastTerms"], list)
        and len(data["pastTerms"]) <= MAX_TERMS_PER_MEMBER
        and isinstance(data["hasHistoricalData"], bool)
        and isinstance(data["dataSource"], str)
        and data["dataSource"] in {"current", "historical"},
        "term catalog or source disposition changed",
    )
    terms = []
    if data["currentTerm"] is not None:
        terms.append(("$.data.currentTerm", data["currentTerm"]))
    terms.extend(("$.data.pastTerms[" + str(i) + "]", term) for i, term in enumerate(data["pastTerms"]))
    _require(terms and len(terms) <= MAX_TERMS_PER_MEMBER, "complete member term catalog is empty or over bound")
    observed = set()
    for path, term in terms:
        expected = {"_id", "termId", "summary", "rating", "votesScore", "activitiesScore"}
        if member["chamber"] == "senate":
            expected |= {"currentTerm", "pastVotesScore"}
        _require(isinstance(term, dict) and set(term) == expected, "member term fields changed")
        term_id = _id(term["_id"])
        period = term["termId"]
        _require(
            isinstance(period, dict) and {"_id", "name", "startYear", "endYear", "congresses"} <= set(period),
            "native term period is incomplete",
        )
        period_id = _id(period["_id"])
        _require(period_id not in observed, "member has repeated shared term periods")
        observed.add(period_id)
        _require(
            isinstance(period["name"], str)
            and period["name"]
            and type(period["startYear"]) is int
            and type(period["endYear"]) is int
            and period["startYear"] <= period["endYear"],
            "literal term name/year structure changed",
        )
        _require(
            isinstance(period["congresses"], list)
            and period["congresses"]
            and all(type(c) is int and 1 <= c <= 999 for c in period["congresses"]),
            "term Congress list is missing or malformed",
        )
        _text(term["summary"])
        _require(
            (term["rating"] is None or isinstance(term["rating"], str))
            and term["rating"] in {None, "", "-", "A+", "A", "B", "C", "D", "F", "N/A", "NA", "n/a"},
            "literal published term grade changed shape",
        )
        if "currentTerm" in term:
            _require(isinstance(term["currentTerm"], bool), "source currentTerm flag is not boolean")
        for collection, item_field in COLLECTIONS:
            if collection not in term:
                continue
            records = term[collection]
            _require(
                isinstance(records, list) and len(records) <= MAX_ITEMS_PER_COLLECTION,
                "complete item collection is malformed or over bound",
            )
            seen = set()
            for record in records:
                _require(
                    isinstance(record, dict) and set(record) == {"score", item_field},
                    "member item result fields changed",
                )
                _require(
                    isinstance(record["score"], str)
                    and record["score"]
                    in (
                        {"", "yes", "no", "other"}
                        if collection == "activitiesScore"
                        else {"", "yea", "nay", "missed", "present", "other"}
                    ),
                    "literal member item result changed shape",
                )
                item = record[item_field]
                _require(
                    isinstance(item, dict)
                    and set(item)
                    in (
                        {"_id", "title", "shortDesc", "longDesc", "rollCall", "readMore", "date", "sbaPosition"},
                        {
                            "_id",
                            "title",
                            "shortDesc",
                            "longDesc",
                            "rollCall",
                            "readMore",
                            "date",
                            "sbaPosition",
                            "congress",
                        },
                    ),
                    "complete publisher item object is missing or changed",
                )
                item_id = _id(item["_id"])
                _require(item_id not in seen, "member term/collection repeats a publisher item")
                seen.add(item_id)
                for field in ("title", "date"):
                    _text(item[field])
                for field in ("shortDesc", "longDesc"):
                    _text(item[field], nullable=True)
                _require(bool(item["title"]), "publisher item title is empty")
                for field in ("rollCall", "readMore"):
                    _text(item[field], nullable=True)
                _require(
                    (item["sbaPosition"] is None or isinstance(item["sbaPosition"], str))
                    and item["sbaPosition"] in {None, "Yes", "No"},
                    "literal publisher target position changed",
                )
                if "congress" in item:
                    _require(
                        isinstance(item["congress"], str) and re.fullmatch(r"\d+", item["congress"]),
                        "explicit item Congress changed",
                    )
        _id(term_id)
    return native, terms, data


def _periods(period, path):
    return [
        {"occurrence_id": "name", "period_text": period["name"], "kind": "explicit", "source_path": path + ".name"},
        {
            "occurrence_id": "start-year",
            "period_text": str(period["startYear"]),
            "year_text": str(period["startYear"]),
            "kind": "explicit",
            "source_path": path + ".startYear",
        },
        {
            "occurrence_id": "end-year",
            "period_text": str(period["endYear"]),
            "year_text": str(period["endYear"]),
            "kind": "explicit",
            "source_path": path + ".endYear",
        },
        *[
            {
                "occurrence_id": "congress-" + str(i),
                "period_text": str(c),
                "congress_text": str(c),
                "kind": "explicit",
                "source_path": path + ".congresses[" + str(i) + "]",
            }
            for i, c in enumerate(period["congresses"])
        ],
    ]


def _legislative_fields(item, path, chamber):
    refs = []
    bills = list(BILL.finditer(item["title"]))
    amendments = list(AMENDMENT.finditer(item["title"]))
    for kind, matches in (("bill", bills), ("amendment", amendments)):
        for i, match in enumerate(matches):
            refs.append(
                {
                    "occurrence_id": kind + "-" + str(i),
                    "kind": kind,
                    "citation_text": match[0],
                    "source_path": path + ".title",
                }
            )
    fields = {
        "congress_text": item.get("congress"),
        "session_text": None,
        "roll_number_text": None,
        "bill_citation_text": bills[0][0] if len(bills) == 1 else None,
        "amendment_citation_text": amendments[0][0] if len(amendments) == 1 else None,
    }
    for name in ("rollCall", "readMore"):
        if item[name]:
            refs.append(
                {
                    "occurrence_id": name,
                    "kind": "source_url",
                    "citation_text": item[name],
                    "source_path": path + "." + name,
                }
            )
    roll = item["rollCall"] or ""
    senate = re.fullmatch(
        r"https?://www\.senate\.gov/legislative/LIS/roll_call_votes/vote(\d+)([12])/vote_(\d+)_([12])_(\d+)\.htm", roll
    )
    house = re.fullmatch(
        r"https?://clerk\.house\.gov/(?:evs/\d{4}/roll(\d+)\.xml|Votes/\d{4}(\d+)(?:\?Page=\d+)?)", roll
    )
    if senate:
        _require(
            chamber == "senate" and senate[1] == senate[3] and senate[2] == senate[4],
            "explicit Senate roll URL identifiers conflict",
        )
        _require(fields["congress_text"] in {None, senate[1]}, "item Congress conflicts with its explicit Senate URL")
        fields.update(congress_text=senate[1], session_text=senate[2], roll_number_text=senate[5])
    elif house:
        _require(chamber == "house", "House roll URL appears in a Senate item")
        fields["roll_number_text"] = house[1] or house[2]
    # A source rollCall field can contain a discharge-petition URL. Its literal
    # URL remains evidence; neither a roll number nor a Congress is invented.
    return fields, json_column(refs)


def acquire_scorecard(selected: ScorecardEdition, context: ScorecardContext):
    _require(selected == edition(), "selection is outside the reviewed continuing catalog")
    requests_started = context._requests
    index = context.read(catalog.INDEX, stage="sba-profiles:catalog", hosts=catalog.HOSTS)
    members = catalog._page(index)
    _require(
        len(members) <= MAX_CATALOG_MEMBERS and context.max_requests - context._requests >= 3 * len(members) + 4,
        "budget cannot acquire and reread the entire source population",
    )
    asset = context.read(catalog.JAVASCRIPT, stage="sba-profiles:catalog-client", hosts=catalog.HOSTS)
    _require(
        asset.url == catalog.JAVASCRIPT and sha256(asset.body).hexdigest() == catalog.JAVASCRIPT_SHA256,
        "complete catalog client requires requalification",
    )
    assets = {"catalog": asset}
    for chamber, (url, pin, *_rest) in ASSETS.items():
        source = context.read(url, stage="sba-profiles:" + chamber + "-client", hosts=catalog.HOSTS)
        _require(
            source.url == url and sha256(source.body).hexdigest() == pin, "member renderer requires requalification"
        )
        assets[chamber] = source
    acquired = []
    for member in members:
        page = context.read(member["profile_url"], stage="sba-profiles:member-page", hosts=catalog.HOSTS)
        member_id, content, notice = _request(page, member)
        document = context.read_request(
            API,
            method="POST",
            content=content,
            request_headers=HEADERS,
            stage="sba-profiles:member-json",
            hosts=catalog.HOSTS,
        )
        native, terms, data = _decode(document, member, member_id)
        _require(
            (native.get("isNewRecord") is True) == bool(notice),
            "source page unrated notice and JSON new-record flag disagree",
        )
        acquired.append((member, page, document, native, terms, data, content, notice))
    corroborations = []
    for member, _page_document, first, native, _terms, data, content, _notice in acquired:
        repeat = context.read_request(
            API,
            method="POST",
            content=content,
            request_headers=HEADERS,
            stage="sba-profiles:member-json-repeat",
            hosts=catalog.HOSTS,
        )
        _, _, repeated = _decode(repeat, member, native["_id"])
        _require(repeated == data, "complete JSON member/term/item facts changed on reread")
        corroborations.append(repeat)
    repeated_index = context.read(catalog.INDEX, stage="sba-profiles:catalog-repeat", hosts=catalog.HOSTS)
    _require(catalog._page(repeated_index) == members, "complete source member catalog changed on reread")
    bundle = Bundle(
        selected,
        context,
        index,
        publisher_name="Susan B. Anthony Pro-Life America",
        parser_version=parser_version,
        homepage=catalog.ORIGIN,
        rendition_rule="Complete continuing native profile catalog: every native Current and Former profile, all current/past term ratings and all vote, past-vote and activity observations, with chamber/term metrics and exact native periods.",
    )
    bundle.use(index, "catalog")
    bundle.use(repeated_index, "catalog", role="corroboration")
    for name, document in assets.items():
        bundle.use(document, "renderer:" + name)
        bundle.add(
            "scorecard_methodologies",
            document,
            "document",
            methodology_id=key("client", name),
            disclosure_status="partial",
            methodology_text=json_column(
                {
                    "reviewed_renderer_sha256": sha256(document.body).hexdigest(),
                    "source_behavior": "Native catalog supplies all Current and Former rows; profiles request one public JSON response containing currentTerm and pastTerms and render each term's rating, summary, votesScore, activitiesScore and Senate pastVotesScore. The renderer supplies no numeric grade formula, item weights or past-vote participation rule.",
                    "source_display_limit": "Missing/null/blank JSON grades can be displayed as '-' by the publisher client. Literal JSON values are preserved separately; blank is not N/A.",
                }
            ),
        )
    periods_seen, items_seen, participation_seen = {}, {}, set()
    period_catalog = []
    for (member, page, document, native, terms, data, _content, notice), repeat in zip(
        acquired, corroborations, strict=True
    ):
        member_key = key(member["chamber"], native["_id"], member["profile_url"])
        groups = tuple(group + ":" + member_key for group in ("member", "terms", "items", "ratings", "results"))
        bundle.use(page, "profile-identity:" + member_key)
        bundle.use(document, *groups)
        bundle.use(repeat, *groups, role="corroboration")
        native_key = "senator" if member["chamber"] == "senate" else "house"
        if notice:
            bundle.add(
                "scorecard_methodologies",
                page,
                ".senator-info .senator-details p",
                methodology_id=key("profile-unrated", member_key),
                disclosure_status="explicit",
                methodology_text=notice,
            )
        bundle.add(
            "scorecard_members",
            document,
            "$.data." + native_key,
            publisher_member_key=member_key,
            publisher_member_id=native["_id"],
            identifiers_json="[]",
            member_name=native["name"],
            chamber_text=member["chamber"].title(),
            state=member["state"],
            district=member["district"],
            party=native["party"],
            eligibility_text=notice,
            notes_text=json_column(
                {
                    "literal_native_member": native,
                    "literal_catalog_member": member,
                    "dataSource": data["dataSource"],
                    "hasHistoricalData": data["hasHistoricalData"],
                    "literal_profile_unrated_notice": notice,
                    "profile_notice_source_url": page.url if notice else None,
                    "profile_notice_source_path": ".senator-info .senator-details p" if notice else None,
                    "identity_limit": "senatorId/repId have no source-declared external namespace; they remain literal publisher fields, not an asserted official crosswalk.",
                }
            ),
        )
        for path, term in terms:
            period = term["termId"]
            metric_id = key(member["chamber"], period["_id"])
            period_core = {k: period[k] for k in ("_id", "name", "startYear", "endYear", "congresses")}
            _require(
                metric_id not in periods_seen or periods_seen[metric_id] == period_core,
                "shared period identity has conflicting source fields",
            )
            if metric_id not in periods_seen:
                periods_seen[metric_id] = period_core
                method_id = key("term-period", metric_id)
                bundle.add(
                    "scorecard_methodologies",
                    document,
                    path + ".termId",
                    methodology_id=method_id,
                    disclosure_status="undocumented",
                    methodology_text=json_column(
                        {
                            "literal_shared_term": period,
                            "metric_scope": "One publisher term rating for this explicit chamber/period. Senate periods can span multiple Congresses and future years. No annual score or score reproduction is inferred.",
                        }
                    ),
                )
                bundle.metric(document, metric_id, "rating", path=path + ".rating", chamber=member["chamber"].title())
                bundle.tables["scorecard_metrics"][-1].update(
                    period_text=period["name"],
                    periods_json=json_column(_periods(period, path + ".termId")),
                    methodology_id=method_id,
                )
                period_catalog.append(
                    {
                        "metric_id": metric_id,
                        "chamber": member["chamber"],
                        "native_term": period_core,
                        "source_profile_url": member["profile_url"],
                        "source_member_id": native["_id"],
                        "source_path": path + ".termId",
                    }
                )
            observation_id = key("member-term", member_key, term["_id"])
            metadata = {k: v for k, v in term.items() if k not in {c for c, _ in COLLECTIONS}}
            metadata.update(
                profile_url=member["profile_url"],
                collection_counts={c: len(term[c]) for c, _ in COLLECTIONS if c in term},
                source_term_path=path,
            )
            bundle.add(
                "scorecard_methodologies",
                document,
                path,
                methodology_id=observation_id,
                disclosure_status="partial",
                methodology_text=json_column(metadata),
            )
            grade = "N/A" if term["rating"] in {"NA", "N/A", "n/a"} else term["rating"]
            bundle.add(
                "scorecard_member_ratings",
                document,
                path + ".rating",
                metric_id=metric_id,
                publisher_member_key=member_key,
                value_text=grade,
                value_status_text=grade if grade in {"N/A", "-"} else None,
                notes_text=json_column(
                    {
                        "literal_source_value": term["rating"],
                        "publisher_member_term_id": term["_id"],
                        "publisher_term_id": period["_id"],
                        "literal_term_metadata": metadata,
                        "methodology_id": observation_id,
                    }
                ),
            )
            for collection, item_field in COLLECTIONS:
                for ordinal, record in enumerate(term.get(collection, [])):
                    item_path = path + "." + collection + "[" + str(ordinal) + "]"
                    item = record[item_field]
                    item_id = key(member["chamber"], "activity" if item_field == "activityId" else "vote", item["_id"])
                    _require(
                        item_id not in items_seen or items_seen[item_id] == item,
                        "publisher item identity has conflicting source definitions",
                    )
                    if item_id not in items_seen:
                        items_seen[item_id] = item
                        source_path = item_path + "." + item_field
                        fields, refs = _legislative_fields(item, source_path, member["chamber"])
                        bundle.add(
                            "scorecard_items",
                            document,
                            source_path,
                            item_id=item_id,
                            publisher_item_id=item["_id"],
                            item_kind_text="activity" if item_field == "activityId" else "vote",
                            title=item["title"],
                            item_date_text=item["date"],
                            chamber_text=member["chamber"].title(),
                            references_json=refs,
                            publisher_position_text=item["sbaPosition"],
                            position_basis="explicit" if item["sbaPosition"] else "absent",
                            position_source_path=source_path + ".sbaPosition" if item["sbaPosition"] else None,
                            **fields,
                        )
                        bundle.add(
                            "scorecard_methodologies",
                            document,
                            source_path,
                            methodology_id=key("item-source", item_id),
                            disclosure_status="partial",
                            methodology_text=json_column(
                                {
                                    "literal_item": item,
                                    "source_item_field": item_field,
                                    "description_limit": "Literal shortDesc/longDesc HTML, source links and position are preserved. A source rollCall can name a discharge petition; no roll call is inferred from that field name. Activity kind is not collapsed to roll calls.",
                                }
                            ),
                        )
                    participation = (metric_id, item_id, collection)
                    if participation not in participation_seen:
                        participation_seen.add(participation)
                        bundle.add(
                            "scorecard_metric_items",
                            document,
                            item_path,
                            metric_id=metric_id,
                            item_id=item_id,
                            participation_id=collection,
                            methodology_id=key("term-period", metric_id),
                            publisher_position_text=item["sbaPosition"],
                            position_basis="explicit" if item["sbaPosition"] else "absent",
                            contribution_rule_text=json_column(
                                {
                                    "publisher_collection": collection,
                                    "participation_limit": "Associated with this source term object; numeric weighting and whether it counts toward the published grade are not disclosed.",
                                }
                            ),
                        )
                    bundle.add(
                        "scorecard_member_item_results",
                        document,
                        item_path + ".score",
                        publisher_member_key=member_key,
                        item_id=item_id,
                        result_id=key(term["_id"], collection),
                        metric_id=metric_id,
                        participation_id=collection,
                        action_text=record["score"],
                        result_text=record["score"],
                        reason_text=json_column(
                            {
                                "publisher_member_term_id": term["_id"],
                                "publisher_term_id": period["_id"],
                                "literal_period": period["name"],
                                "publisher_collection": collection,
                                "source_result_limit": "Literal publisher score token; no official action, numeric contribution, eligibility or grade participation is inferred.",
                            }
                        ),
                    )
    bundle.add(
        "scorecard_methodologies",
        index,
        "table.sc_table",
        methodology_id="complete-profile-catalog",
        disclosure_status="partial",
        methodology_text=json_column(
            {
                "literal_index_prologue": catalog.PERIOD,
                "qualified_scope": "Complete continuing profile catalog of all native Current and Former members, every currentTerm and pastTerms entry, all source-present vote/past-vote/activity arrays.",
                "native_term_catalog": period_catalog,
                "identity_rule": "Exact original profile URL, chamber and publisher member object ID; shared term ID plus chamber names the metric; member-specific term object ID remains separately observed. Future/long Senate term dates are literal, not annual score periods.",
                "grade_limit": "The index rating and profile term rating are separate renditions. Source JSON has blank grades and tokens; they are preserved as blank. NA aliases normalize to N/A with original spelling retained.",
                "reproduction_limit": "No source numeric weights or universal grade formula are supplied by this app. Item associations preserve source collections with counts_toward_metric null. Senate pastVotesScore is retained separately.",
                "remaining_renditions": "Item readMore attachments and individual item detail pages are advertised, not acquired by this complete JSON rendition; original raw item objects retain their links and full disclosed HTML descriptions.",
            }
        ),
    )
    return bundle.finish(
        "Both full native catalog tables reach HTML EOF and agree on reread. Every listed Current and Former original member profile is acquired, its publisher-configured successful JSON body is complete, and every current/past term and item array is walked to EOF. Every full JSON member/term/item object agrees with an exact-request reread; shared term cores and item objects reconcile across members. Missing/error/incomplete/different responses refuse the entire catalog.",
        declared={
            "publisher_declared_counts": None,
            "qualified_rendition": "complete_continuing_native_profile_term_catalog",
            "observed_catalog_members": len(members),
            "observed_member_terms": len(bundle.tables["scorecard_member_ratings"]),
            "observed_chamber_term_metrics": len(periods_seen),
            "observed_publisher_items": len(items_seen),
            "observed_member_item_results": len(bundle.tables["scorecard_member_item_results"]),
            "acquisition_request_count": context._requests - requests_started,
            "request_bound_rule": "At most1000 original catalog members; one profile GET plus one JSON POST plus one exact POST reread for each, and5 catalog/renderer captures. Caller recommended3200 requests.",
        },
    )
