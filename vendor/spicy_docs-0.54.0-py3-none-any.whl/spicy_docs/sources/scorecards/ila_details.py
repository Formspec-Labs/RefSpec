"""ILA's complete native federal member details, distinct score forms and point cells."""

from __future__ import annotations

from urllib.parse import quote

from spicy_docs.sources.scorecards import ila_catalogue as catalogue
from spicy_docs.sources.scorecards.common import Bundle, ScorecardEdition, ScorecardSourceError, json_data, key

parser_version = "ila-federal-native-api-details/1"
PERSON_FIELDS = {
    "id",
    "imageUrl",
    "thumbnailUrl",
    "tusaslug",
    "hasTusaData",
    "history",
    "personId",
    "name",
    "nickname",
    "role",
    "party",
    "district",
    "state",
    "from",
    "startDate",
    "endDate",
    "year",
    "first",
    "middle",
    "last",
    "suffix",
    "sessionId",
    "leadershipTitle",
    "contactEmail",
    "contactPhone",
    "officeUrl",
    "committeeAssignments",
    "rawSourceData",
    "statusReason",
    "lastUpdatedBy",
    "changeReason",
    "bpSlug",
    "scores",
    "chamber",
    "categories",
    "categoriesByYear",
    "allScores",
    "districtGrade",
    "collectorContext",
    "peerStats",
}
DETAIL_ARTICLE_FIELDS = {
    "billNumber",
    "state",
    "status",
    "inFavor",
    "opposed",
    "role",
    "chamber",
    "articleId",
    "year",
    "points",
    "title",
    "description",
    "ilaPosition",
    "vippPosition",
    "momsPosition",
    "euPosition",
    "healthcareReformPosition",
    "gopPlatformPosition",
    "gopPlatformHeading",
    "gopPlatformQuoteText",
    "platformPosition",
    "platformHeading",
    "platformQuoteText",
    "categories",
    "weight",
    "articleType",
    "sortOrder",
}
SCORE_FIELDS = {"id", "points", "score", "votes", "total", "year", "is_na"}
GROUP_FIELDS = {
    "scores": SCORE_FIELDS | {"meetsThreshold"},
    "allScores": SCORE_FIELDS,
    "categories": {"categories", "category", "points", "score", "votes", "year", "total"},
    "categoriesByYear": {"category", "score", "year"},
}


def detail_url(identifier):
    return (
        catalogue.BASE + "/api/lawmakerPage/personDetail?personId=" + quote(identifier, safe="") + "&organizationId=1"
    )


def _edition(organization):
    return ScorecardEdition(
        "ila",
        "api-details",
        catalogue.leaderboard_url("lifetime"),
        organization["settings"]["title"],
        chamber="both",
        is_current=True,
    )


def list_scorecards(context):
    app = context.read(catalogue.INDEX, stage="scorecards:ila_details:listing", hosts=catalogue.HOSTS)
    organization, _, _ = catalogue._application(app)
    return (_edition(organization),)


def _detail(source, identifier, years, native_items, taxonomy):
    data = json_data(source)
    if not isinstance(data, dict) or set(data) != {"person", "personYearArticles"}:
        raise ScorecardSourceError("ILA native person detail root shape changed")
    person, articles = data["person"], data["personYearArticles"]
    if (
        not isinstance(person, dict)
        or set(person) != PERSON_FIELDS
        or person["id"] != identifier
        or person["personId"] != identifier
        or person["state"] != "US"
        or person["chamber"] not in {"House", "Senate"}
        or not isinstance(person["name"], str)
        or not all(isinstance(person[f], str) and person[f] for f in ["party", "from"])
        or type(person["year"]) is not int
        or (person["districtGrade"] is not None and not isinstance(person["districtGrade"], str))
        or not isinstance(articles, list)
    ):
        raise ScorecardSourceError("ILA native person identity/context or complete action array changed")
    category_names = {c["name"] for c in taxonomy["categories"]}
    score_years = {}
    for group, fields in GROUP_FIELDS.items():
        rows = person[group]
        if not isinstance(rows, list):
            raise ScorecardSourceError("ILA native score group is not a complete array")
        identities = set()
        for row in rows:
            if (
                not isinstance(row, dict)
                or set(row) != fields
                or type(row["year"]) is not int
                or str(row["year"]) not in years
            ):
                raise ScorecardSourceError("ILA native measurement fields or period changed")
            if group in {"scores", "allScores"}:
                identity = row["year"]
                if row["id"] != identifier or type(row["is_na"]) is not int or row["is_na"] not in {0, 1}:
                    raise ScorecardSourceError("ILA native score identity or NA flag changed")
                if group == "scores" and type(row["meetsThreshold"]) is not bool:
                    raise ScorecardSourceError("ILA native score threshold flag changed")
            else:
                if not isinstance(row["category"], str) or row["category"] not in category_names:
                    raise ScorecardSourceError("ILA native detail category is outside its original taxonomy")
                identity = (row["category"], row["year"]) if group == "categoriesByYear" else row["category"]
                if group == "categories" and (
                    not isinstance(row["categories"], list)
                    or any(not isinstance(c, str) or c not in category_names for c in row["categories"])
                ):
                    raise ScorecardSourceError("ILA native aggregate category membership changed")
            if identity in identities:
                raise ScorecardSourceError("ILA native detail contains a duplicate measurement identity")
            identities.add(identity)
            for field in ["score", "points", "votes", "total"]:
                if field in row:
                    catalogue._number(row[field])
        score_years[group] = identities
    if not score_years["scores"] or score_years["scores"] != score_years["allScores"]:
        raise ScorecardSourceError("ILA native percent/fraction score period sets do not reconcile")
    identities = set()
    for article in articles:
        if (
            not isinstance(article, dict)
            or set(article) != DETAIL_ARTICLE_FIELDS
            or not isinstance(article["articleId"], str)
            or article["articleId"] in identities
            or article["articleId"] not in native_items
            or article["chamber"] not in {"House", "Senate"}
        ):
            raise ScorecardSourceError("ILA native member point array contains missing or duplicate item identities")
        original = native_items[article["articleId"]]
        # Native details can carry a current Senate label beside an older House item.
        # Preserve both source observations; do not repair the source or relabel the item.
        if any(article[field] != value for field, value in original.items() if field != "chamber"):
            raise ScorecardSourceError("ILA native member item metadata disagrees with its original item catalogue")
        catalogue._number(article["points"])
        identities.add(article["articleId"])
    return data


def acquire_scorecard(edition, context):
    app = context.read(catalogue.INDEX, stage="scorecards:ila_details:app-start", hosts=catalogue.HOSTS)
    organization, years, loader_url = catalogue._application(app)
    if edition != _edition(organization):
        raise ScorecardSourceError("Selected ILA native continuing detail scope is absent or changed")
    loader = context.read(loader_url, stage="scorecards:ila_details:loader-start", hosts=catalogue.HOSTS)
    catalogue._loader(loader)
    # The member-page chunk, selected by the application's build manifest, names
    # personDetail. Its original response is retained separately from catalogue data.
    manifest_scripts = catalogue.soup(app).find_all("script")
    manifests = [s.get("src", "") for s in manifest_scripts if s.get("src", "").endswith("/_buildManifest.js")]
    if len(manifests) != 1:
        raise ScorecardSourceError("ILA original application build manifest selection changed")
    manifest = context.read(
        catalogue.urljoin(app.url, manifests[0]), stage="scorecards:ila_details:manifest-start", hosts=catalogue.HOSTS
    )
    member_loader_url = _member_loader(manifest)
    member_loader = context.read(
        member_loader_url, stage="scorecards:ila_details:member-loader-start", hosts=catalogue.HOSTS
    )
    _member_endpoint(member_loader)
    source = context.read(edition.source_url, stage="scorecards:ila_details:lifetime-start", hosts=catalogue.HOSTS)
    roster = catalogue._roster(source, years)
    catalogue._catalog(app, source)
    articles = context.read(catalogue.ARTICLES, stage="scorecards:ila_details:articles-start", hosts=catalogue.HOSTS)
    categories = context.read(
        catalogue.CATEGORIES, stage="scorecards:ila_details:categories-start", hosts=catalogue.HOSTS
    )
    items, taxonomy = catalogue._items(articles, categories, years)
    method = context.read(catalogue.METHOD, stage="scorecards:ila_details:method-start", hosts=catalogue.HOSTS)
    blocks = catalogue._methodology(method)
    native_items = {item["articleId"]: item for item in items["articles"]}
    identifiers = sorted(member["id"] for member in roster["people"])
    documents, details = {}, {}
    for identifier in identifiers:
        document = context.read(
            detail_url(identifier), stage="scorecards:ila_details:member-start", hosts=catalogue.HOSTS
        )
        documents[identifier] = document
        details[identifier] = _detail(document, identifier, years, native_items, taxonomy)
    corroboration = {}
    for identifier in identifiers:
        document = context.read(
            detail_url(identifier), stage="scorecards:ila_details:member-end", hosts=catalogue.HOSTS
        )
        if _detail(document, identifier, years, native_items, taxonomy) != details[identifier]:
            raise ScorecardSourceError("ILA complete native member detail changed during acquisition")
        corroboration[identifier] = document
    source_end = context.read(edition.source_url, stage="scorecards:ila_details:lifetime-end", hosts=catalogue.HOSTS)
    articles_end = context.read(catalogue.ARTICLES, stage="scorecards:ila_details:articles-end", hosts=catalogue.HOSTS)
    categories_end = context.read(
        catalogue.CATEGORIES, stage="scorecards:ila_details:categories-end", hosts=catalogue.HOSTS
    )
    method_end = context.read(catalogue.METHOD, stage="scorecards:ila_details:method-end", hosts=catalogue.HOSTS)
    member_loader_end = context.read(
        member_loader_url, stage="scorecards:ila_details:member-loader-end", hosts=catalogue.HOSTS
    )
    manifest_end = context.read(manifest.url, stage="scorecards:ila_details:manifest-end", hosts=catalogue.HOSTS)
    loader_end = context.read(loader_url, stage="scorecards:ila_details:loader-end", hosts=catalogue.HOSTS)
    app_end = context.read(catalogue.INDEX, stage="scorecards:ila_details:app-end", hosts=catalogue.HOSTS)
    if (
        catalogue._roster(source_end, years) != roster
        or catalogue._items(articles_end, categories_end, years) != (items, taxonomy)
        or catalogue._methodology(method_end) != blocks
        or loader_end.body != loader.body
        or member_loader_end.body != member_loader.body
        or manifest_end.body != manifest.body
        or catalogue._application(app_end) != catalogue._application(app)
        or catalogue._catalog(app_end, source_end) != catalogue._catalog(app, source)
    ):
        raise ScorecardSourceError("ILA complete native detail selection or authoritative input changed")
    observed_items = {a["articleId"] for d in details.values() for a in d["personYearArticles"]}
    if observed_items != set(native_items):
        raise ScorecardSourceError("ILA complete member point arrays do not cover the original federal item catalogue")
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name=organization["name"],
        parser_version=parser_version,
        rendition_rule="ila-complete-native-federal-member-details/1",
        homepage="https://www.limitedgov.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = catalogue.INDEX
    bundle.tables["scorecards"][0].update(
        methodology_url=method.url,
        series_id=key("ila", organization["settings"]["title"]),
        periods_json=catalogue._literal(
            [
                {
                    "occurrence_id": key("year", year),
                    "kind": "explicit",
                    "period_text": year,
                    "year_text": year,
                    "source_path": f"capture:{app.capture_id}#script#__NEXT_DATA__/props/pageProps/yearsAndStates/state=US,year={year}",
                }
                for year in years
            ]
        ),
    )
    for document, groups in [
        (app, ("organization", "federal_periods")),
        (loader, ("catalogue_api_selection",)),
        (manifest, ("member_loader_selection",)),
        (member_loader, ("detail_api_selection",)),
        (source, ("native_roster_selection", "lifetime_measurements")),
        (articles, ("items",)),
        (categories, ("taxonomy",)),
        (method, ("methodology",)),
    ]:
        bundle.use(document, *groups)
    for document, groups in [
        (app_end, ("organization", "federal_periods")),
        (loader_end, ("catalogue_api_selection",)),
        (manifest_end, ("member_loader_selection",)),
        (member_loader_end, ("detail_api_selection",)),
        (source_end, ("native_roster_selection", "lifetime_measurements")),
        (articles_end, ("items",)),
        (categories_end, ("taxonomy",)),
        (method_end, ("methodology",)),
    ]:
        bundle.use(document, *groups, role="corroboration")
    for identifier in identifiers:
        groups = (key("person", identifier),)
        bundle.use(documents[identifier], *groups)
        bundle.use(corroboration[identifier], *groups, role="corroboration")
    bundle.add(
        "scorecard_methodologies",
        app,
        "script#__NEXT_DATA__/props/pageProps/organization",
        methodology_id="native-organization",
        methodology_text=catalogue._literal(organization),
        methodology_url=app.url,
    )
    bundle.add(
        "scorecard_methodologies",
        categories,
        "/categories",
        methodology_id="native-categories",
        methodology_text=catalogue._literal(taxonomy),
        methodology_url=categories.url,
    )
    for ordinal, text in enumerate(blocks):
        bundle.add(
            "scorecard_methodologies",
            method,
            f".entry-content .et_pb_text_inner/{ordinal}",
            methodology_id=key("block", str(ordinal)),
            methodology_text=text,
            methodology_url=method.url,
        )
    metrics = set()

    def metric(document, path, identifier, name, *, period=None, unit=None, primary=False):
        if identifier not in metrics:
            bundle.metric(document, identifier, name, path=path, unit=unit, primary=primary)
            bundle.tables["scorecard_metrics"][-1]["period_text"] = period
            metrics.add(identifier)

    for field in catalogue.MEASUREMENTS:
        metric(
            source,
            "/people/*/" + field,
            key("leaderboard", "lifetime", field),
            field,
            period="Lifetime",
            unit="percent" if field == "score" else None,
            primary=field == "score",
        )
    for ordinal, item in enumerate(items["articles"]):
        path = f"/articles/{ordinal}"
        item_id = key("article", item["articleId"])
        refs = (
            [
                {
                    "occurrence_id": "billNumber",
                    "kind": "citation",
                    "citation_text": item["billNumber"],
                    "source_path": path + "/billNumber",
                }
            ]
            if item["billNumber"]
            else []
        )
        bundle.add(
            "scorecard_items",
            articles,
            path,
            item_id=item_id,
            publisher_item_id=item["articleId"],
            title=item["title"],
            item_kind_text=item["articleType"],
            chamber_text=item["chamber"],
            bill_citation_text=item["billNumber"],
            references_json=catalogue._literal(refs),
            publisher_position_text=item["ilaPosition"],
            position_basis="explicit",
            position_source_path=path + "/ilaPosition",
        )
        bundle.add(
            "scorecard_methodologies",
            articles,
            path,
            methodology_id=item_id,
            chamber_text=item["chamber"],
            effective_at_text=str(item["year"]),
            methodology_text=catalogue._literal(item),
            methodology_url=articles.url,
        )
        bundle.add(
            "scorecard_metric_items",
            articles,
            path + "/weight",
            metric_id=key("leaderboard", "lifetime", "score"),
            item_id=item_id,
            participation_id="native-weight",
            publisher_position_text=item["ilaPosition"],
            position_basis="explicit",
            weight_text=catalogue._number(item["weight"]),
            weight_number=catalogue._number(item["weight"]),
        )
    roster_by_id = {member["id"]: (ordinal, member) for ordinal, member in enumerate(roster["people"])}
    for identifier in identifiers:
        document, payload = documents[identifier], details[identifier]
        person, actions = payload["person"], payload["personYearArticles"]
        member_key = key("person", identifier)
        bundle.add(
            "scorecard_members",
            document,
            "/person",
            publisher_member_key=member_key,
            publisher_member_id=identifier,
            member_name=person["name"],
            state=person["from"],
            district=person["district"] or None,
            party=person["party"],
            chamber_text=person["chamber"],
            period_text=str(person["year"]),
            identifiers_json=catalogue._literal([{"scheme": "limitedgov.org:person", "value": identifier}]),
            notes_text=catalogue._literal(person),
        )
        native_ordinal, native_member = roster_by_id[identifier]
        for field in catalogue.MEASUREMENTS:
            bundle.add(
                "scorecard_member_ratings",
                source,
                f"/people/{native_ordinal}/{field}",
                metric_id=key("leaderboard", "lifetime", field),
                publisher_member_key=member_key,
                value_text=catalogue._number(native_member[field]),
                value_number=catalogue._number(native_member[field]),
                value_status_text="true" if native_member["meetsThreshold"] else "false",
                rank_text=str(native_member["rank"]) if field == "score" else None,
                notes_text=catalogue._literal(native_member),
            )
        for group in GROUP_FIELDS:
            for ordinal, row in enumerate(person[group]):
                path = f"/person/{group}/{ordinal}"
                # The aggregate category year is a native metadata label, not a
                # claim that a cumulative category value belongs to one year.
                prefix = (
                    (group, row["category"])
                    if group == "categories"
                    else (group, str(row["year"]))
                    if group in {"scores", "allScores"}
                    else (group, str(row["year"]), row["category"])
                )
                for field in ["score", "points", "votes", "total"]:
                    if field not in row:
                        continue
                    metric_id = key(*prefix, field)
                    metric(
                        document,
                        path + "/" + field,
                        metric_id,
                        " / ".join([*prefix, field]),
                        period=None if group == "categories" else str(row["year"]),
                        unit="percent" if group == "scores" and field == "score" else None,
                    )
                    bundle.add(
                        "scorecard_member_ratings",
                        document,
                        path + "/" + field,
                        metric_id=metric_id,
                        publisher_member_key=member_key,
                        value_text=catalogue._number(row[field]),
                        value_number=catalogue._number(row[field]),
                        value_status_text=str(row["is_na"]) if "is_na" in row else None,
                        notes_text=catalogue._literal(row),
                    )
        if person["districtGrade"] is not None:
            metric(document, "/person/districtGrade", "districtGrade", "districtGrade")
            bundle.add(
                "scorecard_member_ratings",
                document,
                "/person/districtGrade",
                metric_id="districtGrade",
                publisher_member_key=member_key,
                value_text=person["districtGrade"],
                notes_text=catalogue._literal({"native_context_year": person["year"], "district": person["district"]}),
            )
        for ordinal, action in enumerate(actions):
            path = f"/personYearArticles/{ordinal}"
            native = {
                field: value
                for field, value in action.items()
                if field not in catalogue.ARTICLE_FIELDS or field in {"chamber", "year"}
            }
            bundle.add(
                "scorecard_member_item_results",
                document,
                path + "/points",
                result_id=key("person", identifier, "article", action["articleId"]),
                publisher_member_key=member_key,
                item_id=key("article", action["articleId"]),
                result_text=catalogue._number(action["points"]),
                contribution_text=catalogue._number(action["points"]),
                contribution_number=catalogue._number(action["points"]),
                reason_text=catalogue._literal(native),
            )
    return bundle.finish(
        "Complete original lifetime roster selects every native federal person ID; each full personDetail array is reconciled against original item IDs and every distinct score form, native period, category, grade and point cell is preserved. Exact complete detail and catalogue rereads match. Native current person context and conflicting detail chamber labels remain explicit; no official action inference, score conversion or reproduction."
    )


def _member_loader(source):
    import re

    try:
        text = source.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("ILA original build manifest is not UTF-8") from None
    matches = re.findall(r'"static/chunks/pages/lawmakers/\[slug\]-[a-f0-9]+\.js"', text)
    if len(matches) != 1 or '"/lawmakers/[slug]"' not in text:
        raise ScorecardSourceError("ILA original member loader build selection changed")
    return catalogue.BASE + "/_next/" + matches[0].strip('"').replace("[slug]", "%5Bslug%5D")


def _member_endpoint(source):
    try:
        text = source.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("ILA original member loader is not UTF-8") from None
    if "/api/lawmakerPage/personDetail?personId=" not in text or "&organizationId=" not in text:
        raise ScorecardSourceError("ILA native member detail endpoint changed")
