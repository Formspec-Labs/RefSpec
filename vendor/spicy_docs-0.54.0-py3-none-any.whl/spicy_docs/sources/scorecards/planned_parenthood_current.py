"""PPFA current-office cumulative percentages and their native profile history."""

from __future__ import annotations

import re

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards import planned_parenthood as publisher
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    json_data,
    key,
)
from spicy_docs.sources.scorecards.votervoice_public import _array, _identifier, _scalar

parser_version = "planned-parenthood-current-office-cumulative/1"
PERIOD = "current and preceding six sessions of Congress"
EDITION = ScorecardEdition(
    "planned_parenthood",
    "current-cumulative",
    publisher.INDEX,
    "current Planned Parenthood Action Fund Score",
    chamber="both",
)
ROSTER = "/Governments/USA/Officials?association=PPFA"


def _read(context, path, headers, stage):
    if path != ROSTER and re.fullmatch(r"/Scorecards/Politicians/[1-9]\d*\?association=PPFA&user=null", path) is None:
        raise ScorecardSourceError("PPFA current read is outside its reviewed original API")
    doc = context.read_request(
        publisher.API + path,
        method="GET",
        content=None,
        request_headers=headers,
        stage="scorecards:planned_parenthood:current:" + stage,
        hosts=publisher.HOSTS,
    )
    if (doc.response.content_type or "").split(";", 1)[0].strip() != "application/json":
        raise ScorecardSourceError("PPFA current response is not native JSON")
    return doc, json_data(doc)


def _roster(context, headers, suffix=""):
    doc, data = _read(context, ROSTER, headers, "roster" + suffix)
    rows = _array(data, "current federal roster")
    identities, members = [], []
    for row in rows:
        if not isinstance(row.get("office"), dict):
            raise ScorecardSourceError("PPFA current roster office is absent")
        identities.append(_identifier(row.get("id"), r"[1-9]\d*"))
        _identifier(row.get("politicianId"), r"[1-9]\d*")
        if row["office"].get("electedBody") not in {"US House", "US Senate"}:
            continue
        for field in ["givenNames", "surname", "displayName"]:
            if not isinstance(row.get(field), str) or not row[field]:
                raise ScorecardSourceError("PPFA current source name is absent")
        for field in ["state", "electoralDistrict", "constituency"]:
            if not isinstance(row["office"].get(field), str):
                raise ScorecardSourceError("PPFA current office context changed type")
        if not row["office"]["state"] or (
            row["office"]["electedBody"] == "US Senate" and row["office"]["electoralDistrict"]
        ):
            raise ScorecardSourceError("PPFA current chamber and district disagree")
        if row.get("party") is not None and not isinstance(row["party"], str):
            raise ScorecardSourceError("PPFA current party changed type")
        members.append(row)
    if len(set(identities)) != len(identities) or not members:
        raise ScorecardSourceError("PPFA current roster is empty or repeats an occupancy identity")
    return doc, rows, members


def _profile(context, politician_id, headers, suffix=""):
    doc, data = _read(
        context,
        "/Scorecards/Politicians/" + politician_id + "?association=PPFA&user=null",
        headers,
        "politician:" + politician_id + suffix,
    )
    if not isinstance(data, dict) or _identifier(data.get("id"), r"[1-9]\d*") != politician_id:
        raise ScorecardSourceError("PPFA politician profile disagrees with its requested native identity")
    if not isinstance(data.get("profile"), dict) or not isinstance(data["profile"].get("personName"), dict):
        raise ScorecardSourceError("PPFA politician profile has no source identity context")
    if not isinstance(data.get("offices"), list) or not isinstance(data.get("scorecards"), list):
        raise ScorecardSourceError("PPFA politician profile office or scorecard array is absent")
    if "score" not in data or (data["score"] is not None and decimal_text(_scalar(data["score"])) is None):
        raise ScorecardSourceError("PPFA politician score changed shape")
    ids = []
    for office in data["offices"]:
        if not isinstance(office, dict):
            raise ScorecardSourceError("PPFA profile office is malformed")
        ids.append(_identifier(office.get("id"), r"[1-9]\d*"))
        if not isinstance(office.get("isCurrent"), bool) or not isinstance(office.get("displayName"), str):
            raise ScorecardSourceError("PPFA profile current-office context is absent")
        if "score" not in office or (office["score"] is not None and decimal_text(_scalar(office["score"])) is None):
            raise ScorecardSourceError("PPFA office score is absent or malformed")
        if not isinstance(office.get("scorecards"), list):
            raise ScorecardSourceError("PPFA office history is absent")
    if len(set(ids)) != len(ids):
        raise ScorecardSourceError("PPFA profile repeats a native office")
    return doc, data


def _select(member, profile, cards):
    matches = [(n, office) for n, office in enumerate(profile["offices"]) if str(office["id"]) == str(member["id"])]
    if not matches:
        # A complete empty publisher profile is an explicit no-score observation.
        # It is accepted only with both accompanying null/empty score observations.
        if profile["offices"] == [] and profile["score"] is None and profile["scorecards"] == []:
            return None, None
        raise ScorecardSourceError("PPFA current source occupancy is absent from a nonempty politician profile")
    number, office = matches[0]
    if not office["isCurrent"]:
        raise ScorecardSourceError("PPFA roster occupancy is not the profile's current office")
    seen, periods = set(), set()
    for card in office["scorecards"]:
        if not isinstance(card, dict) or card.get("cardName") not in cards or card["cardName"] in periods:
            raise ScorecardSourceError("PPFA current office has an unknown or repeated edition period")
        periods.add(card["cardName"])
        scores = card.get("scores")
        if not isinstance(scores, list) or not all(isinstance(score, dict) for score in scores):
            raise ScorecardSourceError("PPFA current profile score history is malformed")
        known = {item["id"] for item in cards[card["cardName"]]["criteria"]}
        for score in scores:
            cid = _identifier(score.get("criterionId"), r"[MSC]-4473-\d+")
            if cid not in known or cid in seen or score.get("positionType") != publisher.TYPES[cid[0]]:
                raise ScorecardSourceError("PPFA current profile repeats or misattributes a criterion")
            seen.add(cid)
            if not isinstance(score.get("displayName"), str) or decimal_text(_scalar(score.get("score"))) is None:
                raise ScorecardSourceError("PPFA current profile item score or title is absent")
            for field in ["position", "symbol", "notes", "voteOutcome"]:
                _scalar(score.get(field))
    return number, office


class PPFACurrentReader:
    """Complete publisher current congressional roster and selected-office profiles."""

    parser_version = parser_version

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        boot, headers = publisher._bootstrap(context)
        publisher._methodology(boot[0])
        _roster(context, headers)
        return (EDITION,)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext):
        if edition != EDITION:
            raise ScorecardSourceError("PPFA current reader requires its named cumulative rendition")
        boot, headers = publisher._bootstrap(context)
        methodology = publisher._methodology(boot[0])
        client = boot[3].body.decode("utf-8")
        if "u.score!==i&&u.score!==null" not in client or 'l.html(u.score+"%")' not in client:
            raise ScorecardSourceError("PPFA current-office percentage display changed")
        governments, catalogs, catalog, editions = publisher._editions(context, headers)
        cards = {card["name"]: card for card in catalog}
        roster_doc, roster, members = _roster(context, headers)
        profiles = {
            pid: _profile(context, pid, headers) for pid in dict.fromkeys(str(m["politicianId"]) for m in members)
        }
        selected = {str(m["id"]): _select(m, profiles[str(m["politicianId"])][1], cards) for m in members}
        observed = {
            s["criterionId"]
            for _, office in selected.values()
            if office is not None
            for c in office["scorecards"]
            for s in c["scores"]
        }
        details = {cid: publisher._criterion(context, cid, headers) for cid in sorted(observed)}
        for cid in details:
            advertised = [item for card in catalog for item in card["criteria"] if item["id"] == cid]
            if len(advertised) != 1 or details[cid][1]["displayName"] != advertised[0]["name"]:
                raise ScorecardSourceError("PPFA cumulative criterion has an ambiguous period or mismatched title")
        repeated_profiles = {pid: _profile(context, pid, headers, ":reread") for pid in profiles}
        repeated_details = {cid: publisher._criterion(context, cid, headers, ":reread") for cid in details}
        final_roster, repeated_roster, _ = _roster(context, headers, ":reread")
        final_governments, finals, repeated_catalog, repeated_editions = publisher._editions(
            context, headers, ":reread"
        )
        if (
            roster != repeated_roster
            or catalog != repeated_catalog
            or editions != repeated_editions
            or any(profiles[pid][1] != repeated_profiles[pid][1] for pid in profiles)
            or any(details[cid][1] != repeated_details[cid][1] for cid in details)
        ):
            raise ScorecardSourceError("PPFA cumulative roster, profiles, catalogs or details changed during reread")
        bundle = Bundle(
            edition,
            context,
            boot[0],
            publisher_name="Planned Parenthood Action Fund",
            parser_version=parser_version,
            homepage="https://www.plannedparenthoodaction.org/",
            rendition_rule="Complete current congressional source roster; selected current-office profile percentage/history. Politician-wide score and other office histories remain separate source context.",
        )
        for n, document in enumerate(boot):
            bundle.use(document, "publisher-application:" + str(n))
        bundle.use(governments, "government-selection")
        bundle.use(final_governments, "government-selection", role="corroboration")
        for n, document in enumerate(catalogs):
            bundle.use(document, "catalog:" + str(n))
            bundle.use(finals[n], "catalog:" + str(n), role="corroboration")
        bundle.use(roster_doc, "current-roster")
        bundle.use(final_roster, "current-roster", role="corroboration")
        period_path = f"p[{methodology[1][0]}]"
        periods = json_column(
            [
                {
                    "occurrence_id": "rolling",
                    "period_text": PERIOD,
                    "kind": "relative",
                    "source_path": f"capture:{boot[0].capture_id}#{period_path}",
                }
            ]
        )
        bundle.tables["scorecards"][0].update(
            timespan_text=PERIOD, periods_json=periods, source_path=period_path, methodology_url=publisher.INDEX
        )
        bundle.add(
            "scorecard_methodologies",
            boot[0],
            period_path,
            methodology_id="publisher",
            methodology_url=publisher.INDEX,
            methodology_text="\n\n".join(text for _, text in methodology),
            disclosure_status="partial",
        )
        bundle.add(
            "scorecard_metrics",
            boot[3],
            "createPoliticianUi:selected-office.score",
            metric_id="current_office_cumulative",
            name="Score",
            value_unit_text="%",
            period_text=PERIOD,
            periods_json=periods,
            is_primary="true",
            methodology_id="publisher",
            cohort_text="Publisher current federal roster entries whose electedBody is US House or US Senate",
        )
        by_item = {item["id"]: (card, item) for card in catalog for item in card["criteria"]}
        by_period = {e.title: e.congress for e in editions}
        for cid, (doc, native, _) in details.items():
            card, item = by_item[cid]
            catdoc = catalogs[0] if card in json_data(catalogs[0]) else catalogs[1]
            path = "$[id=" + card["id"] + "].criteria[id=" + cid + "]"
            stance, pospath = publisher._position(doc, native)
            citation = item.get("billNumber")
            amendment = citation is not None and bool(re.match(r"[HS]\.Amdt\.", citation))
            bundle.use(doc, "criterion:" + cid)
            bundle.use(repeated_details[cid][0], "criterion:" + cid, role="corroboration")
            bundle.add(
                "scorecard_items",
                catdoc,
                path,
                item_id=cid,
                publisher_item_id=cid,
                item_kind_text=native["positionType"],
                title=item["name"],
                congress_text=by_period[card["name"]],
                bill_citation_text=None if amendment else citation,
                amendment_citation_text=citation if amendment else None,
                references_json=json_column(publisher._references(doc, native)),
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                position_source_path=f"capture:{doc.capture_id}#{pospath}" if pospath is not None else None,
            )
            bundle.add(
                "scorecard_methodologies",
                doc,
                "$",
                methodology_id="item:" + cid,
                methodology_text=json_column({k: v for k, v in native.items() if k != "positions"}),
                disclosure_status="partial",
            )
            bundle.add(
                "scorecard_metric_items",
                catdoc,
                path,
                metric_id="current_office_cumulative",
                item_id=cid,
                participation_id="profile",
                publisher_position_text=stance,
                position_basis="explicit" if stance is not None else None,
                contribution_rule_text="Native selected-office scorecards[].scores[].score; publisher cumulative formula retained as stated",
            )
        for pid, (document, _) in profiles.items():
            bundle.use(document, "politician:" + pid)
            bundle.use(repeated_profiles[pid][0], "politician:" + pid, role="corroboration")
        roster_positions = {str(member["id"]): n for n, member in enumerate(roster)}
        for member in members:
            mid, pid = str(member["id"]), str(member["politicianId"])
            doc, native = profiles[pid]
            number, office = selected[mid]
            name = " ".join(v for v in [member["givenNames"], member["surname"], member.get("suffix")] if v)
            # Roster locators use the full original array, including noncongressional offices.
            source_ordinal = roster_positions[mid]
            bundle.add(
                "scorecard_members",
                roster_doc,
                f"$[{source_ordinal}]",
                publisher_member_key=mid,
                publisher_member_id=mid,
                member_name=name,
                chamber_text=member["office"]["electedBody"],
                state=member["office"]["state"],
                district=member["office"]["electoralDistrict"] or None,
                party=member["party"],
                period_text=PERIOD,
                identifiers_json=json_column(
                    [
                        {"scheme": "votervoice_occupancy_id", "value": mid},
                        {"scheme": "votervoice_politician_id", "value": pid},
                    ]
                ),
                notes_text=json_column(
                    {
                        "roster": member,
                        "profile_name": native["profile"]["personName"],
                        "profile_display_name": native["profile"].get("displayName"),
                    }
                ),
            )
            value = None if office is None or office["score"] is None else _scalar(office["score"])
            rating_path = "$.offices" if number is None else f"$.offices[{number}].score"
            bundle.add(
                "scorecard_member_ratings",
                doc,
                rating_path,
                metric_id="current_office_cumulative",
                publisher_member_key=mid,
                value_text=None if value is None else value + "%",
                value_number=decimal_text(value),
                notes_text=json_column(
                    {
                        "politician_score": native["score"],
                        "office": None if office is None else {k: v for k, v in office.items() if k != "scorecards"},
                        "profile_offices_empty": native["offices"] == [],
                    }
                ),
            )
            if office is None:
                continue
            for cn, card in enumerate(office["scorecards"]):
                for sn, score in enumerate(card["scores"]):
                    cid = score["criterionId"]
                    path = f"$.offices[{number}].scorecards[{cn}].scores[{sn}]"
                    effect = _scalar(score["score"])
                    bundle.add(
                        "scorecard_member_item_results",
                        doc,
                        path,
                        publisher_member_key=mid,
                        item_id=cid,
                        result_id=key(mid, cid),
                        metric_id="current_office_cumulative",
                        participation_id="profile",
                        action_text=_scalar(score.get("position")),
                        result_text=_scalar(score.get("symbol")),
                        contribution_text=effect,
                        contribution_number=decimal_text(effect),
                        reason_text=json_column(score),
                    )
        return bundle.finish(
            "Complete current publisher roster and every selected politician profile reached EOF; unique source identities; exact current-office ID selection or explicit empty/null profile; every history item belongs to its source edition; complete roster, catalogs, profiles and details agree on independent reread",
            declared={
                "current_congressional_contexts": len(members),
                "politician_profiles": len(profiles),
                "native_numeric_scores": sum(o is not None and o["score"] is not None for _, o in selected.values()),
                "empty_profile_office_arrays": sum(o is None for _, o in selected.values()),
                "items": len(details),
                "history_results": len(bundle.tables["scorecard_member_item_results"]),
                "count_basis": "Lengths of complete publisher JSON arrays, not separately stated numeric totals",
            },
        )


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    return PPFACurrentReader().list_scorecards(context)


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    return PPFACurrentReader().acquire_scorecard(edition, context)
