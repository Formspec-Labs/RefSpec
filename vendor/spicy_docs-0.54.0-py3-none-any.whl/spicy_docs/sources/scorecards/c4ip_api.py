"""C4IP's current interactive scorecard and complete original public JSON catalogs.

The normal publisher app supplies an X-API-Key in its public JavaScript. The
reader acquires that original configuration and requests the header only for cscp.c4ip.org; it never belongs in URLs or
published evidence. Grades, years and member-bill relationships stay literal.
Bill relationships do not imply a roll call or a disclosed score contribution.
"""

from __future__ import annotations

import re
from urllib.parse import urlencode

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    json_data,
    key,
    soup,
)

parser_version = "c4ip-interactive-public-api/2"
HOSTS = ("c4ip.org",)
APP_HOSTS = ("scorecard.c4ip.org",)
API_HOSTS = ("cscp.c4ip.org",)
API = "https://cscp.c4ip.org"
APP = "https://scorecard.c4ip.org/"
APP_CONFIG = APP + "config.txt"
INDEX = "https://c4ip.org/interactive-scorecard/"
EDITION = ScorecardEdition("c4ip", "2026-interactive", INDEX, "2026 Interactive Scorecard", year="2026", chamber="both")
PAGE_SIZE = 100


def public_app_headers(body: bytes) -> dict[str, str]:
    """Read the publisher's normal app configuration; do not log returned values."""
    try:
        script = body.decode("utf-8")
        binding = re.search(r'headers:\{["\']X-API-Key["\']:([A-Za-z_$][\w$]*)', script)
        if binding is None or "https://cscp.c4ip.org" not in script:
            raise ValueError
        value = re.search(r"\b" + re.escape(binding.group(1)) + r"=[`\"']([^`\"']+)[`\"']", script)
        if value is None or not 8 <= len(value.group(1)) <= 200 or any(c.isspace() for c in value.group(1)):
            raise ValueError
        return {"X-API-Key": value.group(1), "Origin": "https://c4ip.org", "Referer": "https://c4ip.org/"}
    except (UnicodeError, ValueError):
        raise ScorecardSourceError("C4IP public application API configuration changed") from None


def _index(context: ScorecardContext):
    document = context.read(INDEX, stage="c4ip-api:edition", hosts=HOSTS)
    html = soup(document)
    main = html.select_one("main")
    if main is None or "2026 Interactive Scorecard" not in main.get_text(" ", strip=True):
        raise ScorecardSourceError("C4IP interactive scorecard edition changed")
    return document, main


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    _index(context)
    return (EDITION,)


def _bootstrap(context: ScorecardContext, source):
    scripts = [script.get_text() for script in soup(source).select("script:not([src])")]
    if len([script for script in scripts if APP_CONFIG in script and APP in script]) != 1:
        raise ScorecardSourceError("C4IP original scorecard app bootstrap changed")
    config = context.read(APP_CONFIG, stage="c4ip-api:app-config", hosts=APP_HOSTS)
    try:
        lines = config.body.decode("utf-8").strip().splitlines()
        if (
            len(lines) != 2
            or re.fullmatch(r"assets/index-[A-Za-z0-9_-]+\.js", lines[0]) is None
            or re.fullmatch(r"assets/index-[A-Za-z0-9_-]+\.css", lines[1]) is None
        ):
            raise ValueError
    except (UnicodeError, ValueError):
        raise ScorecardSourceError("C4IP original public app asset configuration changed") from None
    script = context.read(APP + lines[0], stage="c4ip-api:app-script", hosts=APP_HOSTS)
    return public_app_headers(script.body), (config, script)


def _read_api(context: ScorecardContext, url: str, *, stage: str, headers: dict[str, str]):
    return context.read_request(url, method="GET", content=None, request_headers=headers, stage=stage, hosts=API_HOSTS)


def _catalog(context: ScorecardContext, route: str, field: str, headers: dict[str, str]):
    rows, captures, total, skip = [], [], None, 0
    while True:
        document = _read_api(
            context,
            API + route + "?" + urlencode({"skip": skip, "limit": PAGE_SIZE}),
            stage="c4ip-api:" + field,
            headers=headers,
        )
        data = json_data(document)
        if not isinstance(data, dict) or not isinstance(data.get(field), list) or type(data.get("total")) is not int:
            raise ScorecardSourceError("C4IP catalog shape or declared count changed")
        declared = data["total"]
        records = data[field]
        if total is None:
            total = declared
        if total != declared or total <= 0 or total > 5000 or len(records) != min(PAGE_SIZE, total - skip):
            raise ScorecardSourceError("C4IP catalog pagination is incomplete or changed")
        if field == "members" and (data.get("skip") != skip or data.get("limit") != PAGE_SIZE):
            raise ScorecardSourceError("C4IP member pagination does not match the selected page")
        identity = "bioguideId" if field == "members" else "id"
        if any(not isinstance(row, dict) or not row.get(identity) for row in records):
            raise ScorecardSourceError("C4IP catalog lacks a source identity")
        rows.extend(records)
        captures.append((document, records))
        skip += len(records)
        if skip == total:
            break
        if not records:
            raise ScorecardSourceError("C4IP catalog ended before its declared count")
    if len({row[identity] for row in rows}) != total:
        raise ScorecardSourceError("C4IP catalog repeats identities across pages")
    return rows, captures


def acquire_scorecard(edition: ScorecardEdition, context: ScorecardContext):
    if edition != EDITION:
        raise ScorecardSourceError("C4IP API reader supports the stated 2026 interactive edition")
    primary, main = _index(context)
    headers, app_documents = _bootstrap(context, primary)
    members, member_pages = _catalog(context, "/public/members/browse", "members", headers)
    bills, bill_pages = _catalog(context, "/public/bills", "bills", headers)
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Council for Innovation Promotion",
        parser_version=parser_version,
        rendition_rule="c4ip-complete-public-api-catalogs-and-member-details/1",
        homepage="https://c4ip.org",
    )
    bundle.use(primary, "edition", "methodology")
    for document, group in zip(app_documents, ("app-config", "app-client-script"), strict=True):
        bundle.use(document, group)
    bundle.add(
        "scorecard_methodologies",
        primary,
        "main",
        methodology_id="interactive-description",
        methodology_text=main.get_text(" ", strip=True),
        methodology_url=INDEX,
        disclosure_status="partial: member-bill relationships do not disclose score contributions",
    )
    metric_ids = set()
    by_bill = {}
    for document, records in bill_pages:
        bundle.use(document, "bills:" + document.url)
        for position, bill in enumerate(records):
            identity = str(bill["id"])
            path = f"$.bills[{position}]"
            if any(
                bill.get(field) is None
                for field in ("identifier", "title", "congress_number", "bill_type", "bill_number")
            ):
                raise ScorecardSourceError("C4IP source bill identity is incomplete")
            by_bill[bill["id"]] = bill
            bundle.add(
                "scorecard_items",
                document,
                path,
                item_id=identity,
                publisher_item_id=identity,
                item_kind_text="bill",
                title=bill["title"],
                item_date_text=bill.get("introduced"),
                congress_text=str(bill["congress_number"]),
                bill_citation_text=bill["identifier"],
                references_json=json_column(
                    [
                        {
                            "occurrence_id": "bill",
                            "citation_text": bill["identifier"],
                            "kind": "bill",
                            "source_path": path + ".identifier",
                            "congress_text": str(bill["congress_number"]),
                        }
                    ]
                ),
                publisher_position_text=bill.get("impact_on_score"),
                position_basis="explicit" if bill.get("impact_on_score") else "absent",
                position_source_path=path + ".impact_on_score" if bill.get("impact_on_score") else None,
            )
            if bill.get("notes"):
                bundle.add(
                    "scorecard_methodologies",
                    document,
                    path + ".notes",
                    methodology_id=key(identity, "bill-notes"),
                    methodology_text=bill["notes"],
                    disclosure_status="partial: publisher bill rationale",
                )
    for document, records in member_pages:
        bundle.use(document, "members:" + document.url)
        for member in records:
            identity = member["bioguideId"]
            detail = _read_api(
                context, API + f"/public/members/{identity}/complete", stage="c4ip-api:member-detail", headers=headers
            )
            bundle.use(detail, "member:" + identity)
            data = json_data(detail)
            if (
                not isinstance(data, dict)
                or not {
                    "bioguideId",
                    "member_name",
                    "state",
                    "party",
                    "chamber",
                    "in_congress",
                    "district",
                    "current_score",
                    "prior_score",
                    "current_score_year",
                    "previous_score_year",
                    "sponsored_bills",
                    "cosponsored_bills",
                }.issubset(data)
                or any(
                    data.get(field) != member.get(field)
                    for field in ("bioguideId", "member_name", "state", "party", "chamber", "in_congress")
                )
            ):
                raise ScorecardSourceError("C4IP detail identity disagrees with the source catalog")
            if data.get("current_score") != member.get("score"):
                raise ScorecardSourceError("C4IP current grade changed during acquisition")
            bundle.add(
                "scorecard_members",
                detail,
                "$",
                publisher_member_key=identity,
                publisher_member_id=identity,
                identifiers_json=json_column([{"scheme": "bioguide", "value": identity}]),
                member_name=data["member_name"],
                chamber_text=data["chamber"],
                state=data["state"],
                district=data.get("district"),
                party=data["party"],
            )
            for source_field, year_field in (
                ("current_score", "current_score_year"),
                ("prior_score", "previous_score_year"),
            ):
                value, year = data.get(source_field), data.get(year_field)
                if value is not None and not isinstance(value, str):
                    raise ScorecardSourceError("C4IP grade is no longer literal text")
                if year is not None and (type(year) is not int or not 2000 <= year <= 2100):
                    raise ScorecardSourceError("C4IP grade period representation changed")
                metric_id = key(source_field, str(year) if year is not None else "unstated-period")
                if metric_id not in metric_ids:
                    bundle.add(
                        "scorecard_metrics",
                        detail,
                        "$" + "." + year_field,
                        metric_id=metric_id,
                        name=source_field,
                        period_text=str(year) if year is not None else None,
                        value_unit_text="grade",
                        is_primary="true" if source_field == "current_score" else "false",
                    )
                    metric_ids.add(metric_id)
                bundle.add(
                    "scorecard_member_ratings",
                    detail,
                    "$" + "." + source_field,
                    metric_id=metric_id,
                    publisher_member_key=identity,
                    value_text=value,
                )
            for field in ("sponsored_bills", "cosponsored_bills"):
                actions = data.get(field)
                if not isinstance(actions, list) or len(
                    {action.get("id") for action in actions if isinstance(action, dict)}
                ) != len(actions):
                    raise ScorecardSourceError("C4IP member bill relationships are malformed or repeated")
                for position, bill in enumerate(actions):
                    known = by_bill.get(bill.get("id"))
                    if known is None or any(
                        bill.get(f) != known.get(f) for f in ("title", "congress_number", "bill_type", "bill_number")
                    ):
                        raise ScorecardSourceError(
                            "C4IP member bill relationship does not reconcile to the complete source catalog"
                        )
                    bundle.add(
                        "scorecard_member_item_results",
                        detail,
                        f"$.{field}[{position}]",
                        item_id=str(bill["id"]),
                        publisher_member_key=identity,
                        result_id=field,
                        result_text=field,
                    )
    for route, field, expected in (("/public/members/browse", "members", members), ("/public/bills", "bills", bills)):
        repeated, pages = _catalog(context, route, field, headers)
        if repeated != expected:
            raise ScorecardSourceError("C4IP complete source catalog changed during acquisition")
        for document, _ in pages:
            bundle.use(document, field + ":" + document.url, role="corroboration")
    return bundle.finish(
        "Complete paginated member and bill catalogs reconcile to their publisher-declared counts and repeat unchanged; every listed member detail matches the source identity and current grade. All source-stated current/prior grades and sponsorship/cosponsorship relationships are retained. Relationships have no invented roll call, score contribution or metric participation.",
        declared={"members": len(members), "bills": len(bills)},
    )
