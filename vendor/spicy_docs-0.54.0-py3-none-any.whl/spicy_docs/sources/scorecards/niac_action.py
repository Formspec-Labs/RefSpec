"""NIAC Action's original current score CSVs and their native item metadata."""

from __future__ import annotations

import csv
import io
import json
import re
from urllib.parse import urljoin

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
    soup,
)

parser_version = "niac-action-current-native-csv/2"
INDEX = "https://scorecard.niacaction.org/"
PUBLISHER = "https://niacouncil.org/homepage_carousel/niac-action-congressional-scorecard/"
HOSTS = ("scorecard.niacaction.org", "niacouncil.org")
EDITION = ScorecardEdition("niac_action", "current-csv", INDEX, "NIAC Action Scorecard", chamber="both")
MEMBER_FIELDS = (
    "full_name",
    "party",
    "state",
    "chamber",
    "bioguide_id",
    "photo_url",
    "district",
    "office_phone",
    "office_address",
    "district_offices",
    "committees",
    "reject_aipac_commitment",
    "reject_aipac_link",
    "first_year_in_office",
    "official_website",
    "birth_year",
    "sworn_in_date",
    "age",
    "years_in_office",
    "in_office",
    "next_election",
    "iran_war_powers_position",
    "iran_war_powers_quote",
    "iran_war_powers_quote_link",
    "iran_war_powers_quote_position",
)
METRIC_FIELDS = tuple(
    field + suffix
    for suffix in ("", "_Civil_Rights_Immigration", "_Iran", "_Israel_Gaza")
    for field in ("Total", "Max_Possible", "Percent", "Grade")
)
CATEGORY_SUFFIX = {
    "Civil Rights & Immigration": "_Civil_Rights_Immigration",
    "Iran": "_Iran",
    "Israel-Gaza": "_Israel_Gaza",
}
FLAGS = ("_cosponsor", "_absent", "_present", "_not_in_office")
META_FIELDS = (
    "column",
    "type",
    "bill_number",
    "display_name",
    "categories",
    "action_types",
    "short_title",
    "notes",
    "sponsor_bioguide_id",
    "sponsor_name",
    "position_to_score",
    "preferred",
    "pair_key",
    "chamber",
    "description",
    "analysis",
    "points",
    "introduced_date",
    "congress_url",
    "learn_more_link",
    "no_cosponsor_benefit",
    "war_powers_consolidated",
    "vote_tallies",
    "vote_date",
    "tracker_only",
)
GRADES = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F", "NA", "N/A", "Incomplete"}


def _literal(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _application(document):
    html = soup(document)
    if "NIAC Action" not in html.get_text(" ", strip=True) or "Scorecard" not in html.get_text(" ", strip=True):
        raise ScorecardSourceError("NIAC Action application identity is absent")
    scripts = [s.get("src", "") for s in html.find_all("script")]
    candidates = [s for s in scripts if re.fullmatch(r"/_next/static/chunks/933-[a-z0-9]+\.js", s)]
    if len(candidates) != 1:
        raise ScorecardSourceError("NIAC Action native CSV loader script is absent or changed")
    return urljoin(document.url, candidates[0])


def _loader(document):
    try:
        text = document.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("NIAC Action application loader is not UTF-8") from None
    names = ("scores_wide.csv", "scores_columns_meta.csv", "manual_scoring_meta.csv")
    if any(text.count('n("/data/' + name + '")') != 1 for name in names):
        raise ScorecardSourceError("NIAC Action native CSV endpoints are absent or changed")
    versions = re.findall(r'let t=""\.concat\(e,"\?v="\)\.concat\("(\d+)"\)', text)
    if len(versions) != 1:
        raise ScorecardSourceError("NIAC Action native CSV revision parameter changed")
    return tuple(urljoin(INDEX, "data/" + name) + "?v=" + versions[0] for name in names)


def _publisher(document):
    html = soup(document)
    if not any(
        a.get("href")
        in {INDEX, INDEX.rstrip("/"), INDEX.replace("https:", "http:"), INDEX.replace("https:", "http:").rstrip("/")}
        for a in html.find_all("a")
    ):
        raise ScorecardSourceError("NIAC original publisher no longer links the selected scorecard application")


def _csv(document):
    try:
        text = document.body.decode("utf-8-sig")
        if not text.endswith("\n"):
            raise ValueError
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        header = next(reader)
        if not header or any(not field for field in header) or len(set(header)) != len(header):
            raise ValueError
        rows = []
        for values in reader:
            if not values:
                continue
            if len(values) != len(header):
                raise ValueError
            rows.append(dict(zip(header, values, strict=True)))
        if not rows:
            raise ValueError
    except (ValueError, UnicodeError, csv.Error, StopIteration):
        raise ScorecardSourceError("NIAC Action CSV is empty, truncated, duplicated or malformed") from None
    return header, rows


def _facts(scores, metadata, manual):
    fields, members = _csv(scores)
    meta_fields, items = _csv(metadata)
    manual_fields, manual_rows = _csv(manual)
    if tuple(meta_fields) != META_FIELDS or manual_fields != ["label", "score", "custom_scoring_description"]:
        raise ScorecardSourceError("NIAC Action item or manual methodology CSV fields changed")
    columns = [item["column"] for item in items]
    if not all(columns) or len(set(columns)) != len(columns) or not set(columns) <= set(fields):
        raise ScorecardSourceError("NIAC Action native item columns do not reconcile with the score CSV")
    flag_fields = {column + flag for column in columns for flag in FLAGS} & set(fields)
    if set(fields) != set(MEMBER_FIELDS) | set(METRIC_FIELDS) | set(columns) | flag_fields:
        raise ScorecardSourceError("NIAC Action native score columns include missing or unreviewed fields")
    identifiers = set()
    for member in members:
        identifier = member["bioguide_id"]
        if (
            not re.fullmatch(r"[A-Z]\d{6}", identifier)
            or identifier in identifiers
            or not all(member[field] for field in ("full_name", "party", "state"))
            or member["chamber"] not in {"HOUSE", "SENATE"}
            or member["in_office"] not in {"0", "1"}
        ):
            raise ScorecardSourceError("NIAC Action native roster identity is missing or duplicated")
        identifiers.add(identifier)
        for field in METRIC_FIELDS:
            value = member[field]
            if (field.startswith("Grade") and value not in GRADES) or (
                not field.startswith("Grade") and value not in {"", "NA", "N/A"} and decimal_text(value) is None
            ):
                raise ScorecardSourceError("NIAC Action native score or grade shape changed")
        if any(member[field] not in {"", "0", "0.0", "1", "1.0"} for field in flag_fields):
            raise ScorecardSourceError("NIAC Action native member item flags changed")
        if any(member[column] and decimal_text(member[column]) is None for column in columns):
            raise ScorecardSourceError("NIAC Action native member item points are not exact decimals")
    if {member["chamber"] for member in members} != {"HOUSE", "SENATE"}:
        raise ScorecardSourceError("NIAC Action native CSV does not contain both source chambers")
    for item in items:
        categories = [c.strip() for c in item["categories"].split(";") if c.strip()]
        if (
            item["type"] not in {"BILL", "MANUAL"}
            or item["position_to_score"] not in {"SUPPORT", "OPPOSE"}
            or not item["display_name"]
            or decimal_text(item["points"]) is None
            or item["tracker_only"] not in {"0", "1"}
            or item["chamber"] not in {"", "HOUSE", "SENATE"}
            or not categories
            or not set(categories) <= set(CATEGORY_SUFFIX)
        ):
            raise ScorecardSourceError("NIAC Action native item metadata shape changed")
    if any(
        not row["label"] or decimal_text(row["score"]) is None or not row["custom_scoring_description"]
        for row in manual_rows
    ):
        raise ScorecardSourceError("NIAC Action manual methodology rows are incomplete")
    if len({(r["label"], r["score"]) for r in manual_rows}) != len(manual_rows):
        raise ScorecardSourceError("NIAC Action manual methodology keys are duplicated")
    return members, items, manual_rows


def list_scorecards(context):
    _application(context.read(INDEX, stage="scorecards:niac-action:listing", hosts=HOSTS))
    return (EDITION,)


def acquire_scorecard(edition, context):
    if edition != EDITION:
        raise ScorecardSourceError("NIAC Action current CSV reader requires its named current scope")
    original = context.read(PUBLISHER, stage="scorecards:niac-action:publisher-start", hosts=HOSTS)
    _publisher(original)
    app = context.read(INDEX, stage="scorecards:niac-action:application-start", hosts=HOSTS)
    loader_url = _application(app)
    loader = context.read(loader_url, stage="scorecards:niac-action:loader-start", hosts=HOSTS)
    urls = _loader(loader)
    sources = [context.read(url, stage="scorecards:niac-action:csv-start", hosts=HOSTS) for url in urls]
    facts = _facts(*sources)
    ends = [context.read(url, stage="scorecards:niac-action:csv-end", hosts=HOSTS) for url in urls]
    if _facts(*ends) != facts:
        raise ScorecardSourceError("NIAC Action native score CSVs changed during acquisition")
    loader_end = context.read(loader_url, stage="scorecards:niac-action:loader-end", hosts=HOSTS)
    app_end = context.read(INDEX, stage="scorecards:niac-action:application-end", hosts=HOSTS)
    original_end = context.read(PUBLISHER, stage="scorecards:niac-action:publisher-end", hosts=HOSTS)
    _publisher(original_end)
    if _loader(loader_end) != urls or _application(app_end) != loader_url:
        raise ScorecardSourceError("NIAC Action application data selection changed during acquisition")
    members, items, manual_rows = facts
    scores, metadata, manual = sources
    bundle = Bundle(
        edition,
        context,
        scores,
        publisher_name="NIAC Action",
        parser_version=parser_version,
        rendition_rule="niac-original-csv-values-and-complete-native-point-flag-grid/2",
        homepage="https://niacouncil.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(series_id=key("niac_action", "Scorecard"), methodology_url=metadata.url)
    for source, groups in [
        (scores, ("ratings", "members", "native_member_item_points")),
        (metadata, ("items", "item_metadata")),
        (manual, ("manual_methodology",)),
        (app, ("application",)),
        (loader, ("data_selection",)),
        (original, ("publisher_link",)),
    ]:
        bundle.use(source, *groups)
    for source, groups in zip(
        ends,
        [("ratings", "members", "native_member_item_points"), ("items", "item_metadata"), ("manual_methodology",)],
        strict=True,
    ):
        bundle.use(source, *groups, role="corroboration")
    bundle.use(loader_end, "data_selection", role="corroboration")
    bundle.use(app_end, "application", role="corroboration")
    bundle.use(original_end, "publisher_link", role="corroboration")
    for field in METRIC_FIELDS:
        bundle.metric(
            scores,
            key("column", field),
            field,
            path="CSV/header/" + field,
            unit="grade" if field.startswith("Grade") else "percent" if field.startswith("Percent") else None,
            primary=field == "Grade",
        )
    for ordinal, row in enumerate(manual_rows, 2):
        bundle.add(
            "scorecard_methodologies",
            manual,
            f"CSV/row/{ordinal}",
            methodology_id=key("manual", row["label"], row["score"]),
            methodology_text=_literal(row),
            methodology_url=manual.url,
            disclosure_status="literal native manual scoring description; no score reproduction",
        )
    for ordinal, item in enumerate(items, 2):
        path, identifier = f"CSV/row/{ordinal}", key("column", item["column"])
        references = []
        for field, kind in [("bill_number", "citation"), ("congress_url", "url"), ("learn_more_link", "url")]:
            if item[field]:
                references.append(
                    {
                        "occurrence_id": field,
                        "kind": kind,
                        "citation_text": item[field],
                        "source_path": path + "/" + field,
                    }
                )
        bundle.add(
            "scorecard_items",
            metadata,
            path,
            item_id=identifier,
            publisher_item_id=item["column"],
            title=item["display_name"],
            item_kind_text=item["action_types"] or item["type"],
            item_date_text=item["vote_date"] or item["introduced_date"] or None,
            chamber_text=item["chamber"] or None,
            bill_citation_text=item["bill_number"] or None,
            references_json=_literal(references),
            publisher_position_text=item["position_to_score"],
            position_basis="explicit",
            position_source_path=path + "/position_to_score",
        )
        bundle.add(
            "scorecard_methodologies",
            metadata,
            path,
            methodology_id=key("item-metadata", item["column"]),
            methodology_text=_literal(item),
            methodology_url=metadata.url,
            disclosure_status="literal item metadata, categories, point allocation, tracker flag and native citations",
        )
        for field in [
            "Total",
            *("Total" + CATEGORY_SUFFIX[c.strip()] for c in item["categories"].split(";") if c.strip()),
        ]:
            bundle.add(
                "scorecard_metric_items",
                metadata,
                path,
                participation_id=key("column", field, item["column"]),
                metric_id=key("column", field),
                item_id=identifier,
                publisher_position_text=item["position_to_score"],
                position_basis="explicit",
                weight_text=item["points"],
                weight_number=decimal_text(item["points"]),
                counts_toward_metric="false" if item["tracker_only"] == "1" else None,
                contribution_rule_text=_literal(
                    {
                        k: item[k]
                        for k in ["action_types", "no_cosponsor_benefit", "war_powers_consolidated", "tracker_only"]
                    }
                ),
            )
    for ordinal, member in enumerate(members, 2):
        path, member_key = f"CSV/row/{ordinal}", key("bioguide", member["bioguide_id"])
        bundle.add(
            "scorecard_members",
            scores,
            path,
            publisher_member_key=member_key,
            member_name=member["full_name"],
            chamber_text=member["chamber"],
            state=member["state"],
            district=member["district"] or None,
            party=member["party"],
            identifiers_json=_literal([{"scheme": "bioguide", "value": member["bioguide_id"]}]),
            notes_text=_literal({field: member[field] for field in MEMBER_FIELDS}),
        )
        for field in METRIC_FIELDS:
            value = member[field]
            if value == "":
                continue
            bundle.add(
                "scorecard_member_ratings",
                scores,
                path + "/" + field,
                metric_id=key("column", field),
                publisher_member_key=member_key,
                value_text="N/A" if value == "NA" else value,
                value_number=None if field.startswith("Grade") else decimal_text(value),
                notes_text=_literal({"native_value": value}) if value == "NA" else None,
            )
        for item in items:
            column = item["column"]
            flags = {flag.removeprefix("_"): member[column + flag] for flag in FLAGS if column + flag in member}
            bundle.add(
                "scorecard_member_item_results",
                scores,
                path + "/" + column,
                result_id=key("member-item", member["bioguide_id"], column),
                publisher_member_key=member_key,
                item_id=key("column", column),
                metric_id=key("column", "Total"),
                participation_id=key("column", "Total", column),
                result_text=member[column],
                contribution_text=member[column],
                contribution_number=decimal_text(member[column]),
                reason_text=_literal(flags),
            )
    return bundle.finish(
        "Complete finite original CSVs through EOF; exact native roster identities and item-column membership; all literal metrics and every member item point cell, including literal empty values and all supplied zero/false flags; stable rereads of CSVs and publisher application selection. Named CSV rendition excludes PAC finance CSV and does not reconstruct official votes or publisher scores."
    )
