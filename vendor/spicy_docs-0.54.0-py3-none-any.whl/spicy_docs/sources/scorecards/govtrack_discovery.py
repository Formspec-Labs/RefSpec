"""Read pinned GovTrack publisher metadata as discovery leads, never ratings."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

from spicy_docs.reading.yaml_input import load_bounded_yaml
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.credentials import CredentialRefusedError
from spicy_docs.transport.source_acquirer import SourceAcquirer, check_payload

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

REPOSITORY = "govtrack/advocacy-organization-scorecards"
DEFAULT_COMMIT = "fa63a2b5326edd4b8835386082c2317627f058ce"
MAX_BYTES = 2 * 1024 * 1024
MAX_FILES = 128
PARSER_VERSION = "govtrack-discovery-v1"
_SHA = re.compile(r"[0-9a-f]{40}")
_PATH = re.compile(r"scorecards/[A-Za-z0-9_.-]+\.yaml")


class GovTrackDiscoveryError(ValueError):
    """The selected discovery input is unavailable or ambiguous."""


def commit_url(commit: str) -> str:
    if not isinstance(commit, str) or not _SHA.fullmatch(commit):
        raise GovTrackDiscoveryError("commit must be a full lowercase Git SHA")
    return f"https://api.github.com/repos/{REPOSITORY}/git/commits/{commit}"


def tree_url(tree_sha: str) -> str:
    commit_url(tree_sha)
    return f"https://api.github.com/repos/{REPOSITORY}/git/trees/{tree_sha}?recursive=1"


def metadata_url(commit: str, path: str) -> str:
    tree_url(commit)
    if not isinstance(path, str) or not _PATH.fullmatch(path):
        raise GovTrackDiscoveryError("path must select a direct scorecards YAML file")
    return f"https://raw.githubusercontent.com/{REPOSITORY}/{commit}/{path}"


def _instant(value: str) -> None:
    try:
        parsed = datetime.fromisoformat(value)
    except (AttributeError, TypeError, ValueError) as error:
        raise GovTrackDiscoveryError("observation requires an ISO timestamp") from error
    if parsed.tzinfo is None:
        raise GovTrackDiscoveryError("observation requires a timezone")


def _checked(capture: CapturedBodyResponse, url: str, *, tree: bool = False) -> bytes:
    if capture.status_code in (401, 403):
        raise CredentialRefusedError("GovTrack discovery access refused; stop acquisition")
    if capture.status_code != 200:
        raise GovTrackDiscoveryError(f"GovTrack discovery returned HTTP {capture.status_code}")
    if capture.requested_url != url or capture.resolved_url != url or capture.method != "GET":
        raise GovTrackDiscoveryError("discovery capture left its exact pinned GET locator")
    if capture.content_encoding not in ("", "identity"):
        raise GovTrackDiscoveryError("discovery requires decoded identity bytes")
    media = (capture.content_type or "").split(";", 1)[0].strip().lower()
    allowed = (
        {"application/json"} if tree else {"text/plain", "application/yaml", "text/yaml", "application/octet-stream"}
    )
    if media not in allowed:
        raise GovTrackDiscoveryError("discovery response has an unexpected content type")
    _instant(capture.observed_at)
    return check_payload(
        capture.body, MAX_BYTES, label="GovTrack discovery", error_type=GovTrackDiscoveryError, allow_empty=False
    )


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise GovTrackDiscoveryError("discovery tree has duplicate fields")
        result[key] = value
    return result


def parse_commit(capture: CapturedBodyResponse, *, commit: str) -> str:
    raw = _checked(capture, commit_url(commit), tree=True)
    try:
        data = json.loads(raw, object_pairs_hook=_object)
    except (ValueError, UnicodeError, RecursionError) as error:
        raise GovTrackDiscoveryError("commit is not unambiguous JSON") from error
    if not isinstance(data, dict) or data.get("sha") != commit or not isinstance(data.get("tree"), dict):
        raise GovTrackDiscoveryError("commit response does not prove the requested commit")
    tree_sha = data["tree"].get("sha")
    if not isinstance(tree_sha, str) or not _SHA.fullmatch(tree_sha):
        raise GovTrackDiscoveryError("commit response lacks its root tree SHA")
    return tree_sha


def parse_tree(capture: CapturedBodyResponse, *, commit: str, tree_sha: str) -> tuple[dict, ...]:
    raw = _checked(capture, tree_url(tree_sha), tree=True)
    try:
        data = json.loads(raw, object_pairs_hook=_object)
    except (ValueError, UnicodeError, RecursionError) as error:
        raise GovTrackDiscoveryError("discovery tree is not unambiguous JSON") from error
    if (
        not isinstance(data, dict)
        or data.get("sha") != tree_sha
        or data.get("truncated") is not False
        or not isinstance(data.get("tree"), list)
    ):
        raise GovTrackDiscoveryError("discovery tree must prove the requested complete commit")
    files, seen = [], set()
    for entry in data["tree"]:
        if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
            raise GovTrackDiscoveryError("discovery tree entry lacks a path")
        path = entry["path"]
        if path in seen:
            raise GovTrackDiscoveryError("discovery tree repeats a path")
        seen.add(path)
        if not path.startswith("scorecards/"):
            continue
        metadata_url(commit, path)
        if (
            entry.get("type") != "blob"
            or entry.get("mode") != "100644"
            or not isinstance(entry.get("sha"), str)
            or not _SHA.fullmatch(entry["sha"])
            or type(entry.get("size")) is not int
            or not 0 < entry["size"] <= MAX_BYTES
        ):
            raise GovTrackDiscoveryError("discovery tree has an unsupported scorecard entry")
        files.append({key: entry[key] for key in ("path", "sha", "size")})
    if not 1 <= len(files) <= MAX_FILES:
        raise GovTrackDiscoveryError("discovery tree has no scorecard files or exceeds its file bound")
    return tuple(sorted(files, key=lambda row: row["path"]))


def _url(value: object) -> str:
    if not isinstance(value, str) or value != value.strip() or any(c.isspace() or ord(c) < 32 for c in value):
        raise GovTrackDiscoveryError("publisher URL must be unambiguous text")
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as error:
        raise GovTrackDiscoveryError("publisher URL is malformed") from error
    if (
        parsed.scheme not in ("http", "https")
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or port not in (None, 80, 443)
    ):
        raise GovTrackDiscoveryError("publisher URL must be an absolute credential-free HTTP(S) URL")
    if parsed.hostname.lower() in {"github.com", "raw.githubusercontent.com", "govtrack.us", "www.govtrack.us"}:
        raise GovTrackDiscoveryError("publisher link must point beyond the discovery provider")
    return value


@dataclass(frozen=True, slots=True)
class DiscoveryLead:
    discovery_id: str
    repository: str
    commit: str
    repository_path: str
    repository_blob_sha1: str
    capture_sha256: str
    metadata_sha256: str
    metadata_line_end: int
    observed_at: str
    name: str
    abbreviation: str | None
    homepage_url: str
    original_scorecard_url: str
    updated_text: str
    period_text: str
    rating_unit_text: str
    discovered_via: str

    def to_dict(self) -> dict:
        return asdict(self)


def parse_metadata(capture: CapturedBodyResponse, *, commit: str, entry: Mapping) -> DiscoveryLead:
    path = entry["path"]
    url = metadata_url(commit, path)
    raw = _checked(capture, url)
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    if len(raw) != entry["size"] or blob != entry["sha"]:
        raise GovTrackDiscoveryError("metadata bytes differ from pinned tree size or Git blob SHA")
    # Stop exactly at YAML's document-end marker. The CSV tail is neither
    # decoded nor parsed, so ratings and maintainer notes cannot become leads.
    lines = raw.splitlines(keepends=True)
    end = next((i for i, line in enumerate(lines) if line.rstrip(b"\r\n \t") == b"..."), None)
    if end is None:
        raise GovTrackDiscoveryError("metadata requires an explicit YAML/CSV boundary")
    header = b"".join(lines[:end])
    data = load_bounded_yaml(
        header,
        source="GovTrack discovery metadata",
        error_type=GovTrackDiscoveryError,
        max_bytes=MAX_BYTES,
        max_nodes=100,
        max_depth=4,
    )
    fields = {"name", "abbrev", "homepage", "link", "updated", "based-on", "type"}
    if not isinstance(data, dict) or set(data) - fields:
        raise GovTrackDiscoveryError("metadata has unsupported fields; inspect source drift")
    for field in fields - {"abbrev"}:
        if not isinstance(data.get(field), str) or not data[field].strip():
            raise GovTrackDiscoveryError(f"metadata requires nonempty {field} text")
    if data.get("abbrev") is not None and (not isinstance(data["abbrev"], str) or not data["abbrev"].strip()):
        raise GovTrackDiscoveryError("abbreviation must be null or nonempty text")
    return DiscoveryLead(
        discovery_id=f"govtrack:{path}",
        repository=REPOSITORY,
        commit=commit,
        repository_path=path,
        repository_blob_sha1=blob,
        capture_sha256=capture.sha256,
        metadata_sha256="sha256:" + hashlib.sha256(header).hexdigest(),
        metadata_line_end=end,
        observed_at=capture.observed_at,
        name=data["name"],
        abbreviation=data.get("abbrev"),
        homepage_url=_url(data["homepage"]),
        original_scorecard_url=_url(data["link"]),
        updated_text=data["updated"],
        period_text=data["based-on"],
        rating_unit_text=data["type"],
        discovered_via=f"https://github.com/{REPOSITORY}/blob/{commit}/{path}",
    )


def parse_retained(captures: Mapping[str, CapturedBodyResponse], *, commit: str) -> tuple[DiscoveryLead, ...]:
    """Require every listed metadata file; one failure refuses the discovery run."""
    if not {"commit", "tree"} <= captures.keys():
        raise GovTrackDiscoveryError("retained discovery is missing commit or tree capture")
    tree_sha = parse_commit(captures["commit"], commit=commit)
    entries = parse_tree(captures["tree"], commit=commit, tree_sha=tree_sha)
    if set(captures) != {"commit", "tree", *(entry["path"] for entry in entries)}:
        raise GovTrackDiscoveryError("retained captures do not match complete pinned tree membership")
    return tuple(parse_metadata(captures[e["path"]], commit=commit, entry=e) for e in entries)


class GovTrackDiscoveryAcquirer(SourceAcquirer):
    """Bounded keyless captures; callers retain bytes privately for offline replay."""

    def __init__(self, *, transport=None, max_requests: int = MAX_FILES + 2):
        super().__init__(
            max_requests=max_requests,
            timeout_seconds=30,
            min_request_interval_seconds=0.2,
            user_agent="spicy-docs-govtrack-discovery/1.0",
            label="GovTrack discovery",
            error_type=GovTrackDiscoveryError,
            context_key="govtrack_discovery",
            transport=transport,
            keyless=True,
        )

    def acquire(
        self, *, commit: str = DEFAULT_COMMIT, retain: Callable[[str, CapturedBodyResponse], None]
    ) -> tuple[DiscoveryLead, ...]:
        captures = {}

        def capture(key, url, tree=False):
            _, response = self.capture_validated(
                url,
                media_types=("application/json",)
                if tree
                else ("text/plain", "application/yaml", "text/yaml", "application/octet-stream"),
                parse=lambda response, _limit: _checked(response, url, tree=tree),
                max_bytes=MAX_BYTES,
                unavailable=lambda response: GovTrackDiscoveryError(
                    f"GovTrack discovery returned HTTP {response.status_code}"
                ),
                context={"commit": commit, "path": key},
                reset_budget=key == "commit",
            )
            retain(key, response)
            captures[key] = response
            return response

        tree_sha = parse_commit(capture("commit", commit_url(commit), True), commit=commit)
        entries = parse_tree(capture("tree", tree_url(tree_sha), True), commit=commit, tree_sha=tree_sha)
        for entry in entries:
            response = capture(entry["path"], metadata_url(commit, entry["path"]))
            parse_metadata(response, commit=commit, entry=entry)
        return parse_retained(captures, commit=commit)
