"""Peace Action's native WordPress score fields and complete annual vote records."""

from __future__ import annotations

import json
import re
from collections import Counter

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardEdition,
    ScorecardSourceError,
    _invalid_json_constant,
    _unique_json_fields,
    decimal_text,
    json_data,
    key,
    soup,
)

parser_version = "peace-action-native-wordpress/2"
BASE = "https://www.peaceaction.org"
INDEX = BASE + "/know-the-score/"
HOSTS = ("www.peaceaction.org", "peaceaction.org")
REST = BASE + "/wp-json/"
MEMBERS = REST + "wp/v2/legislators/?nopaging=true"
IDS = REST + "wp-congress/v1/legislator-ids"
METRICS = ("wpc_score", "wpc_voted_with_score", "wpc_voted_against_score")
MEMBER_FIELDS = {
    "wpc_district",
    "wpc_first_name",
    "wpc_last_name",
    "wpc_in_office",
    "wpc_district_number",
    "wpc_party",
    "wpc_address",
    "wpc_state",
    "wpc_phone",
    "wpc_twitter",
    "wpc_facebook",
    "wpc_id",
    *METRICS,
}
VOTE_FIELDS = {
    "wpc_position",
    "wpc_why",
    "wpc_voted_with_us",
    "wpc_voted_against_us",
    "wpc_voted_other_us",
    "wpc_latest_action",
    "wpc_date",
    "wpc_year",
    "wpc_month",
    "wpc_day",
    "wpc_chamber",
    "wpc_vote_uri",
    "wpc_states_with",
    "wpc_states_against",
}
GROUPS = ("wpc_voted_with_us", "wpc_voted_against_us", "wpc_voted_other_us")
PAGE_SIZE = 100


def literal(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def votes_url(page):
    return REST + f"wp/v2/votes/?per_page={PAGE_SIZE}&page={page}"


def rating_url(year):
    return REST + "wp-congress/v1/honor-roll/?percent=0&year=" + year


def _route_schema(source):
    data = json_data(source)
    try:
        routes = data["routes"]
        vote = routes["/wp/v2/votes"]
        endpoint = next(e for e in vote["endpoints"] if "GET" in e["methods"])
        args = endpoint["args"]
        if (
            vote["namespace"] != "wp/v2"
            or args["per_page"]["maximum"] != PAGE_SIZE
            or args["page"]["minimum"] != 1
            or args["per_page"]["minimum"] != 1
            or "GET" not in routes["/wp-congress/v1/legislator-ids"]["methods"]
            or "GET" not in routes["/wp-congress/v1/honor-roll"]["methods"]
        ):
            raise ValueError
    except (KeyError, TypeError, ValueError, StopIteration):
        raise ScorecardSourceError("Peace Action native route schema or pagination bound changed") from None
    return {
        name: routes[name]
        for name in (
            "/wp/v2/votes",
            "/wp/v2/legislators",
            "/wp-congress/v1/legislator-ids",
            "/wp-congress/v1/honor-roll",
        )
    }


def _application(source):
    document = soup(source)
    headlines = [h.get_text(" ", strip=True) for h in document.find_all("h1")]
    titles = [h for h in headlines if h.startswith("Peace Action’s Congressional Scorecard")]
    notes = [h for h in headlines if h.startswith("Note:")]
    configurations = []
    for script in document.find_all("script"):
        match = re.search(r"var wpCongressApiSettings\s*=\s*(\{.*?\});", script.get_text(), re.DOTALL)
        if match:
            try:
                configurations.append(
                    json.loads(match[1], object_pairs_hook=_unique_json_fields, parse_constant=_invalid_json_constant)
                )
            except (ValueError, TypeError):
                raise ScorecardSourceError("Peace Action original client configuration changed") from None
    loaders = [
        s["src"]
        for s in document.find_all("script", src=True)
        if "/wp-congress/assets/js/wp-congress.min.js" in s["src"]
    ]
    if (
        document.title is None
        or document.title.get_text() != "Know the Score - Peace Action"
        or len(titles) != 1
        or len(notes) != 1
        or len(configurations) != 1
        or len(loaders) != 1
        or configurations[0].get("root") != REST
        or configurations[0].get("versionString") != "wp/v2/"
    ):
        raise ScorecardSourceError("Peace Action original publisher/client selection changed")
    # Public browser keys/nonces are not copied into records or request headers.
    return titles[0], notes[0], loaders[0]


def _client(source):
    try:
        text = source.body.decode("utf-8")
    except UnicodeError:
        raise ScorecardSourceError("Peace Action original client is not UTF-8") from None
    for fragment in [
        'versionString+"legislators/',
        'versionString+"votes/',
        "/wp-json/wp-congress/v1/honor-roll/",
        "nopaging:!0",
        "Math.floor(i/u*100)",
    ]:
        if fragment not in text:
            raise ScorecardSourceError("Peace Action native scorecard client endpoints or display formula changed")
    start = text.find('d.when.apply(d,d(".vote-result")')
    end = text.find('d.ajax({url:wpCongressApiSettings.root+wpCongressApiSettings.versionString+"votes/",', start)
    if start < 0 or end <= start:
        raise ScorecardSourceError("Peace Action original member/year display disclosure changed")
    return text[start:end]


def _members(source, crosswalk):
    records, ids = json_data(source), json_data(crosswalk)
    if (
        not isinstance(records, list)
        or not records
        or not isinstance(ids, list)
        or any(not isinstance(i, str) or not i for i in ids)
    ):
        raise ScorecardSourceError("Peace Action complete native directory or ID census is absent")
    seen = set()
    for row in records:
        try:
            fields = row["cmb2"]["wpc_legislator_details"]
            valid = (
                type(row["id"]) is int
                and row["id"] > 0
                and row["id"] not in seen
                and row["type"] == "legislator"
                and row["status"] == "publish"
                and isinstance(row["title"]["rendered"], str)
                and set(fields) == MEMBER_FIELDS
                and all(isinstance(v, str) for v in fields.values())
                and bool(fields["wpc_id"])
            )
        except (KeyError, TypeError):
            valid = False
        if not valid:
            raise ScorecardSourceError("Peace Action native directory member identity or stored fields changed")
        seen.add(row["id"])
    if Counter(ids) != Counter(r["cmb2"]["wpc_legislator_details"]["wpc_id"] for r in records):
        raise ScorecardSourceError("Peace Action complete native directory does not reconcile with its ID census")
    return records


def _vote_page(source):
    rows = json_data(source)
    if not isinstance(rows, list) or len(rows) > PAGE_SIZE:
        raise ScorecardSourceError("Peace Action native vote page has an unreviewed array shape")
    for row in rows:
        try:
            fields = row["cmb2"]["wpc_vote_details"]
            valid = (
                type(row["id"]) is int
                and row["id"] > 0
                and row["type"] == "vote"
                and row["status"] == "publish"
                and isinstance(row["title"]["rendered"], str)
                and bool(row["title"]["rendered"])
                and set(fields) == VOTE_FIELDS
                and re.fullmatch(r"20\d\d", fields["wpc_year"])
                and fields["wpc_chamber"] in {"house", "senate"}
                and fields["wpc_position"] in {"favor", "opposed"}
            )
            for group in GROUPS:
                values = fields[group]
                valid = valid and (
                    values == ""
                    or isinstance(values, list)
                    and all(isinstance(v, str) and re.fullmatch(r"\d+", v) for v in values)
                    and len(values) == len(set(values))
                )
        except (KeyError, TypeError):
            valid = False
        if not valid:
            raise ScorecardSourceError("Peace Action native vote identity, period, position or member group changed")
    return rows


def _votes(context, phase):
    selected = []
    identities = set()
    for page in range(1, 101):
        source = context.read(votes_url(page), stage="scorecards:peace_action:votes-" + phase, hosts=HOSTS)
        rows = _vote_page(source)
        if not rows:
            raise ScorecardSourceError("Peace Action vote pagination returned an empty success without terminal proof")
        for ordinal, row in enumerate(rows):
            if row["id"] in identities:
                raise ScorecardSourceError("Peace Action vote pagination repeated a native item identity")
            identities.add(row["id"])
            selected.append((source, ordinal, row))
        if len(rows) < PAGE_SIZE:
            return selected
    raise ScorecardSourceError("Peace Action vote pagination exceeded its bounded complete walk")


def _editions(title, votes):
    years = sorted({row["cmb2"]["wpc_vote_details"]["wpc_year"] for _, _, row in votes}, reverse=True)
    return (
        ScorecardEdition("peace_action", "api-stored-record", MEMBERS, title, chamber="both"),
        *[
            ScorecardEdition(
                "peace_action",
                year + "-api-vote-record",
                votes_url(1),
                title,
                year=year,
                chamber="both",
                is_current=False,
            )
            for year in years
        ],
    )


def list_scorecards(context):
    app = context.read(INDEX, stage="scorecards:peace_action:listing-app", hosts=HOSTS)
    title, _, loader = _application(app)
    _client(context.read(loader, stage="scorecards:peace_action:listing-client", hosts=HOSTS))
    _route_schema(context.read(REST, stage="scorecards:peace_action:listing-routes", hosts=HOSTS))
    return _editions(title, _votes(context, "listing"))


def _ratings(source, members):
    rows = json_data(source)
    if not isinstance(rows, list):
        raise ScorecardSourceError("Peace Action native annual query is not a complete JSON array")
    if not rows:
        raise ScorecardSourceError("Peace Action empty reported annual cohort lacks source completeness proof")
    seen = set()
    for row in rows:
        try:
            fields = row["cmb2"]["wpc_legislator_details"]
            valid = (
                type(row["id"]) is int
                and str(row["id"]) in members
                and row["id"] not in seen
                and set(row) == {"id", "title", "link", "cmb2", "photo"}
                and set(fields) == {*METRICS, "wpc_party", "wpc_state", "wpc_district_number"}
                and isinstance(row["title"]["rendered"], str)
            )
            valid = valid and all(type(fields[f]) is int for f in METRICS)
        except (KeyError, TypeError):
            valid = False
        if not valid:
            raise ScorecardSourceError("Peace Action native annual rating query identity or fields changed")
        seen.add(row["id"])
    return rows


def acquire_scorecard(edition, context):
    app = context.read(INDEX, stage="scorecards:peace_action:app-start", hosts=HOSTS)
    title, coverage, loader_url = _application(app)
    client = context.read(loader_url, stage="scorecards:peace_action:client-start", hosts=HOSTS)
    formula = _client(client)
    routes = context.read(REST, stage="scorecards:peace_action:routes-start", hosts=HOSTS)
    route_schema = _route_schema(routes)
    directory = context.read(MEMBERS, stage="scorecards:peace_action:directory-start", hosts=HOSTS)
    crosswalk = context.read(IDS, stage="scorecards:peace_action:ids-start", hosts=HOSTS)
    members = _members(directory, crosswalk)
    votes = _votes(context, "start")
    if edition not in _editions(title, votes):
        raise ScorecardSourceError("Selected Peace Action source-defined period is absent or changed")
    native_members = {str(m["id"]): m for m in members}
    annual = edition.year is not None
    rating_source = (
        context.read(rating_url(edition.year), stage="scorecards:peace_action:ratings-start", hosts=HOSTS)
        if annual
        else directory
    )
    ratings = _ratings(rating_source, native_members) if annual else members
    directory_end = context.read(MEMBERS, stage="scorecards:peace_action:directory-end", hosts=HOSTS)
    crosswalk_end = context.read(IDS, stage="scorecards:peace_action:ids-end", hosts=HOSTS)
    votes_end = _votes(context, "end")
    rating_end = (
        context.read(rating_url(edition.year), stage="scorecards:peace_action:ratings-end", hosts=HOSTS)
        if annual
        else directory_end
    )
    client_end = context.read(loader_url, stage="scorecards:peace_action:client-end", hosts=HOSTS)
    app_end = context.read(INDEX, stage="scorecards:peace_action:app-end", hosts=HOSTS)
    routes_end = context.read(REST, stage="scorecards:peace_action:routes-end", hosts=HOSTS)
    if (
        _members(directory_end, crosswalk_end) != members
        or [r for _, _, r in votes_end] != [r for _, _, r in votes]
        or (_ratings(rating_end, native_members) if annual else json_data(directory_end)) != ratings
        or client_end.body != client.body
        or _client(client_end) != formula
        or _application(app_end) != _application(app)
        or _route_schema(routes_end) != route_schema
    ):
        raise ScorecardSourceError("Peace Action complete original scorecard inputs changed during acquisition")
    selected = [
        (s, o, r) for s, o, r in votes if not annual or r["cmb2"]["wpc_vote_details"]["wpc_year"] == edition.year
    ]
    references = {
        v
        for _, _, r in selected
        for group in GROUPS
        for v in (
            r["cmb2"]["wpc_vote_details"][group] if isinstance(r["cmb2"]["wpc_vote_details"][group], list) else []
        )
    }
    scope = references | {str(r["id"]) for r in ratings} if annual else references | set(native_members)
    primary = rating_source
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="Peace Action",
        parser_version=parser_version,
        rendition_rule="peace-action-native-stored-fields-and-vote-membership/2",
        homepage=BASE + "/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    for source, groups in [
        (app, ("publisher", "coverage")),
        (client, ("api_selection", "client_formula")),
        (directory, ("directory",)),
        (crosswalk, ("directory_ids",)),
        (routes, ("api_schema",)),
    ]:
        bundle.use(source, *groups)
    for source, groups in [
        (app_end, ("publisher", "coverage")),
        (client_end, ("api_selection", "client_formula")),
        (directory_end, ("directory",)),
        (crosswalk_end, ("directory_ids",)),
        (routes_end, ("api_schema",)),
    ]:
        bundle.use(source, *groups, role="corroboration")
    if annual:
        bundle.use(rating_source, "reported_annual_query")
        bundle.use(rating_end, "reported_annual_query", role="corroboration")
    for phase, entries in [("primary", votes), ("corroboration", votes_end)]:
        for page, source in enumerate({s.capture_id: s for s, _, _ in entries}.values(), 1):
            bundle.use(source, "vote_page:" + str(page), role=phase)
    bundle.add(
        "scorecard_methodologies",
        app,
        "h1/coverage",
        methodology_id="coverage",
        methodology_text=coverage,
        methodology_url=app.url,
    )
    bundle.add(
        "scorecard_methodologies",
        client,
        "./legislator-votes.js/member-year-display",
        methodology_id="client-display-formula",
        methodology_text=formula,
        methodology_url=client.url,
        disclosure_status="Literal publisher client display formula; no score reproduction or invented server-query completeness",
    )
    for field in METRICS:
        bundle.metric(
            rating_source,
            field,
            field,
            path="/*/cmb2/wpc_legislator_details/" + field,
            unit="percent" if field == "wpc_score" else None,
            primary=field == "wpc_score",
        )
        bundle.tables["scorecard_metrics"][-1]["period_text"] = edition.year
    directory_positions = {str(m["id"]): n for n, m in enumerate(members)}
    for identifier in sorted(scope, key=int):
        member_key = key("wordpress", identifier)
        if identifier in native_members:
            row = native_members[identifier]
            fields = row["cmb2"]["wpc_legislator_details"]
            bundle.add(
                "scorecard_members",
                directory,
                "/" + str(directory_positions[identifier]),
                publisher_member_key=member_key,
                publisher_member_id=identifier,
                member_name=row["title"]["rendered"],
                state=fields["wpc_state"] or None,
                district=fields["wpc_district_number"] or None,
                party=fields["wpc_party"] or None,
                identifiers_json=literal(
                    [
                        {"scheme": "peaceaction.org:legislator", "value": identifier},
                        {"scheme": "peaceaction.org:wpc_id", "value": fields["wpc_id"]},
                        *(
                            [{"scheme": "ocd-division", "value": fields["wpc_district"]}]
                            if fields["wpc_district"]
                            else []
                        ),
                    ]
                ),
                notes_text=literal(
                    {
                        "native_fields": fields,
                        "native_link": row["link"],
                        "native_date": row["date"],
                        "native_modified": row["modified"],
                    }
                ),
            )
        else:
            document, ordinal, row, group, occurrence = next(
                (s, o, r, g, p)
                for s, o, r in selected
                for g in GROUPS
                for p, v in enumerate(
                    r["cmb2"]["wpc_vote_details"][g] if isinstance(r["cmb2"]["wpc_vote_details"][g], list) else []
                )
                if v == identifier
            )
            bundle.add(
                "scorecard_members",
                document,
                f"/{ordinal}/cmb2/wpc_vote_details/{group}/{occurrence}",
                publisher_member_key=member_key,
                publisher_member_id=identifier,
                identifiers_json=literal([{"scheme": "peaceaction.org:legislator", "value": identifier}]),
                notes_text=literal(
                    {"profile_status": "native item reference absent from complete publisher directory"}
                ),
            )
    for ordinal, row in enumerate(ratings):
        fields = row["cmb2"]["wpc_legislator_details"]
        rating_notes = {"native_fields": fields, "native_title": row["title"], "native_link": row["link"]}
        if annual:
            rating_notes["native_photo"] = row["photo"]
        for field in METRICS:
            value = str(fields[field])
            normalized = "N/A" if value == "NA" else value
            bundle.add(
                "scorecard_member_ratings",
                rating_source,
                f"/{ordinal}/cmb2/wpc_legislator_details/{field}",
                metric_id=field,
                publisher_member_key=key("wordpress", str(row["id"])),
                value_text=normalized,
                value_number=decimal_text(value),
                value_status_text="N/A" if normalized == "N/A" else None,
                notes_text=literal(rating_notes),
            )
    for document, ordinal, row in selected:
        fields = row["cmb2"]["wpc_vote_details"]
        path = f"/{ordinal}/cmb2/wpc_vote_details"
        item_id = key("wordpress", str(row["id"]))
        uri = fields["wpc_vote_uri"]
        identity = re.fullmatch(
            r"https://api\.propublica\.org/congress/v1/(\d+)/(house|senate)/sessions/(\d+)/votes/(\d+)\.json", uri
        )
        references_json = (
            [
                {
                    "occurrence_id": "native-vote-uri",
                    "kind": "url",
                    "citation_text": uri,
                    "source_path": path + "/wpc_vote_uri",
                }
            ]
            if uri
            else []
        )
        if identity:
            references_json[0].update(
                congress_text=identity[1],
                chamber_text=identity[2],
                session_text=identity[3],
                roll_number_text=identity[4],
            )
        bundle.add(
            "scorecard_items",
            document,
            "/" + str(ordinal),
            item_id=item_id,
            publisher_item_id=str(row["id"]),
            title=row["title"]["rendered"],
            item_kind_text=row["type"],
            item_date_text=fields["wpc_date"],
            chamber_text=fields["wpc_chamber"],
            congress_text=identity[1] if identity else None,
            session_text=identity[3] if identity else None,
            roll_number_text=identity[4] if identity else None,
            references_json=literal(references_json),
            publisher_position_text=fields["wpc_position"],
            position_basis="explicit",
            position_source_path=path + "/wpc_position",
        )
        bundle.add(
            "scorecard_methodologies",
            document,
            path,
            methodology_id=item_id,
            effective_at_text=fields["wpc_year"],
            methodology_text=literal(fields),
            methodology_url=row["link"],
            disclosure_status="Literal source groups, narrative, date and URI; blank collections and contradictory memberships remain preserved",
        )
        for group in GROUPS:
            values = fields[group] if isinstance(fields[group], list) else []
            for occurrence, identifier in enumerate(values):
                bundle.add(
                    "scorecard_member_item_results",
                    document,
                    f"{path}/{group}/{occurrence}",
                    result_id=key("native-group", group, identifier),
                    item_id=item_id,
                    publisher_member_key=key("wordpress", identifier),
                    result_text=group,
                    reason_text=literal(
                        {"native_group": group, "native_member_id": identifier, "native_year": fields["wpc_year"]}
                    ),
                )
    return bundle.finish(
        "Complete source directory reconciles its exact native ID census including duplicate crosswalk values; explicit bounded vote pagination reaches a nonempty short final page and all source-defined periods and distinct WP item identities reconcile. Stable complete rereads preserve every literal stored/query score and native member-group occurrence, including overlaps, blank collections and identifier-only references. Annual reported-query cohort is separate from complete vote records; no inferred annual missing scores, official votes, weights or reproduced formula.",
        declared={
            "directory_profiles": len(members),
            "directory_id_occurrences": len(json_data(crosswalk)),
            "complete_vote_items": len(votes),
            "scope_vote_items": len(selected),
            "native_member_group_occurrences": sum(
                len(r["cmb2"]["wpc_vote_details"][g]) if isinstance(r["cmb2"]["wpc_vote_details"][g], list) else 0
                for _, _, r in selected
                for g in GROUPS
            ),
        },
    )
