"""ACEC's complete source-defined 116th Congress four-document scorecard."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "acec-116-qualified-semantic/1"
HOSTS = ("www.acec.org", "acec.org")
BASE = "https://www.acec.org/wp-content/uploads/2023/03/"
SOURCES = {
    "senate-ratings-116": (
        BASE + "116th_Senate_Score_Card.pdf",
        "eeb32a2deae154c5a7073855461d8073ba958d015044246a137cf1309ed6e21b",
        6,
    ),
    "house-ratings-116": (
        BASE + "116th_House_Score_Card.pdf",
        "f52653fc6add8ecb6992d476de64416cad331c3ffe38d9b6220eefa257e57f64",
        17,
    ),
    "senate-method-116": (
        BASE + "Senate_Issues.pdf",
        "c2da9389f4bc9f824afe118b796ddc71b91d5fa0c1cb101fc11064e19023afa2",
        2,
    ),
    "house-method-116": (
        BASE + "House_Issues.pdf",
        "209b6dbe40713f5061f9df01cac87eddc8f6aa4ed6b15dfff6be3fed337b1f9b",
        2,
    ),
}
QUALIFIED_SHA256 = "94247b8b45dabab60138daa0ef40e2523ab83747a234696460daf7964bfd9d1f"
EDITION = ScorecardEdition(
    "acec",
    "116",
    SOURCES["senate-ratings-116"][0],
    "116th Congress Scorecard",
    congress="116",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    "senate-ratings-116": (18, 18, 17, 17, 17, 14),
    "house-ratings-116": (24, 29, 29, 27, 26, 27, 26, 26, 26, 26, 27, 27, 25, 26, 29, 26, 12),
}
# Chart positions are independently reconciled to the numbered publisher narratives.
CHART_ITEMS = {"House": tuple(range(1, 14)), "Senate": (2, 3, 1, 4, 5, 6, 8, 9, 7)}
ITEM_IDENTITIES = {
    "House": (
        ("87", "H.J.RES.31"),
        (None, "H.R. 1043"),
        (None, "H.R. 1251"),
        (None, "H.R. 216"),
        ("701", None),
        ("493", "H.R. 748"),
        ("114", "H.R. 7010"),
        ("138", "H.R. 2"),
        (None, None),
        ("155", "H.R. 1957"),
        ("198", "H.R. 8337"),
        ("206", "H.R. 4447"),
        ("13", "H.R. 535"),
    ),
    "Senate": (
        ("26", None),
        (None, "S. 460"),
        (None, "S. 932"),
        (None, "S. 1149"),
        ("14", None),
        ("80", "H.R. 748"),
        (None, None),
        ("121", "H.R. 1957"),
        ("197", "H.R. 8337"),
    ),
}
TOKENS = {"", "Yea", "yea", "Yean", "Nay", "Not Voting", "Present"}


@dataclass(frozen=True, slots=True)
class ACECReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    document = context.read(EDITION.source_url, stage="scorecards:acec:listing", hosts=HOSTS)
    if sha256(document.body).hexdigest() != SOURCES["senate-ratings-116"][1]:
        raise ScorecardSourceError("ACEC qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if data["format_version"] != "acec-qualified-source-facts/1" or data["sources"] != {
            label: {"sha256": pin, "page_count": pages} for label, (_, pin, pages) in SOURCES.items()
        }:
            raise ValueError
        counts = {(label, page): 0 for label, pages in PAGE_MEMBERS.items() for page in range(1, len(pages) + 1)}
        locations = set()
        for entry in data["members"]:
            record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
            label, page, ordinal = evidence["source_label"], evidence["physical_page"], evidence["source_ordinal"]
            loc = (label, page, ordinal)
            if (
                (label, page) not in counts
                or loc in locations
                or ordinal != counts[label, page]
                or chamber != ("Senate" if label.startswith("senate") else "House")
                or not record["member_name_text"]
                or not record["state_text"]
                or record["party_text"] not in {"R", "D", "I", "L"}
                or record["district_text"] is not None
                or set(record["results"]) != {str(i) for i in range(1, len(CHART_ITEMS[chamber]) + 1)}
                or any(v not in TOKENS for v in record["results"].values())
                or re.fullmatch(r"\d{1,3}%", record["score_text"]) is None
                or int(record["score_text"][:-1]) > 100
            ):
                raise ValueError
            counts[label, page] += 1
            locations.add(loc)
        expected_counts = {
            (label, page): count for label, pages in PAGE_MEMBERS.items() for page, count in enumerate(pages, 1)
        }
        identities = set()
        for entry in data["items"]:
            item, chamber, evidence = entry["record"], entry["chamber"], entry["evidence"]
            ordinal = int(item["publisher_item_key_text"])
            identity = (chamber, ordinal)
            roll, bill = ITEM_IDENTITIES[chamber][ordinal - 1]
            kind = (
                "sign_on_letter"
                if ordinal == (9 if chamber == "House" else 7)
                else "cosponsorship"
                if ordinal in (2, 3, 4)
                else "roll_call"
            )
            if (
                identity in identities
                or not item["title_text"]
                or not item["methodology_text"]
                or not item["publisher_position_text"]
                or item["position_basis"] != "explicit"
                or item["roll_number_text"] != roll
                or item["bill_citation_text"] != bill
                or item["amendment_citation_text"] is not None
                or item["item_date_text"] is not None
                or item["item_kind_text"] != kind
                or evidence["chart_ordinal"] != CHART_ITEMS[chamber].index(ordinal) + 1
                or evidence["source_label"] != chamber.lower() + "-method-116"
                or not item["source_pages"]
                or any(p not in (1, 2) for p in item["source_pages"])
            ):
                raise ValueError
            identities.add(identity)
        expected_items = {(c, i) for c, values in ITEM_IDENTITIES.items() for i in range(1, len(values) + 1)}
        if counts != expected_counts or identities != expected_items or data["methodology"] != []:
            raise ValueError
        return data
    except (KeyError, IndexError, TypeError, ValueError):
        raise ScorecardSourceError("ACEC semantic facts fail the complete qualified four-document shape") from None


def _references(item, loc, chart_loc):
    refs = []
    for i, ref in enumerate(item["references"]):
        kind = ref["kind"]
        entry = {
            "occurrence_id": str(i),
            "kind": kind,
            "citation_text": ref["citation_text"],
            "source_path": chart_loc if ref["citation_text"] == "H.J.RES.31" else loc + f"/references/{i}",
        }
        if kind in {"bill", "amendment"}:
            entry["bill_citation_text" if kind == "bill" else "amendment_citation_text"] = ref["citation_text"]
        refs.append(entry)
    return json.dumps(refs, ensure_ascii=False)


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("ACEC edition requires reviewed semantic facts and private retention")
    documents = {
        label: context.read(url, stage="scorecards:acec:" + label, hosts=HOSTS)
        for label, (url, _, _) in SOURCES.items()
    }
    if any(sha256(documents[label].body).hexdigest() != pin for label, (_, pin, _) in SOURCES.items()):
        raise ScorecardSourceError("ACEC four-document qualification pins changed; requalification required")
    primary = documents["senate-ratings-116"]
    observation = retain_qualified(
        primary,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCES["senate-ratings-116"][1],
        observations_sha256=QUALIFIED_SHA256,
        stage="acec:qualified-116",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        primary,
        publisher_name="American Council of Engineering Companies",
        parser_version=parser_version,
        rendition_rule="acec-four-original-pdfs-source-actions-and-published-percent/1",
        homepage="https://www.acec.org/",
    )
    bundle.tables["scorecards"][0]["methodology_url"] = SOURCES["senate-method-116"][0]
    for label, document in documents.items():
        groups = ("scored_items", "methodology") if "-method-" in label else ("members_and_scores", "member_results")
        bundle.use(document, *(label.split("-")[0] + ":" + group for group in groups))
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for chamber in CHART_ITEMS:
        document = documents[chamber.lower() + "-ratings-116"]
        bundle.metric(
            document,
            key(chamber, "percent"),
            "% with ACEC",
            path=path(1, "/score-heading"),
            chamber=chamber,
            unit="percent",
        )
    for i, entry in enumerate(data["items"]):
        item, chamber, evidence = entry["record"], entry["chamber"], entry["evidence"]
        document = documents[evidence["source_label"]]
        loc = path(evidence["physical_page"], f"/items/{i}/record")
        chart_label = chamber.lower() + "-ratings-116"
        chart_loc = f"source={chart_label};sha256={SOURCES[chart_label][1]};" + path(
            1, f"/chart-columns/{evidence['chart_ordinal']}"
        )
        item_id = key(chamber, item["publisher_item_key_text"])
        bundle.add(
            "scorecard_items",
            document,
            loc,
            item_id=item_id,
            publisher_item_id=item["publisher_item_key_text"],
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            congress_text="116",
            chamber_text=chamber,
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            references_json=_references(item, loc, chart_loc),
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        methodology_id = key(chamber, "item", item["publisher_item_key_text"])
        bundle.add(
            "scorecard_methodologies",
            document,
            loc + "/methodology_text",
            methodology_id=methodology_id,
            methodology_text=item["methodology_text"],
            methodology_url=document.url,
            disclosure_status="explicit item narrative and target; overall weights, blank semantics and denominator undocumented",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            loc,
            metric_id=key(chamber, "percent"),
            item_id=item_id,
            participation_id="congress-116",
            methodology_id=methodology_id,
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
        )
    for i, entry in enumerate(data["members"]):
        record, evidence, chamber = entry["record"], entry["evidence"], entry["chamber"]
        document = documents[evidence["source_label"]]
        loc = path(evidence["physical_page"], f"/members/{i}/record")
        # The source repeats Scott, Davis and Maloney within a state and prints no district.
        identity = key(
            chamber,
            record["state_text"],
            record["member_name_text"],
            str(evidence["physical_page"]),
            str(evidence["source_ordinal"]),
        )
        bundle.add(
            "scorecard_members",
            document,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            district=None,
            party=record["party_text"],
            chamber_text=chamber,
            notes_text=record["notes_text"] or None,
        )
        bundle.add(
            "scorecard_member_ratings",
            document,
            loc + "/score_text",
            metric_id=key(chamber, "percent"),
            publisher_member_key=identity,
            value_text=record["score_text"],
            value_number=decimal_text(record["score_text"]),
        )
        for ordinal, value in record["results"].items():
            item = CHART_ITEMS[chamber][int(ordinal) - 1]
            bundle.add(
                "scorecard_member_item_results",
                document,
                loc + "/results/" + ordinal,
                item_id=key(chamber, str(item)),
                metric_id=key(chamber, "percent"),
                participation_id="congress-116",
                publisher_member_key=identity,
                result_id="published-chart",
                result_text=value,
            )
    return bundle.finish(
        "Complete source-defined 116th Congress four-PDF edition: every original House/Senate page, percent, scoring column and numbered item narrative reconciles independently. Senate chart order is mapped explicitly to narrative ordinals. Surname-only identities, absent districts, duplicate names, source spelling, blanks, lowercase yea and Yean remain literal; no invented official actions, weights, sessions or score reproduction."
    )
