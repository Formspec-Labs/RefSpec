"""FRC Action named congressional PDFs, from reviewed semantic source facts.

One edition reader keeps source scores, complete action grids, exclusions and
chamber methods. Qualification uses shared rendered extraction and independent
native-source reconciliation; acquisition consumes its pinned private result.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar, TypedDict

from spicy_docs.schemas.tables import json_column
from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardAcquisition,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    SourceDocument,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "frc-action-named-qualified-pdf/1"
INDEX = "https://www.frcaction.org/scorecard"
HOSTS = ("downloads.frcaction.org",)


class EditionSpec(TypedDict):
    url: str
    source_sha256: str
    observations_sha256: str
    pages: int
    members: dict[str, int]
    items: dict[str, int]
    member_pages: dict[int, int]
    year: str
    congress: str
    session: str


QUALIFIED_EDITIONS: dict[str, EditionSpec] = {
    "119-1-2025": {
        "url": "https://downloads.frcaction.org/EF/EF26A01.pdf",
        "source_sha256": "c17c6d54bc25aa2796259639b250c93fc7ac1cef7e3c050be10353517ac86acd",
        "observations_sha256": "2426e9231f8f2d80199baeebc716a58cb8e262ed64a5d423cff55e00e9801f45",
        "pages": 24,
        "members": {"House": 439, "Senate": 102},
        "items": {"House": 4, "Senate": 4},
        "member_pages": {
            6: 42,
            7: 45,
            8: 46,
            9: 42,
            10: 41,
            11: 37,
            12: 46,
            13: 44,
            14: 44,
            15: 41,
            16: 11,
            19: 25,
            20: 26,
            21: 27,
            22: 24,
        },
        "year": "2025",
        "congress": "119",
        "session": "1",
    },
    "118-2-2024": {
        "url": "https://downloads.frcaction.org/EF/EF25D02.pdf",
        "source_sha256": "29feba2249ee65ade1387746ad1be1df029631c3dbd7bbc6d3e5a24723a56e67",
        "observations_sha256": "3024aa1b00bd82af62c2fb2cb2ffad6106c9c9de14e63d9bc170eb2637d0df43",
        "pages": 25,
        "members": {"House": 441, "Senate": 101},
        "items": {"House": 12, "Senate": 4},
        "member_pages": {
            8: 42,
            9: 46,
            10: 46,
            11: 42,
            12: 42,
            13: 38,
            14: 45,
            15: 44,
            16: 44,
            17: 42,
            18: 10,
            21: 26,
            22: 26,
            23: 27,
            24: 22,
        },
        "year": "2024",
        "congress": "118",
        "session": "2",
    },
    "118-1-2023": {
        "url": "https://downloads.frcaction.org/EF/EF24E01.pdf",
        "source_sha256": "dd40e71c5a866fc4daf5dbe9dd5a32523a75e40258c4e003ec2b88324d46ff9a",
        "observations_sha256": "9e02926c1e0b1cf22705b3451787a1b5ba3685f75c9d3ef5c3d2c6085ef867eb",
        "pages": 27,
        "members": {"House": 437, "Senate": 101},
        "items": {"House": 17, "Senate": 11},
        "member_pages": {
            8: 42,
            9: 45,
            10: 46,
            11: 40,
            12: 38,
            13: 31,
            14: 41,
            15: 41,
            16: 37,
            17: 44,
            18: 32,
            23: 25,
            24: 28,
            25: 28,
            26: 20,
        },
        "year": "2023",
        "congress": "118",
        "session": "1",
    },
}
RESULTS = {"+", "-", "NV", "P", "N/A", "NA", ""}
SCHEMAS = {
    "frc-pdf-member-facts/1",
    "frc-pdf-member-row-reread/1",
    "frc-pdf-member-row-group/1",
    "frc-pdf-item-facts/1",
    "frc-pdf-edition-facts/1",
}
# Observed literal legislative citation syntax. Informal amendment ordinals stay
# source citations; their exact correspondence to official amendments is downstream.
CITATION = re.compile(
    r"\b(?:H\.\s*(?:R\.|(?:J\.|Con\.)?\s*Res\.|Amdt\.)|S\.\s*(?:(?:J\.|Con\.)\s*Res\.|Amdt\.)?)\s*\d+\b"
    r"|\bAmendment\s+(?:No\.\s*|#\s*)\d+\b"
)


def _edition(identifier: str) -> ScorecardEdition:
    spec = QUALIFIED_EDITIONS[identifier]
    return ScorecardEdition(
        "frc_action",
        identifier,
        spec["url"],
        "VOTE SCORECARD",
        year=spec["year"],
        congress=spec["congress"],
        chamber="both",
        is_current=False,
    )


def _source(document: SourceDocument, spec: EditionSpec) -> None:
    if (
        document.url != spec["url"]
        or not document.body.startswith(b"%PDF-")
        or b"%%EOF" not in document.body[-2048:]
        or sha256(document.body).hexdigest() != spec["source_sha256"]
    ):
        raise ScorecardSourceError("FRC named PDF differs from the complete reviewed original")


def list_scorecards(context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
    editions = []
    for identifier, spec in QUALIFIED_EDITIONS.items():
        _source(context.read(spec["url"], stage=f"frc:{identifier}:pdf:list", hosts=HOSTS), spec)
        editions.append(_edition(identifier))
    return tuple(editions)


@dataclass(frozen=True, slots=True)
class FRCNamedEditionReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context: ScorecardContext) -> tuple[ScorecardEdition, ...]:
        data, spec = _qualified(self.qualified_observations)
        identifier = data["edition_id"]
        _source(context.read(spec["url"], stage=f"frc:{identifier}:pdf:list", hosts=HOSTS), spec)
        return (_edition(identifier),)

    def acquire_scorecard(self, edition: ScorecardEdition, context: ScorecardContext) -> ScorecardAcquisition:
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def _evidence(value: dict, spec: EditionSpec) -> None:
    if (
        type(value["physical_page"]) is not int
        or not 1 <= value["physical_page"] <= spec["pages"]
        or value["schema_version"] not in SCHEMAS
        or not isinstance(value["json_pointer"], str)
        or not value["json_pointer"].startswith("/")
        or any(not re.fullmatch(r"[0-9a-f]{64}", value[k]) for k in ("outcome_sha256", "observation_sha256"))
    ):
        raise ValueError


def _qualified(body: bytes) -> tuple[dict, EditionSpec]:
    try:
        if not isinstance(body, bytes):
            raise TypeError
        data = json.loads(body)
        spec = QUALIFIED_EDITIONS[data["edition_id"]]
        if (
            sha256(body).hexdigest() != spec["observations_sha256"]
            or data["format_version"] != "frc-action-qualified-pdf-edition/1"
            or data["source_sha256"] != spec["source_sha256"]
            or data["physical_page_count"] != spec["pages"]
            or data["member_counts"] != spec["members"]
            or data["item_counts"] != spec["items"]
            or data["member_page_counts"] != {str(p): n for p, n in spec["member_pages"].items()}
        ):
            raise ValueError
        fronts = set()
        for e in data["front"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            tokens = [v["result_text"] for v in r["result_definitions"]]
            if (
                chamber not in spec["members"]
                or chamber in fronts
                or r["year_text"] != spec["year"]
                or r["title_text"] != "VOTE SCORECARD"
                or not r["period_statements"]
                or r["score_label_text"] != "Score"
                or r["score_unit_text"] is not None
                or r["score_formula_text"] is not None
                or r["uncertainties"]
                or not r["source_legend_text"]
                or not {"+", "-", "NV"}.issubset(tokens)
                or len(tokens) != len(set(tokens))
                or any(not v["meaning_text"] for v in r["result_definitions"])
            ):
                raise ValueError
            fronts.add(chamber)
        if fronts != set(spec["members"]):
            raise ValueError
        items = set()
        for e in data["items"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            n = r["reviewed_item_number"]
            if (
                chamber not in spec["items"]
                or not isinstance(n, str)
                or not n.isdigit()
                or not 1 <= int(n) <= spec["items"][chamber]
                or (chamber, n) in items
                or not r["title_text"]
                or not r["source_native_text"]
                or not r["publisher_position_text"]
                or r["weight_text"] is not None
                or r["member_specific_rules"]
                or any(not isinstance(c, str) or not c for k in ("bill_citations", "amendment_citations") for c in r[k])
                or (
                    r["roll_number_text"] is not None
                    and not re.fullmatch(r"(?:Roll Call No\. )?\d+", r["roll_number_text"])
                )
                or (r["roll_number_text"] is None and "cosponsorship" not in r["publisher_position_text"])
            ):
                raise ValueError
            items.add((chamber, n))
        if dict(Counter(c for c, _ in items)) != spec["items"]:
            raise ValueError
        identities, members, pages = set(), Counter(), Counter()
        for e in data["members"]:
            _evidence(e["evidence"], spec)
            r, chamber = e["record"], e["chamber"]
            identity = (chamber, r["state_text"], r["member_name_text"])
            if (
                chamber not in spec["members"]
                or identity in identities
                or not r["member_name_text"]
                or not r["state_text"]
                or not r["display_name_text"]
                or r["district_text"] is not None
                or r["party_text"] not in {"R", "D", "I"}
                or r["annotation_text"] not in {None, "*", "**", "†", "††", "*†", "*††"}
                or not isinstance(r["score_text"], str)
                or not re.fullmatch(r"\d+|N/A|NA", r["score_text"])
                or set(r["item_results"]) != {n for c, n in items if c == chamber}
                or any(value not in RESULTS for value in r["item_results"].values())
                or e["evidence"]["physical_page"] not in spec["member_pages"]
            ):
                raise ValueError
            identities.add(identity)
            members[chamber] += 1
            pages[e["evidence"]["physical_page"]] += 1
        if dict(members) != spec["members"] or dict(pages) != spec["member_pages"]:
            raise ValueError
        return data, spec
    except (ValueError, TypeError, KeyError, IndexError) as error:
        raise ScorecardSourceError("FRC named facts do not establish the pinned complete reviewed edition") from error


def _references(record: dict, location: str, chamber: str, spec: EditionSpec) -> list[dict]:
    references = []
    for n, match in enumerate(CITATION.finditer(record["source_native_text"])):
        text = match[0]
        kind = "amendment" if "Amdt" in text or text.startswith("Amendment") else "bill"
        references.append(
            {
                "occurrence_id": str(n),
                "citation_text": text,
                "kind": kind,
                kind + "_citation_text": text,
                "congress_text": spec["congress"],
                "chamber_text": chamber,
                "source_path": location + f"/source_native_text/offset={match.start()}",
            }
        )
    if record["roll_number_text"] is not None:
        references.append(
            {
                "occurrence_id": "roll",
                "citation_text": record["roll_number_text"],
                "kind": "roll_call",
                "roll_number_text": record["roll_number_text"].removeprefix("Roll Call No. "),
                "congress_text": spec["congress"],
                "session_text": spec["session"],
                "chamber_text": chamber,
                "source_path": location + "/roll_number_text",
            }
        )
    return references


def acquire_scorecard(edition, context, *, qualified_observations=None, retain_observations=None):
    if qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("FRC named PDF requires pinned reviewed facts and private observation retention")
    data, spec = _qualified(qualified_observations)
    if edition != _edition(data["edition_id"]):
        raise ScorecardSourceError("FRC PDF selection and its qualified named edition differ")
    document = context.read(spec["url"], stage=f"frc:{edition.edition_id}:pdf", hosts=HOSTS)
    _source(document, spec)
    observation = retain_qualified(
        document,
        qualified_observations,
        retain_observations,
        source_sha256=spec["source_sha256"],
        observations_sha256=spec["observations_sha256"],
        stage=f"frc:{edition.edition_id}:qualified-observations",
    )
    bundle = Bundle(
        edition,
        context,
        document,
        publisher_name="FRC Action",
        parser_version=parser_version,
        rendition_rule="complete named original PDF; reviewed semantic fields and every member/action cell reconcile independent native/rendered source; exact stable reread",
        homepage="https://www.frcaction.org/",
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    period = next(e["record"]["period_statements"][0] for e in data["front"] if e["chamber"] == "House")
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        methodology_url=spec["url"],
        timespan_text=period,
        session_text=next(e["record"]["session_text"] for e in data["front"] if e["chamber"] == "House"),
        edition_label_text=None,
        periods_json=json_column(
            [
                {
                    "occurrence_id": key(e["chamber"], "period", str(n)),
                    "kind": "explicit",
                    "period_text": statement,
                    "congress_text": spec["congress"],
                    "session_text": spec["session"],
                    "year_text": spec["year"],
                    "chamber_text": e["chamber"],
                    "source_path": f"pdf:page=1;observation={observation};/front/{i}/record/period_statements/{n}",
                }
                for i, e in enumerate(data["front"])
                for n, statement in enumerate(e["record"]["period_statements"])
            ]
        ),
    )

    def path(group, n, suffix=""):
        e = data[group][n]["evidence"]
        return f"pdf:page={e['physical_page']};observation={observation};/{group}/{n}/record{suffix}"

    legends, annotations = {}, {}
    for n, e in enumerate(data["front"]):
        r, chamber = e["record"], e["chamber"]
        legends[chamber] = {v["result_text"]: v["meaning_text"] for v in r["result_definitions"]}
        annotations[chamber] = {v["annotation_text"]: v["meaning_text"] for v in r["member_annotation_definitions"]}
        method = key(chamber, "printed-method")
        bundle.add(
            "scorecard_methodologies",
            document,
            path("front", n),
            methodology_id=method,
            chamber_text=chamber,
            methodology_text=json_column(r),
            methodology_url=spec["url"],
            disclosure_status="partial",
        )
        bundle.add(
            "scorecard_metrics",
            document,
            path("front", n, "/score_label_text"),
            metric_id=key(chamber, "Score"),
            methodology_id=method,
            name=r["score_label_text"],
            value_unit_text=r["score_unit_text"],
            chamber_text=chamber,
            period_text=spec["year"],
            is_primary="true",
        )
    for n, e in enumerate(data["items"]):
        r, chamber = e["record"], e["chamber"]
        location = path("items", n)
        identifier = key(chamber, r["reviewed_item_number"])
        metric = key(chamber, "Score")
        method = key(chamber, "item", r["reviewed_item_number"])
        refs = _references(r, location, chamber, spec)
        bills = {v["bill_citation_text"] for v in refs if "bill_citation_text" in v}
        amendments = {v["amendment_citation_text"] for v in refs if "amendment_citation_text" in v}
        bundle.add(
            "scorecard_methodologies",
            document,
            location,
            methodology_id=method,
            chamber_text=chamber,
            methodology_text=json_column(
                {
                    "source_native_text": r["source_native_text"],
                    "source_action_kind_text": r["action_kind_text"],
                    "source_action_summary_text": r["source_action_summary_text"],
                    "source_roll_number_text": r["roll_number_text"],
                    "source_item_number_text": r["item_number_text"],
                    "member_specific_rules": r["member_specific_rules"],
                }
            ),
            disclosure_status="explicit",
        )
        bundle.add(
            "scorecard_items",
            document,
            location,
            item_id=identifier,
            publisher_item_id=r["item_number_text"],
            title=r["title_text"],
            item_kind_text="roll call" if r["roll_number_text"] is not None else "cosponsorship",
            item_date_text=r["item_date_text"],
            congress_text=spec["congress"],
            session_text=spec["session"],
            chamber_text=chamber,
            roll_number_text=r["roll_number_text"].removeprefix("Roll Call No. ")
            if r["roll_number_text"] is not None
            else None,
            bill_citation_text=next(iter(bills)) if len(bills) == 1 else None,
            amendment_citation_text=next(iter(amendments)) if len(amendments) == 1 else None,
            references_json=json_column(refs),
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            position_source_path=location + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            document,
            location,
            item_id=identifier,
            metric_id=metric,
            participation_id="printed-grid",
            methodology_id=method,
            publisher_position_text=r["publisher_position_text"],
            position_basis="explicit",
            weight_text=r["weight_text"],
            counts_toward_metric=None,
        )
    for n, e in enumerate(data["members"]):
        r, chamber = e["record"], e["chamber"]
        location = path("members", n)
        member = key(chamber, r["state_text"], r["member_name_text"])
        metric = key(chamber, "Score")
        notes = {
            "source_display_name": r["display_name_text"],
            "state_heading_text": r["state_heading_text"],
            "source_annotation_text": r["annotation_text"],
            "annotation_definitions": annotations[chamber],
        }
        bundle.add(
            "scorecard_members",
            document,
            location,
            publisher_member_key=member,
            member_name=r["member_name_text"],
            chamber_text=chamber,
            state=r["state_text"],
            party=r["party_text"],
            district=r["district_text"],
            period_text=spec["year"],
            identifiers_json="[]",
            notes_text=json_column(notes),
        )
        score = "N/A" if r["score_text"] in {"NA", "N/A"} else r["score_text"]
        bundle.add(
            "scorecard_member_ratings",
            document,
            location + "/score_text",
            publisher_member_key=member,
            metric_id=metric,
            value_text=score,
            value_number=decimal_text(score),
            value_status_text=score if score == "N/A" else None,
            notes_text=json_column(
                {"source_score_text": r["score_text"], "source_annotation_text": r["annotation_text"]}
            ),
        )
        for number, token in r["item_results"].items():
            normalized = "N/A" if token in {"NA", "N/A"} else token
            bundle.add(
                "scorecard_member_item_results",
                document,
                location + "/item_results/" + number,
                publisher_member_key=member,
                item_id=key(chamber, number),
                metric_id=metric,
                participation_id="printed-grid",
                result_id="printed-cell",
                result_text=normalized,
                reason_text=legends[chamber].get(normalized),
            )
    repeated = context.read(spec["url"], stage=f"frc:{edition.edition_id}:pdf:reread", hosts=HOSTS)
    _source(repeated, spec)
    bundle.use(repeated, role="corroboration")
    return bundle.finish(
        "Complete source PDF; all named member rows, source scores, ordered item definitions and action cells reconcile independent retained native/rendered originals; exact stable source reread",
        declared={
            "physical_pages": spec["pages"],
            "members_by_chamber": spec["members"],
            "members_by_physical_page": spec["member_pages"],
            "items_by_chamber": spec["items"],
            "count_basis": "all printed named source grid rows; introductory letter declares selected items, not a member census",
            "reader_edition_key_basis": "explicit cover Congress/session plus letter calendar year; no publisher ID printed",
            "source_na_ratings": sum(e["record"]["score_text"] in {"NA", "N/A"} for e in data["members"]),
            "source_blank_item_cells": sum(
                v == "" for e in data["members"] for v in e["record"]["item_results"].values()
            ),
        },
    )
