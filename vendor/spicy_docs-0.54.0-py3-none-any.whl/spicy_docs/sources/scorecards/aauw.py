"""AAUW Action Fund's complete 118th voting record, including prior-Congress scores."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from hashlib import sha256
from typing import ClassVar

from spicy_docs.sources.scorecards.common import (
    Bundle,
    ScorecardContext,
    ScorecardEdition,
    ScorecardSourceError,
    decimal_text,
    key,
)
from spicy_docs.sources.scorecards.qualified_observations import RetainObservations, retain_qualified

parser_version = "aauw-118-qualified-semantic/1"
HOSTS = ("www.aauwaction.org",)
URL = "https://www.aauwaction.org/wp-content/uploads/2024/10/CVR-2024-FINAL-VERSION-2.pdf"
SOURCE_SHA256 = "bfef31fa18504c8e9db18aaa5cb8def6cfed8e6c376cc4aea28a770008d54a48"
QUALIFIED_SHA256 = "250bb7f0f8de309bd221610f68ebe0fd796d56b51c9dc799031d42cc9b434b9a"
EDITION = ScorecardEdition(
    "aauw",
    "118-final",
    URL,
    "Congressional Voting Record: 118th Congress",
    congress="118",
    chamber="both",
    is_current=False,
)
PAGE_MEMBERS = {
    8: 16,
    9: 15,
    10: 16,
    11: 15,
    12: 15,
    13: 16,
    14: 8,
    19: 20,
    20: 21,
    21: 22,
    22: 20,
    23: 20,
    24: 20,
    25: 19,
    26: 19,
    27: 19,
    28: 19,
    29: 21,
    30: 18,
    31: 19,
    32: 20,
    33: 21,
    34: 20,
    35: 20,
    36: 19,
    37: 21,
    38: 22,
    39: 18,
    40: 18,
    41: 6,
    42: 6,
}
ITEM_KEYS = {"Senate": tuple("ABCDEFG"), "House": tuple("ABCDEFGH")}
ITEM_CHAMBERS = {"U.S. Senate": "Senate", "U.S. House of Representatives": "House"}
TOKENS = {"", "✓", "✗", "NV", "I"}


@dataclass(frozen=True, slots=True)
class AAUWReader:
    parser_version: ClassVar[str] = parser_version
    qualified_observations: bytes = field(repr=False)
    retain_observations: RetainObservations = field(repr=False)

    def list_scorecards(self, context):
        return list_scorecards(context)

    def acquire_scorecard(self, edition, context):
        return acquire_scorecard(
            edition,
            context,
            qualified_observations=self.qualified_observations,
            retain_observations=self.retain_observations,
        )


def list_scorecards(context: ScorecardContext):
    source = context.read(URL, stage="scorecards:aauw:listing", hosts=HOSTS)
    if sha256(source.body).hexdigest() != SOURCE_SHA256:
        raise ScorecardSourceError("AAUW qualified PDF changed; source requalification required")
    return (EDITION,)


def _facts(data):
    try:
        if (
            data["format_version"] != "aauw-qualified-source-facts/1"
            or data["source_sha256"] != SOURCE_SHA256
            or data["source_page_count"] != 43
            or len(data["members"]) != sum(PAGE_MEMBERS.values())
        ):
            raise ValueError
        counts = dict.fromkeys(PAGE_MEMBERS, 0)
        identities = set()
        previous = 0
        for entry in data["members"]:
            record, page = entry["record"], entry["evidence"]["physical_page"]
            chamber = "Senate" if page < 15 else "House"
            if (
                page not in counts
                or page < previous
                or not all(
                    isinstance(record[f], str) and record[f] for f in ("member_name_text", "state_text", "party_text")
                )
                or record["party_text"] not in {"R", "D", "I"}
                or (chamber == "Senate" and record["district_text"] is not None)
                or (chamber == "House" and re.fullmatch(r"AL|\d+", record["district_text"] or "") is None)
                or set(record["results"]) != set(ITEM_KEYS[chamber])
                or any(value not in TOKENS for value in record["results"].values())
                or any(
                    re.fullmatch(r"(?:\d+(?:\s*¶)?|NA|N/A)", record[f"score_{c}_text"]) is None for c in (118, 117, 116)
                )
            ):
                raise ValueError
            identity = (chamber, record["state_text"], record["district_text"], record["member_name_text"])
            if identity in identities:
                raise ValueError
            identities.add(identity)
            counts[page] += 1
            previous = page
        if counts != PAGE_MEMBERS or [m["evidence"]["physical_page"] for m in data["methodology"]] != [2, 8, 19, 42]:
            raise ValueError
        items = {
            (ITEM_CHAMBERS[entry["chamber"]], entry["record"]["publisher_item_key_text"]) for entry in data["items"]
        }
        expected = {(chamber, k) for chamber, keys in ITEM_KEYS.items() for k in keys}
        if items != expected or len(data["items"]) != len(expected):
            raise ValueError
        for entry in data["items"]:
            item = entry["record"]
            if (
                not item["title_text"]
                or not item["publisher_position_text"]
                or not item["bill_citation_text"]
                or not item["source_pages"]
                or any(p < 4 or p > 19 for p in item["source_pages"])
            ):
                raise ValueError
            vote = item["publisher_item_key_text"] in ("D", "E")
            if vote != (item["roll_number_text"] is not None):
                raise ValueError
        return data
    except (KeyError, TypeError, ValueError):
        raise ScorecardSourceError("AAUW semantic facts fail the complete qualified edition shape") from None


def acquire_scorecard(
    edition,
    context: ScorecardContext,
    *,
    qualified_observations: bytes | None = None,
    retain_observations: RetainObservations | None = None,
):
    if edition != EDITION or qualified_observations is None or retain_observations is None:
        raise ScorecardSourceError("AAUW edition requires reviewed semantic facts and private retention")
    source = context.read(URL, stage="scorecards:aauw:report", hosts=HOSTS)
    observation = retain_qualified(
        source,
        qualified_observations,
        retain_observations,
        source_sha256=SOURCE_SHA256,
        observations_sha256=QUALIFIED_SHA256,
        stage="aauw:qualified-118",
    )
    data = _facts(json.loads(qualified_observations))
    bundle = Bundle(
        edition,
        context,
        source,
        publisher_name="AAUW Action Fund",
        parser_version=parser_version,
        rendition_rule="aauw-complete-source-member-action-and-congress-score-facts/1",
        homepage="https://www.aauwaction.org/",
    )
    bundle.use(source, "members_and_scores", "scored_items", "methodology")
    path = lambda page, pointer: f"pdf:page={page};observation={observation};{pointer}"
    for i, entry in enumerate(data["methodology"]):
        method = entry["record"]
        text = (
            method["methodology_text"]
            + "\n"
            + "\n".join(r["value_text"] + ": " + r["meaning_text"] for r in method["legend"])
        )
        bundle.add(
            "scorecard_methodologies",
            source,
            path(entry["evidence"]["physical_page"], f"/methodology/{i}/record"),
            methodology_id=f"source-page-{entry['evidence']['physical_page']}",
            methodology_text=text,
            methodology_url=URL,
            disclosure_status="explicit: uniform weights, historical metrics and publisher exclusions",
        )
    for chamber, page in (("Senate", 8), ("House", 19)):
        for congress in (118, 117, 116):
            bundle.add(
                "scorecard_metrics",
                source,
                path(page, "/score-headings"),
                metric_id=key(chamber, str(congress)),
                name=f"{congress}th Score",
                chamber_text=chamber,
                period_text=f"{congress}th Congress",
                value_unit_text="percent",
                is_primary="true" if congress == 118 else "false",
            )
    for i, entry in enumerate(data["items"]):
        item, chamber = entry["record"], ITEM_CHAMBERS[entry["chamber"]]
        item_id = key(chamber, item["publisher_item_key_text"])
        loc = path(entry["evidence"]["physical_page"], f"/items/{i}/record")
        bundle.add(
            "scorecard_items",
            source,
            loc,
            item_id=item_id,
            publisher_item_id=item["publisher_item_key_text"],
            item_kind_text=item["item_kind_text"],
            title=item["title_text"],
            chamber_text=entry["chamber"],
            congress_text="118",
            item_date_text=item["item_date_text"],
            roll_number_text=item["roll_number_text"],
            bill_citation_text=item["bill_citation_text"],
            amendment_citation_text=item["amendment_citation_text"],
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            position_source_path=loc + "/publisher_position_text",
        )
        bundle.add(
            "scorecard_metric_items",
            source,
            loc,
            metric_id=key(chamber, "118"),
            item_id=item_id,
            participation_id="current-congress",
            publisher_position_text=item["publisher_position_text"],
            position_basis="explicit",
            methodology_id="source-page-2",
        )
    for i, entry in enumerate(data["members"]):
        record, page = entry["record"], entry["evidence"]["physical_page"]
        chamber = "Senate" if page < 15 else "House"
        identity = key(
            chamber, record["state_text"], record["member_name_text"], record["district_text"] or "no-district"
        )
        loc = path(page, f"/members/{i}/record")
        bundle.add(
            "scorecard_members",
            source,
            loc,
            publisher_member_key=identity,
            member_name=record["member_name_text"],
            state=record["state_text"],
            party=record["party_text"],
            district=record["district_text"],
            chamber_text=chamber,
        )
        for congress in (118, 117, 116):
            raw = record[f"score_{congress}_text"]
            value = "N/A" if raw == "NA" else raw
            bundle.add(
                "scorecard_member_ratings",
                source,
                loc + f"/score_{congress}_text",
                metric_id=key(chamber, str(congress)),
                publisher_member_key=identity,
                value_text=value,
                value_number=decimal_text(value),
            )
        for action, value in record["results"].items():
            bundle.add(
                "scorecard_member_item_results",
                source,
                loc + "/results/" + action,
                item_id=key(chamber, action),
                metric_id=key(chamber, "118"),
                participation_id="current-congress",
                publisher_member_key=identity,
                result_id="published-chart",
                result_text=value,
            )
    return bundle.finish(
        "Complete publisher final 118th report: exact source and private observation hashes; every reviewed Senate, House and delegate page reconciles to its source member count. All published action cells and 118th/117th/116th scores are preserved separately. Empty, NV, ineligible and footnote cells remain source facts; no invented historical item participation. Standalone NA ratings normalize to N/A; original spelling remains in pinned observations."
    )
