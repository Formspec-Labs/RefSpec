"""Shared complete-header and literal-row reading for FEC committee and candidate masters."""

from __future__ import annotations

import csv
import io
from collections.abc import Iterator, Mapping
from contextlib import contextmanager

from spicy_docs.sources.fec.bulk_profile import MAX_DECODED_BYTES
from spicy_docs.sources.fec.delimited import delimited_rows, selected_stream
from spicy_docs.sources.fec.originals import original_capture

ENCODING = "utf-8"
MAX_RECORD_BYTES = 16 * 1024
MAX_HEADER_BYTES = 4 * 1024


def master_header(raw: bytes, *, fields: tuple[str, ...], label: str) -> tuple[str, ...]:
    """Require the complete bounded header to name exactly the supported fields."""
    if len(raw) > MAX_HEADER_BYTES:
        raise ValueError(f"FEC {label} master header exceeds its byte bound")
    rows = [row for row in csv.reader(io.StringIO(raw.decode(ENCODING))) if row]
    if rows != [list(fields)]:
        raise ValueError(f"FEC {label} master header differs from the fields this reader maps")
    return fields


@contextmanager
def _retained(blob_source, capture: Mapping):
    """Open retained bytes by their digest, which the blob source verifies, and hold them to the stated size."""
    with blob_source.open(capture["responseSha256"]) as stream:
        size = stream.seek(0, io.SEEK_END)
        stream.seek(0)
        if size != capture["byteSize"]:
            raise ValueError("FEC retained original differs from its stated byte size")
        yield stream


def iter_master_rows(
    *,
    capture: Mapping,
    header_capture: Mapping,
    blob_source,
    cycle: int,
    fields: tuple[str, ...],
    label: str,
    url: str,
    header_url: str,
    member_name: str,
) -> Iterator[dict]:
    """Read one complete bounded master header and the selected literal member rows."""
    capture, header_capture = original_capture(capture), original_capture(header_capture)
    if capture["requestUrl"] != url or capture["representation"] != "zip":
        raise ValueError(f"FEC {label} master capture is not this cycle's ZIP")
    if header_capture["requestUrl"] != header_url or header_capture["representation"] != "opaque":
        raise ValueError(f"FEC {label} master header capture is not the selected header")
    for selected, expected in ((capture, url), (header_capture, header_url)):
        if selected.get("resolvedUrl", expected) != expected:
            raise ValueError(f"FEC {label} master capture resolved to a different selected file")
    with _retained(blob_source, header_capture) as stream:
        master_header(stream.read(MAX_HEADER_BYTES + 1), fields=fields, label=label)
    rows = 0
    with (
        _retained(blob_source, capture) as original,
        selected_stream(
            original,
            capture=capture,
            member={"ordinal": 0, "name": member_name},
            max_members=1,
            max_decoded_bytes=MAX_DECODED_BYTES,
        ) as (decoded, _, sha256),
    ):
        try:
            for row in delimited_rows(
                decoded,
                sha256=sha256,
                encoding=ENCODING,
                delimiter="|",
                quoting="literal",
                max_record_bytes=MAX_RECORD_BYTES,
            ):
                values = row["fields"]
                if len(values) != len(fields):
                    raise ValueError(f"FEC {label} master row has {len(values)} fields, not {len(fields)}")
                rows += 1
                yield {
                    "cycle": cycle,
                    "fields": dict(zip(fields, values, strict=True)),
                    "source": row["source"],
                }
        except csv.Error as error:
            raise ValueError(f"FEC {label} master row is not literal pipe-delimited text: {error}") from error
    if not rows:
        raise ValueError(f"FEC {label} master member has no rows")
