"""The FEC candidate master: one row per candidate per two-year cycle, from the bulk ``cn<yy>.zip`` files.

The bulk bucket holds one file per cycle, each a ZIP whose only member is ``cn.txt``:
pipe-delimited rows with no header and literal quotes, whose fields
``cn_header_file.csv`` names. The reading rules mirror
:mod:`spicy_docs.sources.fec.committee_master` exactly: the header file is the
only statement of what each position means, quotes are data, fields stay the
publisher's literal strings, and retained bytes are read through a blob source
that verifies them by digest.
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping

from spicy_docs.sources.fec.catalog import BUCKET_URL
from spicy_docs.sources.fec.master import iter_master_rows, master_header

#: ``cn_header_file.csv``, in order (retained 2026-09-12 as sha256:86fe00a8…).
CANDIDATE_MASTER_FIELDS: tuple[str, ...] = (
    "CAND_ID",
    "CAND_NAME",
    "CAND_PTY_AFFILIATION",
    "CAND_ELECTION_YR",
    "CAND_OFFICE_ST",
    "CAND_OFFICE",
    "CAND_OFFICE_DISTRICT",
    "CAND_ICI",
    "CAND_STATUS",
    "CAND_PCC",
    "CAND_ST1",
    "CAND_ST2",
    "CAND_CITY",
    "CAND_ST",
    "CAND_ZIP",
)
HEADER_URL = f"{BUCKET_URL}bulk-downloads/data_dictionaries/cn_header_file.csv"
#: The bulk bucket files masters from 1980; 1976/1978 exist only in the OpenFEC dump (gap 8, decision 53).
FIRST_CYCLE = 1980


def _cycle(cycle: int) -> int:
    if type(cycle) is not int or cycle < FIRST_CYCLE or cycle % 2:
        raise ValueError(f"FEC candidate master cycles are even years from {FIRST_CYCLE}")
    return cycle


def candidate_master_cycles(through: int) -> tuple[int, ...]:
    """Every cycle from 1980 through ``through``: the even years the bucket files the candidate master by."""
    return tuple(range(FIRST_CYCLE, _cycle(through) + 1, 2))


def candidate_master_url(cycle: int) -> str:
    """The bucket URL of one cycle's candidate master, ``bulk-downloads/<cycle>/cn<yy>.zip``."""
    return f"{BUCKET_URL}bulk-downloads/{_cycle(cycle)}/cn{cycle % 100:02d}.zip"


def candidate_master_header(raw: bytes) -> tuple[str, ...]:
    """Read ``cn_header_file.csv`` and refuse any field list but :data:`CANDIDATE_MASTER_FIELDS`.

    The data files carry no header, so this is the only statement of what each position means; a publisher change
    must stop a reader, not shift every column.
    """
    return master_header(raw, fields=CANDIDATE_MASTER_FIELDS, label="candidate")


def iter_candidate_master_rows(*, capture: Mapping, header_capture: Mapping, blob_source, cycle: int) -> Iterator[dict]:
    """Yield each row of one cycle's retained file as ``{cycle, fields, source}``, fields keyed by the header.

    ``capture`` and ``header_capture`` are the retained originals' capture facts: the cycle's own ZIP, requested at
    :func:`candidate_master_url`, and ``cn_header_file.csv`` at :data:`HEADER_URL`. ``blob_source`` opens each by
    its digest and must verify it, as ``rulespec_artifacts.LocalBlobSource`` does; its size must match too. The
    header is read and checked here. ``source`` gives the member's sha256 and the row's byte offset and length.

    It refuses a ZIP with any member but ``cn.txt``, a member with no rows, a row of another width, and bytes that
    are not UTF-8 or not literal pipe-delimited text. Only natural exhaustion establishes a complete parse: a
    refusal part-way stops the reader after earlier rows were yielded, so keep nothing from a file until it ends.
    """
    yield from iter_master_rows(
        capture=capture,
        header_capture=header_capture,
        blob_source=blob_source,
        cycle=cycle,
        fields=CANDIDATE_MASTER_FIELDS,
        label="candidate",
        url=candidate_master_url(cycle),
        header_url=HEADER_URL,
        member_name="cn.txt",
    )


__all__ = [
    "CANDIDATE_MASTER_FIELDS",
    "FIRST_CYCLE",
    "HEADER_URL",
    "candidate_master_cycles",
    "candidate_master_header",
    "candidate_master_url",
    "iter_candidate_master_rows",
]
