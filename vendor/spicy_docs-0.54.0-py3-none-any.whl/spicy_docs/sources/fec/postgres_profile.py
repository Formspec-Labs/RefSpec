"""Replay retained FEC PostgreSQL originals as bounded native COPY observations."""

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

from rulespec_artifacts import canonical_json_bytes

from spicy_docs.releases.profile import SourceNativeBlobPage
from spicy_docs.sources.fec.postgres import (
    MAX_RECORD_BYTES,
    derive_postgres_table,
    postgres_capture,
    postgres_copy_rows,
    validate_derivation,
)
from spicy_docs.sources.fec.retained import MAX_SCOPE_BYTES
from spicy_docs.sources.fec.row_profile import FEC_POSITIONAL_ROWS_PROFILE, MAX_PAGE_BYTES, row_pages


def postgres_row_scope(capture, *, derivation, max_records_per_page=1000, max_record_bytes=MAX_RECORD_BYTES):
    """Select a native archive and the exact pg_restore outputs it must reproduce."""
    capture = postgres_capture(capture)
    derivation = validate_derivation(derivation, capture=capture)
    for value, limit in ((max_records_per_page, 1000), (max_record_bytes, MAX_RECORD_BYTES)):
        if type(value) is not int or not 1 <= value <= limit:
            raise ValueError("FEC PostgreSQL row bound is invalid")
    scope = {
        "capture": capture,
        "derivation": derivation,
        "max_records_per_page": max_records_per_page,
        "max_record_bytes": max_record_bytes,
    }
    if len(canonical_json_bytes(scope)) > MAX_SCOPE_BYTES:
        raise ValueError("FEC PostgreSQL scope exceeds its byte bound")
    return scope


def _scope(value):
    if not isinstance(value, dict) or set(value) != {
        "capture",
        "derivation",
        "max_records_per_page",
        "max_record_bytes",
    }:
        raise ValueError("FEC PostgreSQL scope fields differ")
    return postgres_row_scope(**value)


def iter_retained_postgres_rows(scope, *, blob_source):
    """Yield the original archive; generated SQL is never labeled a downloaded body."""
    capture = _scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0,
        0,
        "fec-rows://page/0",
        capture["responseSha256"],
        capture["byteSize"],
        blob_source,
        "application/octet-stream",
    )


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = _scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        "fec-rows://page/0",
        capture["responseSha256"],
        capture["byteSize"],
        "application/octet-stream",
    ):
        raise ValueError("FEC PostgreSQL original differs from its selected capture")
    with TemporaryDirectory() as temporary:
        output = Path(temporary) / "decoded"
        derived = derive_postgres_table(stream, capture=capture, output_directory=output)
        if derived != scope["derivation"]:
            raise ValueError("FEC PostgreSQL decoder outputs differ from the selected derivation")
        with (output / "data.sql").open("rb") as decoded:
            yield from row_pages(
                postgres_copy_rows(decoded, derivation=derived, max_record_bytes=scope["max_record_bytes"]),
                evidence_ref=evidence_ref,
                member=None,
                max_records_per_page=scope["max_records_per_page"],
            )


def _validate_record(record, *, query_scope, page_window):
    digest = query_scope["capture"]["responseSha256"]
    parsed = record["record"]
    if record["member"] is not None or record["id"] != f"{digest}/original/{record['ordinal']:020d}":
        raise ValueError("FEC PostgreSQL record coordinates differ")
    if (
        parsed.get("kind") != "postgres-copy"
        or parsed.get("source", {}).get("original_sha256") != digest
        or parsed.get("source", {}).get("sha256") != query_scope["derivation"]["outputs"]["data"]["sha256"]
    ):
        raise ValueError("FEC PostgreSQL record provenance differs")
    if len(parsed.get("fields", [])) != len(query_scope["derivation"]["columns"]) or len(
        parsed.get("values", [])
    ) != len(query_scope["derivation"]["columns"]):
        raise ValueError("FEC PostgreSQL record width differs")


# The positional schema already owns ordinal/member/native-record observations.
# Only acquisition and decoding differ; paging, closure and release wiring remain
# with that owner instead of introducing a second generic publication subsystem.
FEC_POSTGRES_ROWS_PROFILE = replace(
    FEC_POSITIONAL_ROWS_PROFILE,
    name="Retained FEC PostgreSQL COPY rows",
    source_system_id="urn:spicy-docs:source:fec-postgres-originals",
    acquisition_policy_id="urn:spicy-docs:acquisition:fec-postgres-rows",
    acquisition_policy=lambda scope: {
        "initialQueryScope": _scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "One retained native committee-history table; all native columns and COPY row observations.",
            "pg_restore writes pinned SQL text only. Source archive, tool, schema and derived stream identities remain distinct.",
            "SQL NULL, empty text and array text stay distinct; no current relationships, financial types or amendment selection inferred.",
        ],
    },
    validate_query_scope=_scope,
    parse_file_stream=_parse_file,
    validate_record_scope=_validate_record,
)

__all__ = ["FEC_POSTGRES_ROWS_PROFILE", "iter_retained_postgres_rows", "postgres_row_scope"]
