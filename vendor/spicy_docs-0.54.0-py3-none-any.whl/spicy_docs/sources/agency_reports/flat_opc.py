"""Literal Word Flat OPC parts and text tokens; distinct from native FOIA report statistics."""

from __future__ import annotations

import hashlib

from spicy_docs.sources.agency_reports.xml_elements import xml_elements

_PACKAGE = "{http://schemas.microsoft.com/office/2006/xmlPackage}"
_WORD = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_TEXT_TAGS = {_WORD + local for local in ("t", "instrText", "delText", "tab", "br", "cr")}
_TEXT_TAGS.add("{http://schemas.openxmlformats.org/drawingml/2006/main}t")


class FlatOpcError(ValueError):
    """The retained bytes are not a supported complete Word Flat OPC package."""


def parse_word_flat_opc(body: bytes, *, max_bytes=4 * 1024**2, max_elements=100_000) -> dict:
    """Keep every XML element and distinct package part, with literal Word text/control tokens.

    Text tokens retain deleted text and field instructions under their native tags;
    they are not a rendered document, accepted revision, inferred table or FOIA statistic.
    Unknown parts and markup remain in ``elements`` and in the exact original bytes.
    No relationships or embedded resources are followed.
    """

    def root(tag):
        if tag != _PACKAGE + "package":
            raise FlatOpcError("Word Flat OPC requires its native package root")

    elements = xml_elements(
        body,
        max_bytes=max_bytes,
        max_elements=max_elements,
        error_type=FlatOpcError,
        label="Word Flat OPC",
        validate_root=root,
    )
    children = {}
    for index, element in enumerate(elements):
        children.setdefault(element["parent"], []).append(index)
    parts, part_for_element, names = [], {}, set()
    for index, element in enumerate(elements):
        parent = element["parent"]
        if parent == 0:
            attributes = element["attributes"]
            name, content_type = attributes.get(_PACKAGE + "name"), attributes.get(_PACKAGE + "contentType")
            if element["tag"] != _PACKAGE + "part" or not name or not content_type or name in names:
                raise FlatOpcError("Word Flat OPC needs uniquely named typed package parts")
            payloads = children.get(index, [])
            if len(payloads) != 1 or elements[payloads[0]]["tag"] not in {
                _PACKAGE + "xmlData",
                _PACKAGE + "binaryData",
            }:
                raise FlatOpcError("Word Flat OPC part needs exactly one XML or binary payload")
            payload = payloads[0]
            if elements[payload]["tag"] == _PACKAGE + "xmlData" and len(children.get(payload, [])) != 1:
                raise FlatOpcError("Word Flat OPC XML part needs exactly one root")
            if content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml" and (
                elements[payload]["tag"] != _PACKAGE + "xmlData"
                or elements[children[payload][0]]["tag"] != _WORD + "document"
            ):
                raise FlatOpcError("Word Flat OPC main part lacks its Word document root")
            names.add(name)
            part_for_element[index] = len(parts)
            parts.append({"element": index, "name": name, "content_type": content_type, "attributes": attributes})
        elif parent in part_for_element:
            part_for_element[index] = part_for_element[parent]
    if not parts or not any(
        p["content_type"] == "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
        for p in parts
    ):
        raise FlatOpcError("Word Flat OPC lacks its main Word document part")
    bodies = [
        {
            "element": index,
            "part": part_for_element[index],
            "tag": element["tag"],
            "attributes": element["attributes"],
            "text": element["text"],
            "child_indices": element["child_indices"],
        }
        for index, element in enumerate(elements)
        if element["tag"] in _TEXT_TAGS and index in part_for_element
    ]
    return {
        "source": {"sha256": "sha256:" + hashlib.sha256(body).hexdigest(), "bytes": len(body)},
        "metadata": {"representation": "word-flat-opc", "package_attributes": elements[0]["attributes"]},
        "parts": parts,
        "elements": elements,
        "bodies": bodies,
    }
