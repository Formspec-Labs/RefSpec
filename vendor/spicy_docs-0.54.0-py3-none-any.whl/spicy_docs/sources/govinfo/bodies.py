"""Locate and prove one GovInfo package or granule body, offline.

A package id is the publisher's own address for a committee report, hearing
transcript, committee print, Congressional Record issue, congressional
document, directory, bill text or budget volume, and a granule id names one
constituent of a package -- one Record speech, one page range -- reached through
its package's content path, with membership proved by the granule MODS's nested
host accessId rather than assumed from the URL. Body renditions are keyless and
their folder is not the format name; the offered set is read from the MODS
``access="raw object"`` URLs, not the summary's ``download`` links, which list
no body rendition at all for some collections, and a format a package does not
offer redirects to the publisher's "Page Not Found" page, which answers HTTP
200 and is a refusal, never data and never absence. The collection a package id
names is not always the ``collectionCode`` its records state (``BUDGET`` and
``GPO-CDOC`` both state ``GPO``), so each grammar carries the code its records
state; every parser requires a positive byte bound, and no helper here makes a
network request or writes a file.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from spicy_docs.reading.json_input import load_decimal_json
from spicy_docs.sources.congress.bill_status import BILL_TYPES
from spicy_docs.sources.govinfo.discovery import API
from spicy_docs.sources.govinfo.error_page import check_not_error_page
from spicy_docs.sources.govinfo.mods import (
    MODS_NAMESPACE,
    RETAINED_MODS_MAX_ELEMENTS,
    GovInfoModsError,
    GovInfoModsPackage,
    ModsRecord,
    parse_govinfo_mods,
)
from spicy_docs.transport.source_acquirer import check_final_url, check_payload

CONTENT = "https://www.govinfo.gov"
MAX_PACKAGE_ID = 128
_RAW_OBJECT = "raw object"
_MODS_URL = f"{{{MODS_NAMESPACE}}}url"
# GPO writes ``<congCommittee>`` inside the GPO extension but its ``<name>``
# children in the MODS namespace, so the child name is expanded and the
# extension's own children are not.
_MODS_NAME = f"{{{MODS_NAMESPACE}}}name"
# ``<section>`` inside ``<USCode>`` inherits the MODS default namespace the
# root declares, the same way ``<congCommittee>``'s ``<name>`` does, so the
# child name is expanded rather than written bare.
_MODS_SECTION = f"{{{MODS_NAMESPACE}}}section"
_CONGRESS = r"[1-9][0-9]*"
_NUMBER = r"[1-9][0-9]*"
# A hearing jacket is an opaque printing number, so leading zeros are kept.
_JACKET = r"[0-9]+"
# Longest first, then alphabetically: hconres must win over hr, whatever order
# the frozenset iterates in, so the compiled pattern is the same every run.
_BILL_TYPE = "|".join(sorted(BILL_TYPES, key=lambda name: (-len(name), name)))
_DATE = r"[0-9]{4}-[0-9]{2}-[0-9]{2}"
#: Every part of the President's budget the publisher has been measured
#: spelling. A budget volume is addressed by its fiscal year and its part, with
#: no Congress anywhere: ``BUDGET-2027-APP``.
#:
#: **Sealed to measured parts, and additions-only.** A part no sample has seen
#: is a part whose address is not established, and a refusal naming what was
#: expected is recoverable where a guessed address is not -- the rule every
#: other grammar here follows. Adding one is an entry here plus the id that
#: showed it. It is one object rather than a pattern plus a prose list so that
#: a caller reporting coverage and the parser that refuses a row cannot
#: disagree about what the vocabulary is.
#:
#: The first six were measured 2026-09-20 across the eight retained volumes, on
#: a ``published/BUDGET`` walk from 2025-01-01:
#:
#: - ``APP`` (Appendix) -- BUDGET-2027-APP
#: - ``BALANCES`` (Balances of Budget Authority) -- BUDGET-2026-BALANCES
#: - ``BUD`` (Budget of the U.S. Government) -- BUDGET-2027-BUD
#: - ``FCS`` (Federal Credit Supplement) -- BUDGET-2027-FCS
#: - ``MSR`` (Mid-Session Review) -- BUDGET-2026-MSR
#: - ``PER`` (Analytical Perspectives) -- BUDGET-2027-PER
#:
#: Seven more joined the same day. A hosted run walked the same route from
#: **2023-01-01** and served 40 rows, of which **17 carried a part outside the
#: six** and were refused by name (receipt
#: ``rollups-pdf-families-2026-09-20/requests/print-citations-resume.json``).
#: Each is proved on its own summary and MODS, fetched once
#: (``budget-parts-2026-09-20/``, 14 requests of a 20 cap):
#:
#: - ``OBJCLASS`` (Object Class Analysis) -- BUDGET-2027-OBJCLASS
#: - ``TAB`` (Historical Tables) -- BUDGET-2027-TAB
#: - ``DB`` (Public Budget Database) -- BUDGET-2027-DB
#: - ``CLIMATE`` (Climate Risk Analysis) -- BUDGET-2025-CLIMATE
#: - ``LRB`` (Long Range Budget Projections) -- BUDGET-2025-LRB
#: - ``CROSSCUT`` (Crosscut Tables) -- BUDGET-2026-CROSSCUT
#: - ``DOD`` (Department of Defense Appendix) -- BUDGET-2026-DOD
#:
#: **An id parsing is not a promise that a package body exists**, and these
#: seven are where the two come apart. Three of them (OBJCLASS, CROSSCUT, DOD)
#: state a PDF at exactly ``package_body_locator(id, "pdf")``. Three (CLIMATE,
#: DB, TAB) state their PDF only inside a constituent, at a *granule* stem
#: (``pdf/BUDGET-2027-TAB-1.pdf``), so the package root offers nothing and
#: ``acquire`` answers ``GovInfoFormatNotOfferedError`` while
#: ``acquire_granule`` reaches the body. One (LRB) states one XLS at the
#: package stem and no body rendition at all. That is the publisher's own
#: answer in each case, and it is only reachable because the address parses:
#: before this widening all seven were refused before any request. A caller
#: walking this collection reads such a refusal as that shape, not as a
#: missing volume.
MEASURED_BUDGET_PARTS: frozenset[str] = frozenset(
    {
        "APP",
        "BALANCES",
        "BUD",
        "CLIMATE",
        "CROSSCUT",
        "DB",
        "DOD",
        "FCS",
        "LRB",
        "MSR",
        "OBJCLASS",
        "PER",
        "TAB",
    }
)
# Sorted so the compiled pattern is byte-identical every run, the same reason
# ``_BILL_TYPE`` sorts: a frozenset's iteration order is not stable across
# interpreters. Alphabetical is safe where ``_BILL_TYPE``'s longest-first is
# not, because this alternation sits inside a ``fullmatch`` that backtracks
# past a shorter alternative -- ``DB`` cannot shadow ``DOD``, and a test parses
# every part to hold that.
_BUDGET_PART = "|".join(sorted(MEASURED_BUDGET_PARTS))
_FISCAL_YEAR = r"[0-9]{4}"


@dataclass(frozen=True, slots=True)
class PackageGrammar:
    """One collection's id grammar, an example of it, and the code its records state.

    ``collection_code`` is the ``collectionCode`` the publisher's own summary
    and MODS state for this collection, which is *not* always the id's prefix:
    ``BUDGET-2027-BUD`` and ``GPO-CDOC-119sdoc3`` both state ``GPO`` (measured
    2026-09-20). It lives beside the pattern so a collection states everything
    about itself in one place and no check has to assume the two agree.

    ``part`` is the suffix a part's granule id adds to the package id, with
    the part's number as its ``number`` group, or ``None`` where no record was
    measured stating a part. Only part 1 may stand at a record's root in place
    of the package's own stem (``_stated_part``); every part may be a
    constituent (``_constituent_part``).

    ``volumes`` is a second, exact pattern for the stems the publisher
    addresses as separate packages of one number, with the suffix as its
    ``volume`` group, or ``None``. It names measured stems only and is never
    widened into a general suffix, so an unmeasured one stays refused by name.
    """

    pattern: re.Pattern[str]
    example: str
    collection_code: str
    part: re.Pattern[str] | None = None
    volumes: re.Pattern[str] | None = None


_GRAMMARS: dict[str, PackageGrammar] = {
    "CRPT": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>hrpt|srpt|erpt)(?P<number>{_NUMBER})"),
        "119hrpt1",
        "CRPT",
        # ``-pt{N}``, measured 2026-09-23 on every multi-part record retained:
        # a root names only ``-pt1`` (CRPT-119hrpt811, CRPT-112hrpt38 and six
        # more), and constituents name ``-pt1`` and ``-pt2`` (CRPT-119hrpt455,
        # -119hrpt620, -108hrpt24) or ``-pt2`` beside an unsuffixed Part 1
        # (CRPT-119hrpt494).
        part=re.compile(r"-pt(?P<number>[1-9][0-9]*)"),
    ),
    "CHRG": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>hhrg|shrg|jhrg)(?P<number>{_JACKET})"),
        "119hhrg64242",
        "CHRG",
        # Two volumes of the 79th Congress's Pearl Harbor attack hearings
        # (jacket 79716), each its own package: the retained CHRG listing named
        # them, and each summary's packageId and MODS accessId state the id
        # exactly (captured 2026-09-25; tests/fixtures/govinfo_compiled_hearing).
        # No other volume of 79716 has been listed, so none is admitted.
        volumes=re.compile(r"(?P<congress>79)(?P<type>jhrg)(?P<number>79716)(?P<volume>p11|p19)"),
    ),
    "CDOC": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>hdoc|sdoc|tdoc)(?P<number>{_NUMBER})"), "119tdoc2", "CDOC"
    ),
    # Verified on a real package summary 2026-09-19 (CPRT-118HPRT57104): the
    # chamber-plus-doctype token is spelled upper-case here, unlike CRPT's own
    # lower-case hrpt/srpt/erpt -- the two collections do not share a case
    # convention, so this is measured, not inferred from CRPT's shape.
    "CPRT": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>HPRT|SPRT|JPRT)(?P<number>{_NUMBER})"), "118HPRT57104", "CPRT"
    ),
    "CREC": PackageGrammar(
        re.compile(rf"(?P<date>{_DATE})(?:-(?P<suffix>[vi]{_NUMBER}))?"), "2026-01-02 or 2019-01-03-v164", "CREC"
    ),
    "CDIR": PackageGrammar(re.compile(rf"(?P<date>{_DATE})"), "2026-02-20", "CDIR"),
    "BILLS": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>{_BILL_TYPE})(?P<number>{_NUMBER})(?P<version>[a-z][a-z0-9]*)"),
        "119hr1enr",
        "BILLS",
    ),
    # The President's budget. Its records state ``collectionCode`` ``GPO`` and
    # ``docClass`` ``BUDGET``; the fiscal year in the id is the one the MODS
    # also states as ``<field name="Fiscal Year">`` on all eight volumes
    # measured, and it is not the ``dateIssued`` year (BUDGET-2026-MSR was
    # issued 2025-09-05).
    "BUDGET": PackageGrammar(
        re.compile(rf"(?P<fiscal_year>{_FISCAL_YEAR})-(?P<type>{_BUDGET_PART})"), "2027-APP", "GPO"
    ),
    # The Senate Secretary's semiannual report, published as a CDOC reprint
    # under a ``GPO-`` prefix. The collection is the whole two-segment prefix,
    # never ``GPO`` alone: ``GPO-J6-REPORT`` states ``collectionCode`` ``GPO``
    # too and is a different family with a different address, so matching on
    # ``GPO`` would readmit exactly the id ``parse_package_id`` exists to
    # refuse. Only ``sdoc`` is sealed: all three retained reprints and all
    # five of their granules spell it that way and state ``docClass`` ``SDOC``
    # (2026-09-20). ``hdoc`` and ``tdoc`` are real CDOC document types and are
    # deliberately *not* inferred here -- no ``GPO-CDOC-`` id carrying one has
    # been measured, and this module already refused to infer CPRT's case
    # convention from CRPT's for the same reason.
    "GPO-CDOC": PackageGrammar(
        re.compile(rf"(?P<congress>{_CONGRESS})(?P<type>sdoc)(?P<number>{_NUMBER})"), "119sdoc3", "GPO"
    ),
}


class GovInfoBodySourceError(ValueError):
    """GovInfo evidence does not prove the requested package body."""


@dataclass(frozen=True, slots=True)
class BodyFormat:
    """One keyless rendition: its folder, file extension and accepted media types."""

    name: str
    folder: str
    extension: str
    media_types: tuple[str, ...]


#: The grammar: every rendition this module can address. The order callers
#: should ask for them in is ``BODY_PREFERENCE`` below.
PACKAGE_BODY_FORMATS: dict[str, BodyFormat] = {
    "htm": BodyFormat("htm", "html", "htm", ("text/html",)),
    "xml": BodyFormat("xml", "xml", "xml", ("application/xml", "text/xml")),
    # United States Legislative Markup: a second, richer structured rendition
    # BILLS offers alongside its own xml -- same folder-not-format-name rule,
    # ``uslm/{id}.xml``, and the same media types, since GovInfo serves it as
    # plain XML (measured 2026-09-19, BILLS-119hconres11enr: content-type
    # application/xml). See ``extraction/body_text.py`` for why its text
    # derivation is the same markup reader as ``xml``, not a dedicated parser.
    "uslm": BodyFormat("uslm", "uslm", "xml", ("application/xml", "text/xml")),
    "txt": BodyFormat("txt", "text", "txt", ("text/plain",)),
    "pdf": BodyFormat("pdf", "pdf", "pdf", ("application/pdf",)),
}

#: The one sealed body preference for every GovInfo caller: structure first,
#: page images last.
#:
#: The ruling this seals, verbatim: *"shouldn't we prefer xml? and accept pdf
#: as a final fallback?"* Before it, each caller carried its own order and
#: stopped early -- the bill family asked for ``("xml", "txt")`` and the
#: committee-report transform for ``("txt", "htm", "xml")`` -- so a package
#: offered only as PDF got no body at all, and two callers disagreed about
#: what the same publisher offers. One constant, one order, everywhere.
#:
#: XML is first because it is the only rendition that states the document's
#: own structure. PDF is last because it is a rendering, not a text stream,
#: and the measurement below says what that costs. Measured 2026-09-19 on
#: three real committee reports, each in the rendition it offers and in its
#: own PDF (receipts and per-package numbers in
#: ``docs/sources/govinfo-bodies.md``, "Why PDF is last"):
#:
#: - **Words split in half.** PyMuPDF's page text carries 1,863 and 1,894
#:   mid-word print wraps on CRPT-113srpt77 and CRPT-113hrpt135, which
#:   ``gpo_normalize`` rejoins only on a gutter-numbered document -- and a
#:   committee report never is one. The same packages' ``htm`` rendition
#:   carries 32 and 47 hyphens, and every sampled one is a real compound word
#:   (``man-made``, ``long-standing``), not a print wrap.
#: - **Table rows destroyed.** 841 and 190 appropriations account rows keep
#:   their label, leader dots and amount on one line in ``htm``; 0 and 3 do
#:   in the PDF text, which emits the label and its amount as separate lines
#:   in column order.
#: - **No font cue to buy back.** GPO sets section headings in the body face
#:   at body size: only 89 and 16 lines are bold against 297 and 201 heading
#:   lines the report-block parser matches, and only 15 and 12 matched lines
#:   carry any font cue at all. Reading PyMuPDF spans would label the table
#:   body font, not the headings, and would still have to rebuild rows from
#:   bounding boxes -- which the ``htm`` rendition already hands over joined.
#:
#: ``htm`` before ``txt`` is not a measured ranking: no package offers both
#: (CRPT/CHRG/CDOC offer htm and pdf, CDIR offers txt and pdf, BILLS offers
#: htm, xml and pdf), so the two never compete. They are ordered by the same
#: structure-first rule, since markup can only add to what plain text states.
#:
#: ``uslm`` sits right after ``xml``: it is the second structured rendition
#: (§B7, measured 2026-09-19 on every BILLS package in the text-versions
#: sample that offers one -- five enrolled packages, pinned in
#: tests/fixtures/govinfo_bills/uslm-renditions-2026-09-19.json), and BILLS
#: offers both on the same package, so an order was needed. XML wins the top
#: slot because every BILLS package measured offering USLM offers XML too
#: (all five MODS state htm, pdf, xml and uslm together -- Formatted-XML
#: siblings on the same publisher record), so nothing is lost by trying XML
#: first; USLM still outranks HTML and text, since it is markup over the same
#: structured source, not a plain-text reduction of it.
BODY_PREFERENCE: tuple[str, ...] = ("xml", "uslm", "htm", "txt", "pdf")

#: ``BODY_PREFERENCE`` with PDF moved from last to first, for the print
#: families whose own contracts publish a page number. **The sealed order does
#: not move**: this is a second named order a caller passes as ``prefer``, the
#: way ``bill_pdf.py`` passes ``("pdf",)``, and every collection that does not
#: state a page keeps the default.
#:
#: "Why PDF is last" is still true where it was measured -- a committee
#: report's ``htm`` keeps its account rows joined and its words whole -- and is
#: not the question here. The question is whether the rendition can answer what
#: the contract publishes, and for the page-stating families it cannot.
#: Measured 2026-09-20 on the first hosted run of the PDF-family rollups
#: (receipt ``rollups-pdf-families-2026-09-20/``, the retained wrong run
#: ``requests/print-citations-attempt-1-html.json``), over 41 CRPT committee
#: activity reports read under the sealed order:
#:
#: - **10 of 41 refused outright**, every run, with ``MarkupReadError: HTML
#:   markup exceeds the supported nesting depth``. A quarter of the family
#:   unreadable is not a preference question.
#: - The 31 that were read published **0 page attributions across 29,308
#:   citation rows**, and NULL ``pages_read``, ``stated_page_count`` and
#:   ``pages_capped`` on every document row. No GovInfo ``htm`` body of any
#:   collection carries a page boundary, and ``extraction/body_text.py`` says
#:   so structurally: ``BodyText.pages`` is ``None`` for every rendition but
#:   ``pdf``. Four published columns state a page, so reading HTML publishes
#:   four NULLs and calls it a row.
#: - Under this order the same window read as PDF: 41 reports and 23 budget
#:   volumes, **zero refusals**, and an ``evidence_page`` on every one of
#:   49,792 citation rows.
#:
#: PDF is first and the whole sealed order follows it, rather than
#: ``("pdf",)``: a package that offers no PDF -- and four of the thirteen
#: measured BUDGET parts state none at the package root -- still yields a body
#: instead of being refused for want of one.
PRINT_BODY_PREFERENCE: tuple[str, ...] = ("pdf", *(name for name in BODY_PREFERENCE if name != "pdf"))

#: The granule counterpart of ``BODY_PREFERENCE``, for
#: ``GovInfoBodyAcquirer.acquire_granule``. Measured on CREC-2026-09-18 (§B2):
#: every one of its 11 granules states HTML and PDF, both through the granule's
#: own locator (``granule_body_locator``), never the whole-issue package's.
#: HTML wins because it is the Record's actual reading text; the package-level
#: PDF ``acquire(package_id)`` already reaches (CREC packages offer PDF alone,
#: see ``BODY_PREFERENCE`` above) stays available unchanged for a caller that
#: wants the whole issue rather than one granule.
GRANULE_BODY_PREFERENCE: tuple[str, ...] = ("htm", "pdf")

# uslm shares xml's file extension -- both are xml/{id}.xml-shaped, just in
# different folders -- so an extension alone cannot always name a rendition
# found at an unexpected folder (see _package_rendition_format). xml is kept
# as that fallback's answer for the shared extension, since it existed first
# and is the far more common of the two; setdefault leaves it untouched by
# uslm's later, colliding entry.
_FORMAT_BY_EXTENSION: dict[str, str] = {}
for _name, _body_format in PACKAGE_BODY_FORMATS.items():
    _FORMAT_BY_EXTENSION.setdefault(_body_format.extension, _name)
del _name, _body_format
_PACKAGE_RENDITION = re.compile(
    rf"{re.escape(CONTENT)}/content/pkg/(?P<package>[^/]+)/[^/]+/[^/]+\.(?P<extension>[A-Za-z0-9]+)"
)


@dataclass(frozen=True, slots=True)
class PackageIdentity:
    """One parsed package id; every part is the publisher's own spelling."""

    package_id: str
    collection: str
    congress: int | None = None
    document_type: str | None = None
    number: str | None = None
    issue_date: str | None = None
    issue_suffix: str | None = None
    version: str | None = None
    #: The fiscal year a BUDGET id names, as the publisher spells it. Kept as a
    #: string, the way ``PackageSummary.session`` is: it is an identifier in the
    #: publisher's own grammar, not an arithmetic quantity. ``None`` for every
    #: collection whose ids carry no fiscal year.
    fiscal_year: str | None = None
    #: The volume suffix a separately addressed package adds to its number
    #: (``p11`` of ``CHRG-79jhrg79716p11``), read only through a grammar's
    #: measured ``volumes`` pattern; ``None`` everywhere else.
    volume: str | None = None


@dataclass(frozen=True, slots=True)
class GranuleIdentity:
    """One granule id together with the package identity it was requested under.

    A granule carries no address of its own -- every locator reaches it
    through its package's content path -- so its identity is always this
    pair, never the granule id alone.
    """

    package: PackageIdentity
    granule_id: str


@dataclass(frozen=True, slots=True)
class PackageSummary:
    """The keyed summary's own statement about one package."""

    identity: PackageIdentity
    collection_code: str
    date_issued: str | None
    last_modified: str | None
    title: str | None
    #: Every ``download`` link as the publisher spelled it, ``(name, url)``,
    #: repeated names included. Evidence, not a statement of what is fetchable.
    download_links: tuple[tuple[str, str], ...]
    #: The session of Congress the summary states, as the publisher spells it.
    #: Kept as a string: it is an identifier in the publisher's own grammar,
    #: not an arithmetic quantity.
    session: str | None = None
    #: How many pages the publisher says the document has, verbatim. This is
    #: the document's own extent, not how far any reader got, so a caller that
    #: reads a capped window reports both and never re-derives this from the
    #: bytes (measured 2026-09-20: CRPT-118hrpt968 states 56 and PyMuPDF counts
    #: 56; CRPT-118hrpt965 states 282 and a 60-page read saw 60).
    pages: str | None = None


@dataclass(frozen=True, slots=True)
class GranuleSummary:
    """The keyed granule summary's own statement about one granule and its package.

    A granule summary states both ``packageId`` and ``granuleId`` directly --
    unlike a missing package, a granule that does not belong to the requested
    package answers HTTP 400, not 404 (measured 2026-09-19: a granule id from
    another day under CREC-2026-09-18, and that same real granule id requested
    under CREC-2026-09-17, both answer 400 ``invalid granuleId``), so this is
    read as an ordinary shape mismatch rather than a distinct refusal type.
    """

    identity: GranuleIdentity
    collection_code: str
    date_issued: str | None
    title: str | None
    download_links: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class ModsBill:
    """One ``<bill>`` a package MODS names, in the publisher's own document order.

    ``context`` is the publisher's own priority marker (``PRIMARY``,
    ``OTHER``, ...), or the empty string when the publisher's ``<bill>``
    states none -- kept rather than dropped, since a ``<bill>`` with no stated
    context is still evidence the MODS named it. Document order is not
    priority order (CRPT-119hrpt1 lists S. 5 ``OTHER`` before H. Res. 53
    ``PRIMARY``), so a caller wanting the bill a report is chiefly about reads
    ``PackageModsIdentity.primary_bill``, never ``bills[0]``.

    ``bill_type`` is the publisher's own spelling (``HRES``, ``S``, ``HR``,
    ...); ``normalized_bill_type`` lower-cases it to match
    ``sources.congress.bill_status.BILL_TYPES``, so a caller matching against
    that vocabulary does not normalize twice, and is ``None`` when the
    lower-cased spelling is not one of that vocabulary's entries.
    """

    congress: int
    bill_type: str
    number: str
    context: str
    normalized_bill_type: str | None


def _mods_bills(root: ModsRecord) -> tuple[ModsBill, ...]:
    """Read every root-level ``<bill>`` a package MODS states, in document order.

    Read the same way ``accessId`` and ``collectionCode`` are --
    ``root.fields("extension", "bill")`` reaches only the root's own
    ``extension`` children, so a constituent's own ``<bill>``, if any, is not
    read here, the same boundary ``access_ids`` already draws. A ``<bill>``
    missing ``congress``, ``type`` or a numeric ``number`` is skipped rather
    than guessed at; nothing here claims completeness beyond what was
    stated. A ``<bill>`` with no ``context`` is kept, with ``context=""``
    (see ``ModsBill``), not dropped.
    """
    bills: list[ModsBill] = []
    for element in root.fields("extension", "bill"):
        congress = element.attribute("congress")
        bill_type = element.attribute("type")
        number = element.attribute("number")
        context = element.attribute("context")
        if not (congress and congress.isdecimal() and bill_type and number and number.isdecimal()):
            continue
        normalized = bill_type.lower()
        bills.append(
            ModsBill(
                congress=int(congress),
                bill_type=bill_type,
                number=number,
                context=context or "",
                normalized_bill_type=normalized if normalized in BILL_TYPES else None,
            )
        )
    return tuple(bills)


@dataclass(frozen=True, slots=True)
class ModsCommittee:
    """One ``<congCommittee>`` a package MODS names, with its own authority id.

    ``authority_id`` is the ``systemCode`` the Congress.gov committee routes
    and this repository's ``committees`` table already key on (``hsfa00``), so
    a report's authoring committee is a join and not a name match.  It is the
    publisher's statement about the document, which is why a contract reads it
    here rather than resolving the committee name a print happens to set.
    """

    authority_id: str
    chamber: str | None
    congress: int | None
    type: str | None
    #: The ``type="authority-standard"`` name, the roster's own spelling.
    name: str | None


@dataclass(frozen=True, slots=True)
class ModsUsCodeSection:
    """One ``<USCode title="N"><section number="S"/></USCode>`` the MODS names.

    Only a ``<section>`` is read: the other child measured is ``<chapter>``,
    which is not a section -- there is no hosted key for it and inventing one
    would publish ``5-8`` as if the document cited 5 U.S.C. 8 -- so a
    chapter-only block contributes nothing here, and its title is still
    visible through any sibling section.

    ``detail`` is the publisher's own subsection pointer (``(a)(1)(B)``),
    carried because it is the only place the MODS is more precise than a
    section number.
    """

    title: str
    number: str
    detail: str | None


@dataclass(frozen=True, slots=True)
class ModsCfrPart:
    """One ``<cfr title="N"><part number="M"/></cfr>`` the MODS names."""

    title: str
    part: str


@dataclass(frozen=True, slots=True)
class ModsStatute:
    """One ``<statuteAtLarge volume="N"><page pages="M"/></statuteAtLarge>``."""

    volume: str
    pages: str


@dataclass(frozen=True, slots=True)
class ModsReport:
    """One ``<congReport>`` a package MODS names: a sibling report, by its package id."""

    congress: int
    report_type: str
    number: str

    @property
    def package_id(self) -> str:
        """``congress=118 type=H number=29`` is ``CRPT-118hrpt29``."""
        return f"CRPT-{self.congress}{self.report_type.lower()}rpt{self.number}"


@dataclass(frozen=True, slots=True)
class ModsMember:
    """One ``<congMember>`` a package MODS names, and the role it names them in.

    ``bioguide_id`` is ``None`` where the publisher states the element without
    one (CRPT-118hrpt965's ``role="SUBMITTEDBY"`` member states no
    ``bioGuideId``), so a caller must treat the id as absent rather than infer
    one from the role.
    """

    bioguide_id: str | None
    role: str | None
    chamber: str | None
    congress: int | None
    state: str | None


@dataclass(frozen=True, slots=True)
class ModsLaw:
    """One ``<law>`` a package MODS names, in the publisher's own document order.

    ``is_private`` is the publisher's own ``isPrivate`` flag folded onto the
    ``public``/``private`` vocabulary ``laws.law_type`` seals; a ``<law>`` that
    states neither a numeric congress nor a numeric number is skipped rather
    than guessed at, the same boundary :func:`_mods_bills` draws.
    """

    congress: int
    number: str
    law_type: str


def _primary_bill(bills: tuple[ModsBill, ...]) -> ModsBill | None:
    """The one ``<bill>`` stating ``context="PRIMARY"``, never the first-listed one.

    Document order is not priority order (measured, CRPT-119hrpt1: S. 5
    ``OTHER`` precedes H. Res. 53 ``PRIMARY``).
    """
    return next((bill for bill in bills if bill.context == "PRIMARY"), None)


@dataclass(frozen=True, slots=True)
class ReportPart:
    """One published part of a report package: its id, number, renditions and body address, as its record states them.

    ``part_id`` is the publisher's own granule ``accessId`` for the part, which
    is also the file stem its renditions are published under:
    ``CRPT-119hrpt455-pt2``, or the package id itself where the part's stem is
    the package's -- a report published in one part (``CRPT-119hrpt1``) and
    ``CRPT-119hrpt494``'s unsuffixed Part 1. It is never ``None``.

    ``part_number`` is the number the record states: the constituent's
    ``partNumber``, or the ``-pt{N}`` its id carries, which must agree.
    ``None`` for a report published in one part, whose record numbers none.

    ``bills`` are the part's own ``<bill>`` statements. A constituent carries
    them in its own extension, and a multi-part package's root states none
    (CRPT-119hrpt455, -119hrpt494), so ``PackageModsIdentity.bills`` is empty
    there and the part's are the ones to read.
    """

    package: PackageIdentity
    part_id: str
    part_number: int | None
    offered_formats: tuple[str, ...]
    moved_renditions: tuple[tuple[str, str], ...] = ()
    other_renditions: tuple[tuple[str, str], ...] = ()
    bills: tuple[ModsBill, ...] = ()

    @property
    def primary_bill(self) -> ModsBill | None:
        """The ``<bill>`` this part is chiefly about, or ``None``."""
        return _primary_bill(self.bills)

    def body_locator(self, format: str) -> str:
        """The keyless address this part's rendition in ``format`` is proved at."""
        return package_body_locator(self.package, format, part_id=self.part_id)


@dataclass(frozen=True, slots=True)
class PackageModsIdentity:
    """The MODS accessIds and the renditions the publisher says it offers."""

    identity: PackageIdentity
    access_ids: tuple[str, ...]
    collection_code: str | None
    #: Formats whose stated rendition URL is exactly this module's locator.
    offered_formats: tuple[str, ...]
    #: ``(format, url)`` for a rendition of this package in a supported file
    #: type at an address this module does not derive: the publisher and this
    #: module disagree about where that format lives.
    moved_renditions: tuple[tuple[str, str], ...]
    #: ``(displayLabel, url)`` for every other raw-object rendition, verbatim.
    other_renditions: tuple[tuple[str, str], ...]
    #: Every ``<bill>`` the MODS names, in document order. Empty for a
    #: package whose MODS states none.
    bills: tuple[ModsBill, ...]
    #: Every ``<congCommittee>`` the root extension names, in document order.
    committees: tuple[ModsCommittee, ...] = ()
    #: Every ``<law>`` the root extension names, in document order.
    laws: tuple[ModsLaw, ...] = ()
    #: Every ``<USCode>`` *section* the root extension names, in document
    #: order; a chapter-only block contributes nothing (see
    #: :class:`ModsUsCodeSection`).
    usc_sections: tuple[ModsUsCodeSection, ...] = ()
    #: Every ``<cfr>`` part the root extension names, in document order.
    cfr_parts: tuple[ModsCfrPart, ...] = ()
    #: Every ``<statuteAtLarge>`` page the root extension names, in document order.
    statutes: tuple[ModsStatute, ...] = ()
    #: Every ``<rin>``'s number, in document order.
    rins: tuple[str, ...] = ()
    #: Every ``<congReport>`` the root extension names, in document order.
    reports: tuple[ModsReport, ...] = ()
    #: Every ``<congMember>`` the root extension names, in document order.
    members: tuple[ModsMember, ...] = ()
    #: The session of Congress the root extension states.
    session: str | None = None
    #: The fiscal year the root extension states as
    #: ``<field name="Fiscal Year">``. All eight retained budget volumes state
    #: one and no sampled CRPT or GPO-CDOC record does (2026-09-20), so this is
    #: the publisher's own labelled statement of a fact the BUDGET package id
    #: also carries -- two independent statements a caller can hold equal.
    fiscal_year: str | None = None
    #: The ``<heldDate>`` the root extension states: the day a hearing was
    #: held, which is not the day its transcript was issued (CHRG-118hhrg52385
    #: was held 2023-05-23 and issued 2024-02-15). Read because it is half the
    #: join key every hearing-to-bill link rule checks itself against
    #: (``interpretation/hearing_bill_links.py``); ``None`` for a collection
    #: whose records state none, which every sampled CRPT record does. ``None``
    #: too where the record states several distinct dates (``held_dates``).
    held_date: str | None = None
    #: Every nonempty ``<heldDate>`` the root extension states, in document
    #: order, repetitions kept: a compiled volume states several
    #: (CHRG-117shrg56721 states eleven), and which bill was heard on which
    #: day is not stated, so none is paired with a bill.
    held_dates: tuple[str, ...] = ()
    #: Every nonempty ``<eventId>`` the record states: the committee-meeting
    #: event id Congress.gov's ``committee-meeting`` route keys on. Read from
    #: the root's extension and then each constituent's (``_stated_records``),
    #: in document order, repetitions kept: a hearing published as several
    #: granules states its facts only in them, the transcript and each
    #: addendum alike (CHRG-118shrg63051 states ``336227`` twice).
    event_ids: tuple[str, ...] = ()
    #: Every nonempty ``<witness>`` the record states, verbatim -- one string
    #: per witness, name, position and organization as GPO wrote them (``Curtis
    #: Legeyt, President and CEO, National Association of Broadcasters``; a
    #: Senate record may state ``Abbate, Julie``) -- read the way ``event_ids``
    #: is. Empty where the record states none: MODS has no element for "no
    #: witnesses", so emptiness here is silence, never a stated empty list.
    witnesses: tuple[str, ...] = ()
    #: Every ``<congCommittee>``'s ``<subCommittee><name type="parsed">``,
    #: read the way ``event_ids`` is: the subcommittee GPO says held the
    #: hearing, which is what tells two same-day meetings of one committee
    #: apart (CHRG-118hhrg63377's Communications and Technology, against the
    #: Oversight and Investigations meeting both publishers pair it with).
    subcommittees: tuple[str, ...] = ()
    #: Every ``<congCommittee>``'s ``authorityId``, as stated, read the way
    #: ``event_ids`` is: ``committees`` reads the root alone, and 15 of the
    #: 185 retained CHRG MODS (2026-10-03) state their committee only in the
    #: granules (CHRG-118shrg63051's ``ssju00``, once in each).
    committee_codes: tuple[str, ...] = ()
    #: The part 1 (``CRPT-119hrpt811-pt1``) the root states in place of the
    #: package's own stem, or ``None``. A granule of this package, never a
    #: package id: ``offered_formats`` were proved at its stem, which is where
    #: the package's body is fetched from. It says whose file the bytes are,
    #: not that the part is the whole report.
    part_id: str | None = None
    #: Every part the record states, in document order: the root's one part
    #: when the record lists no constituent, else each constituent. Empty for
    #: a collection whose grammar has no ``part``. See ``_report_parts``.
    parts: tuple[ReportPart, ...] = ()

    @property
    def submitted_by(self) -> ModsMember | None:
        """The member the MODS names as having submitted the document, if any."""
        return next((member for member in self.members if member.role == "SUBMITTEDBY"), None)

    @property
    def primary_bill(self) -> ModsBill | None:
        """The ``<bill>`` this document's root states it is chiefly about, or ``None``."""
        return _primary_bill(self.bills)

    @property
    def first_held_date(self) -> str | None:
        """The first ``<heldDate>`` stated, the date of the package itself; ``held_date`` is the date of one event.

        Two rules on one list, for two questions. ``held_date`` is NULL on a
        compiled volume because a caller pairs it with each bill the volume
        covers, and its first date was once published as the date of every one
        (``_one_held_date``). A transcript row pairs it with nothing: it dates
        the package, as GovInfo's own ``dateIssued`` does (equal to this on 185
        of 185 retained CHRG MODS, 2026-10-03), and a compiled volume's row
        then reads as when its series began, not as each session's date.
        """
        return next(iter(self.held_dates), None)


def _mods_committees(root: ModsRecord) -> tuple[ModsCommittee, ...]:
    """Every root-level ``<congCommittee>``, read the way ``_mods_bills`` reads bills.

    Root-level only, so a constituent granule's own committee is not read here.
    A ``<congCommittee>`` with no ``authorityId`` is skipped: the id is the
    whole point of reading this element, and a committee with only a printed
    name is what the ``committee_name`` citation rule is for.
    """
    committees: list[ModsCommittee] = []
    for element in root.fields("extension", "congCommittee"):
        authority = element.attribute("authorityId")
        if not authority:
            continue
        congress = element.attribute("congress")
        names = {name.attribute("type"): name.text.strip() for name in element.findall(_MODS_NAME)}
        committees.append(
            ModsCommittee(
                authority_id=authority,
                chamber=element.attribute("chamber"),
                congress=int(congress) if congress and congress.isdecimal() else None,
                type=element.attribute("type"),
                name=names.get("authority-standard") or next(iter(names.values()), None),
            )
        )
    return tuple(committees)


def _mods_laws(root: ModsRecord) -> tuple[ModsLaw, ...]:
    """Every root-level ``<law>``, folded onto the sealed ``public``/``private`` vocabulary.

    The publisher states ``isPrivate="false"`` on every ``<law>`` measured
    2026-09-20 (22 across two CRPT packages); anything but the literal
    ``"true"`` reads as public, because that is the flag's own spelling and a
    missing flag on a congressional report is the ordinary public case.
    """
    laws: list[ModsLaw] = []
    for element in root.fields("extension", "law"):
        congress = element.attribute("congress")
        number = element.attribute("number")
        if not (congress and congress.isdecimal() and number and number.isdecimal()):
            continue
        private = (element.attribute("isPrivate") or "").strip().lower() == "true"
        laws.append(ModsLaw(congress=int(congress), number=number, law_type="private" if private else "public"))
    return tuple(laws)


def _mods_usc_sections(root: ModsRecord) -> tuple[ModsUsCodeSection, ...]:
    """Every root-level ``<USCode>``'s ``<section>`` children, title carried down.

    This is the element the first build of the citation contract missed, and
    missing it made a false claim: CRPT-118hrpt968's whole printed U.S. Code
    yield is ``2 U.S.C. 190``, which this states, and CRPT-118hrpt965's MODS
    states ``15 U.S.C. 57a`` that a 60-page read never reached.  A
    ``<chapter>`` child is deliberately not read (see
    :class:`ModsUsCodeSection`).
    """
    sections: list[ModsUsCodeSection] = []
    for element in root.fields("extension", "USCode"):
        title = element.attribute("title")
        if not title:
            continue
        for section in element.findall(_MODS_SECTION):
            number = section.attribute("number")
            if not number:
                continue
            sections.append(ModsUsCodeSection(title=title, number=number, detail=section.attribute("detail")))
    return tuple(sections)


def _mods_cfr_parts(root: ModsRecord) -> tuple[ModsCfrPart, ...]:
    """Every ``<cfr>`` title with its ``<part>`` children.

    Read even though no sampled CRPT record states one: an *empty* answer and
    *no element of this shape in the vocabulary* are different facts, and a
    contract's ``stated_by_index`` must be able to say "compared, and the
    index does not state it" rather than "not compared".
    """
    parts: list[ModsCfrPart] = []
    for element in root.fields("extension", "cfr"):
        title = element.attribute("title")
        if not title:
            continue
        for child in element.children:
            number = child.attribute("number")
            if number:
                parts.append(ModsCfrPart(title=title, part=number))
    return tuple(parts)


def _mods_statutes(root: ModsRecord) -> tuple[ModsStatute, ...]:
    """Every ``<statuteAtLarge>`` volume with its ``<page>`` children."""
    statutes: list[ModsStatute] = []
    for element in root.fields("extension", "statuteAtLarge"):
        volume = element.attribute("volume")
        if not volume:
            continue
        for child in element.children:
            pages = child.attribute("pages")
            if pages:
                statutes.append(ModsStatute(volume=volume, pages=pages))
    return tuple(statutes)


def _mods_rins(root: ModsRecord) -> tuple[str, ...]:
    """Every ``<rin number="nnnn-XXnn"/>`` the root extension states."""
    return tuple(number for element in root.fields("extension", "rin") if (number := element.attribute("number")))


def _mods_fiscal_year(root: ModsRecord) -> str | None:
    """The ``<field name="Fiscal Year">`` the root extension states, if any.

    GPO carries this as a *named* field rather than an element of its own, so
    the name is matched and nothing is read off position. Measured 2026-09-20:
    8 of 8 budget volumes state exactly one, and no CRPT or GPO-CDOC record
    states any field of this name.
    """
    return next(
        (
            text
            for element in root.fields("extension", "field")
            if element.attribute("name") == "Fiscal Year" and (text := element.text.strip())
        ),
        None,
    )


def _stated_records(parsed: GovInfoModsPackage) -> tuple[ModsRecord, ...]:
    """The root and then each constituent, in document order: every record a package MODS states about itself.

    A hearing published as one granule states its ``eventId`` and ``witness``
    in the root's own extension; one published as a transcript and addenda
    states them only in the constituents (11 of the 185 retained CHRG MODS,
    2026-10-03, among them CHRG-118shrg63051), so reading the root alone would
    publish the publisher's silence where it spoke.
    """
    return (parsed.package, *parsed.constituents)


def _stated_texts(
    records: tuple[ModsRecord, ...], *path: str, name_type: str | None = None, attribute: str | None = None
) -> tuple[str, ...]:
    """Every nonempty text at ``extension/<path>`` across ``records``, in document order, repetitions kept.

    ``name_type`` keeps only elements whose ``type`` attribute is that value
    (a ``<name type="parsed">``); ``attribute`` reads that attribute's value
    in place of the element's text (a ``<congCommittee authorityId="...">``).
    """
    return tuple(
        text
        for record in records
        for element in record.fields("extension", *path)
        if (name_type is None or element.attribute("type") == name_type)
        and (text := (element.text if attribute is None else element.attribute(attribute) or "").strip())
    )


def _one_held_date(dates: tuple[str, ...]) -> str | None:
    """The hearing's date when the record states exactly one distinct date, else ``None``.

    One per record on all 25 CHRG MODS retained by the
    [hearing-bill linkage measurement](../../../../docs/research/hearing-bill-linkage-2026-09-20.md),
    House and Senate alike, and it is the date Congress.gov's *Hearings Held*
    action and docs.house.gov's ``<calendar-date>`` were both checked against.
    A compiled volume states several (CHRG-117shrg56721, eleven; 2026-09-25
    audit) and names no one event, so it gets no scalar: its first date was
    once published as the date of every bill it covers.
    """
    return dates[0] if len(set(dates)) == 1 else None


def _mods_reports(root: ModsRecord) -> tuple[ModsReport, ...]:
    """Every root-level ``<congReport>``: the sibling reports this one names."""
    reports: list[ModsReport] = []
    for element in root.fields("extension", "congReport"):
        congress = element.attribute("congress")
        number = element.attribute("number")
        report_type = element.attribute("type")
        if not (congress and congress.isdecimal() and number and number.isdecimal() and report_type):
            continue
        reports.append(ModsReport(congress=int(congress), report_type=report_type, number=number))
    return tuple(reports)


def _mods_members(root: ModsRecord) -> tuple[ModsMember, ...]:
    """Every root-level ``<congMember>``, bioguide id included where stated.

    Unlike the other readers here, an element missing its identifier is
    **kept**: the role and chamber are still the publisher's statement about
    the document, and the absent id is the fact a caller needs to see
    (CRPT-118hrpt965 states exactly that).
    """
    members: list[ModsMember] = []
    for element in root.fields("extension", "congMember"):
        congress = element.attribute("congress")
        members.append(
            ModsMember(
                bioguide_id=element.attribute("bioGuideId") or None,
                role=element.attribute("role"),
                chamber=element.attribute("chamber"),
                congress=int(congress) if congress and congress.isdecimal() else None,
                state=element.attribute("state"),
            )
        )
    return tuple(members)


@dataclass(frozen=True, slots=True)
class GranuleModsIdentity:
    """The granule's own accessId, its host package's accessId, and offered renditions.

    A granule MODS states two identities: its own, directly under the root --
    the same shape a package MODS states its own accessId in -- and its host
    package's, nested inside a ``relatedItem type="host"``. The second is
    GovInfo's own proof that this granule belongs to that package, not an
    assumption drawn from the request URL.
    """

    identity: GranuleIdentity
    access_ids: tuple[str, ...]
    collection_code: str | None
    host_package_ids: tuple[str, ...]
    offered_formats: tuple[str, ...]
    moved_renditions: tuple[tuple[str, str], ...]
    other_renditions: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class PackageBodyIdentity:
    """A body proved against its locator, media type and the publisher's error page."""

    identity: PackageIdentity
    format: str
    media_type: str
    final_url: str
    byte_size: int
    #: The part whose stem the body was proved at (``ReportPart.part_id``), or
    #: ``None`` where the record states no part.
    part_id: str | None = None


@dataclass(frozen=True, slots=True)
class GranuleBodyIdentity:
    """A granule body proved against its locator, media type and the publisher's error page.

    Mirrors ``PackageBodyIdentity``: the body itself names no granule, so the
    locator -- the package's folder, the granule's own file stem -- is the
    identity.
    """

    identity: GranuleIdentity
    format: str
    media_type: str
    final_url: str
    byte_size: int


def _checked_bytes(payload: object, max_bytes: object, *, label: str) -> bytes:
    """This family's spelling of the shared bounded-evidence rule.

    No GovInfo route here can mean an empty response: a package that is not
    there redirects or answers 404, so zero bytes is a refusal, not absence.
    """
    return check_payload(
        payload, max_bytes, label=f"GovInfo {label}", error_type=GovInfoBodySourceError, allow_empty=False
    )


def _checked_date(value: str, collection: str) -> str:
    try:
        parsed = date.fromisoformat(value)
    except ValueError as error:
        raise GovInfoBodySourceError(f"{collection} package id date is not a calendar date") from error
    if parsed.isoformat() != value:
        raise GovInfoBodySourceError(f"{collection} package id date is not canonical")
    return value


def _collection_of(package_id: str) -> str | None:
    """The registered collection whose prefix this id carries, longest prefix first.

    A collection name is not always one path segment: the Senate Secretary's
    reprints are addressed ``GPO-CDOC-119sdoc3``, so the prefix that has to
    match is the whole family name. Longest-first is what keeps that safe --
    matching ``GPO`` alone would readmit ``GPO-J6-REPORT``, a different family
    at a different address, which is exactly what this function's caller
    exists to refuse. ``O(K * I)`` over the nine registered collections.

    **The match does not backtrack**: the longest registered prefix wins and
    its grammar is the only one tried, so registering a *shorter* prefix later
    -- a bare ``GPO`` collection, say -- would not merely add a collection, it
    would reroute nothing already covered but would start claiming ids this
    function currently refuses. Adding a prefix that is a prefix of another is
    therefore a routing change and belongs in a decision record, not in the
    table alone.
    """
    matched = [name for name in _GRAMMARS if package_id.startswith(f"{name}-")]
    return max(matched, key=len) if matched else None


def parse_package_id(package_id: object) -> PackageIdentity:
    """Parse one package id under its collection's grammar, or refuse it by name.

    The grammar is strict on purpose, and the refusal names what was expected.
    A ``published`` walk scoped to one collection also returns ids belonging to
    neighboring collections -- ``ERP-2009`` states ``collectionCode`` ``ERP``
    and ``GPO-J6-REPORT`` states ``GPO`` (79 of 1,681 CDOC-scoped and 3 of
    3,000 CRPT-scoped ids sampled on 2026-09-19). Those are other collections
    with other addresses, so they are refused here rather than guessed at.
    ``GPO-CDOC-*`` is now covered and ``GPO-J6-REPORT`` still is not, because
    the registered prefix is the whole two-segment family name.
    """
    if not isinstance(package_id, str) or not package_id:
        raise GovInfoBodySourceError("package id must be a nonempty string")
    if len(package_id) > MAX_PACKAGE_ID:
        raise GovInfoBodySourceError(f"package id exceeds {MAX_PACKAGE_ID} characters")
    collection = _collection_of(package_id)
    if collection is None:
        supported = ", ".join(sorted(_GRAMMARS))
        raise GovInfoBodySourceError(f"package id collection is unsupported; expected one of {supported}")
    grammar = _GRAMMARS[collection]
    stem = package_id[len(collection) + 1 :]
    match = grammar.pattern.fullmatch(stem) or (grammar.volumes.fullmatch(stem) if grammar.volumes else None)
    if match is None:
        raise GovInfoBodySourceError(
            f"{collection} package id does not match its grammar; expected {collection}-{grammar.example}"
        )
    parts = match.groupdict()
    issue_date = parts.get("date")
    return PackageIdentity(
        package_id=package_id,
        collection=collection,
        congress=int(parts["congress"]) if parts.get("congress") else None,
        document_type=parts.get("type"),
        number=parts.get("number"),
        issue_date=_checked_date(issue_date, collection) if issue_date else None,
        issue_suffix=parts.get("suffix"),
        version=parts.get("version"),
        fiscal_year=parts.get("fiscal_year"),
        volume=parts.get("volume"),
    )


def stated_collection_code(collection: str) -> str:
    """The ``collectionCode`` the publisher's records state for one collection.

    Seven of the nine are their own id prefix; ``BUDGET`` and ``GPO-CDOC``
    both state ``GPO``. Exposed so a caller comparing a record against a
    collection asks this module rather than re-deriving the rule.
    """
    grammar = _GRAMMARS.get(collection)
    if grammar is None:
        supported = ", ".join(sorted(_GRAMMARS))
        raise GovInfoBodySourceError(f"package id collection is unsupported; expected one of {supported}")
    return grammar.collection_code


def _identity(value: PackageIdentity | str) -> PackageIdentity:
    return value if isinstance(value, PackageIdentity) else parse_package_id(value)


# GovInfo publishes no per-collection granule-id grammar the way it does for
# package ids; a granule id is an opaque publisher-assigned path segment
# (measured: CREC-2026-09-18-pt1-PgS4837-4), so only its shape as a safe
# single path segment is checked, at the same bound as a package id.
_GRANULE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")


def _checked_granule_id(value: object) -> str:
    if not isinstance(value, str) or _GRANULE_ID.fullmatch(value) is None:
        raise GovInfoBodySourceError(f"granule id must be a nonempty string of at most {MAX_PACKAGE_ID} characters")
    return value


def parse_granule_identity(package: PackageIdentity | str, granule_id: object) -> GranuleIdentity:
    """Parse one granule id against its package identity in ``O(I)`` time."""
    return GranuleIdentity(_identity(package), _checked_granule_id(granule_id))


def _format(name: object) -> BodyFormat:
    if not isinstance(name, str) or name not in PACKAGE_BODY_FORMATS:
        offered = ", ".join(PACKAGE_BODY_FORMATS)
        raise GovInfoBodySourceError(f"body format must be one of {offered}")
    return PACKAGE_BODY_FORMATS[name]


def _part_number(identity: PackageIdentity, value: object) -> int | None:
    """``N`` when ``value`` is this package's id plus its grammar's part suffix ``-pt{N}``, else ``None``."""
    part = _GRAMMARS[identity.collection].part
    if part is None or not isinstance(value, str) or not value.startswith(identity.package_id):
        return None
    match = part.fullmatch(value, len(identity.package_id))
    return None if match is None else int(match["number"])


def package_body_locator(package: PackageIdentity | str, format: str, *, part_id: str | None = None) -> str:
    """Return the keyless rendition locator in ``O(I)`` time.

    ``part_id`` is the part whose rendition this is (``ReportPart.part_id``):
    a granule's address, at the part's own stem. Only this package's own
    parts are accepted -- its id plus its grammar's ``part`` suffix, or the
    package id itself, the part whose stem is the package's.
    """
    identity = _identity(package)
    body_format = _format(format)
    if part_id is not None:
        if part_id != identity.package_id and _part_number(identity, part_id) is None:
            raise GovInfoBodySourceError(f"{part_id!r} is not a part of {identity.package_id}")
        return granule_body_locator(identity, part_id, format)
    package_id = identity.package_id
    return f"{CONTENT}/content/pkg/{package_id}/{body_format.folder}/{package_id}.{body_format.extension}"


def package_summary_locator(package: PackageIdentity | str) -> str:
    """Return the keyed summary locator; the credential travels as a header."""
    return f"{API}/packages/{_identity(package).package_id}/summary"


def package_mods_locator(package: PackageIdentity | str) -> str:
    """Return the keyed package MODS locator; the credential travels as a header."""
    return f"{API}/packages/{_identity(package).package_id}/mods"


def granule_summary_locator(package: PackageIdentity | str, granule_id: str) -> str:
    """Return the keyed granule summary locator; the credential travels as a header."""
    identity = parse_granule_identity(package, granule_id)
    return f"{API}/packages/{identity.package.package_id}/granules/{identity.granule_id}/summary"


def granule_mods_locator(package: PackageIdentity | str, granule_id: str) -> str:
    """Return the keyed granule MODS locator; the credential travels as a header."""
    identity = parse_granule_identity(package, granule_id)
    return f"{API}/packages/{identity.package.package_id}/granules/{identity.granule_id}/mods"


def granule_body_locator(package: PackageIdentity | str, granule_id: str, format: str) -> str:
    """Return the keyless granule rendition locator in ``O(I)`` time.

    The folder comes from ``PACKAGE_BODY_FORMATS`` exactly as it does for a
    package rendition; only the file stem differs -- the granule id, not the
    package id (measured 2026-09-19: ``content/pkg/CREC-2026-09-18/html/
    CREC-2026-09-18-pt1-PgS4837-4.htm``).
    """
    identity = parse_granule_identity(package, granule_id)
    body_format = _format(format)
    package_id = identity.package.package_id
    return f"{CONTENT}/content/pkg/{package_id}/{body_format.folder}/{identity.granule_id}.{body_format.extension}"


def validate_package_summary(
    body: bytes,
    *,
    package: PackageIdentity | str,
    final_url: str,
    max_bytes: int,
) -> PackageSummary:
    """Prove the summary states the requested ``packageId`` and keep its download links.

    The links are kept as the publisher spelled them and nothing is derived
    from them: they address the API's own content routes, three collections
    list no body rendition at all while serving HTML and PDF, and BILLS spells
    its HTML rendition ``txtLink``. The offered set comes from the MODS.
    """
    identity = _identity(package)
    exact = _checked_bytes(body, max_bytes, label="package summary")
    check_final_url(
        final_url,
        package_summary_locator(identity),
        error_type=GovInfoBodySourceError,
        message="GovInfo summary final URL differs from the requested locator",
    )
    document = load_decimal_json(exact, source="GovInfo package summary", error_type=GovInfoBodySourceError)
    if not isinstance(document, dict):
        raise GovInfoBodySourceError("GovInfo package summary is not a JSON object")
    if document.get("packageId") != identity.package_id:
        raise GovInfoBodySourceError("GovInfo summary packageId differs from the requested package")
    collection_code = document.get("collectionCode")
    if not isinstance(collection_code, str) or collection_code != stated_collection_code(identity.collection):
        raise GovInfoBodySourceError("GovInfo summary collectionCode differs from the requested collection")
    return PackageSummary(
        identity=identity,
        collection_code=collection_code,
        date_issued=_text(document.get("dateIssued")),
        last_modified=_text(document.get("lastModified")),
        title=_text(document.get("title")),
        download_links=_download_links(document.get("download"), label="summary"),
        session=_text(document.get("session")),
        pages=_text(document.get("pages")),
    )


def validate_granule_summary(
    body: bytes,
    *,
    package: PackageIdentity | str,
    granule_id: str,
    final_url: str,
    max_bytes: int,
) -> GranuleSummary:
    """Prove the granule summary states the requested ``packageId`` and ``granuleId``.

    Both must agree, not just the one the request URL was built from: unlike a
    missing package, a granule that does not belong to the requested package
    answers HTTP 400 with no ``packageId``/``granuleId`` at all (measured
    2026-09-19), which this reads as an ordinary field mismatch rather than a
    distinct status-code rule.
    """
    identity = parse_granule_identity(package, granule_id)
    exact = _checked_bytes(body, max_bytes, label="granule summary")
    check_final_url(
        final_url,
        granule_summary_locator(identity.package, identity.granule_id),
        error_type=GovInfoBodySourceError,
        message="GovInfo granule summary final URL differs from the requested locator",
    )
    document = load_decimal_json(exact, source="GovInfo granule summary", error_type=GovInfoBodySourceError)
    if not isinstance(document, dict):
        raise GovInfoBodySourceError("GovInfo granule summary is not a JSON object")
    if document.get("packageId") != identity.package.package_id:
        raise GovInfoBodySourceError("GovInfo granule summary packageId differs from the requested package")
    if document.get("granuleId") != identity.granule_id:
        raise GovInfoBodySourceError("GovInfo granule summary granuleId differs from the requested granule")
    collection_code = document.get("collectionCode")
    if not isinstance(collection_code, str) or collection_code != stated_collection_code(identity.package.collection):
        raise GovInfoBodySourceError("GovInfo granule summary collectionCode differs from the requested collection")
    return GranuleSummary(
        identity=identity,
        collection_code=collection_code,
        date_issued=_text(document.get("dateIssued")),
        title=_text(document.get("title")),
        download_links=_download_links(document.get("download"), label="summary"),
    )


def _text(value: object) -> str | None:
    return value if isinstance(value, str) else None


def _download_links(download: object, *, label: str) -> tuple[tuple[str, str], ...]:
    """Keep every ``download`` link as the publisher spelled it; derive nothing from it.

    Shared by the package and granule summary readers: neither summary's
    links state the offered rendition set (three package collections list no
    body link at all while serving HTML and PDF, and BILLS spells its HTML
    rendition ``txtLink``), so both keep the links as evidence only.
    """
    if download is not None and not isinstance(download, dict):
        raise GovInfoBodySourceError(f"GovInfo {label} download block is not a JSON object")
    links: list[tuple[str, str]] = []
    for name, value in sorted((download or {}).items()):
        # A link can repeat under one name: GPO-J6-REPORT states five jpegLink
        # entries as a list. Each stays under its own name; anything that is
        # not a URL string is an anomaly this block cannot state.
        for url in value if isinstance(value, list) else [value]:
            if not isinstance(url, str):
                raise GovInfoBodySourceError(f"GovInfo {label} download link is not a URL string")
            links.append((name, url))
    return tuple(links)


def _package_rendition_format(url: str, identity: PackageIdentity) -> str | None:
    """Name the format of a rendition of this package that sits somewhere else.

    The file extension names the format, because the folder is exactly what
    disagrees. ``None`` means the URL is not this package's content address in
    a supported file type, so it says nothing about where a format lives.
    """
    match = _PACKAGE_RENDITION.fullmatch(url)
    if match is None or match["package"] != identity.package_id:
        return None
    return _FORMAT_BY_EXTENSION.get(match["extension"])


def validate_package_mods(
    body: bytes,
    *,
    package: PackageIdentity | str,
    final_url: str,
    max_bytes: int,
    max_elements: int = RETAINED_MODS_MAX_ELEMENTS,
) -> PackageModsIdentity:
    """Prove every package-level ``accessId`` and read the renditions it states.

    Only the root's own ``extension`` children are read; a constituent's
    accessId names a granule, not this package. A rendition counts as offered
    when its stated URL is exactly this module's locator for a supported
    format, so the publisher's statement and the derived address must agree.

    The renditions that do not match are separated, because they mean
    different things. One at another address for this package in a supported
    file type is a disagreement about where a format lives, and the caller
    can see the address the publisher gave. Anything else (another package,
    another file type, another host) is recorded verbatim and means nothing
    about this fetch.

    One accessId other than the package's own is admitted: the part 1 a
    one-part report states in place of its stem (``_stated_part``). The
    renditions are then proved at that part's stem, and ``part_id`` says so.
    ``parts`` lists every part the record states (``_report_parts``).
    """
    identity = _identity(package)
    exact = _checked_bytes(body, max_bytes, label="package MODS")
    check_final_url(
        final_url,
        package_mods_locator(identity),
        error_type=GovInfoBodySourceError,
        message="GovInfo MODS final URL differs from the requested locator",
    )
    try:
        parsed = parse_govinfo_mods(exact, max_bytes=max_bytes, max_elements=max_elements)
    except GovInfoModsError as error:
        raise GovInfoBodySourceError(f"GovInfo package MODS is unreadable: {error}") from error
    root = parsed.package
    access_ids = root.access_ids
    if not access_ids:
        raise GovInfoBodySourceError("GovInfo package MODS states no accessId")
    part_id = _stated_part(parsed, identity)
    if identity.package_id not in access_ids or any(
        value not in (identity.package_id, part_id) for value in access_ids
    ):
        raise GovInfoBodySourceError("GovInfo MODS accessId differs from the requested package")
    codes = {element.text.strip() for element in root.fields("extension", "collectionCode")}
    if codes and codes != {stated_collection_code(identity.collection)}:
        raise GovInfoBodySourceError("GovInfo MODS collectionCode differs from the requested collection")
    locators = {package_body_locator(identity, name, part_id=part_id): name for name in PACKAGE_BODY_FORMATS}
    offered, moved, other = _read_offered_renditions(root, locators, identity)
    bills = _mods_bills(root)
    # Root only: all 185 retained CHRG MODS state heldDate there and no constituent states one (2026-10-03).
    held_dates = _stated_texts((root,), "heldDate")
    records = _stated_records(parsed)
    root_part = ReportPart(
        identity, part_id or identity.package_id, _part_number(identity, part_id), offered, moved, other, bills
    )
    return PackageModsIdentity(
        identity=identity,
        access_ids=access_ids,
        collection_code=next(iter(codes), None),
        offered_formats=offered,
        moved_renditions=moved,
        other_renditions=other,
        bills=bills,
        committees=_mods_committees(root),
        laws=_mods_laws(root),
        usc_sections=_mods_usc_sections(root),
        cfr_parts=_mods_cfr_parts(root),
        statutes=_mods_statutes(root),
        rins=_mods_rins(root),
        reports=_mods_reports(root),
        members=_mods_members(root),
        session=next((element.text.strip() for element in root.fields("extension", "session")), None),
        fiscal_year=_mods_fiscal_year(root),
        held_date=_one_held_date(held_dates),
        held_dates=held_dates,
        event_ids=_stated_texts(records, "eventId"),
        witnesses=_stated_texts(records, "witness"),
        subcommittees=_stated_texts(records, "congCommittee", "subCommittee", "name", name_type="parsed"),
        committee_codes=_stated_texts(records, "congCommittee", attribute="authorityId"),
        part_id=part_id,
        parts=_report_parts(parsed, identity, root_part),
    )


def _stated_part(parsed: GovInfoModsPackage, identity: PackageIdentity) -> str | None:
    """The part 1 a one-part report's root states beside the package's own accessId, or ``None``.

    GovInfo writes a package that holds one granule by flattening the
    granule's record into the package root: a second root ``extension``
    stating the granule's ``granuleClass`` and ``accessId``, and a root
    ``location`` stating the granule's renditions. For a single-part report
    the granule id is the package id, so the two agree (CRPT-119hrpt1). When
    the one granule is part 1 of a multi-part report it is
    ``{package id}-pt1`` and the root's renditions sit at the part's stem,
    while the package stem redirects to the error page (CRPT-119hrpt811; the
    2011 report CRPT-112hrpt38 still states only its part 1). A package
    holding two or more parts states each as a ``relatedItem
    type="constituent"`` and no rendition at its root, so nothing here reads
    it.

    So an accessId counts as the part only when it is this package's part 1
    (its grammar's ``part``, numbered 1) and its own extension states
    ``granuleClass`` ``FIRSTPART``; anything else is left for the caller's
    accessId check to refuse, a later part included. The flattened shape means
    the package holds that one granule and nothing else, so a record that also
    states any constituent -- a Part 2 published beside it, the way
    CRPT-119hrpt494 states its ``-pt2`` -- is refused here rather than read as
    the whole package.
    """
    stated = [
        value
        for extension in map(ModsRecord, parsed.package.fields("extension"))
        if any(element.text.strip() == "FIRSTPART" for element in extension.fields("granuleClass"))
        for element in extension.fields("accessId")
        if _part_number(identity, value := element.text.strip()) == 1
    ]
    if not stated:
        return None
    if parsed.constituents:
        raise GovInfoBodySourceError("GovInfo package MODS states a part at its root and constituents beside it")
    return stated[0]


#: The ``granuleClass`` a part of each number states: measured 2026-09-23 on
#: every multi-part record retained (CRPT-119hrpt455, -119hrpt494,
#: -119hrpt620, -108hrpt24, and the eight flattened ``-pt1`` roots).
_FIRST_PART_CLASS = "FIRSTPART"
_LATER_PART_CLASS = "OTHERPART"


def _report_parts(parsed: GovInfoModsPackage, identity: PackageIdentity, root: ReportPart) -> tuple[ReportPart, ...]:
    """Every part a report package's record states, in document order, or a refusal naming the disagreement.

    A record that lists no constituent is one part, its root: a report
    published in one part (``CRPT-119hrpt1``) or the flattened Part 1 of one
    (``CRPT-119hrpt811``). A record that lists constituents is those parts,
    each read by ``_constituent_part``: two suffixed parts with nothing at the
    root (``CRPT-119hrpt455``), or an unsuffixed Part 1 beside a ``-pt2``
    (``CRPT-119hrpt494``), whose root repeats Part 1's renditions.

    Nothing about a part is inferred: each states its own id, number and
    renditions, one id or one number stated twice is refused, so is a set of
    numbers other than exactly 1 to N (a lone ``-pt2``, or parts 1 and 3,
    would publish a report missing a part), and so is a rendition at the root
    that no part states, which would be a body the package offers that belongs
    to none of its parts. ``O(C * R)`` over the constituents and their
    renditions.
    """
    if _GRAMMARS[identity.collection].part is None:
        return ()
    if not parsed.constituents:
        return (root,)
    parts = tuple(_constituent_part(record, identity) for record in parsed.constituents)
    for field in ("part_id", "part_number"):
        values = [getattr(part, field) for part in parts]
        if len(set(values)) != len(values):
            raise GovInfoBodySourceError(f"GovInfo package MODS states one {field} for two parts")
    numbers = {part.part_number for part in parts}
    missing = sorted(set(range(1, max(numbers) + 1)) - numbers)
    if missing:
        raise GovInfoBodySourceError(
            f"GovInfo package MODS numbers its parts {', '.join(map(str, sorted(numbers)))}, "
            f"missing {', '.join(map(str, missing))}"
        )
    stated = {part.body_locator(name) for part in parts for name in part.offered_formats}
    at_root = {root.body_locator(name) for name in root.offered_formats} | {url for _, url in root.moved_renditions}
    if not at_root <= stated:
        raise GovInfoBodySourceError("GovInfo package MODS states a rendition at its root that no part states")
    return parts


def _constituent_part(record: ModsRecord, identity: PackageIdentity) -> ReportPart:
    """One ``relatedItem type="constituent"`` read as a part of this package, or refused.

    The same identity rules the flattened ``-pt1`` path applies, stated for
    any part: the constituent's own extension names exactly one ``accessId``,
    and it is this package's id plus its grammar's ``-pt{N}``, or the package
    id itself, which only Part 1 was measured using (CRPT-119hrpt494). The
    ``partNumber`` must equal that number where stated, and must be stated on
    the unsuffixed part, whose id carries none. ``granuleClass`` is
    ``FIRSTPART`` for part 1 and ``OTHERPART`` for every later part.
    Renditions are read from the constituent's own ``location`` and proved at
    the part's stem, the same offered/moved/other split the root uses.
    """
    extensions = tuple(map(ModsRecord, record.fields("extension")))
    stated_ids = [element.text.strip() for extension in extensions for element in extension.fields("accessId")]
    if len(stated_ids) != 1:
        raise GovInfoBodySourceError("GovInfo MODS constituent does not state exactly one accessId")
    part_id = stated_ids[0]
    unsuffixed = part_id == identity.package_id
    number = 1 if unsuffixed else _part_number(identity, part_id)
    if number is None:
        raise GovInfoBodySourceError("GovInfo MODS constituent is not a part of the requested package")
    stated = [element.text.strip() for extension in extensions for element in extension.fields("partNumber")]
    if stated != [str(number)] and (stated or unsuffixed):
        raise GovInfoBodySourceError(f"GovInfo MODS constituent {part_id} states a partNumber other than its own")
    classes = {element.text.strip() for extension in extensions for element in extension.fields("granuleClass")}
    if classes != {_FIRST_PART_CLASS if number == 1 else _LATER_PART_CLASS}:
        raise GovInfoBodySourceError(f"GovInfo MODS constituent {part_id} states a granuleClass for another part")
    locators = {granule_body_locator(identity, part_id, name): name for name in PACKAGE_BODY_FORMATS}
    offered, moved, other = _read_offered_renditions(record, locators, identity)
    return ReportPart(identity, part_id, number, offered, moved, other, _mods_bills(record))


def validate_granule_mods(
    body: bytes,
    *,
    package: PackageIdentity | str,
    granule_id: str,
    final_url: str,
    max_bytes: int,
    max_elements: int = RETAINED_MODS_MAX_ELEMENTS,
) -> GranuleModsIdentity:
    """Prove the granule's own accessId and its host package's, then read its offered renditions.

    A granule MODS states its own identity the same way a package MODS states
    its own -- directly under the root, in the root's own ``extension``
    children -- and states its host package's identity nested inside a
    ``relatedItem type="host"``. Both are read and checked before any
    rendition is trusted, so membership rests on the publisher's own record,
    not on the package id the caller happened to request under.

    Renditions are read from the root's own ``location`` only (never the
    nested host's), the same rule and the same three-way split
    (offered/moved/other) ``validate_package_mods`` applies.
    """
    identity = parse_granule_identity(package, granule_id)
    exact = _checked_bytes(body, max_bytes, label="granule MODS")
    check_final_url(
        final_url,
        granule_mods_locator(identity.package, identity.granule_id),
        error_type=GovInfoBodySourceError,
        message="GovInfo granule MODS final URL differs from the requested locator",
    )
    try:
        parsed = parse_govinfo_mods(exact, max_bytes=max_bytes, max_elements=max_elements)
    except GovInfoModsError as error:
        raise GovInfoBodySourceError(f"GovInfo granule MODS is unreadable: {error}") from error
    root = parsed.package
    access_ids = root.access_ids
    if not access_ids:
        raise GovInfoBodySourceError("GovInfo granule MODS states no accessId")
    if any(value != identity.granule_id for value in access_ids):
        raise GovInfoBodySourceError("GovInfo granule MODS accessId differs from the requested granule")
    codes = {element.text.strip() for element in root.fields("extension", "collectionCode")}
    if codes and codes != {stated_collection_code(identity.package.collection)}:
        raise GovInfoBodySourceError("GovInfo granule MODS collectionCode differs from the requested collection")
    host_ids = root.host_access_ids
    if not host_ids:
        raise GovInfoBodySourceError("GovInfo granule MODS states no host package")
    if any(value != identity.package.package_id for value in host_ids):
        raise GovInfoBodySourceError("GovInfo granule MODS host package differs from the requested package")
    locators = {
        granule_body_locator(identity.package, identity.granule_id, name): name for name in PACKAGE_BODY_FORMATS
    }
    offered, moved, other = _read_offered_renditions(root, locators, identity.package)
    return GranuleModsIdentity(
        identity=identity,
        access_ids=access_ids,
        collection_code=next(iter(codes), None),
        host_package_ids=host_ids,
        offered_formats=offered,
        moved_renditions=moved,
        other_renditions=other,
    )


def _read_offered_renditions(
    root: ModsRecord, locators: dict[str, str], identity: PackageIdentity
) -> tuple[tuple[str, ...], tuple[tuple[str, str], ...], tuple[tuple[str, str], ...]]:
    """Classify every raw-object rendition URL a MODS root's own ``location`` states.

    Shared by the package and granule MODS readers: both name their offered
    set from a root-level ``location`` (never a nested one -- a granule's own
    location sits directly under its root, its host package's sits nested
    inside ``relatedItem type="host"`` and is never read here), so the same
    three-way offered/moved/other split applies to either identity.
    """
    offered: list[str] = []
    moved: list[tuple[str, str]] = []
    other: list[tuple[str, str]] = []
    for location in root.fields("location"):
        for element in location.findall(_MODS_URL):
            if element.attribute("access") != _RAW_OBJECT:
                continue
            url = element.text.strip()
            name = locators.get(url)
            if name is not None:
                if name not in offered:
                    offered.append(name)
                continue
            elsewhere = _package_rendition_format(url, identity)
            if elsewhere is None:
                other.append((element.attribute("displayLabel") or "", url))
            else:
                moved.append((elsewhere, url))
    return tuple(offered), tuple(moved), tuple(other)


def _validate_body(
    body: bytes,
    *,
    format: str,
    content_type: str | None,
    final_url: str,
    expected_url: str,
    max_bytes: int,
    label: str,
) -> tuple[bytes, BodyFormat, str]:
    """The identity and shape checks every rendition needs, package or granule alike.

    The body itself names neither a package nor a granule, so the locator is
    the identity: the client refuses redirects, so a response at this URL is
    the requested object or it is the error page, which is refused first, so
    a response that landed on it says so rather than reporting a URL mismatch
    the caller cannot interpret.
    """
    body_format = _format(format)
    exact = _checked_bytes(body, max_bytes, label=label)
    check_not_error_page(
        exact,
        final_url,
        error_type=GovInfoBodySourceError,
        message=f"govinfo returned its HTTP-200 error page, not the requested {label}",
    )
    check_final_url(
        final_url,
        expected_url,
        error_type=GovInfoBodySourceError,
        message=f"GovInfo {label} final URL differs from the requested locator",
    )
    media_type = (content_type or "").split(";", 1)[0].strip().casefold()
    if media_type not in body_format.media_types:
        raise GovInfoBodySourceError(f"GovInfo {label} Content-Type is not {body_format.name} for the requested format")
    if body_format.name == "pdf" and not exact.startswith(b"%PDF-"):
        raise GovInfoBodySourceError(f"GovInfo {label} does not begin with %PDF-")
    return exact, body_format, media_type


def validate_package_body(
    body: bytes,
    *,
    package: PackageIdentity | str,
    format: str,
    content_type: str | None,
    final_url: str,
    max_bytes: int,
    part_id: str | None = None,
) -> PackageBodyIdentity:
    """Prove a bounded body against its locator, media type and native magic.

    ``part_id`` is the part the bytes are (``ReportPart.part_id``), whose stem
    is then the locator; the package id itself names the package's own stem.
    """
    identity = _identity(package)
    exact, body_format, media_type = _validate_body(
        body,
        format=format,
        content_type=content_type,
        final_url=final_url,
        expected_url=package_body_locator(identity, format, part_id=part_id),
        max_bytes=max_bytes,
        label="package body",
    )
    return PackageBodyIdentity(
        identity=identity,
        format=body_format.name,
        media_type=media_type,
        final_url=final_url,
        byte_size=len(exact),
        part_id=part_id,
    )


def validate_granule_body(
    body: bytes,
    *,
    package: PackageIdentity | str,
    granule_id: str,
    format: str,
    content_type: str | None,
    final_url: str,
    max_bytes: int,
) -> GranuleBodyIdentity:
    """Prove a bounded granule body against its locator, media type and native magic.

    Mirrors ``validate_package_body``: it differs only in which locator --
    the package's folder, the granule's own file stem -- and in the label its
    refusals carry.
    """
    identity = parse_granule_identity(package, granule_id)
    exact, body_format, media_type = _validate_body(
        body,
        format=format,
        content_type=content_type,
        final_url=final_url,
        expected_url=granule_body_locator(identity.package, identity.granule_id, format),
        max_bytes=max_bytes,
        label="granule body",
    )
    return GranuleBodyIdentity(
        identity=identity,
        format=body_format.name,
        media_type=media_type,
        final_url=final_url,
        byte_size=len(exact),
    )


#: The publisher's own statement, inside a text rendition, that the prose is
#: only in the PDF: it stands in for the text of the ``htm`` bodies of
#: CRPT-119srpt35 (below its cover page) and CHRG-119hhrg64529 (2026-09-25
#: report audit). ``[GRAPHIC(S) NOT AVAILABLE IN TIFF FORMAT]`` is not it:
#: that marks a missing image, not missing prose.
PUBLISHER_PLACEHOLDER = "[TEXT NOT AVAILABLE IN REFER TO PDF]"
#: Every spelling of that notice the publisher is measured to print. The
#: 2026-09-25 qualification audit found the second, without "IN", as the whole
#: text of CRPT-119hrpt649 and CHRG-119jhrg60491. Literals, not a pattern: a
#: looser match could flag real prose that happens to mention a PDF.
PUBLISHER_PLACEHOLDERS = (PUBLISHER_PLACEHOLDER, "[TEXT NOT AVAILABLE REFER TO PDF]")


def publisher_body_status(text: str, *, rendition: str) -> str:
    """What one body's derived text states about its own completeness, in ``O(T)``.

    ``publisher_placeholder`` where the text carries one of ``PUBLISHER_PLACEHOLDERS``,
    else ``pdf_extracted`` for a PDF rendition and ``not_flagged`` for any
    other. Only the publisher's marker flags a body; no status asserts that
    unmarked text is complete.
    """
    if any(marker in text for marker in PUBLISHER_PLACEHOLDERS):
        return "publisher_placeholder"
    return "pdf_extracted" if rendition == "pdf" else "not_flagged"


__all__ = [
    "BODY_PREFERENCE",
    "GRANULE_BODY_PREFERENCE",
    "MEASURED_BUDGET_PARTS",
    "PACKAGE_BODY_FORMATS",
    "PRINT_BODY_PREFERENCE",
    "PUBLISHER_PLACEHOLDER",
    "PUBLISHER_PLACEHOLDERS",
    "BodyFormat",
    "GovInfoBodySourceError",
    "GranuleBodyIdentity",
    "GranuleIdentity",
    "GranuleModsIdentity",
    "GranuleSummary",
    "ModsBill",
    "ModsCfrPart",
    "ModsCommittee",
    "ModsLaw",
    "ModsMember",
    "ModsReport",
    "ModsStatute",
    "ModsUsCodeSection",
    "PackageBodyIdentity",
    "PackageGrammar",
    "PackageIdentity",
    "PackageModsIdentity",
    "PackageSummary",
    "ReportPart",
    "granule_body_locator",
    "granule_mods_locator",
    "granule_summary_locator",
    "package_body_locator",
    "package_mods_locator",
    "package_summary_locator",
    "parse_granule_identity",
    "parse_package_id",
    "publisher_body_status",
    "stated_collection_code",
    "validate_granule_body",
    "validate_granule_mods",
    "validate_granule_summary",
    "validate_package_body",
    "validate_package_mods",
    "validate_package_summary",
]
