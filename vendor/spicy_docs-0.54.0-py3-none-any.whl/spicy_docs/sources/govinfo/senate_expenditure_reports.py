"""Which GovInfo CDOC package is the Secretary of the Senate's semiannual expenditure report.

The report is reprinted inside the ``CDOC`` collection under a ``GPO-CDOC-`` id, and nothing but its title says what
it is, so the rule reads the row's own id and title, the way :func:`activity_reports.is_activity_report` reads a
CRPT row's. The collection walked and the id prefix differ on purpose: ``GPO-CDOC`` is its own entry in the package
grammar, so ``GPO-J6-REPORT``, which states the same ``collectionCode``, is still refused by name. Measured
2026-09-20 over the 291 rows a ``published`` CDOC walk served for 2024-01-01..2026-09-20: 5 matched, every one
titled in full "Report of the Secretary of the Senate: <period>". spicy-regs held this rule until 2026-10-03.
"""

from __future__ import annotations

import re

#: The collection a ``published`` walk is scoped to.
SENATE_EXPENDITURE_COLLECTION = "CDOC"
#: The id prefix a report's row must carry; a collection-scoped walk can serve neighbours.
SENATE_EXPENDITURE_PACKAGE_PREFIX = "GPO-CDOC-"
#: The report's own title.
SENATE_EXPENDITURE_REPORT_TITLE = re.compile(r"(?i)\breport of the secretary of the senate\b")


def is_senate_expenditure_report(package_id: object, title: object) -> bool:
    """Whether a ``published`` row is the report: a ``GPO-CDOC-`` id and the report's title.

    A non-string on either side is not a match rather than an error: a publisher row with a missing field is a row to
    skip, not a run to stop.
    """
    if not isinstance(package_id, str) or not isinstance(title, str):
        return False
    return (
        package_id.startswith(SENATE_EXPENDITURE_PACKAGE_PREFIX)
        and SENATE_EXPENDITURE_REPORT_TITLE.search(title) is not None
    )
