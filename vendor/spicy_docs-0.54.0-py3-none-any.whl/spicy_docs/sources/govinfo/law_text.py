"""Read native sections from retained, identity-validated public/private-law USLM.

This promotes the worked DocumentCapture USLM grammar and event tree. Rows own
text below their section, excluding its number/heading, print furniture and
nested sections. Print furniture is what the Statutes at Large page carries
beside the enacted words: page numbers, running heads and the margin notes
(``sidenote``: ``42 USC 405 note.``, the approval date, a topical catchword
such as ``Contracts.``), each excluded with a ``print_furniture_excluded``
issue. ``amendingAction`` is inline markup around words of a sentence, as the
USLM schema types it, and never breaks a line. Nested quoted sections remain
separately addressable source text; no amendment application or enrolled-bill
equivalence is inferred.
"""

from __future__ import annotations

import hashlib
from collections import Counter
from dataclasses import dataclass, replace

from spicy_docs.reading.markup import MarkupEvent, MarkupReadError, read_xml_events
from spicy_docs.reading.markup_structure import Elem, Grammar, element_tree
from spicy_docs.sources.govinfo.uslm import (
    DEFAULT_MAX_BYTES,
    USLM_NAMESPACE,
    PublicLawSelection,
    UslmMetadata,
    UslmSourceError,
    validate_public_law_xml,
)

#: ``v2`` (2026-10-03): ``sidenote`` is furniture and ``amendingAction`` is inline. ``v1`` kept every margin
#: note as body lines with no issue and put each amending-action word on its own line (measured on the 113
#: parsed laws of the 119th: 7,068 margin-note lines and 12,037 lone action-word lines, both to 0 under v2).
LAW_TEXT_READER_VERSION = "law-sections-uslm-v2"
_XHTML_NAMESPACE = "http://www.w3.org/1999/xhtml"
_XHTML_TABLE_BLOCKS = frozenset({"table", "thead", "tbody", "tfoot", "tr", "td", "th", "caption"})

USLM = Grammar(
    name="uslm-law",
    containers={
        "division": "division",
        "title": "division",
        "subtitle": "division",
        "chapter": "division",
        "subchapter": "division",
        "part": "division",
        "subpart": "division",
        "level": "division",
        "subdivision": "division",
        "appropriations": "division",
        "meta": "metadata",
        "preface": "frontMatter",
        "main": "body",
        "signatures": "backMatter",
        "section": "section",
        "subsection": "paragraph",
        "paragraph": "paragraph",
        "subparagraph": "paragraph",
        "clause": "paragraph",
        "subclause": "paragraph",
        "item": "paragraph",
        "quotedContent": "quote",
        "note": "note",
        "longTitle": "title",
        "toc": "uslm-law:toc",
        "legislativeHistory": "backMatter",
    },
    leaves={
        "heading": "heading",
        "num": "label",
        "content": "paragraph",
        "chapeau": "paragraph",
        "p": "paragraph",
        "continuation": "paragraph",
        "proviso": "paragraph",
        "docTitle": "title",
        "officialTitle": "title",
        "enactingFormula": "uslm-law:enactingFormula",
        "sourceCredit": "uslm-law:sourceCredit",
    },
    # A sidenote is "a note that is to be rendered in the side margins of a page" (uslm-2.0.17.xsd), and an
    # amendingAction "an atomic-level amendment instruction" in the schema's ``inline`` substitution group.
    furniture={"page": "pageNumber", "centerRunningHead": "runningHead", "sidenote": "marginNote"},
    inline=frozenset(
        {"ref", "inline", "quotedText", "date", "term", "b", "i", "span", "shortTitle", "def", "br", "amendingAction"}
    ),
)


@dataclass(frozen=True, slots=True)
class LawSection:
    """One native section occurrence; positional identity survives missing/repeated labels."""

    seq: int
    publisher_id: str | None
    publisher_identifier: str | None
    section_number: str | None
    section_number_value: str | None
    heading: str | None
    parent_seq: int | None
    hierarchy: tuple[dict[str, str | None], ...]
    native_path: str
    body: str
    is_quoted: bool
    issues: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class LawTextDocument:
    """Validated law identity and source-owned section text from the exact retained bytes."""

    metadata: UslmMetadata
    sections: tuple[LawSection, ...]
    source_sha256: str
    unsectioned_body: str
    issues: tuple[str, ...]
    reader_version: str = LAW_TEXT_READER_VERSION


def _name(elem: Elem) -> str:
    return elem.name.rpartition(":")[2] if elem.namespace_uri == USLM_NAMESPACE else elem.name


def _is(elem: Elem, name: str) -> bool:
    return elem.namespace_uri == USLM_NAMESPACE and _name(elem) == name


def _literal(elem: Elem) -> str:
    return "".join(part.text or "" if isinstance(part, MarkupEvent) else _literal(part) for part in elem.parts)


def _field(elem: Elem, name: str) -> tuple[str | None, str | None, int]:
    children = [part for part in elem.parts if isinstance(part, Elem) and _is(part, name)]
    if not children:
        return None, None, 0
    # Preserve repeated direct fields explicitly instead of silently choosing the first.
    values = [_literal(child).strip() for child in children]
    return "\n".join(values), children[0].attributes.get("value") if len(children) == 1 else None, len(children)


def _ancestor(elem: Elem) -> dict[str, str | None]:
    return {
        "element": _name(elem),
        "native_path": elem.native_path,
        "publisher_id": elem.attributes.get("id"),
        "publisher_identifier": elem.attributes.get("identifier"),
        "number": _field(elem, "num")[0],
        "heading": _field(elem, "heading")[0],
    }


#: USLM layout elements the grammar gives no reading role, which still separate lines: table rows and cells, and
#: the line break (``br`` is also inline, so it raises no unknown-element issue).
_LAYOUT_BLOCKS = frozenset({"table", "tr", "td", "th", "row", "entry", "br"})


def _breaks_lines(name: str) -> bool:
    """Whether a USLM element separates lines of body text.

    The grammar is the one declaration: every element with a reading role is a structural block except the
    inline ones, which stay inside their sentence. Furniture never reaches this question; ``_body`` excludes it
    first. Deriving block-ness from the role tables rather than from a second list is what keeps an inline element
    from becoming a line break by being registered somewhere else.
    """
    return name in _LAYOUT_BLOCKS or (USLM.role(name) is not None and name not in USLM.inline)


def _body(section: Elem) -> tuple[str, tuple[str, ...]]:
    pieces: list[str] = []
    issues: set[str] = set()

    def visit(elem: Elem) -> None:
        name = _name(elem)
        if elem is not section and _is(elem, "section"):
            pieces.append("\n")
            issues.add("nested_section_text_excluded")
            return
        if elem.namespace_uri == USLM_NAMESPACE and name in USLM.furniture:
            issues.add(f"print_furniture_excluded:{name}")
            return
        if elem.namespace_uri != USLM_NAMESPACE or (USLM.role(name) is None and name not in USLM.inline):
            issues.add(f"unknown_element:{elem.name}")
        if _is(elem, "quotedContent"):
            issues.add("contains_quoted_content")
        xhtml_table_block = (
            elem.namespace_uri == _XHTML_NAMESPACE and elem.name.rpartition(":")[2] in _XHTML_TABLE_BLOCKS
        )
        if xhtml_table_block:
            issues.add("table_structure_rendered_as_text")
        block = elem is not section and (
            (elem.namespace_uri == USLM_NAMESPACE and _breaks_lines(name)) or xhtml_table_block
        )
        if block:
            pieces.append("\n")
        for part in elem.parts:
            if isinstance(part, MarkupEvent):
                pieces.append(part.text or "")
            elif elem is section and _is(section, "section") and (_is(part, "num") or _is(part, "heading")):
                continue
            else:
                visit(part)
        if block:
            pieces.append("\n")

    visit(section)
    # Formatting indentation is not body content; never add spaces between inline fragments.
    text = "\n".join(line.strip() for line in "".join(pieces).split("\n") if line.strip())
    return text, tuple(sorted(issues))


def read_law_sections(
    body: bytes,
    *,
    selection: PublicLawSelection,
    final_url: str,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> LawTextDocument:
    """Read native main-body sections after proving the requested law's own identity.

    ``native_path`` is an absolute namespace-qualified XPath 1.0 selector into
    these bytes. ``body`` separates source blocks with newlines and preserves
    inline adjacency; it is not an exact-byte quote. Whitespace is the
    publisher's: a newline written inside a leaf (the Statutes at Large
    wraps a sentence at a page turn) stays a line break, and excluded
    furniture adds none. Child sections own their text once, and quoted
    ancestry is explicit. Missing/duplicate publisher labels remain
    observations. No sections in a nonempty law body refuses.
    """
    metadata = validate_public_law_xml(body, selection=selection, final_url=final_url, max_bytes=max_bytes)
    try:
        tree = element_tree(read_xml_events(body), body)
    except (MarkupReadError, RecursionError) as exc:
        raise UslmSourceError("law section markup cannot be represented") from exc
    root = next(part for part in tree.parts if isinstance(part, Elem))
    mains = [part for part in root.parts if isinstance(part, Elem) and _is(part, "main")]
    if len(mains) != 1:
        raise UslmSourceError("law sections require one native main element")
    sections: list[LawSection] = []

    def visit(elem: Elem, ancestry: tuple[Elem, ...], parent_seq: int | None, quoted: bool) -> None:
        quoted = quoted or _is(elem, "quotedContent")
        if _is(elem, "section"):
            number, value, number_count = _field(elem, "num")
            heading, _, heading_count = _field(elem, "heading")
            text, observations = _body(elem)
            issues = list(observations)
            for field, present in (
                ("id", elem.attributes.get("id")),
                ("identifier", elem.attributes.get("identifier")),
                ("number", number),
                ("heading", heading),
            ):
                if not present:
                    issues.append(f"missing_{field}")
            if number_count > 1:
                issues.append("multiple_number_elements")
            if heading_count > 1:
                issues.append("multiple_heading_elements")
            if not text:
                issues.append("empty_body")
            seq = len(sections)
            sections.append(
                LawSection(
                    seq,
                    elem.attributes.get("id"),
                    elem.attributes.get("identifier"),
                    number,
                    value,
                    heading,
                    parent_seq,
                    tuple(_ancestor(a) for a in ancestry),
                    elem.native_path,
                    text,
                    quoted,
                    tuple(sorted(issues)),
                )
            )
            parent_seq = seq
        if elem.namespace_uri == USLM_NAMESPACE and _name(elem) in USLM.containers and not _is(elem, "main"):
            ancestry = (*ancestry, elem)
        for part in elem.parts:
            if isinstance(part, Elem):
                visit(part, ancestry, parent_seq, quoted)

    try:
        visit(mains[0], (), None, False)
        remainder, remainder_issues = _body(mains[0])
    except RecursionError as exc:
        raise UslmSourceError("law section structure exceeds supported nesting") from exc
    if not sections:
        raise UslmSourceError("law body has no native section elements")
    duplicates = {
        field: Counter(getattr(section, field) for section in sections if getattr(section, field))
        for field in ("publisher_id", "publisher_identifier", "section_number")
    }
    for i, section in enumerate(sections):
        extra = [
            f"duplicate_{label}"
            for field, label in (
                ("publisher_id", "id"),
                ("publisher_identifier", "identifier"),
                ("section_number", "number"),
            )
            if duplicates[field][getattr(section, field)] > 1
        ]
        if extra:
            sections[i] = replace(section, issues=tuple(sorted((*section.issues, *extra))))
    return LawTextDocument(
        metadata,
        tuple(sections),
        "sha256:" + hashlib.sha256(body).hexdigest(),
        remainder,
        tuple(sorted({"native_sections_with_main_remainder", *remainder_issues})),
    )
