"""Tests for the R2 storage connector (sources/r2.py)."""

from pathlib import Path

import pytest

import spicy_regs.sources.r2 as r2


def test_download_delegates(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list = []
    monkeypatch.setattr(r2, "download_from_r2", lambda key, path: calls.append((key, path)) or True)

    assert r2.download("manifest.parquet", tmp_path / "manifest.parquet") is True
    assert calls == [("manifest.parquet", tmp_path / "manifest.parquet")]


def test_upload_dataset_uploads_existing_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """upload_dataset publishes the existing {type}.parquet files (+ manifest)."""
    (tmp_path / "dockets.parquet").write_bytes(b"d")
    (tmp_path / "documents.parquet").write_bytes(b"x")
    (tmp_path / "manifest.parquet").write_bytes(b"m")
    # comments.parquet intentionally absent — it's published as partitions.

    uploaded: list[Path] = []
    monkeypatch.setattr(r2, "upload_file", lambda p, remote_key=None: uploaded.append(p))

    r2.upload_dataset(tmp_path, ["dockets", "documents", "comments"])

    assert set(uploaded) == {
        tmp_path / "dockets.parquet",
        tmp_path / "documents.parquet",
        tmp_path / "manifest.parquet",
    }


def test_upload_comment_partitions_uploads_changed_and_index(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """upload_comment_partitions publishes each changed partition and the index."""
    changed = tmp_path / "comments" / "agency_code=EPA" / "part-0.parquet"
    changed.parent.mkdir(parents=True)
    changed.write_bytes(b"c")
    (tmp_path / "comments_index.parquet").write_bytes(b"i")

    uploaded: list[tuple[Path, str | None]] = []
    monkeypatch.setattr(r2, "upload_file", lambda p, remote_key=None: uploaded.append((p, remote_key)))

    r2.upload_comment_partitions(tmp_path, [changed])

    assert (changed, str(changed.relative_to(tmp_path))) in uploaded
    assert (tmp_path / "comments_index.parquet", "comments_index.parquet") in uploaded


def _upload_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Minimal R2 env so upload_file runs its body (isolate_env strips these)."""
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "k")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "s")
    monkeypatch.setenv("R2_BUCKET_NAME", "spicy-regs")
    monkeypatch.setenv("R2_PUBLIC_URL", "https://data.spicy-regs.dev")


def test_upload_file_purges_exact_object_url(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """After a successful upload, the edge cache is purged for that one URL."""
    _upload_env(monkeypatch)
    (tmp_path / "agency_stats.parquet").write_bytes(b"x" * 100)

    monkeypatch.setattr(r2, "get_r2_client", lambda: __import__("unittest.mock", fromlist=["MagicMock"]).MagicMock())
    monkeypatch.setattr(r2, "_get_remote_size", lambda *a, **k: None)
    purged: list[list[str]] = []
    monkeypatch.setattr(r2, "purge_urls", lambda urls: purged.append(urls))

    r2.upload_file(tmp_path / "agency_stats.parquet")

    assert purged == [["https://data.spicy-regs.dev/agency_stats.parquet"]]


def test_upload_file_survives_unreachable_edge(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """End-to-end: a dead Cloudflare edge must not fail a successful publish.

    Uses the real ``purge_urls`` (creds set) with ``httpx.post`` raising, so this
    exercises the actual composition rather than a mock — the property that
    matters is that the ETL never dies because the cache couldn't be purged.
    """
    _upload_env(monkeypatch)
    monkeypatch.setenv("CLOUDFLARE_API_TOKEN", "tok")
    monkeypatch.setenv("CLOUDFLARE_ZONE_ID", "zone")
    (tmp_path / "agency_stats.parquet").write_bytes(b"x" * 100)

    monkeypatch.setattr(r2, "get_r2_client", lambda: __import__("unittest.mock", fromlist=["MagicMock"]).MagicMock())
    monkeypatch.setattr(r2, "_get_remote_size", lambda *a, **k: None)

    import httpx

    def _raise(*a, **k):
        raise httpx.ConnectError("edge down")

    monkeypatch.setattr(httpx, "post", _raise)

    # Must complete normally despite the purge failing underneath.
    r2.upload_file(tmp_path / "agency_stats.parquet")
